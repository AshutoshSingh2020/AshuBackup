const puppeteer = require('puppeteer');

// (async () => {
//   const browser = await puppeteer.launch({
//     headless: false,
//     args: ['--remote-debugging-port=9222']
//   });

//   const res = await fetch('http://localhost:9222/json/version');
//   // const browserURL = 'http://localhost:9222'; // or the WebSocket debugger URL
//   // const browser = await puppeteer.connect({ browserURL });
//   const pages = await res.pages();
//   const page = pages[0]; // Assuming you want to interact with the first page

//   // Now you can use Puppeteer to control the page
//   await page.goto('https://moneyclick.ktkbank.com/BankAwayRetail/AuthenticationController?__START_TRAN_FLAG__=Y&FORMSGROUP_ID__=AuthenticationFG&__EVENT_ID__=LOAD&FG_BUTTONS__=LOAD&ACTION.LOAD=Y&AuthenticationFG.LOGIN_FLAG=1&BANK_ID=KBL&LANGUAGE_ID=001'); // Navigate to a different page if needed


//   // Perform other actions with Puppeteer
//   // ...

//   // Disconnect Puppeteer when done

// })();

(async () => {
  const browser = await puppeteer.launch({
    headless: false
  });

  const page = await browser.newPage();

  await page.goto('https://moneyclick.ktkbank.com/BankAwayRetail/AuthenticationController?__START_TRAN_FLAG__=Y&FORMSGROUP_ID__=AuthenticationFG&__EVENT_ID__=LOAD&FG_BUTTONS__=LOAD&ACTION.LOAD=Y&AuthenticationFG.LOGIN_FLAG=1&BANK_ID=KBL&LANGUAGE_ID=001');

  // Your automation goes here...

  // await browser.close(); // Uncomment when done
})();