const puppeteer = require("puppeteer");
const fs = require("fs");
const path = require("path");
const fetch = require("node-fetch");
const saveTransactionUrl = "https://91.playludo.app/api/CommonAPI/SavebankTransaction";
const CONFIG = require("./config");
const UpiIdStatusURL = "https://91.playludo.app/api/CommonAPI/GetUpiStatus?upiId=" + CONFIG.upiId;
const  UpiIdUpdateURL = "https://91.playludo.app/api/CommonAPI/UpdateDateBasedOnUpi?upiId=" + CONFIG.upiId;
const moment = require('moment');
const vision = require('@google-cloud/vision');
const FormData = require('form-data');
async function launchBrowser() {
  // const browserURL = 'http://localhost:9222';
  // log("browser connecting...");
  // return await puppeteer.connect({ browserURL });
  return await puppeteer.launch({
    headless: false,
    args: ["--disable-infobars","--no-sandbox","--disable-setuid-sandbox","--disable-web-security"],
  });
}

async function configurePage(browser) {
  let page = await browser.newPage();
  await page.setViewport({ width: 1366, height: 768 });
  return page;
}

async function login(page) {
  await page.goto(CONFIG.loginUrl, { timeout: "240000" });
  await delaySleep(1000);
  let url = await page.evaluate(() => document.URL);
  console.log(url);
  await delaySleep(1000);
  log("Typing user id");
  await typeIntoElement(page,"xpath",'//*[@id="AuthenticationFG.ENTERED_USER_ID"]',CONFIG.userId);
  await delaySleep(600);
  let cp0=0;
  while(cp0==0){
    log("Getting Captcha");
    const [imageElement] = await page.$x('//*[@id="IMAGECAPTCHA"]');
    let cText = "";
    if (imageElement) {
      await imageElement.screenshot({
        path: 'cimg.jpg'
      });
      await getCaptchatext('cimg.jpg').then(text => {
        log('Captcha is :'+ text);
        cText = text;
        // if (!/^\d{6}$/.test(cText)) {
        //   throw new Error('Detected text does not consist of exactly 6 digits.');
        // }
      }).catch(console.error);
      await delaySleep(500);
      await typeIntoElement(page,"xpath",'//*[@id="AuthenticationFG.VERIFICATION_CODE"]',cText);
      await delaySleep(600);
      log("Clicking continue button");
      await clickElementByXPath(page,'//*[@id="STU_VALIDATE_CREDENTIALS"]');
      await page.waitForNavigation({timeout: 60000});
      await delaySleep(600);
    } else {
      log('Captcha img not found.');
      cp0=1;
    }
  }
  log("Clicking check terms");
  await clickElementByXPath(page,'//*[@id="AuthenticationFG.TARGET_CHECKBOX_Label"]');
  await delaySleep(600);
  log("Clicking password input");
  await clickElementByXPath(page,'/html/body/form/div/div[2]/div/div/div/div/div[1]/div[2]/div/div/div/div/div[1]/div[2]/p/span[2]/input');
  await delaySleep(600);
  log("Typing password");
  await typeIntoElement(page,"xpath",'/html/body/form/div/div[2]/div/div/div/div/div[1]/div[2]/div/div/div/div/div[1]/div[2]/p/span[2]/input',CONFIG.password);
  await delaySleep(600);
  log("Clicking Login button");
  await clickElementByXPath(page,'//*[@id="VALIDATE_STU_CREDENTIALS_UX"]');
  await page.waitForNavigation({timeout: 60000});
  await delaySleep(600);
}

async function mousehovElement(page,xpath){
  let [parelement] = await page.$x(xpath);
  if (parelement)
    {
    let boundingBox = await parelement.boundingBox();
    if (boundingBox) {
      await page.mouse.move(boundingBox.x + boundingBox.width / 2,boundingBox.y + boundingBox.height / 2);
      await page.mouse.click(boundingBox.x + boundingBox.width / 2,boundingBox.y + boundingBox.height / 2);
    }
  }
}

async function setInputValueByXPath(page,xpath,value) {  
  const [element] = await page.$x(xpath);
  if (element) {
    await page.evaluate((el, val) => el.value = val, element, value);
  }
}

async function getTransactions(page){
  await delaySleep(5000);
  log("clicking Dashboard button");
  // await clickElementByXPath(page,'//*[@id="ID_DASHAT"]');
  // await delaySleep(5000);
  log("clicking Menu");
  await clickElementByXPath(page,'//*[@id="RetailUserDashboardUX3_W108__1:menu0"]');
  await delaySleep(5000);
  log("clicking actions btn")
  await clickElementByXPath(page,'//*[@id="RetailUserDashboardUX3_W108__1:VIEW_MINI_STATEMENT[0]6"]');
  await delaySleep(4000);
  log("Fetching latest statement...");
  await delaySleep(6000);
  let tblHTML=await getHTMLByXpath(page,'/html/body/div[15]/div[2]/div/div[3]/div[3]/div/div/div[1]/div/div/div/div/table');
  let jsonData = await convertHtmlToJson(page,tblHTML);
  log("Checking Avalable Balance...");
  let AvlBal = await getINRValueByXPath(page,'//*[@id="RetailUserDashboardUX3_W108__1:HREF_availableBalOutput"]');
  let newMatch = AvlBal.replace(/[₹,]/g,'');
  let balMatch = newMatch.match(/[\d.]+/);
  let avlBalDigits=balMatch ? balMatch[0] : null;
  log("Availale Balance fetched : "+avlBalDigits);
  let bnkName = "KBL - "+CONFIG.userId;
  let bnkLoginId = CONFIG.userId;
  jsonData = jsonData.map(item => {
    return { ...item, BankName: bnkName, BankLoginId:bnkLoginId, AccountBalance: avlBalDigits};
  });
  log(JSON.stringify(jsonData));
  await delaySleep(500);
  log("clicking close button");
  await delaySleep(500);
  await clickElementByXPath(page,'//*[@id="parentTop_DASHAT"]');
  await delaySleep(3000);
  return jsonData;
}

async function logoutFromBank(page){
  try{
    log("Clicking Logout Button");
    await clickElementByXPath(page," /html/body/form/div[2]/nav/div/div/div/div[2]/ul[1]/li[6]/a");
    await delaySleep(3000);
    await clickElementByXPath(page,"/html/body/form/div[1]/div[2]/div/p[3]/span/span[2]/a");
    log("Logged Out");
  }
  catch(e){
    log("logout error : "+e);  
  }
}

async function analyzeLocalImage(filePath) {
  // Load the image file into memory
  const fileContent = fs.readFileSync(filePath);
  const client = new vision.ImageAnnotatorClient({
    keyFilename: 'gkey.json'
  });
  // Send the image to Google Cloud Vision API for analysis
  const [result] = await client.textDetection({image: {content: fileContent}});
  const detections = result.textAnnotations;
  const text = detections.length ? detections[0].description.trim() : '';
  // Return the analysis results
  return text.replace(/ /g, '');
}
async function getCaptchatext(filePath){
  try {
    const form = new FormData();
    form.append('file', fs.createReadStream(filePath));

    const response = await fetch('https://91uat.playludo.app/api/captchareader', {
      method: 'POST',
      body: form,
      headers: form.getHeaders()
    });

    const result = await response.json();
    return result.ErrorMessage;
  } catch (err) {
    console.error(err);
    res.status(500).send('Error sending captcha');
  }
}

function delaySleep(time) {
  return new Promise(resolve => setTimeout(resolve, time));
}

async function getOTPFromAPI() {
  // const OTPtimeStamp = moment().add(5, 'hours').add(30, 'minutes');
  const OTPtimeStamp = moment();
  let retryCount = 0;
  while (retryCount < 10) {
    await new Promise(resolve => setTimeout(resolve, 10000)); // Wait for 10 seconds
    log(`Trying to get OTP from API.. Attempt ${retryCount}`);
    try {
      log('https://91.playludo.app/api/CommonAPI/GetBankPhoneOTPViaUPIId?UpiId='+CONFIG.userId);
      const response = await fetch('https://91.playludo.app/api/CommonAPI/GetBankPhoneOTPViaUPIId?UpiId='+CONFIG.userId);
      if (!response.ok) throw new Error('Network response was not ok');
      const otpAPI = await response.json();
      let OTPapiTime=moment(otpAPI.ErrorMessage, 'YYYY-MM-DD HH:mm:ss');
      if (otpAPI && otpAPI.ErrorCode === "1" && OTPtimeStamp.isBefore(OTPapiTime)) {
        log("OTP received from API");
        return otpAPI.Result;
      } else {
        log("Failed to get OTP from API");
      }
    } catch (error) {
      log("Error fetching OTP:"+ error.message);
    }
    retryCount++;
  }
  throw "1";
}

async function UpiIdDateUpdate() {
  try {
    const response = await fetch(UpiIdUpdateURL);
    if (!response.ok) throw new Error('Network response was not ok');
    const APIresponse = await response.json();
    if (APIresponse && APIresponse.ErrorCode === "1") {
      log("Upi Id status updated");
      return APIresponse.Result;
    } else {
      log("Failed to update Upi Id  date status");
    }
  } catch (error) {
    log("Error from Upi Id update date API:", error.message);
  }
}

async function typeIntoElement(page, selectorType, selector, text) {
  let elementHandle;
  if (selectorType === "xpath") {
    const elements = await page.$x(selector);
    elementHandle = elements[0];
  } else if (selectorType === "id") {
    elementHandle = await page.$(`#${selector}`);
  } else if (selectorType === "name") {
    elementHandle = await page.$(`[name=${selector}]`);
  } else {
    throw new Error(`Unsupported selector type: ${selectorType}`);
  }
  if (elementHandle) {
    for (const char of text) {
      await elementHandle.type(char, { delay: getRandomDelay() });
    }
  } else {
    throw new Error(`No element found for ${selectorType}: ${selector}`);
  }
}

async function getINRValueByXPath(page, xpath) {
  // Wait for the element to be present in the DOM
  await page.waitForXPath(xpath);

  // Evaluate the XPath to extract the value
  const value = await page.evaluate((xpath) => {
    const element = document.evaluate(xpath, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
    if (element) {
      return element.value.replace('INR ', ''); // Remove 'INR ' from the value
    }
    return '0.00';
  }, xpath);

  return value;
}

async function getTextByXpath(page, xpath) {
  const elements = await page.$x(xpath);
  if (elements.length === 0) {
    return null;
  }
  return page.evaluate(el => el.textContent, elements[0]);
}

async function getHTMLByXpath(page, xpath) {
  const elements = await page.$x(xpath);
  if (elements.length === 0) {
    return null;
  }
  return await elements[0].evaluate(el => el.outerHTML);
}

async function convertHtmlToJson(page, htmlString) {
  let jsonDataX = await page.evaluate(html => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const rows = doc.querySelectorAll('table tbody.listrowwrapper tr');
    let data = [];
    
    rows.forEach(row => {
      const cells = row.querySelectorAll('td');
      if (cells.length > 0) {
        let debitAmountText = cells[2].innerText.trim().replace(/,/g, '');
        let debitAmount = debitAmountText ? parseFloat(debitAmountText).toFixed(2) : '';
        let creditAmountText = cells[3].innerText.trim().replace(/,/g, '');
        let creditAmount = creditAmountText ? parseFloat(creditAmountText).toFixed(2) : '';
        
        const rowData = {
          "Date": cells[0].innerText.trim(),
          "Description": cells[1].innerText.trim(),
          "Debit Amount": debitAmount,
          "Credit Amount": creditAmount
        };
        
        if (rowData.Date) {
          data.push(rowData);
        }
      }
    });
    return data.map(transaction => {
      let createdDateParts = transaction.Date.split(",");
      let createdDate = `${createdDateParts[1]}/${createdDateParts[0]}/2024`;
      
      let amount = transaction["Debit Amount"]? "-"+transaction["Debit Amount"] : '' || transaction["Credit Amount"];
      let descriptionx = transaction.Description;
      let UPIid = "";
      if (descriptionx.startsWith("UPI:")) {
        let upiIdentifier = descriptionx.split(':')[1];
         UPIid = (descriptionx.split(':')[2]).split('(')[0];
        descriptionx = `${upiIdentifier} ${descriptionx}`;
      }
      let refNumber = descriptionx;
      
      return {
        CreatedDate: createdDate,
        Description: descriptionx,
        Amount: amount,
        RefNumber: refNumber,
        UPIId:UPIid
      };
    });
  }, htmlString);
  return jsonDataX;
}

async function clickElementByXPath(page, xpath) {
  const elements = await page.$x(xpath);
  // console.log("elements" +elements)
  if (elements.length > 0) {
    // console.log("elements00000" +elements)
    await elements[0].click();
  } else {
    throw new Error(`No element found to click for XPath: ${xpath}`);
  }
}

async function hoverElementByXPath(page, xpath) {
  const elements = await page.$x(xpath);
  if (elements.length > 0) {
    await elements[0].hover();
  } else {
    throw new Error(`No element found to hover for XPath: ${xpath}`);
  }
}

async function changeElementStyle(page, xpath, styleProperty, styleValue) {
  const elements = await page.$x(xpath);
  if (elements.length > 0) {
    await page.evaluate((element, property, value) => {
      element.style[property] = value;
    }, elements[0], styleProperty, styleValue);
  } else {
    console.log('No element found for the given XPath');
  }
}

function getRandomDelay() {
  return Math.floor(Math.random() * (300 - 100 + 1)) + 100; // Random delay between 500 and 1000 milliseconds
}

async function postData(url, data) {
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    const responseData = await response.json();
    return responseData;
  } catch (error) {
    console.error('Error:', error);
  }
}

async function GetBankStatusViaUPIId() {
  try {
    log("Checking UPI status...");
    const response = await fetch(UpiIdStatusURL);
    if (!response.ok) throw new Error('Network response was not ok');
    const APIresponse = await response.json();
    log(JSON.stringify(response));
    if (APIresponse) {
      return APIresponse.Result;
    } else {
      return "2";
    }
  } catch (error) {
    return "2";
  }
}

function log(message) {
  let now = new Date();
  let formattedDate = now.toLocaleString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
  });
  let printMessage = `[${formattedDate} - ${CONFIG.upiId}] ${message}`;
  console.log(printMessage);
}

let page;
let browser ;
async function main() {
  while(true){
    try{
      if (page) {
        await page.close();
      }
   
      let runCheck="2";//2
      while(runCheck!="1"){
        runCheck = await GetBankStatusViaUPIId();
        if(runCheck!="1"){
          log("UPIid is not active.")
          await delaySleep(10000);
        }
      }
      log("Opening browser...");
      if (!browser) {
        browser = await launchBrowser();
      }
      log("Initializing page...");
      page = await configurePage(browser);
      page.on('dialog', async dialog => {
        console.log(dialog.message());
        await dialog.accept();
      });
      log("Initializing login...");
      await login(page);
      while(true){
        log("Initializing txn flow...");
        let txnData = await getTransactions(page);
        console.log("Ashuuuuuuuu"+JSON.stringify(txnData))
        let runCheck2 = await GetBankStatusViaUPIId();
        if(runCheck2!="1"){
          log("UPIid is not active.");
          break;
        }
        log("Updating Latest Statement...");
        let saveApiRes = "";
        // let saveApiRes = await postData(saveTransactionUrl, txnData);
        log(JSON.stringify(saveApiRes));
        await UpiIdDateUpdate();
      }
    } catch (error) {
      log("Encountered major error");
      log(error);
      if(page&&browser){
        await logoutFromBank(page,browser);
      }
      // await delaySleep(10000);
      throw(error);
    }
  }
}

async function runMainSafely() {
  while (true) {
    try {
      console.log("initializing scrapper...");
      await main();
    } catch (error) {
      console.error('An error occurred, restarting main:', error);
    }
  }
}

runMainSafely();