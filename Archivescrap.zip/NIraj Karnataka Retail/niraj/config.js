const CONFIG = {
  landingUrl:"https://moneyclick.ktkbank.com/BankAwayRetail/AuthenticationController?__START_TRAN_FLAG__=Y&FORMSGROUP_ID__=AuthenticationFG&__EVENT_ID__=LOAD&FG_BUTTONS__=LOAD&ACTION.LOAD=Y&AuthenticationFG.LOGIN_FLAG=1&BANK_ID=KBL&LANGUAGE_ID=001",
  loginUrl:"https://moneyclick.ktkbank.com/BankAwayRetail/AuthenticationController?__START_TRAN_FLAG__=Y&FORMSGROUP_ID__=AuthenticationFG&__EVENT_ID__=LOAD&FG_BUTTONS__=LOAD&ACTION.LOAD=Y&AuthenticationFG.LOGIN_FLAG=1&BANK_ID=KBL&LANGUAGE_ID=001",
  // userId: "R04259171",
  // password: "Zebra@9870",
  // upiId: "ramu12@kbl",
  userId: "R04125219",
  password: "Latin@6580",
  upiId: "kndjif123@kbl"
};

module.exports = CONFIG;