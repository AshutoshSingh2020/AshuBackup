const CONFIG = {
  landingUrl:"https://psbomnigateway.onlinepsb.co.in/PSBCORPORATE/#/login",
  loginUrl:"https://psbomnigateway.onlinepsb.co.in/PSBCORPORATE/#/login",
  corpId: "babuali2030",
  userId: "babu2030",
  password: "Zebra@3030",
  otherUrl: "http://yourwebsite.com/otherpage",
  upiid: "7678210017@psbpay"
};

module.exports = CONFIG;
