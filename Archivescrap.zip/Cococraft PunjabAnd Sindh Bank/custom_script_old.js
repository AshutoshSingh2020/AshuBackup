const puppeteer = require("puppeteer");
const fs = require("fs");
const path = require("path");
const fetch = require("node-fetch");
const saveTransactionUrl = "https://91.playludo.app/api/CommonAPI/SavebankTransaction";
const CONFIG = require("./config");
const UpiIdStatusURL = "https://91.playludo.app/api/CommonAPI/GetUpiStatus?upiId=" + CONFIG.upiid;
const  UpiIdUpdateURL = "https://91.playludo.app/api/CommonAPI/UpdateDateBasedOnUpi?upiId=" + CONFIG.upiid;
const { config } = require("process");
async function launchBrowser() {
  return await puppeteer.launch({
    headless: false,
    args: ["--disable-infobars","--no-sandbox","--disable-setuid-sandbox","--disable-web-security"],
  });
}
async function configurePage(browser) {
  let page = await browser.newPage();
  await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36");
  await page.setViewport({ width: 1366, height: 768 });
  return page;
}

async function replaceJavaScript(page) {
  await page.setRequestInterception(true);
  page.on("request", (request) => {
    if (request.url().endsWith("22.1aa3ac87c1b6fcacee95.js")) {
      const customScriptPath = path.join(__dirname,"22.1aa3ac87c1b6fcacee95.js");
      const customScriptContent = fs.readFileSync(customScriptPath, "utf8");
      request.respond({
        status: 200,
        contentType: "text/javascript",
        body: customScriptContent,
      });
    } else {
      request.continue();
    }
  });
}

// async function landingToLogin (page){
//   await delaySleep(5000);
//   log("Clicking Corporate button");
//   await clickElementByXPath(page,"/html/body/app-root/div[1]/app-nli-landing-page/div[1]/div/div/div[2]/div/div/div[1]/ul/li[3]/a/div/em");
//   await delaySleep(5000);
//   log("Clicking Proprieter login button");
//   await clickElementByXPath(page,"/html/body/app-root/div[1]/app-nli-landing-page/div[1]/div/div/div[2]/div/div/div[2]/div/div[1]/div[1]/div/div/div[1]/div/div/button[2]");
//   await page.waitForNavigation({timeout:120000}); // The promise resolves after navigation
//   await delaySleep(5000);
// }

async function login(page) {
  await page.goto(CONFIG.loginUrl, { timeout: "120000" });
  // await delaySleep(5000);
  let url = await page.evaluate(() => document.URL);
  if(url=="https://psbomnigateway.onlinepsb.co.in/PSB/#/login"){
  page.goBack();
  await delaySleep(5000);
}
url = await page.evaluate(() => document.URL);
if(url=="https://psbomnigateway.onlinepsb.co.in/PSB/#/nliLanding"){
page.goBack();
await delaySleep(5000);
}

let globalVariableValue = await page.evaluate(() => {
  return window.myGlobalVariable;
});

log("Captcha is : "+ globalVariableValue);

await delaySleep(5000);
log("Typing corporate id");
await typeIntoElement(page,"xpath","/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[1]/div/input",CONFIG.corpId);

await delaySleep(600);
log("Typing user id");
await typeIntoElement(page,"xpath","/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[3]/div/input",CONFIG.userId);

await delaySleep(600);
log("Typing password");
await typeIntoElement(page,"xpath","/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[5]/div/input",CONFIG.password);

await delaySleep(600);
log("Typing captcha");
await typeIntoElement(page,"xpath","/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[7]/div/input",globalVariableValue);
await delaySleep(600);

if(!globalVariableValue){
  globalVariableValue = await page.evaluate(() => {
    return window.myGlobalVariable;
  }); 
  log("Captcha is : "+ globalVariableValue);
}

log("Clicking captcha input");
await clickElementByXPath(page,"/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[7]/div/input");
await delaySleep(1000);
log("Clicking password input");
await clickElementByXPath(page,"/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[1]/div[5]/div/input");
await delaySleep(2000);
log("Clicking login button");
await clickElementByXPath(page,"/html/body/app-root/div[1]/app-login/div[1]/div/div/div/div[3]/div[1]/div[3]/div[1]/form/div[3]/div/div/button");

await page.waitForSelector('#otppassword1');
var otpVal="";
await getOTPFromAPI().then(otp => {
  log("OTP : "+ otp);
  otpVal=otp;
}).catch(error => {
  log("An error occurred:", error);
});

await page.type('#otppassword1', otpVal.charAt(0));
await delaySleep(700);
await page.type('#otppassword2', otpVal.charAt(1));
await delaySleep(400);
await page.type('#otppassword3', otpVal.charAt(2));
await delaySleep(300);
await page.type('#otppassword4', otpVal.charAt(3));
await delaySleep(900);
await page.type('#otppassword5', otpVal.charAt(4));
await delaySleep(400);
await page.type('#otppassword6', otpVal.charAt(5));
await delaySleep(300);

await delaySleep(2000);
log("Clicking submit otp button");
await clickElementByXPath(page,"/html/body/app-root/div[1]/app-login/div[6]/div[4]/div/div/div/button");
await page.waitForNavigation();
await delaySleep(7000);

log("Clicking my account icon");
await clickElementByXPath(page,"/html/body/app-root/div[1]/app-dashboard-page/div/div[1]/div/div/div/div/div/div/div[1]/div[2]/div/owl-carousel-o/div/div[1]/owl-stage/div/div/div[2]/div/a/div/span/img");
await page.waitForNavigation();
await delaySleep(2000);
}


async function getTransactions(page){
  await delaySleep(1000);
  log("Hovering on account details");
  await hoverElementByXPath(page,"/html/body/app-root/div[1]/app-accountpage/div[1]/div/div/div/div/div[3]/div/div/div[1]/div[2]/div/div/div[1]/div/div/div[2]/div/ul/li[2]");
  
  log("Clicking More Details button");
  await clickElementByXPath(page,"/html/body/app-root/div[1]/app-accountpage/div[1]/div/div/div/div/div[3]/div/div/div[1]/div[2]/div/div/div[1]/div/div/div[2]/div/ul/li[2]/div[5]/div/button[2]");
  await delaySleep(2000);
  
  log("Checking Avalable Balance...");
  let AvlBal = await getTextByXpath(page,"/html/body/app-root/div[1]/app-my-accounts-info/div[1]/div/div/div/div/div[3]/div/div/div[1]/div/div[2]/div/div/div/ul/li/div[2]/div/div[1]/h5");
  // log(AvlBal+" is the Available Balance");
let newMatch = AvlBal.replace(/[₹,]/g,'');
  let balMatch = newMatch.match(/[\d.]+/);
  let avlBalDigits=balMatch ? balMatch[0] : null;
  log("Fetching latest statement...");
  let tblHTML=await getHTMLByXpath(page,"/html/body/app-root/div[1]/app-my-accounts-info/div[1]/div/div/div/div/div[3]/div/div/div[1]/div/div[4]/div/div/div/div/div/div[2]/div/ul");
  let jsonData = await convertHtmlToJson(page, tblHTML);
  let bnkName = "PSB - "+CONFIG.corpId+"."+CONFIG.userId;
  let bnkLoginId = CONFIG.corpId+"."+CONFIG.userId;
  jsonData = jsonData.map(item => {
    return { ...item, BankName: bnkName, BankLoginId:bnkLoginId, AccountBalance: avlBalDigits};
  });
  log(JSON.stringify(jsonData));
  await delaySleep(2000);
  await clickElementByXPath(page,"/html/body/app-root/div[1]/app-my-accounts-info/div[1]/div/div/div/div/div[1]/div/div/ul/li[2]/a");
  log("Fetched statement, updating on server..");
  return jsonData;
}

async function logoutFromBank(page){
  try{
    log("Clicking Logout Button");
    await clickElementByXPath(page,"/html/body/app-root/div[1]/app-header/header/div/div/div/div[4]/div/ul/li[6]/a");
    await delaySleep(3000);
    await clickElementByXPath(page,"/html/body/app-root/div[1]/app-header/div[4]/div/div/div[3]/button[2]");
    log("Logged Out");
  }
  catch(e){
    log("logout error : "+e);  
  }
}


function delaySleep(time) {
  return new Promise(resolve => setTimeout(resolve, time));
}

async function getOTPFromAPI() {
  let retryCount = 0;
  while (retryCount < 10) {
    await new Promise(resolve => setTimeout(resolve, 10000)); // Wait for 10 seconds
    log(`Trying to get OTP from API.. Attempt ${retryCount}`);
    try {
      log('https://91.playludo.app/api/CommonAPI/GetBankPhoneOTPViaUPIId?UpiId='+CONFIG.corpId);
      const response = await fetch('https://91.playludo.app/api/CommonAPI/GetBankPhoneOTPViaUPIId?UpiId='+CONFIG.corpId);
      if (!response.ok) throw new Error('Network response was not ok');
      const otpAPI = await response.json();
      log(otpAPI);
      if (otpAPI && otpAPI.ErrorCode === "1") {
        log("OTP received from API");
        return otpAPI.Result;
      } else {
        log("Failed to get OTP from API");
      }
    } catch (error) {
      log("Error fetching OTP:"+ error.message);
    }
    retryCount++;
  }
  return "1";
}

async function UpiIdDateUpdate() {
  try {
    const response = await fetch(UpiIdUpdateURL);
    if (!response.ok) throw new Error('Network response was not ok');
    const APIresponse = await response.json();
    if (APIresponse && APIresponse.ErrorCode === "1") {
      log("Upi Id update status updated");
      return APIresponse.Result;
    } else {
      log("Failed to Upi Id update date status");
    }
  } catch (error) {
    log("Error from Upi Id update date API:", error.message);
  }
}

async function typeIntoElement(page, selectorType, selector, text) {
  let elementHandle;
  if (selectorType === "xpath") {
    const elements = await page.$x(selector);
    elementHandle = elements[0];
  } else if (selectorType === "id") {
    elementHandle = await page.$(`#${selector}`);
  } else if (selectorType === "name") {
    elementHandle = await page.$(`[name=${selector}]`);
  } else {
    throw new Error(`Unsupported selector type: ${selectorType}`);
  }
  if (elementHandle) {
    for (const char of text) {
      await elementHandle.type(char, { delay: getRandomDelay() });
    }
  } else {
    throw new Error(`No element found for ${selectorType}: ${selector}`);
  }
}

async function getTextByXpath(page, xpath) {
  const elements = await page.$x(xpath);
  if (elements.length === 0) {
    return null;
  }
  return page.evaluate(el => el.textContent, elements[0]);
}

async function getHTMLByXpath(page, xpath) {
  const elements = await page.$x(xpath);
  if (elements.length === 0) {
    return null;
  }
  return await elements[0].evaluate(el => el.outerHTML);
}

async function convertHtmlToJson(page, htmlString) {
  let jsonDataX = page.evaluate(html => {
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    const listItems = doc.querySelectorAll('.grid-list3.nb-m.ng-star-inserted > li:not(:first-child)');
    let jsonData = [];
    listItems.forEach(li => {
      const dataElements = li.querySelectorAll('.full-info h5');
      let dataObject = {};
      dataElements.forEach((element, index) => {
        dataObject[`key${index + 1}`] = element.textContent.trim();
      });
      jsonData.push(dataObject);
    });
    jsonData = jsonData.map(item => {
      console.log(item);
	let newMatch = item.key4.replace(/[₹,]/g,'')
      const match = newMatch.match(/[\d.]+/);
      let trxAmount=match ? match[0] : null;
      
      const match2 = item.key2.match(/(\d+)/);
      let refDescString = match2? `${match2[0]} ${item.key2}`:"";
      
      return {
        CreatedDate: item.key1,
        Description: refDescString,
        RefNumber: refDescString,
        Amount:item.key3=='CR'?trxAmount: '-'+trxAmount,
        AccountBalance: "00.00",
        BankName: "",
        UPIId: "",
        BankLoginId: ""
      };
    });
    return jsonData;
  }, htmlString);
  return jsonDataX;
}

async function clickElementByXPath(page, xpath) {
  const elements = await page.$x(xpath);
  if (elements.length > 0) {
    await elements[0].click();
  } else {
    throw new Error(`No element found to click for XPath: ${xpath}`);
  }
}

async function hoverElementByXPath(page, xpath) {
  const elements = await page.$x(xpath);
  if (elements.length > 0) {
    await elements[0].hover();
  } else {
    throw new Error(`No element found to hover for XPath: ${xpath}`);
  }
}

function getRandomDelay() {
  return Math.floor(Math.random() * (300 - 100 + 1)) + 100; // Random delay between 500 and 1000 milliseconds
}

async function postData(url, data) {
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    const responseData = await response.json();
    return responseData;
  } catch (error) {
    console.error('Error:', error);
  }
}

async function GetBankStatusViaUPIId() {
  try {
    log("Checking UPI status...");
    const response = await fetch(UpiIdStatusURL);
    if (!response.ok) throw new Error('Network response was not ok');
    const APIresponse = await response.json();
    log(JSON.stringify(response));
    if (APIresponse) {
      return APIresponse.Result;
    } else {
      return "2";
    }
  } catch (error) {
    return "2";
  }
}

function log(message) {
  let now = new Date();
  let formattedDate = now.toLocaleString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "numeric",
    second: "numeric",
  });
  let printMessage = `[${formattedDate} - ${CONFIG.upiid}] ${message}`;
  console.log(printMessage);
}

let browser;
async function main() {
  while(true){
    try{
      if (browser) {
        await browser.close();
      }
      let runCheck="2";
      while(runCheck!="1"){
        runCheck = await GetBankStatusViaUPIId();
        if(runCheck!="1"){
          log("UPIid is not active.")
          await delaySleep(10000);
        }
      }
      log("Opening browser...");
      browser = await launchBrowser();
      log("Initializing page...");
      let page = await configurePage(browser);
      log("Initializing script...");
      await replaceJavaScript(page);
      log("Initializing login...");
      await login(page);
      while(true){
        log("Initializing txn flow...");
        let txnData = await getTransactions(page);
        let runCheck2 = await GetBankStatusViaUPIId();
        if(runCheck2!="1"){
          log("UPIid is not active.");
          break;
        }
        log("Updating Latest Statement...");
        let saveApiRes = await postData(saveTransactionUrl, txnData);
        log(JSON.stringify(saveApiRes));
        await UpiIdDateUpdate();
      }
    } catch (error) {
      log("Encountered major error");
      log(error);
      if(page&&browser){
        await logoutFromBank(page,browser);
      }
      delaySleep(10000);
      throw(error);
    }
  }
}

async function runMainSafely() {
  while (true) {
    try {
      console.log("initializing scrapper...");
      await main();
    } catch (error) {
      // Log the error and restart main
      console.error('An error occurred, restarting main:', error);
    }
  }
}

runMainSafely();