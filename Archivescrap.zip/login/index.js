const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({
    headless: false, // Set to true if you don't want to see the browser
    defaultViewport: null,
  });
  const page = await browser.newPage();
  await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36");
  await page.setViewport({ width: 1366, height: 768 });
  // Go to login page
  await page.goto('http://portal.91springboard.com/', { waitUntil: 'networkidle2' });

  // Wait for email field and type email
//   await page.waitForSelector('input[type="email"]');
//   await page.type('input[type="email"]', 'your-email@example.com', { delay: 100 });
let selector = '';
let text = 'ankit11patel99@gmail.com';
await page.waitForSelector('#emailField');
let elementHandle = await page.$(`#${selector}`);
if (elementHandle) {
  for (const char of text) {
    await elementHandle.type(char, { delay: getRandomDelay() });
  }
} else {
  throw new Error(`No element found for ${selectorType}: ${selector}`);
}
// await page.type('#emailField', 'ankit11patel99@gmail.com', { delay: 100 });
await page.waitForSelector('#passwordField');
await page.type('#passwordField', 'test123', { delay: 100 });

  // Wait for password field and type password
//   await page.waitForSelector('input[type="password"]');
//   await page.type('input[type="password"]', 'your-password', { delay: 100 });

  // Click login button
  await page.click('button[type="submit"]');

  // Optional: wait for navigation or dashboard element
  await page.waitForNavigation({ waitUntil: 'networkidle2' });

  console.log('Logged in successfully!');
  // await browser.close(); // Uncomment if you want to close the browser after login
})();
