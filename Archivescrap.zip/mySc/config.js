const CONFIG = {
  loginUrl:"https://hireaxle.live",
  userId: "97157321",
  password: "2ZP82Q"
};

module.exports = CONFIG;
