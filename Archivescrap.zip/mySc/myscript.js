const puppeteer = require('puppeteer');
const CONFIG = require("./config");
const Tesseract = require('tesseract.js');


async function launchBrowser() {
  const extensionPath = './extension';
  return await puppeteer.launch({
    headless: false,
    args: ["--disable-infobars","--no-sandbox","--disable-setuid-sandbox","--disable-web-security",  
      `--disable-extensions-except=${extensionPath}`, 
      `--load-extension=${extensionPath}`
    ],
  });
}
function getRandomDelay() {
  return Math.floor(Math.random() * (300 - 100 + 1)) + 100;
}
function delaySleep(time) {
  return new Promise(resolve => setTimeout(resolve, time));
}
async function configurePage(browser) {
  let page = await browser.newPage();
  await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36");
  await page.setViewport({ width: 1570, height: 768 });
  return page;
}
async function typeIntoElement(page, selectorType, selector, text) {
  let elementHandle;
  if (selectorType === "xpath") {
    const elements = await page.$x(selector);
    elementHandle = elements[0];
  } else if (selectorType === "id") {
    elementHandle = await page.$(`#${selector}`);
  } else if (selectorType === "name") {
    elementHandle = await page.$(`[name=${selector}]`);
  } else {
    throw new Error(`Unsupported selector type: ${selectorType}`);
  }
  if (elementHandle) {
    for (const char of text) {
      await elementHandle.type(char, { delay: getRandomDelay() });
    }
  } else {
    throw new Error(`No element found for ${selectorType}: ${selector}`);
  }
}
async function clickElementByXPath(page, xpath) {
  const elements = await page.$x(xpath);
  if (elements.length > 0) {
    await elements[0].click();
  } else {
    throw new Error(`No element found to click for XPath: ${xpath}`);
  }
}
async function extractAndSplitText(imgSrc,index) {
  try {
    const { data: { text } } = await Tesseract.recognize(imgSrc);
    let cleanedData = "";
    if(index == 2){
       cleanedData = text.replace(/\n/g, ' ');
    }else{
       cleanedData = text.replace(/\n/g, '');
       
      }
      cleanedData = cleanedData.replace('~~', '');
    return cleanedData;
  } catch (error) {
    console.error('Error recognizing text:', error);
    return [];
  }
}
let browser;
(async () => {
  if (browser) {
    await browser.close();
  }
  browser = await launchBrowser();
  let page = await configurePage(browser);

  // Open the website
  await page.goto(CONFIG.loginUrl,{ timeout: 0 });
  await delaySleep(5000);
  // log("Typing user id");
  console.log(page)
await typeIntoElement(page,"id",'useremail',CONFIG.userId);

await delaySleep(600);
// log("Typing password");
await typeIntoElement(page,"id",'password',CONFIG.password);
await delaySleep(600);
await page.evaluate(() => {
  document.querySelector('input[type="submit"][value="Log In"]').click();
});

await delaySleep(5000);
// await page.waitForNavigation({ waitUntil: 'networkidle0' });

await delaySleep(1500);
// Now navigate to the new page
await page.goto('https://hireaxle.live/start-work', { timeout: 120000 });
await delaySleep(1200);
await page.evaluate(() => {
  document.getElementById('dataId').click();
});
// await page.click('#dataId');
//     await page.evaluate(() => {
//       const selectElement = document.getElementById('dataId');
//       selectElement.value = '52'; // Set the value to the desired option
//       const event = new Event('change', { bubbles: true });
//       selectElement.dispatchEvent(event); // Dispatch the change event
//     });
// await delaySleep(600);
await page.select('#dataId', '51');
// await clickElementByXPath(page,"/html/body/div/div[2]/div/div/div/form/input");
await page.reload();


  // Close the browser
  // await browser.close();
//   await page.evaluate(() => {
//     const img = document.getElementById('blah');
//     console.log(img ? img.src : null);
//   });
// let img = imgUrl(page);

// await page.evaluate(() => {
//   const selectElement = document.getElementById('dataId');
//   if (selectElement) {
//     selectElement.addEventListener('change', (event) => {
//       // The new value selected
//       const newValue = event.target.value;
//       window.handleSelectChange(newValue);
//     });
//   }
// });

// await page.exposeFunction('handleSelectChange', async (newValue) => {
//   // Call the function defined outside
//   await checkForImage(); 
// });

// const checkIfFieldsAreBlank = async () => {
//   const isNameFieldBlank = await page.evaluate(() => {
//     const input = document.getElementById('name');
//     return input ? !input.value : true;
//   });
const checkIfFieldsAreBlank = async () => {
  try {
    return await page.evaluate(() => {
      const input = document.getElementById('name');
      return input ? !input.value.trim() : true;
    });
  } catch (error) {
    console.error('Error checking fields:', error);
    return true; // Assume fields are blank if an error occurs
  }
};

  // const isCompanyNameFieldBlank = await page.evaluate(() => {
  //   const input = document.getElementById('company_name');
  //   return input ? !input.value : true;
  // });

  // const isOfficeContactFieldBlank = await page.evaluate(() => {
  //   const input = document.getElementById('office_contact');
  //   return input ? !input.value : true;
  // });

  // return isNameFieldBlank || isCompanyNameFieldBlank || isOfficeContactFieldBlank;
 
var intervalId = '';
var textArr = [];
const checkForImage = async () => {
  try {
  //  let  imgSrc  =''
  //    imgSrc = await page.evaluate(() => {
  //     const img = document.getElementById('blah');
  //     return img ? img.src : null;
  //   });
  const imgSrcs = await page.evaluate(() => {
    const imgs = document.querySelectorAll('#blah');
    return Array.from(imgs).map(img => img.src);
  });

    if (imgSrcs.length>0) {
      console.log('Image found with src:', imgSrcs);
      // imgSrcs.forEach((item)=>{
        // textArr.push(extractAndSplitText(item));
        // });
        
  const first = await extractAndSplitText(imgSrcs[0],0);
  const second = await extractAndSplitText(imgSrcs[1],1);
  const third = await extractAndSplitText(imgSrcs[2],2);

  console.log("first: " + first);
  console.log("second: " + second);
  console.log("third: " + third);
      // let form1 = textArr[0].split("  ");
      // let form2 = (extractAndSplitText(item));
      // let form3 = textArr[2].split("  ");
delaySleep(6000)

      const splitPattern = /(\()|(\d)/;

      // Find the match and index to split the data
      const match = first.match(splitPattern);
      
      if (match) {
        const splitIndex = match.index;
        const part1 = first.slice(0, splitIndex).trim();
        const part2 = first.slice(splitIndex).trim();
      
            await page.evaluate((part1) => {
              const input = document.getElementById('name');
              if (input) input.value = part1; 
            },part1);
             await page.evaluate((part1) => {
              const input = document.getElementById('designation');
              if (input) input.value = part1; 
          },part1);
            await page.evaluate((part2) => {
            const input = document.getElementById('mobile_no');
            if (input) input.value = part2; 
          },part2);
        console.log('Part 1:', part1);
        console.log('Part 2:', part2);
      } else {
        console.log('No split point found in the string.');
      }



// console.log("form2 data"+form2);
      const urlPattern = /((https?:\/\/)?(www\.)?[^\s]+\.[^\s]{2,})/g;
      const urls = second.match(urlPattern);
      console.log("urls"+urls);
      if (urls && urls.length > 0) {
        console.log('URLs found:', urls);
        const splitData = second.split(urls);
        console.log('Split data:', splitData);
        await page.evaluate((splitData) => {
          const input = document.getElementById('company_name');
          if (input) input.value = (splitData[0])?(splitData[0]).trim():''; 
        },splitData);
         await page.evaluate((urls) => {
          const input = document.getElementById('website');
          if (input) input.value = urls; 
      },urls);
        await page.evaluate((splitData) => {
        const input = document.getElementById('address');
        if (input) input.value = (splitData[1])?(splitData[1]).trim():''; 
      },splitData);
      } else {
        console.log('No URL found in the string.');
      }


// Regular expression to match an email address
const emailPattern = /([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+[a-zA-Z])/;
const emailMatch = third.match(emailPattern);

if (emailMatch) {
  // const email = emailMatch;
  // console.log(email)
  
  // const splitIndex = emailMatch.index;
  // const part1 = first.slice(0, splitIndex).trim();
  // const part2 = first.slice(splitIndex).trim();
  // console.log(part1)
  // console.log(part2)

  // const [beforeEmail, afterEmail] = third.split(email);
  // console.log(beforeEmail, afterEmail);
  const email = emailMatch[0];

  // Split the data at the email address
  const [beforeEmail, afterEmail] = third.split(email);

  // Find the last number in the `beforeEmail` part using regex
  const lastNumberPattern = /\d+[-.\s]*\d*/g;
  let lastNumberMatch;
  let match;
  while ((match = lastNumberPattern.exec(beforeEmail)) !== null) {
    lastNumberMatch = match;
  }

  if (lastNumberMatch) {
    // Get the index of the last number's end
    const lastNumberEndIndex = lastNumberPattern.lastIndex;
    const textBeforeNumber = beforeEmail.slice(0, lastNumberEndIndex).trim();
    const textAfterNumber = beforeEmail.slice(lastNumberEndIndex).trim();

    console.log('Text before last number and email:', textBeforeNumber);
    console.log('Text before last number and email:', beforeEmail);
    console.log('Email:', email);
    console.log('Text after email:', afterEmail.trim());

  }

  await page.evaluate((beforeEmail) => {
    const input = document.getElementById('office_contact');
    if (input) input.value = (beforeEmail).trim(); 
  },beforeEmail);
   await page.evaluate((email) => {
    const input = document.getElementById('email');
    if (input) input.value = (email).trim(); 
},email);
  let splitYes = (afterEmail.trim()).split(" ");
  await page.evaluate((splitYes) => {
    const input = document.getElementById('linkedin');
    if (input) input.value = (splitYes[0]).trim(); 
},splitYes); 

 await page.evaluate((splitYes) => {
  const input = document.getElementById('twitter');
  if (input) input.value =  (splitYes[1]).trim(); 
},splitYes);

  await page.evaluate((splitYes) => {
  const input = document.getElementById('skype');
  if (input) input.value =  (splitYes[2]).trim(); 
},splitYes);  

await page.evaluate((splitYes) => {
  const input = document.getElementById('qrcode');
  if (input) input.value =  (splitYes[3]).trim(); 
},splitYes);

  console.log('Before email:', beforeEmail.trim());
  console.log('Email:', email);
  console.log('After email:', afterEmail.trim());
} else {
  await page.evaluate((beforeEmail) => {
    const input = document.getElementById('office_contact');
    if (input) input.value = (beforeEmail).trim(); 
  },beforeEmail);
  console.log('No email found in the string.');
}
await delaySleep(5000);
await page.evaluate(() => {
  document.getElementById('nextBtn').click();
});

await delaySleep(5000);
await page.evaluate(() => {
  document.getElementById('nextBtn').click();
});
await delaySleep(5000);
await page.evaluate(() => {
  document.getElementById('nextBtn').click();
});
await delaySleep(5000);


      clearInterval(intervalId);
      // clearInterval(intervalId2);
    } else {
      console.log('Image not found, checking again in 5 seconds...');
    }
  } catch (err) {
    console.error('Error checking for image:', err);
  }
};

// const intervalId2 = setInterval(async () => {
//   let fieldsAreBlank = false;
//     fieldsAreBlank = await checkIfFieldsAreBlank();
//   if (fieldsAreBlank) {
//     console.log('Some fields are blank. Fetching image...');
//     intervalId = setInterval(checkForImage, 5000);
//   } else {
//     console.log('All fields are filled. Stopping the interval.');
//     clearInterval(intervalId2); // Stop checking if all fields are filled
//   }
// }, 5000);
let fetchingImage = false;
const intervalId2 = setInterval(async () => {
  console.log("Caliing checking");
  const fieldsAreBlank = await checkIfFieldsAreBlank();
  if (fieldsAreBlank) {
    if (!fetchingImage) {
      console.log('Some fields are blank. Fetching image...');
      fetchingImage = true; 
      await checkForImage(); 
      fetchingImage = false; 
      setTimeout(() => {}, 5000);
    }else{
      console.log('Image is being fetched, waiting...');
      fetchingImage = false;
    }
  } else {
    if (fetchingImage) {
      console.log('All fields are filled. Stopping the interval.');
      fetchingImage = false;
      // clearInterval(intervalId2);
    } else {
      console.log('All fields are filled. Checking again after a pause.');
      setTimeout(async () => {
        // Re-check after a pause to ensure fields remain filled
        const recheckFieldsAreBlank = await checkIfFieldsAreBlank();
        if (recheckFieldsAreBlank) {
          console.log('Some fields are blank after recheck. Fetching image again...');
          fetchingImage = true;
          await checkForImage();
          fetchingImage = false;
       
        }
      }, 5000);
    }
  }
}, 20000);



// Optionally, stop the interval after a certain period (e.g., 30 seconds)
// setTimeout(() => {
//   clearInterval(intervalId);
//   console.log('Stopped checking for the image.');
// }, 300000);

// console.log(img)
// if(imgSrc.length>0){
  

// }
})();



  
//   await page.evaluate((splidata) => {
//     const input = document.getElementById('office_contact');
//     if (input) input.value = splidata[2]; 
//   }, splidata[2]);
  
//   await page.evaluate((splidata) => {
//     const input = document.getElementById('email');
//     if (input) input.value = splidata[2]; 
//   }, splidata[2]);
  
//   await page.evaluate((splidata) => {
//     const input = document.getElementById('linkedin');
//     if (input) input.value = splidata[2]; 
//   }, splidata[2]);
//   await page.evaluate((splidata) => {
//     const input = document.getElementById('twitter');
//     if (input) input.value = splidata[2]; 
//   }, splidata[2]);
//   await page.evaluate((splidata) => {
//     const input = document.getElementById('skype');
//     if (input) input.value = splidata[2]; 
//   }, splidata[2]);
//   await page.evaluate((splidata) => {
//     const input = document.getElementById('qrcode');
//     if (input) input.value = splidata[2]; 
//   }, splidata[2]);
  
// }
   