
/* *********************************************/
/* Absolute Enable Right Click & Copy
/* Created by Absolute
/* Date 2017-12-26
/* *********************************************/