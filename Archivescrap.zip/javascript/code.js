//Common Element
let arr = [1,4,5,3,6];
let arr2 = [2,3,4,1,7,9]
const res = (arr1,arr2)=>{
    let comm = []
        for(let val of arr){
            for(let val2 of arr2){
                if(val == val2){
                    comm.push(val)
                }
            }
        }
        return comm;
}
console.log(res(arr,arr2))

//last Element
let lastArr =['apple','grapes','guava']
console.log(lastArr[lastArr.length -1 ]);




const sort = (arr)=>{
    for(let i=0;i<arr.length-1;i++){
        for(let j=0;j<arr.length-i-1;j++){
            if(arr[j] > arr[j+1]){
                [arr[j],arr[j+1]] = [arr[j+1],arr[j]]
            }
        }
    }
    return arr;
}
console.log(sort([1,4,5,2,7]))

let arrr = [1,2,3,4,5,3,2,5,6]
console.log(arrr.reduce((a,b)=> a!=b))

const remove = (arr)=>{
    let newArr = [];
    for(let i=0;i<arr.length ; i++){
        let insert  = false;
        for(let j=0; j<newArr.length;j++){
           if(arr[i] == newArr[j]){
            insert = true;
            break;
         }
    }
    if(!insert){
        newArr.push(arr[i])

    }
    }
    return newArr;
}

console.log(remove([1,4,2,5,6,8,5,4,9,3,32]))

const removeD = (arr)=>{
    return new Set(...[arr])
}
console.log(removeD([1,4,2,5,6,8,5,4,9,3,32]))

let arr = [1, 2, 2, 3, 4, 4, 5, 1];

let unique = arr.filter((value, index) => {
  return arr.indexOf(value) === index;
});

console.log(unique);

let arr = [1, 2, 2, 3, 4, 4, 5, 1];

let unique = arr.reduce((acc, curr) => {
  if (!acc.includes(curr)) {
    acc.push(curr);
  }
  return acc;
}, []);

console.log(unique);


const largest = (arr)=>{
    let high = arr[0]
    let low = arr[0];
    for(let i=0;i<arr.length;i++){
        if(high < arr[i]){
            high = arr[i]
        }
        if( arr[i] < low){
            low = arr[i]
        }
    }
    return [high,low]
}
console.log(largest([3,5,2,6,10,8,2,9]))

let arr = ["2","4","5","*","s"];
const sum = arr =>{
    let sum = 0;
    for(let val of arr){
        if(parseInt(val)){
            sum+= parseInt(val);
        }
    }
    return sum
}
console.log(sum(arr))

Rotate left array 

const rotate = (arr,k) =>{
    for(let i=0;i<k;i++){
        arr.push(arr.shift())

    }
    return arr;
}
console.log(rotate([1,2,3,4,5],2))

Rotate Right array 
const rotate = (arr,k) =>{
    for(let i=0;i<k;i++){
        arr.unshift(arr.pop())

    }
    return arr;
}
console.log(rotate([1,2,3,4,5],2))

Find pair of sum 

const findpair = (arr,sum) =>{
    for(let i =0;i<arr.length;i++){
        for(let j=0;j<arr.length-1;j++){
            if(i!=j){
                if( arr[i]+ arr[j] == sum){
                    return [arr[i],arr[j]]
                }
               
            }

        }
    }
    return false;
}
console.log(findpair([1,3,5,7,2,8,2],12))

Longest not repeated

const longest = (str)=>{
    let set = new Set();
    let left = 0;
    let right = 0;
    let maxSubstring = "";

    while(right < str.length){
        if(!set.has(str[right])){
            set.add(str[right]);
            right++;
            if((right - left)  > maxSubstring.length){
                maxSubstring = str.slice(left,right);

            }
        }else{
            set.delete(str[left]);
            left++;
        }
    }
    return maxSubstring;
}
console.log(longest('pwwkew'));


ArmStrong number
const armStrong = (num)=>{
    let str = num.toString();
    let length = str.length;
    let add = 0;
    for(let val of str){
        add += Math.pow(parseInt(val),length);
    }
    if(num == add){
        return true;
    }
    return false;

}
console.log(armStrong(143))

Factorial
const fact = (num)=>{
    if(num <=1) return 1
    return num * fact(num-1);
}
console.log(fact(6));

🔹 1. Arrays
Remove Duplicates

Input: [1,2,2,3,3,4] → Output: [1,2,3,4]

Find the Missing Number

Input: [1,2,4,5] → Output: 3

Rotate an Array (K times)

Input: [1,2,3,4,5], k=2 → Output: [4,5,1,2,3]

Find Pair with Given Sum

Input: [1,2,3,9], sum=8 → Output: false

🔹 2. Strings
Check for Anagram

'listen' & 'silent' → true

Reverse Words in a String

Input: 'JavaScript is cool' → Output: 'cool is JavaScript'

First Non-Repeating Character

Input: 'aabcb' → Output: 'c'

Check if Palindrome

'madam' → true

🔹 3. Numbers
Check Prime Number

Fibonacci Series (Recursive & DP)

Factorial using Recursion

Armstrong Number

🔹 4. Objects / Maps
Find Most Frequent Element in Array

Group Anagrams

Input: ["bat", "tab", "cat"] → Output: [['bat','tab'],['cat']]

Count Character Frequency in a String

🔹 5. Recursion
Sum of Digits of a Number

Print All Subsets (Power Set)

Permutations of a String

🔹 6. Sorting / Searching
Implement Bubble Sort / Selection Sort

Binary Search (Iterative & Recursive)

Merge Two Sorted Arrays

🔹 7. Stack / Queue
Balanced Parentheses Check

Input: '[()]{}{[()()]()}' → Output: true

Implement Stack using Array

Evaluate Postfix Expression

🔹 8. Miscellaneous / Advanced
Two Sum Problem

Longest Substring Without Repeating Characters

Find Intersection of Two Arrays

LRU Cache (Design) – Using Map and Doubly Linked List

Debounce / Throttle Function (Behavioral DSA using JS)


const notrepeat = (str)=>{
    let newStr = "";
    let i =0;
    let prev = ""
    let next = str[0]
    for(let val of str){
        if(!newStr.includes(val)){
            newStr += val;
            i++;
        }else if(newStr.includes(val) && i <= 1){
            newStr += val;
            i++;
        }else{
            i=0;
        }
        prev = next
        next = val
        if(prev != next){
            i=0;
        }
    }
    return newStr;
}
console.log(notrepeat('aaabbcaa'))


function truncateRepeats(str) {
  return str.replace(/(.)\1{2,}/g, '$1$1');
}

const input = 'aaabbcaaaddg';
const output = truncateRepeats(input);
console.log(output)

let str = "1234567890"
console.log([...str])