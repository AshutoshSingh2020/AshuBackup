const ffmpeg = require('fluent-ffmpeg');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const https = require('https');

// Array of image URLs
const imageUrls = [
   'https://vmtrackapi.fairbet91.com/013526_PM_28Sep2024.jpg',
   'https://vmtrackapi.fairbet91.com/013532_PM_28Sep2024.jpg',
   'https://vmtrackapi.fairbet91.com/013525_PM_28Sep2024.jpg',
   'https://vmtrackapi.fairbet91.com/013527_PM_28Sep2024.jpg',
   'https://vmtrackapi.fairbet91.com/013537_PM_28Sep2024.jpg',
   // Add all 800 image URLs here
];

const outputDir = path.join(__dirname, 'images');
const outputVideoPath = path.join(__dirname, 'output.mp4');

// Custom HTTPS agent to handle TLS issues
const httpsAgent = new https.Agent({
  keepAlive: true,
  rejectUnauthorized: false // Use with caution for SSL verification issues
});

// Function to download images with retry mechanism
async function downloadImage(url, filename, retries = 3) {
  try {
    const response = await axios({
      url,
      responseType: 'stream',
      httpsAgent, // Use custom agent
      timeout: 10000 // Timeout after 10 seconds
    });
    return new Promise((resolve, reject) => {
      const writer = fs.createWriteStream(filename);
      response.data.pipe(writer);
      writer.on('finish', resolve);
      writer.on('error', reject);
    });
  } catch (error) {
    if (retries > 0) {
      console.warn(`Retrying download for ${url}. Attempts left: ${retries - 1}`);
      return downloadImage(url, filename, retries - 1);
    } else {
      console.error(`Failed to download ${url}:`, error.message);
    }
  }
}

// Download all images
async function downloadAllImages() {
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir);
  }

  const downloadPromises = imageUrls.map((url, index) => {
    const filename = path.join(outputDir, `image${index.toString().padStart(3, '0')}.jpg`);
    return downloadImage(url, filename);
  });

  await Promise.all(downloadPromises);
}

// Create video from images
async function createVideo() {
  await downloadAllImages();

  ffmpeg()
    .addInput(`${outputDir}/image%03d.jpg`) // Use sequence pattern for images
    .inputOptions('-framerate 1') // Frame rate: 1 frame per second (adjust as needed)
    .outputOptions('-c:v libx264') // Codec
    .outputOptions('-pix_fmt yuv420p') // Pixel format
    .save(outputVideoPath)
    .on('end', () => {
      console.log('Video created successfully!');
    })
    .on('error', (err) => {
      console.error('Error creating video:', err);
    });
}

// Start the process
createVideo().catch(console.error);


// const ffmpeg = require('fluent-ffmpeg');
// const path = require('path');
// const fs = require('fs');

// const outputDir = path.join(__dirname, 'images');
// const outputVideoPath = path.join(__dirname, 'output.mp4');

// // Create video from images
// async function createVideo() {
//   ffmpeg()
//     .addInput(`${outputDir}/image%03d.jpg`) // Use sequence pattern for images
//     .inputOptions('-framerate 1') // Frame rate: 1 frame per second (adjust as needed)
//     .outputOptions('-c:v libx264') // Codec
//     .outputOptions('-pix_fmt yuv420p') // Pixel format
//     .save(outputVideoPath)
//     .on('end', () => {
//       console.log('Video created successfully!');
//     })
//     .on('error', (err) => {
//       console.error('Error creating video:', err);
//     });
// }

// // Start the process
// createVideo().catch(console.error);