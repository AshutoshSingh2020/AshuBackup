import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { CommonFunctionService } from '@services/common-function.service';

@Component({
  selector: 'app-tracking',
  templateUrl: './tracking.component.html',
  styleUrls: ['./tracking.component.scss'],
  providers: [DatePipe]
})
export class TrackingComponent implements OnInit, OnDestroy {

  dkCols = localStorage.getItem('dkMode') == 'sd-dark' ? true : false;
  dIndex = { deposit: 0, withdraw: 0, bonus: 0 };
  private loaderSubscriber!: Subscription;
  private apiSubscriber: Subscription[] = [];
  maxDate = new Date();
  userWals = JSON.parse(sessionStorage.getItem('WalList'));
  userid = JSON.parse(localStorage.getItem('personalDetails'));
  submitDisabled: string = ''
  dynamicControls = [
    { que: 'trackingDate', type: 'date', defaultDate: this.maxDate, maxDate: this.maxDate, startDate: this.maxDate, subque: [] }
  ];
  currentQuery = { "trackingDate": this.datePipe.transform(this.maxDate, 'YYYY-MM-dd') }
  UserCollumnHeaders: any =
    [
      [{ value: 'S. No.', bg: 'white-drop' },
      { value: 'UserId', bg: 'white-drop' },
      { value: 'UserName', bg: 'white-drop' },
      { value: 'LoginDateTime', bg: 'white-drop' },
      { value: 'TotalBreak', bg: 'white-drop' },
      { value: 'BreakTime', bg: 'white-drop' },
      { value: 'LunchBreak', bg: 'white-drop' },
      { value: 'LogoutTime', bg: 'white-drop' }]
    ];
  AllUserinfo = [];
  UserinfoData = [];
  rowCount = { f: 0, l: 0, t: 0 };
  pageCount = [10, 50, 100, 500, 1000];
  pagesTotal = 1;
  paginatorBlock: any = [];

  UserCollumnLoading = false;
  UserDataCollumns :any[]= [];

  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading: any = {}) => {
      this.UserCollumnLoading = ('getusertrackingdetails' in loading) ? true : false;
    });
    this.GetUserDetails();
  }
  getSearchQuery(formVal: any) {
    this.currentQuery.trackingDate = this.datePipe.transform(formVal.trackingDate.value, 'YYYY-MM-dd');
    this.GetUserDetails();
  }


  GetUserDetails() {
    this.UserinfoData = [];
    this.UserDataCollumns = [];
    this.AllUserinfo = [];

    const queryParams = new URLSearchParams(this.currentQuery).toString();
    const url = `${config['getusertrackingdetails']}?${queryParams}`;

    this.apiSubscriber[1] = this.apiservice.getRequest(url, 'getusertrackingdetails').subscribe(
      (data: any) => {
    this.AllUserinfo = Array.isArray(data) ? data : [];
    if (this.AllUserinfo.length > 0) {
      this.UserDataCollumns = this.UserCollumnHeaders;
      const defaultCellStyle = 'white-cell';
      this.UserinfoData = this.AllUserinfo.map((element: any, index: number) => [
        { value: index + 1, bg: defaultCellStyle },
        { value: element.UserId, bg: defaultCellStyle },
        { value: element.UserName, bg: defaultCellStyle },
        { value: element.LoginDateTime, bg: defaultCellStyle },
        { value: element.TotalBreak, bg: defaultCellStyle },
        { value: element.BreakTime, bg: defaultCellStyle },
        { value: element.LunchBreak, bg: defaultCellStyle },
        { value: element.LogoutTime, bg: defaultCellStyle }
      ]);
      this.rowCount = { f: 1, l: 1, t: this.AllUserinfo.length };
    } else {
      this.rowCount = { f: 0, l: 0, t: 0 };
      this.UserDataCollumns = this.utilities.TableDataNone;
      }
    },
    (error) => {
      console.error(error);
      this.utilities.toastMsg('warning','','Failed to fetch user details. Please try again later.');
    }
    );
  }


  onValueChange(formVal: any) {
    this.GetUserDetails();
  }

  ngOnDestroy() {
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
    if (this.apiSubscriber[1]) {
      this.apiSubscriber[1].unsubscribe();
    }
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
  }

  track(type: string) {
    let param = {
      TrackingType: type
    };
    this.submitDisabled = type;
    const queryParams = new URLSearchParams(param).toString();
    const url = `${config['SaveUserTrackingDetails']}?${queryParams}`;
    this.apiSubscriber[0] = this.apiservice.getRequest(url, 'SaveUserTrackingDetails').subscribe(
      (data: any) => {
        if (data.ErrorCode == '1') {
          this.utilities.toastMsg('success', data.Result, data.ErrorMessage)
          this.submitDisabled = '';
        } else {
          this.utilities.toastMsg('warning', data.Result, data.ErrorMessage)
          this.submitDisabled = '';
        }
      },
      (error) => {
        console.error(`Error tracking ${type}:`, error);
      }
    );
  }
}
