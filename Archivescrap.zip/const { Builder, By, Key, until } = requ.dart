const puppeteer = require('puppeteer');

(async () => {
  // Launch the browser
  const browser = await puppeteer.launch({ headless: false }); // Set headless: true for headless mode
  const page = await browser.newPage();

  // Open the website
  await page.goto('https://hireaxle.live');

  // Fetch an image or any element
//   const imageUrl = await page.evaluate(() => {
//     const imageElement = document.querySelector('img.selector'); // Replace with the actual selector
//     return imageElement ? imageElement.src : null;
//   });

//   console.log('Image URL:', imageUrl);

//   // Fill a form (replace with your form's field selectors and values)
//   await page.type('input[name="fieldName"]', 'sample text'); // Replace with actual selector and text

//   // Click a button (replace with your button's selector)
//   await page.click('button[type="submit"]');

//   // Wait for a specific element to appear (if necessary)
//   await page.waitForSelector('div.success-message'); // Replace with actual selector

  // Close the browser
//   await browser.close();
})();
