const CONFIG = {
    landingUrl:"https://netbanking.hdfcbank.com/netbanking/",
    loginUrl:"https://netbanking.hdfcbank.com/netbanking/",
    corpId: "268993775",
    userId: "268993775",
    password: "Latin@2060",
    otherUrl: "http://yourwebsite.com/otherpage",
    upiid: "anandprecisionengine.36109796@hdfcbank"
  };
  
  module.exports = CONFIG;