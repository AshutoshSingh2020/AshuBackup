const puppeteer = require("puppeteer");
const fs = require("fs");
const path = require("path");
const saveTransactionUrl = "https://91.playludo.app/api/CommonAPI/SavebankTransaction";
const CONFIG = require("./config");
const UpiIdStatusURL = "https://91.playludo.app/api/CommonAPI/GetUpiStatus?upiId=" + CONFIG.upiid;
const UpiIdUpdateURL = "https://91.playludo.app/api/CommonAPI/UpdateDateBasedOnUpi?upiId=" + CONFIG.upiid;
const moment = require('moment');

async function launchBrowser() {
    return await puppeteer.launch({
        headless: false,
        args: ["--disable-infobars", "--no-sandbox", "--disable-setuid-sandbox", "--disable-web-security"],
    });
}
async function configurePage(browser) {
    let page = await browser.newPage();
    await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36");
    await page.setViewport({ width: 1366, height: 768 });
    return page;
}
function log(message) {
    let now = new Date();
    let formattedDate = now.toLocaleString("en-US", {
        month: "long",
        day: "numeric",
        year: "numeric",
        hour: "numeric",
        minute: "numeric",
        second: "numeric",
    });
    let printMessage = `[${formattedDate} - ${CONFIG.upiid}] ${message}`;
    console.log(printMessage);
}
function delaySleep(time) {
    return new Promise(resolve => setTimeout(resolve, time));
}

async function typeIntoElement(page, selectorType, selector, text) {
    let elementHandle;
    if (selectorType === "xpath") {
        const elements = await page.$x(selector);
        elementHandle = elements[0];
    } else if (selectorType === "id") {
        elementHandle = await page.$(`#${selector}`);
    } else if (selectorType === "name") {
        elementHandle = await page.$(`[name=${selector}]`);
    } else {
        throw new Error(`Unsupported selector type: ${selectorType}`);
    }
    if (elementHandle) {
        for (const char of text) {
            await elementHandle.type(char, { delay: getRandomDelay() });
        }
    } else {
        throw new Error(`No element found for ${selectorType}: ${selector}`);
    }
}
async function clickElementByXPath(page, xpath) {
    const elements = await page.$x(xpath);
    if (elements.length > 0) {
        await elements[0].click();
    } else {
        throw new Error(`No element found to click for XPath: ${xpath}`);
    }
}
async function clickButtonById(page, id) {
    await page.waitForSelector(`#${id}`, { timeout: 10000 });
    await page.click(`#${id}`);

    console.log(`Clicked element with ID: ${id}`);
}
async function checkCheckbox(page, selector) {
    console.log("Page in class" + page)
    await page.waitForSelector(selector, { timeout: 10000 });
    const checkbox = await page.$(selector);
    const isChecked = await page.evaluate(el => el.checked, checkbox);
    if (!isChecked) {
        await checkbox.click();
        console.log('Checkbox was not checked, now checked.');
    } else {
        console.log('Checkbox is already checked.');
    }
}
async function clickElementByClass(page, className) {
    await page.waitForSelector(`${className}`, { timeout: 10000 });
    const elements = await page.$(className);
    if (elements) {
        await elements.click();
    } else {
        console.error(`No elements found with class: ${className}`);
    }
}
function getRandomDelay() {
    return Math.floor(Math.random() * (300 - 100 + 1)) + 100;
}

async function selectNthOptionFromDropdown(page) {
    const dropdownSelector = '.dropdown.dropdown-ms';
    try {
        await page.waitForSelector(dropdownSelector, { visible: true, timeout: 20000 });
        const dropdown = await page.$(dropdownSelector);
        if (dropdown) {
            await dropdown.click();
            console.log('Dropdown opened.');
            const className = '.ui-select-choices-row-inner';
            await page.waitForSelector(className, { timeout: 10000 });
            const elements = await page.$$(className);
            console.log(elements)
            if (elements.length > 0) {
                await elements[0].click();
                console.log(`Clicked the first element with class: ${className}`);
            } else {
                console.error(`No elements found with class: ${className}`);
            }
        } else {
            console.error('Dropdown not found.');
        }
    } catch (error) {
        console.error(`Error selecting the ${n}th option from the dropdown:`, error);
    }
}
async function GetBankStatusViaUPIId() {
    try {
        log("Checking UPI status...");
        const response = await fetch(UpiIdStatusURL);
        if (!response.ok) throw new Error('Network response was not ok');
        const APIresponse = await response.json();
        log(JSON.stringify(response));
        if (APIresponse) {
            return APIresponse.Result;
        } else {
            return "2";
        }
    } catch (error) {
        return "2";
    }
}
async function getTableData(page) {
    const tableSelector = '.borderless.table-striped.mob-table tbody';

    try {
        await page.waitForSelector(tableSelector, { visible: true, timeout: 10000 });

        const tableData = await page.evaluate((selector, config) => {
            const rows = Array.from(document.querySelectorAll(`${selector} tr`));
            return rows.map(row => {
                const cells = Array.from(row.querySelectorAll('td'));

                const leftSection = cells[0].querySelector('.left-section').innerHTML;
                function cleanHTML(html) {
                    let cleanedHtml = html.replace(/<\/?p[^>]*>/g, '');
                    return cleanedHtml.trim();
                }

                const cleanedLeftSection = cleanHTML(leftSection);
                const [createdDate, description, refNumber] = cleanedLeftSection.split(/<br\s*\/?>/).map(val => val.trim().replace(/"/g, ''));
                const fullText = cells[0].textContent.trim();
                const amountMatch = fullText.match(/₹\s*([\d,]+(\.\d{1,2})?)/);
                let amount = amountMatch ? amountMatch[1] : '';

                const balanceMatch = fullText.match(/Balance:\s*₹\s*([\d,]+(\.\d{1,2})?)/);
                let accountBalance = balanceMatch ? balanceMatch[1] : '';

                return {
                    Description: refNumber ? refNumber + ' - ' + description : description,
                    CreatedDate: createdDate || '',
                    Amount: amount || '',
                    RefNumber: refNumber ? refNumber + ' ' + description : description,
                    AccountBalance: accountBalance || '',
                    BankName: "HDFC - " + config.corpId,
                    UPIId: "",
                    BankLoginId: config.corpId
                };
            });
        }, tableSelector, CONFIG);

        const tableDataJson = JSON.stringify(tableData, null, 2);
        return tableData;
    } catch (error) {
        console.error('Error fetching table data:', error);
        return null;
    }
}

async function postData(url, data) {
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        });
        const responseData = await response.json();
        return responseData;
    } catch (error) {
        console.error('Error:', error);
    }
}
async function scrollPageDown(page) {
    try {
        await page.evaluate(() => {
            window.scrollBy(0, window.innerHeight);
        });
    } catch (error) {
        console.error('Error scrolling down the page:', error);
    }
}
async function scrollPageUp(page, pixels = 100) {
    try {
        await page.evaluate(pixels => {
            window.scrollBy(0, -pixels);
        }, pixels);
    } catch (error) {
        console.error('Error scrolling up the page:', error);
    }
}
async function logoutFromBank(page) {
    try {
        await delaySleep(6000);
        await clickElementByClass(page, 'btn btn-primary login-btn');
        await delaySleep(6000);
        await clickElementByClass(page, '.btn.btn-primary.nb-logout.yes-btn');
    }
    catch (e) {
        log("logout error : " + e);
    }
}
async function UpiIdDateUpdate() {
    try {
        const response = await fetch(UpiIdUpdateURL);
        if (!response.ok) throw new Error('Network response was not ok');
        const APIresponse = await response.json();
        if (APIresponse && APIresponse.ErrorCode === "1") {
            log("Upi Id update status updated");
            return APIresponse.Result;
        } else {
            log("Failed to Upi Id update date status");
        }
    } catch (error) {
        log("Error from Upi Id update date API:", error.message);
    }
}
async function login(page) {
    await page.goto(CONFIG.loginUrl, { timeout: "120000", waitUntil: 'networkidle2' });
    let url = await page.evaluate(() => document.URL);
    if (url == "https://www.hdfcbank.com/") {
        page.goBack();
        await delaySleep(5000);
    }
    url = await page.evaluate(() => document.URL);
    if (url == "https://www.hdfcbank.com/") {
        page.goBack();
        await delaySleep(5000);
    }
    await page.waitForSelector('frameset');
    const frames = await page.frames();
    const loginFrame = frames.find(frame => frame.name() === 'login_page');

    if (!loginFrame) {
        console.error('Iframe with name "login_page" not found.');
        return;
    }

    await loginFrame.waitForSelector('input[name="fldLoginUserId"]');

    const inputElement = await loginFrame.$('input[name="fldLoginUserId"]');
    if (inputElement) {
        console.log('Input field found in iframe');
        await delaySleep(1000);
        await inputElement.type(CONFIG.corpId);
        await delaySleep(6000);
    } else {
        console.log('Input field not found in iframe');
    }


    await loginFrame.waitForSelector('a.btn.btn-primary.login-btn');
    await delaySleep(6000);
    const buttonElement = await loginFrame.$('a.btn.btn-primary.login-btn');
    await delaySleep(6000);
    if (buttonElement) {
        console.log('Button found in iframe');
        await delaySleep(5000);
        await buttonElement.click();
        await delaySleep(5000);
    } else {
        console.log('Button not found in iframe');
    }

    await delaySleep(1000);
    await typeIntoElement(page, "id", "keyboard", CONFIG.password);
    await delaySleep(6000);
    await checkCheckbox(page, '#secureAccessID');
    await delaySleep(10000);
    await clickButtonById(page, 'loginBtn');
    await delaySleep(6000);
    await clickElementByClass(page, '.fr.text-right');
    await delaySleep(6000);

}

let browser;
async function main() {
    while (true) {
        try {
            if (browser) {
                await browser.close();
            }
            let runCheck = "";
            let runCheck2 = await GetBankStatusViaUPIId();
            if (runCheck2 != "1") {
                log("UPIid is not active.");
                break;
            }
            log("Opening browser...");
            browser = await launchBrowser();
            log("Initializing page...");
            let page = await configurePage(browser);
            log("Initializing login...");
            await login(page);
            await scrollPageDown(page);
            await delaySleep(6000);
            while (true) {
                await selectNthOptionFromDropdown(page);
                await delaySleep(6000);
                let runCheck3 = await GetBankStatusViaUPIId();
                if (runCheck3 != "1") {
                    await logoutFromBank(page);
                    log("UPIid is not active.");
                    break;
                }
                log("Initializing txn flow...");
                let jsonData = await getTableData(page);
                console.log(jsonData)
                log("Updating Latest Statement...");
                let saveApiRes = await postData(saveTransactionUrl, jsonData);
                log(JSON.stringify(saveApiRes));
                await UpiIdDateUpdate();
                await scrollPageDown(page);
                await delaySleep(10000);
                await scrollPageUp(page);
                await delaySleep(10000);
                await scrollPageUp(page);
                await delaySleep(10000);
            }
        } catch (error) {
            log("Encountered major error");
            log(error);
            if (page && browser) {
                await logoutFromBank(page);
            }
            delaySleep(10000);
            throw (error);
        }
    }
}

async function runMainSafely() {
    while (true) {
        try {
            await delaySleep(10000)
            console.log("initializing scrapper...");
            await main();
        } catch (error) {
            console.error('An error occurred, restarting main:', error);
        }
    }
}

runMainSafely();