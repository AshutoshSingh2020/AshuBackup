export const environment = {
    production: false,
    //  apiUrl: 'https://91uat.playludo.app/api/'
    apiUrl: 'https://91.playludo.app/api/'
}; 