export const config: any = {
  "emailAuthApi": "HomeApi/LoginAuth",
  "loginApi": "HomeApi/UserLogin",
  "getAdminMenuMappingsData": "UserApi/GetAdminMenuMappingsData",
  "GetDashBoardCount":"DashboardApi/GetDashboardCount",
  "GetDashboardChart":"DashboardApi/GetDashboardDepositChart",
  'GetTopDepositors': 'DashboardApi/GetTopDepositors',
  'GetTopWithdraw': 'DashboardApi/GetTopWithdraw',
  'GetClientGatewayData': 'DashboardApi/GetClientGatewayData',
  "GetPGRefCode":"UserApi/GetRefCode",
  "getpgGraphData":"DashboardApi/BindGraphDateWiseClientGateway",
  'SavePaymentGetway': 'DashboardApi/SavePaymentGetway',
  "ChangeClientPGStatus":"UserApi/ChangeClientPGStatus",
  "ChangeClientPPStatus":"UserApi/ChangeClientPPStatus",
  "ChangeClientPGIPStatus":"UserApi/ChangeClientPGIPStatus",
  "GetPGClientIPList":"UserApi/GetPGClientIPList",
  "SavePaymentGetwayIPAddress":"UserApi/SavePaymentGetwayIPAddress",
  "DeleteClientPGIPStatus":"UserApi/DeleteClientPGIPStatus",

  "GetAdminDetails": "LeadApi/GetAdminDetail",
  "GetLeadClients": "LeadApi/GetLeadClientData",
  "SaveLead": "LeadApi/SaveLead",
  "GetAllLeads": "LeadApi/GetAllLeads",
  "AssignLeadToAdmin": "LeadApi/AssignLeadToAdmin",
  "GetLeadLog": "LeadApi/GetLeadLog",
  "UploadBulkLead": "LeadApi/UploadBulkLead",
  "UploadBulkTrx": "UserAPI/UploadBulkBankTransactions",//bank/bulktrx
  "GetLeadPerformer": "LeadApi/GetLeadPerformer",
  "GetAgentTiming": "LeadApi/GetAgentTiming",
  "GetMyLeads": "LeadApi/GetMyLeads",
  "GetRefCode": "LeadApi/GetRefCode",
  "SaveLeadLog": "LeadApi/SaveLeadLog",
  'ChangePassword': 'UserApi/ChangePassword',
  "GetLeadDashhboard": "LeadApi/GetLeadDashhboard",
  "GetRegisterLead": "LeadApi/GetRegisterLead",

  'GetDeposits':'dashboardApi/GetDeposits',
  'GetSettlement':'dashboardApi/GetSettlement',
  'GetChargebackList':'dashboardApi/GetChargebackList',
  'DownLoadDepositExcel':'dashboardApi/DownLoadDepositExcel',
  'DownLoadStatementExcel':'dashboardApi/DownLoadStatementExcel',
  'MakeCallBackAllClient':'api/OtherApi/MakeCallBackAllClient',
  'TransferFund':'dashboardApi/TransferFund',

  "getAllPlayer" : "UserApi/GetAllPlayer",
  "getUserData" : "UserApi/GetUserData",
  "hasDepositAccess" : "UserApi/HasDepositAccess",
  "getUserDepositeData" : "UserApi/GetUserDepositeData",
  "getUserStatement": "UserApi/GetUserStatement",
  "getUserWithdrawal" : "UserApi/GetUserWithdrawData",
  "getGamePlayed" : "UserApi/getGamePlayed",
  "getCallLog" : "UserApi/GetCallBackRequestList",
  "getOnlineDepositList" : "UserApi/GetOnlineDepositList",
  "changeUserStatus" : "UserApi/ChangeUserStatus",
  "updateUserAccount" : "UserApi/UpdateUserAccount",
  "exportDepositAndWithdrawal": "UserApi/ExportDepositAndWithdrawal",
  "exportStatement": "UserApi/ExportStatement",
  "getAdminRoles": "UserApi/GetAdminRolesData",
  "getAdminAssignMenu": "UserApi/GetAdminAssignMenu",
  "getAllAdmins": "UserApi/GetAllAdmins",
  "saveRoleChange": "UserApi/SaveRoleChange",
  "saveBlockAdmin": "UserApi/SaveBlockAdmin",
  "saveIMPSAccess": "UserApi/SaveIMPSAccess",
  "blockaccess": "UserApi/SaveActiveBlockAccess",
  'saveDepositAccess': 'UserApi/SaveDepositAccess',
  "getCallBackRequest": "UserApi/GetCallBackRequest",
  "saveCallRequest": "UserApi/SaveCallRequest",
  "saveUserProfile": "UserApi/SaveUserProfile",
  "withdrawalData": "UserApi/WithdrawalData",
  "saveAdminProfile":"UserApi/SaveAdminProfile",

  "getPayoutProviders":"withdrawal/GetPGPayoutProviderData",// withdrawal Page
  "getSafeXPayBalance":"UserApi/GetSafeXPayBalance",// withdrawal Page
  "otpOpenMoney":"withdrawal/InitiateOtpViaOpenMoney",// withdrawal Page
  "trxOpenMoney":"withdrawal/TransferFundsPlayerViaOpenMoney",// withdrawal Page
  "otpOpenMoneyRoyal":"withdrawal/InitiateOtpViaOpenMoneyRoyal",// withdrawal Page
  "trxOpenMoneyRoyal":"withdrawal/TransferFundsPlayerViaOpenMoneyRolyal", // withdrawal Page
  "trxVader":"withdrawal/TransferFundsPlayerViaVaderPay",// withdrawal Page
  "exportWithdrawalData":"withdrawal/ExportWithdrawalData",// withdrawal Page
  "getIPData":"UserApi/GetAdminIPAddress",//ip listing
  "updateIPData":"Userapi/UpdateAdminIPAddress",//ip listing
  "removeIP":"Userapi/RemoveAdminIPAddress",//ip listing
  "saveIP":"Userapi/SaveAdminIPAddress",//ip listing

  "GetBankTransaction": "UserApi/GetBankTransaction",//banktransaction
  "SaveBankTransaction": "UserApi/SaveBankTransaction",//banktransaction
  "setBTrxDesc":"UserApi/UpdateBankTransactionDescription",//banktransaction
  
  "getAllBanks":"UserApi/GetAllBankDetails",//allbank
  "getBankPercentage":"UserApi/GetAllBankDetailsWithPercentage",//allbank
  "changeUpiStat":"UserApi/ChangeBankUpiStatus",//allbank
  "changeUpiVisibility":"UserApi/ChangeBankUpiIsVisible",//allbank
  "getBankSummary":"UserApi/GetBankUPIPercentageSummaryViaUPI",//allbank
  "getBClientList":"UserApi/GetBankClientList",//allbank
  "addToBClient":"UserApi/AddBankClientMapping",//allbank
  "delFromBClient":"UserApi/RemoveBankClientMapping",//allbank
  "getBClientStat":"UserApi/GetBankClientStatus",//allbank

  "getPGMaster":"UserApi/GetPaymentGatewayMasterDetails",//pgmaster
  "setPGStat":"UserApi/ChangePaymentGatewayStatus",//pgmaster
  "saveNewPGMaster":"UserApi/SavePaymentGatewayMasterDetails",//pgmaster

  "getPayoutList":"UserApi/GetClientPayoutWithoutBalanceList",//client-payout
  "getPayoutData":"UserApi/GetClientPayout",//client-payout
  "getPayoutDropdown":"UserApi/GetClientPayoutList",//client-payout
  "getWithdrawBank":"UserApi/GetActiveWithdrawBankDetails",//client-payout
  "getPGPayoutProvider":"UserApi/GetPGPayoutProviderData",//client-payout
  "getSafeXPayBal":"UserApi/GetSafeXPayBalance",//client-payout
  "dlCPayout":"UserApi/ExportClientPayout",//client/client-payout

  "doCallback":"UserApi/CallbackClientTransaction",//client-deposit
  "expCDeposit":"UserApi/ExportClientDeposit",//client-deposit

  "getClientDeposit":"UserApi/GetClientDeposit",//client-deposit client-add-deposit
  "editCbackTrx":"UserApi/EditCallbackClientTransaction",//client-add-deposit

  "userVerifications":"UserApi/GetUserVarificationData",//uservarification
  "blockUserUPI": "UserApi/BlockUPI",//uservarification

  "getPGMstData": "UserApi/GetPGPaymentGatewayMasterDetails",//client/pg-master
  "changePGStatus": "UserApi/ChangePGPaymentGatewayStatus",//client/pg-master
  "savePGDetails": "UserApi/SavePGPaymentGatewayMasterDetails",//client/pg-master

  "getClientRoles":"UserApi/GetClientRoleList",//client/client-pg-user
  "getClients":"UserApi/GetClientList",//client/client-pg-user
  "getClientAdmins":"UserApi/GetClientAdminData",//client/client-pg-user
  "changeAdminStatus":"UserApi/ChangeAdminStatus",//client/client-pg-user
  "saveClientUser":"UserApi/SaveClientUser",//client/client-pg-user
  "clientPayoutProviderReset":"payout/ClientPayoutProviderReset",//client/client-pg-user

  "getPayoutBal":"UserApi/GetPayoutBalance",//client/payout-balance
  "getClientPayoutList":"UserApi/GetClientPayoutList",//client/payout-balance
  "savePayoutBal":"UserApi/SavePayoutBalance",//client/payout-balance
  
  "getClientRecon":"UserApi/GetClientReconciliation",//reconciliation/recon
  "downLoadWithdraw":"UserApi/DownLoadExcelWithdrawal",//reconciliation/recon

  "getTally":"UserApi/GetTallyRecords",//reconciliation/tally
  "saveTally":"UserApi/SaveTally",//reconciliation/tally

  "dlPaykunPmt":"UserApi/DownloadPaymentPaykun",//reconciliation/pay-gate

  "dlDailyUserActWGame":"UserApi/DownLoadADailyUserAcivityWithGame",//reconciliation/download
  "dlGamesAct":"UserApi/DownloadGameAcivity",//reconciliation/download
  "dlAllPGdata":"UserApi/DownLoadAllPaymentGatewayExcell",//reconciliation/download
  "dlAllPOdata":"UserApi/DownLoadAllPayoutExcell",//reconciliation/download

  "getClientCb":"UserApi/GetClientChargeback",//dashboard/chargeback
  "dlClientCb":"UserApi/ExportClientChargeback",//dashboard/chargeback
  "makeCBReq":"UserApi/MakeChargebackRequest",//dashboard/chargeback

  "getWD":"UserApi/GetWithdraw",//dashboard/addclientpayout
  "submitWdReq":"UserApi/SubmitWithdrawalRequest",//dashboard/addclientpayout

  "getRefCodelead":"LeadApi/GetRefCode",//dashboard/bdpginfo
  "getDataBDCG":"UserApi/GetBDClientGatewayData",//dashboard/bdpginfo
  "getGraphBDCG":"UserApi/BindBDGraphDateWiseClientGateway",//dashboard/bdpginfo
  "dlBDCGPayIn":"UserApi/DownLoadAllBDPaymentGatewayExcell",//dashboard/bdpginfo
  "dlBDCGPayOut":"UserApi/DownLoadAllBDPayoutExcell",//dashboard/bdpginfo
  "saveBDCG":"UserApi/SaveBDPaymentGetway",//dashboard/bdpginfo
  "changeBDCPP":"UserApi/ChangeBDClientPPStatus",//dashboard/bdpginfo
  "changeBDCPG":"UserApi/ChangeBDClientPGStatus",//dashboard/bdpginfo

  "getPayClicks":"UserApi/GetPaymenntClickData",//users/payment-click
  "blockUserPayment":"UserApi/BlockUserTrypayment",//users/payment-click

  "getBDBankTrx":"UserApi/GetBDBankTransaction",//bd-bank/bd-bank-trx
  "saveBDBankTrx":"UserApi/SaveBDBankTransaction",//bd-bank/bd-bank-trx

  "getBDDailyTrx":"UserApi/GetBDDailyBankTransaction",//bd-bank/bd-daytrx
  "exportBDDailyTrx":"UserApi/ExportBDDailyBankTransaction",//bd-bank/bd-daytrx

  "dlUserDeposits":"UserApi/DownloadUserDepositData",//dashboard/index
  "dlUserWithdraws":"UserApi/DownloadUserWithdrawData",//dashboard/index
  "dlUserBnusDeposits":"UserApi/DownloadUserBonusDepositData",//dashboard/index

  "okWithdrawal":"withdrawal/ApproveWithdrawal",//users/withdrawal-request
  
  'transferFundViaPayconnect':'UserApi/TransferFundsWithOtpPlayer', //users/approval-BankDetailsComponent
  'initiateOtp':'UserApi/InitiateOtp', //users/approval-BankDetailsComponent
  'trxFundsViaPMR':'withdrawal/TransferFundsPlayerViaPayMyRecharge', //users/approval-BankDetailsComponent
  'transferFundsWithOtpPlayerV1':'UserApi/TransferFundsWithOtpPlayerV1', //users/approval-BankDetailsComponent
  'transferUserFundsUsingVaderPay':'UserWithdrawal/TransferUserFundsUsingVaderPay', //users/approval-BankDetailsComponent
  'setCPayout':'payout/ApproveClientPayout', //client/payout

  'initiateOtpV1':'UserApi/InitiateOtpV1', //users/approval-BankDetailsComponent

  'approveClientPayout':'UserApi/ApproveClientPayout', //client/approval-BankDetailsComponent
  // 'transferFundsUsingPayMyRecharge':'UserApi/TransferFundsUsingPayMyRecharge', //client/approval-BankDetailsComponent
  'transferFundsUsingPayMyRecharge':"payout/TransferFundsPlayerViaPayMyRecharge", //client/approval-PMR
  'approveClientPayoutV1':'UserApi/ApproveClientPayoutV1', //client/approval-BankDetailsComponent
  'transferClientFundsUsingVaderPay':'UserWithdrawal/TransferClientFundsUsingVaderPay', //client/approval-BankDetailsComponent
  'updatePayoutData':'UserApi/UpdatePayoutData', //client/approval-BankDetailsComponent
  'trxWDviaPFSASPay':'withdrawal/TransferFundsPlayerViaPFSASPay',
  'statWDviaPFSASPay':'withdrawal/CheckStatusTransferFundsPlayerViaPFSASPay',
  'trxPayoutViaPFSASPay':'payout/TransferFundsPlayerViaPFSASPay',
  'statTrxPFSASPay':'payout/CheckStatusTransferFundsPlayerViaPFSASPay',
  'trxPayoutQTPPay':'payout/TransferFundsPlayerViaQTPPay',//payout/qtppay
  'statPayoutQTPPay':'payout/CheckStatusTransferFundsPlayerViaQTPPay',//payout/qtppay
  'trxWDQTPPay':'withdrawal/TransferFundsPlayerViaQTPPay',//wdraw/qtpay
  'statWDQTPPay':'withdrawal/CheckStatusTransferFundsPlayerViaQTPPay',//wdraw/qtpay

  'downLoadAllPaymentGatewayExcell':'UserApi/DownLoadAllPaymentGatewayExcell', //dashboard/payment-gateway /pg-data
  'downLoadAllPayoutExcell':'UserApi/DownLoadAllPayoutExcell', //dashboard/payment-gateway /pg-data

  'processWithdrawal':'UserApi/ProcessWithdrawal', //user/withdrawal-request
  'negativeWithdrawalData':'UserApi/NegativeWithdrawalData', //user/ negative-withdrawal-request
  'exportNegativeWithdrawalData':'UserApi/ExportNegativeWithdrawalData', //user/ negative-withdrawal-request
  'clientWithdrawalProviderReset':'withdrawal/ClientWithdrawalProviderReset', //user/ negative-withdrawal-request

  'updateBankUPIDescription':'UserApi/UpdateBankUPIDescription', //user/ negative-withdrawal-request
  'getAllAffiliate':'UserApi/GetAllAffiliate', //user/ negative-withdrawal-request
  'saveBlockAffiliate':'UserApi/SaveBlockAffiliate', //modules/ affiliate
  'saveAffiliate':'UserApi/SaveAffiliate', //modules/ affiliate
  'getUsersListBlock':'UserApi/GetUsersListBlock', //modules/ users/ blocked-users
  'getRegisterUser':'UserApi/GetRegisterUser', //modules/ report/ register-users
  'downloadAllReportData':'UserApi/DownloadAllReportData', //modules/ report/ register-users
  'exportBankTransaction':'UserApi/ExportBankTransaction', //modules/ report/ register-users
  'changeBDBankTransactionStatus':'UserApi/ChangeBDBankTransactionStatus', //modules/ bd-bank
  'exportBDBankTransaction':'UserApi/ExportBDBankTransaction', //modules/ bd-bank
  'getBDAllBankDetails':'UserApi/GetBDAllBankDetails', //modules/ bd-bank
  'changeBDBankUpiStatus':'UserApi/ChangeBDBankUpiStatus', //modules/ bd-bank
  'changeBDBankUpiIsVisible':'UserApi/ChangeBDBankUpiIsVisible', //modules/ bd-bank
  'getBDBankAppNotification':'UserApi/GetBDBankAppNotification', //modules/ bd-bank
  'getBDClientDeposit':'UserApi/GetBDClientDeposit', //modules/ bd-client
  'bDCallbackClientTransaction':'UserApi/BDCallbackClientTransaction', //modules/ bd-client
  'getBDClientPayout':'UserApi/GetBDClientPayout', //modules/ bd-client
  'bdresetpayout':'payout/BDClientPayoutProviderReset', //modules/ bd-client
  
  'editCallbackBDClientTransaction':'UserApi/EditCallbackBDClientTransaction', //modules/ bd-client
  'updateBDPayoutData':'UserApi/UpdateBDPayoutData', //modules/ bd-client
  'getGameList':'UserApi/GetGameList', //modules/ game-list
  'updateGameDetail':'UserApi/UpdateGameDetail', //modules/ game-list
  'getAllPlayerForEdit':'UserApi/GetAllPlayerForEdit', //modules/ game-list
  'editPlayerDetails':'UserApi/EditPlayerDetails', //modules/ game-list
  'resetPassword':'UserApi/ResetPassword', //modules/ game-list
  'editGameDetails':'UserApi/EditGameDetails', //modules/ game-list

  'getPGFrauds':'UserApi/GetPGFraudDetectionList', //security/pgfraud-check
  'setPGFrauds':'Userapi/BlockPGFraudDetectionStatus', //security/pgfraud-check
  'riskInvestigation':'UserApi/RiskInvestigation', //security/pgfraud-check
  'resetStatus':'Userapi/ResetClientDepositStatus', //client/add-deposits,
  'payoutStatustoPending':"payout/ClientPayoutChangeStatustoPending", // client/clientpayout

  'transferFundsPlayerViaSafeXPay':"payout/TransferFundsPlayerViaSafeXPay", // client/clientpayout
  'checkStatusTransferFundsPlayerViaSafeXPay':"payout/CheckStatusTransferFundsPlayerViaSafeXPay", // client/clientpayout
  'withtransferFundsPlayerViaSafeXPay':"withdrawal/TransferFundsPlayerViaSafeXPay", // client/clientpayout
  'withcheckstaussafex':"withdrawal/CheckStatusTransferFundsPlayerViaSafeXPay", //whithdrawl
  'infinityPay':"payout/TransferFundsPlayerViaInfinityitPay", // client/clientpayout
  'withinfinitypay':"withdrawal/TransferFundsPlayerViaInfinityitPay", // withdrawal/
  'transferFundkavach':"payout/TransferFundsPlayerViaTrueKavach", // client/
  'checkStauskavach':"payout/CheckStatusTransferFundsPlayerViaTrueKavach", // client/
  'withtransferkavach':"withdrawal/TransferFundsPlayerViaTrueKavach", // withdrawal/
  'withcheckstatuskavach':"withdrawal/CheckStatusTransferFundsPlayerViaTrueKavach", // withdrawal/
  'transferFundPlanetC':"payout/TransferFundsPlayerViaPlanetC", // client/
  'checkStausPlaneC':"payout/CheckStatusTransferFundsPlayerViaPlanetC", // client/
  'withtransferPlanetC':"withdrawal/TransferFundsPlayerViaPlanetC", // withdrawal/
  'withcheckstatusPlanetC':"withdrawal/CheckStatusTransferFundsPlayerViaPlanetC", // withdrawal/ 
  'transferFundRakPay':"payout/TransferFundsPlayerViaRAKPayout", // client/
  'checkStausRakPay':"payout/CheckStatusTransferFundsPlayerViaRAKPayout", // client/
  'withtransferRakPay':"withdrawal/TransferFundsPlayerViaRAKPayout", // withdrawal/
  'withcheckstatusRakPay':"withdrawal/CheckStatusTransferFundsPlayerViaRAKPayout", // withdrawal/ 

  'withdrawlInvestigation':"UserApi/GetUserWSWithdrawalInvestigate", // playerDetails/ 
  'transferZookPay':"payout/TransferFundsPlayerViaZookPay", // playerDetails/ 
  'transferCheckZookPay':"payout/CheckStatusTransferFundsPlayerViaZookPay", // playerDetails/ 
  'withdrawlZookPay':"withdrawal/TransferFundsPlayerViaZookPay", // playerDetails/ 
  'withdrawlCheckZookPay':"withdrawal/CheckStatusTransferFundsPlayerViaZookPay", // playerDetails/ 
  
  'tranferViaPayatom':"payout/BDTransferFundsPlayerViaPayAtom", // bdpayout/
  'checkViaPayatom':"payout/BDCheckStatusTransferFundsPlayerViaPayAtom", // bdpayout/ 
  'bdagentpay':"payout/BDTransferFundsPlayerViaAgentPay", // bdpayout/ 
  'exportBdClientPayout_Download':"UserAPI/DownLoadExcelBDClientPayout", // bdpayout/ 
  'exportBdClientdeposit':"UserAPI/DownLoadBDClientDeposit", // bdpdeposit/

  'bdbankList':"userapi/GetBDBankClientList", // bdallbank/ 
  'addbdbankList':"userapi/AddBDBankClientMapping", // bdallbank/ 
  'removebdbankList':"userapi/RemoveBDBankClientMapping", // bdallbank/ 

  'upiList':"UserApi/GetBDBankUPIList", // bdallbank merchant/ 
  'listViewMerchant':"UserApi/GetBDMerchantUPILevelMappingList", // bdallbank merchant/ 
  'labalList':"UserApi/GetLevelNameList", // bdallbank merchant/ 
  'addLevel':"UserApi/AddBDMerchantUPILevelMapping", // bdallbank merchant/ 
  'removeLevel':"UserApi/RemoveBDMerchantUPILevelMapping", // bdallbank merchant/ 


  'bdClientSupport':"UserApi/UpdateBDWithdrawAccountWallet", // bd bank support/ 
  'bdClientSupportSatus':"UserApi/UpdateStatusBDPPWithdraw", // approve support/ 
  'depositutrVia':"UserAPI/UpdateDepositUTRViaSMSLog", // client deposit/ 
  'banksmslog':"UserApi/GetAllSmsLog", // client deposit/ 
  'viewSms':"UserApi/ViewSmsLog", // client deposit/ 
  'bankupiList':"UserApi/GetActiveBankUPIList", // client deposit/ 
  'missingDeposit':"UserApi/GetMissingUserDeposit", // client  Missing deposit/ 
  'changeStatus':"UserApi/MissingUserDepositStatusChange", // client Missing deposit/ 

  'addBeneficialy':"UserAPI/SaveBeneficiaryBankMappingWithBankId", // Bank Transfer Add/ 
  'beneficiaryList':"UserAPI/GetActiveBeneficiaryBankList", // Bank Transfer Add/ 
  'saveAutoTransfer':"UserApi/SaveAutoTransferBeneficiary", // Bank Transfer Add/ 
  'getAutoTransfer':"UserApi/GetAutoTransferBeneficiaryDetails", // Bank Transfer Add/ 
  'getAllTransfer':"UserApi/GetAllBankTransferDetails", // Bank Transfer Add/ 
  'statusChangeBene':"UserApi/UpdateStatusTransferBeneAccount", // Bank Transfer Add/ 
  'beneactive':"UserApi/GetBeneficiaryActiveBankList", // Bank Transfer Add/ 

  'getBDBankTrxOut':"UserApi/GetBDBankTransactionOut", // Bank Transfer Add/ 
  'changeBDBankTransactionOutStatus':"UserApi/ChangeBDBankTransactionOutStatus", // Bank Transfer Add/ 
  'exportBDBankTransactionOut':"UserApi/ExportBDBankTransactionOut", // Bank Transfer Add/ 
  'exchangePayout':"payout/TransferFundsPlayerViaQTPExchPay", // client payout/ 
  'withexchangePayout':"withdrawal/TransferFundsPlayerViaQTPExchPay", // withdraw payout/
  'withinPayPayout':"withdrawal/TransferFundsPlayerViaQueenPay", // withdraw payout/ 
  'inpayPayout':"payout/TransferFundsPlayerViaQueenPay", // client payout/ 

  'walletflowPayout':"withdrawal/TransferFundsPlayerViaWalletflow", // withdraw payout/ 
  'clientWalletflow':"payout/TransferFundsPlayerViaWalletflow", // client payout/ 
  'balanceCheck':"payout/CheckBalanceViaQueenPay", // client payout/ 
  'withRaniPay':"withdrawal/TransferFundsPlayerViaRaniGPay", // withdraw payout/ 
  'clientRaniPay':"payout/TransferFundsPlayerViaRaniGPay", // client payout/ 
  'withSparkPay':"withdrawal/TransferFundsPlayerViaQTPSparkExchPay", // withdraw payout/ 
  'clientSparkPay':"payout/TransferFundsPlayerViaQTPSparkExchPay", // client payout/ 
  'easyPay':"payout/TransferFundsPlayerViaEasyWalletPay", // client payout/ 
  'easyPayStatus':"payout/CheckStatusTransferFundsPlayerViaEasyWalletPay", // client payout/ 
  'withEasyPay':"withdrawal/TransferFundsPlayerViaEasyWalletPay", // withdraw payout/ 
  'withEasyStatusPay':"withdrawal/CheckStatusTransferFundsPlayerViaEasyWalletPay", // withdraw payout/ 

  'viambtPiePay':"withdrawal/TransferFundsPlayerViambtpiePay", // withdraw payout/ 
  'payoutViabti':"payout/TransferFundsPlayerViambtpiePay", // client payout/ 

  'punjikendrapay':"payout/TransferFundsPlayerViapunjikendra", // client payout/ 
  'punjikendrawith':"withdrawal/TransferFundsPlayerViapunjikendra", // withdraw payout/ 
  'punjikendrastatus':"payout/CheckStatusTransferFundsPlayerViapunjikendra", // client payout/ 
  'punjikendrawithstatus':"withdrawal/CheckStatusTransferFundsPlayerViapunjikendra", // withdraw payout/ 

  'Fpay':"payout/TransferFundsPlayerViaFPay", // client payout/ 
  'fpaycheck':"payout/CheckStatusTransferFundsPlayerViaFPay", // withdraw payout/ 
  'withFpay':"withdrawal/TransferFundsPlayerViaFPay", // client payout/ 
  'withfpayCheck':"withdrawal/CheckStatusTransferFundsPlayerViaFPay", // withdraw payout/ 
  'bankfpay':"payout/GetFpayBankId", // withdraw payout/ 
  'clientTransfer':"payout/TransferFundsPlayerViaTransPay", // withdraw payout/ 
  'withdrawTransfer':"withdrawal/TransferFundsPlayerViaTransPay", // withdraw payout/ 

  'clientAuto':"UserApi/UpdateAutoTransferWithdraw", // client payout/ 
  'withdrawAuto':"UserApi/UpdateAutoTransferUserWithdraw", // withdraw payout/ 
  'getUserCount':"UserApi/GetUserCountPerMachine", // userreport
  'userMachine':"UserApi/GetUsersByMachine", // userreport
  'logDetails':"UserApi/GetDailyLoginLogoutTime", // userreport
  'applicationLog':"UserApi/GetActivityCaptureLog", // userreport
  'deactivateuser':"CommonAPI/DeactivateUser", // Deactivateuser
  'machineName':"UserApi/GetMachineDetails", // userreport
  'getUserMachine':"UserApi/GetUserListForMachine", // userreport
  'getClipReport':"UserApi/GetCaptureCopyLog", // userreport
  'getScreenReport':"UserApi/GetAllFileName", // userreport
  'manualApp':"UserApi/UpdateMannualTransferWithdraw", // withdraw payout/ 
  'clientmanualApp':"UserApi/UpdateManulTransferClientpayout", // client payout/ 
  'clientPayout':"payout/TransferFundsPlayerViaPayWaleXPayout", // client payout/ 
  'withDrawPay':"withdrawal/TransferFundsPlayerViaPayWaleXPayout", // with payout/ 
  'getCategoryList':"UserApi/GetCallRequestCategoryList", // with payout/ 
  'getSubCategoryList':"UserApi/GetCallRequestSubCategoryList", // with payout/ 
  'saveConversation':"userapi/SaveCallBackConversation", // with payout/ 
  'reportDetails':"report/DownloadPlayerConversationDetails", // dashboard/ 
  'dashboardChart':"DashboardApi/GetCallBackConversationDashboardDetails", // dashboard/ 
  'workinglog':"UserApi/GetWorkingLog", // dashboard/ 
  'dragonpayPayout':"withdrawal/TransferFundsPlayerViaDragonpayPayout", // dashboard/ 
  'ClientdragonpayPayout':"payout/TransferFundsPlayerViaDragonpayPayout", // dashboard/ 
  'cryptoGet':"DashboardApi/GetCRPClientGatewayData", // dashboard/ 
  'downloadPayIn':"UserApi/DownLoadAllCRPPaymentGatewayExcell", // dashboard/ 
  'downloadPayOut':"UserApi/DownLoadAllCRPPayoutExcell", // dashboard/ 
  'cryptoGraph':"DashboardApi/CRPBindGraphDateWiseClientGateway", // dashboard/ 
  'saveCryptoPg':"DashboardApi/SaveCRPPaymentGetway", // dashboard/ 
  'crpStatus':"UserApi/ChangeCRPClientPGStatus", // crypto pg/ 
  'crppStatus':"UserApi/ChangeCRPClientPPStatus", // crypto pg/ 
  'crpPGIpStatus':"UserApi/ChangeCRPClientPGIPStatus", // crypto pg/ 
  'draganpaycheck':"payout/CheckBalanceViaDragonPay", // dashboard/ 
  'bdpayout':"payout/BDTransferFundsPlayerViaProntoPay", // bd payout/ 
  'sharkPeClient':"payout/TransferFundsPlayerViaSharkPePayout", // bd payout/ 
  'sharkPeClientcheckStatus':"payout/CheckStatusTransferFundsPlayerViaSharkpe", // bd payout/ 
  'withdrawSharkPe':"withdrawal/TransferFundsPlayerViaSharkPePayout", // bd payout/ 
  'withdrawCheckStatuSharkPe':"withdrawal/CheckStatusTransferFundsPlayerViaSharkpe", // bd payout/ 
  "clientPaygateTransfer":"payout/TransferFundsPlayerViaPayGatePayout",
  "clientPaygateCheck":"payout/CheckStatusTransferFundsPlayerViaPayGate",
  "withdrawPaygateTranfer":"withdrawal/TransferFundsPlayerViaPayGatePayout",
  "withdrawPaygateCheck":"withdrawal/CheckStatusTransferFundsPlayerViaPayGate",

  'crpdeposit':"UserApi/GetCRPClientDeposit", // crp-client-deposit
  'downloadcrpdeposit':"UserApi/DownLoadCRPClientDeposit", // crp-client-deposit
  'editCallbackCRP':"UserApi/EditCallbackCRPClientTransaction", // crp-client-deposit
  'trackingproduct':"UserApi/GetAllUserTracking", // user-report productivity 
  'crpClientPayout':"UserApi/GetCRPClientPayout", // crp-client-deposit
  'crpClientExportPayout':"UserApi/ExportCRPClientPayout", // crp-client-deposit
  'progressApi':"UserApi/GetProgressBarData", // crp-client-deposit
  'CryptoWithDraw':"CryptoPayoutApi/CrpPayoutWithdrawRequestCheck", // crp-client-deposit
  'cryptocheckStatus':"CryptoPayoutApi/GetCrpStatusofWithdrawRequest", // crp-client-deposit
  'approvePayment':"CryptoPayoutApi/ApproveCrpClientPayout", // crp-client-deposit
  'cryptoResetpro':"payout/CrpClientPayoutProviderReset", // crp-client-deposit
  'payoutadminBalance':"payout/CrpWalletBalance", // crp-client-deposit


  "GetTransferTransaction":"UserApi/GetTransferTransaction",
  "GetTransactionBanks":"CommonAPI/GetTransactionBanks",
  "GetTransactionType":"CommonAPI/GetTransactionType",
  "SaveTransferTransaction": "UserApi/SaveTransferTransaction",
  "UpdateTransferTransaction": "UserApi/UpdateTransferTransaction",
  "RejectTransferTransaction": "UserApi/RejectTransferTransaction",
  "ApproveTransferTransaction":"FileUpload/ApproveTransferTransaction",
  "Tobank":"CommonAPI/GetTransactionToBanks",


  "UpdateBDWithdrawAccountWalletManual":"UserApi/UpdateBDWithdrawAccountWalletManual",


  "ExportTransferTransaction":"UserApi/ExportTransferTransaction"
}