import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-button-grid-new',
  templateUrl: './button-grid-new.component.html',
  styleUrls: ['./button-grid-new.component.scss']
})
export class ButtonGridNewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
