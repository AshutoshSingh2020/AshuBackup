import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ScreenshotReportComponent } from './screenshot-report/screenshot-report.component';
import { ActivityReportComponent } from './activity-report/activity-report.component';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { WorkingLogComponent } from './working-log/working-log.component';
import { ProductivityReportComponent } from './productivity-report/productivity-report.component';

const routes: Routes = [
{
  path:'dashboard',
  component: UserDashboardComponent
},
{
  path:'screenshotreport',
  component: ScreenshotReportComponent
},
{
  path:'activityreport',
  component: ActivityReportComponent
},
{
  path:'userList/:id',
  component: UserListComponent
},
{
  path:'userdetails/:id',
  component: UserDetailsComponent
},
{
  path:'workinglog',
  component: WorkingLogComponent
},
{
  path:'productivityreport',
  component: ProductivityReportComponent
},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserReportRoutingModule { }
