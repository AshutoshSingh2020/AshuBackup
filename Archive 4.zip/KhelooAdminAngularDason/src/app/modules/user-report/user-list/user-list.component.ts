import { Component, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.scss']
})
export class UserListComponent implements OnInit {
  @ViewChild('confirmpopup') confirmpopup!: TemplateRef<any>;
  AllUserinfo:any=[];
  UserinfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  userData :any =[]
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  dynamicControls = [{changeAction:'submit',type:'select',default:{value:"",name:'All Status'},options:[{value:"Active",name:'Active'},{value:"Inactive",name:'Inactive'}]},
  {placeholder:'Search',type:'text',label:'Search'}
    
  ];
  UserCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Machine Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},{value:'Status',bg:'white-drop'},{value:'View',bg:'white-drop'}]
  ]
  UserDataCollumns=this.UserCollumnHeaders;
  UserCollumnLoading = false;
  machineId:string = '';
  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[1],"MachineName":"","StatusFilter":""};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private route: ActivatedRoute,private dialog:MatDialog) { }
  
  ngOnInit(): void {
    let paramId = this.route.snapshot.paramMap.get('id');
    if(paramId){
      this.machineId =paramId;
      this.GetAllUsers();
    }
  }
  
  initializeData()
  {
    this.UserCollumnLoading = true;
    this.currentQuery.MachineName = this.machineId;
    this.AllUserinfo = [];
    this.UserinfoData = [];
    if(this.apiSubscriber[0]){
      this.apiSubscriber[0].unsubscribe();
    }
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllUsers();
  }
  
  GetAllUsers() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['userMachine'], this.currentQuery).subscribe((data: any) => {
      this.UserCollumnLoading = false;
      this.AllUserinfo=data;
      console.log( this.AllUserinfo);
      if(this.AllUserinfo[0]){
        this.UserDataCollumns=this.UserCollumnHeaders;
        this.pagesTotal=Math.ceil(this.AllUserinfo[0].TotalCount/this.currentQuery.PageSize);
        this.AllUserinfo.forEach((element:any,index:any) => {
          this.UserinfoData.push([
          {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
          {value:element.MachineName,bg:'white-cell'},
          {value:element.UserName,bg:'white-cell'},
          { value:element.isActive == 'true'?'Active' : 'Inactive', bg: 'white-cell' },
          {bg:'white-cell',icon:'Multi',value:[
            ...([{value:'View',bg:'white-cell',icon:'None'}]),
            ...([{value:'Delete user',bg:'white-cell',icon:'None'}]),
          ]}
          
          ])
          
        });
        
        this.rowCount={f:this.UserinfoData[0][0].value,l:this.UserinfoData[this.UserinfoData.length-1][0].value,t:this.AllUserinfo[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.UserDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      this.UserCollumnLoading = false;
      console.log(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  onValueChange(formVal:any){
    if(formVal.type=='View'){
      window.open('/userreport/userdetails/'+this.AllUserinfo[formVal.row].UserName+'#'+this.AllUserinfo[formVal.row].MachineName, '_blank');
    }
    if(formVal.type=='Delete user'){
      this.userData = this.AllUserinfo[formVal.row]
      this.disableuser();
    }
  }
  disableuser(){
    let dialogRef = this.dialog.open(this.confirmpopup, {
      width: '600px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
    
  }
  onSave(){
    this.dialog.closeAll();
    this.GetAllUsers();
  }
  onBack(){
    this.dialog.closeAll();
  }
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.C1;
    this.currentQuery.PageNo = 1;
    this.currentQuery.StatusFilter=formVal.C0;
    this.GetAllUsers();
  }
  ngOnDestroy(): void {
    if(this.apiSubscriber[0]){
      this.apiSubscriber[0].unsubscribe();
    }
  }

}
