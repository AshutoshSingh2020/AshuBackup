import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-working-log',
  templateUrl: './working-log.component.html',
  styleUrls: ['./working-log.component.scss'],
  providers: [DatePipe]
})
export class WorkingLogComponent implements OnInit {
  maxDate = new Date();
  dynamicControls = [
    { que: 'MachineName', changeAction: 'submit', type: 'dropdownVal', default: { name: 'Select Machine', value: '' }, options: [], subque: [] },
    { que: 'UserName', changeAction: 'submit', type: 'dropdownVal', default: { name: 'Select Name', value: '' }, options: [], subque: [] },
    { que: 'Date', type: 'date', 'defaultDate': this.maxDate, maxDate: this.maxDate, subque: [] }
  ];
  startDate = new Date();
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[] = [];
  apiLoader = { cadc_list: false, cpc_list: false };
  rowCount = { f: 0, l: 0, t: 0 };
  rowCount1 = { f: 0, l: 0, t: 0 };
  pageCount = [10, 50, 100, 500, 1000];
  pagesTotal = 1;
  paginatorBlock: any = [];
  allData: any = [];
  tableInfoData: any = [];
  tableCollumns :any =[]
  collumnHeads: any = [
    [{ value: 'Sr. No.', bg: 'white-drop'},
    { value: 'User Name', bg: 'white-drop'},
    { value: 'Working Time', bg: 'white-drop'},
    { value: 'Idle Time', bg: 'white-drop'},
    { value: 'Description', bg: 'white-drop'},
    { value: 'Date', bg: 'white-drop'}]
  ];
  currentQuery = { "PageNo": 1, "PageSize": this.pageCount[1], "StartDateTime":  moment(this.startDate).format('yyyy-MM-DD'),"MachineName": "", "UserName": "" };
  constructor(private apiService: ApiService,private utilities:CommonFunctionService, private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.getAllMachines();
    this.loaderSubscriber = this.apiService.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.cpc_list=('workinglog' in loading)?true:false;
    });
    this.GetMasterData();
  }
  getSearchQuery(formVal: any) {
    this.currentQuery.StartDateTime = this.datePipe.transform(formVal.Date.value, 'yyyy-MM-dd') ;
    this.currentQuery.MachineName = formVal.MachineName.value;
    if(this.currentQuery.MachineName){
      this.getAllUsersByMachine(this.currentQuery.MachineName);
    }
    this.currentQuery.UserName = formVal.UserName.value;
    this.currentQuery.PageNo = 1;
     this.GetMasterData();
  }
  getAllMachines() {
    this.apiService.getRequest(config['machineName'], 'machineName').subscribe({
      next: (res: any) => {
        if (res) {
          res.forEach((element) => {
            this.dynamicControls[0].options.push({ name: element.MachineName, value: element.MachineName });
          });
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }
  getAllUsersByMachine(param:any) {
    this.dynamicControls[1].options = [];
    let data = {"MachineName":param}
    this.apiService.sendRequest(config['getUserMachine'],data, 'getUserMachine').subscribe({
      next: (res: any) => {
        if (res) {
          res.forEach((element) => {
            this.dynamicControls[1].options.push({ name: element.UserName, value: element.UserName });
          });
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }
  setPaginator() {
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
  }
  GetMasterData() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiService.sendRequest(config['workinglog'], this.currentQuery, 'workinglog').subscribe((data: any) => {
      this.allData = data;
      if (this.allData[0]) {
        this.tableCollumns = this.collumnHeads;
        this.pagesTotal = Math.ceil(this.allData[0].TotalCount / this.currentQuery.PageSize);
        let bg_cell = 'white-cell';
        this.allData.forEach((element: any, index: any) => {
          this.tableInfoData.push([
            { value: ((this.currentQuery.PageNo - 1) * this.currentQuery.PageSize) + (index + 1), bg: bg_cell },
            { value: element.UserName, bg: bg_cell },
            { value: element.WorkingTime, bg: bg_cell },
            { value: element.IdleTime, bg: bg_cell },
            { value: element.Description, bg: bg_cell },
            { value: element.CreatedDate ? moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy") : '', bg: bg_cell,},
          ])
        });
        this.rowCount = { f: this.tableInfoData[0][0].value, l: this.tableInfoData[this.tableInfoData.length - 1][0].value, t: this.allData[0].TotalCount };
        this.setPaginator();
      }
      else {
        this.rowCount = { f: 0, l: 0, t: 0 };
        this.tableCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }
  onValueChange(formVal: any) {

  }
  onPaginatorChange(paginatorQuery: any) {
    if (paginatorQuery.action == 'pageSize') {
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if (paginatorQuery.action == 'pageNo') {
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetMasterData();
  }
}
