import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkingLogComponent } from './working-log.component';

describe('WorkingLogComponent', () => {
  let component: WorkingLogComponent;
  let fixture: ComponentFixture<WorkingLogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WorkingLogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(WorkingLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
