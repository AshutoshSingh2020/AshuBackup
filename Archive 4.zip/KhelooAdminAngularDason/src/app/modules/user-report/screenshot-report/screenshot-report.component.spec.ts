import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScreenshotReportComponent } from './screenshot-report.component';

describe('ScreenshotReportComponent', () => {
  let component: ScreenshotReportComponent;
  let fixture: ComponentFixture<ScreenshotReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ScreenshotReportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ScreenshotReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
