import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import { DatePipe } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { CustomImageEvent } from '@hreimer/angular-image-viewer';
@Component({
  selector: 'app-screenshot-report',
  templateUrl: './screenshot-report.component.html',
  styleUrls: ['./screenshot-report.component.scss'],
  providers: [DatePipe]
})
export class ScreenshotReportComponent implements OnInit {
  maxDate=new Date();
  time:any = [
    {name:'00 AM',value:'00:00'},
    {name:'01 AM',value:'01:00'},
    {name:'02 AM',value:'02:00'},
    {name:'03 AM',value:'03:00'},
    {name:'04 AM',value:'04:00'},
    {name:'05 AM',value:'05:00'},
    {name:'06 AM',value:'06:00'},
    {name:'07 AM',value:'07:00'},
    {name:'08 AM',value:'08:00'},
    {name:'09 AM',value:'09:00'},
    {name:'10 AM',value:'10:00'},
    {name:'11 AM',value:'11:00'},
    {name:'12 AM',value:'12:00'},
    {name:'13 PM',value:'13:00'},
    {name:'14 PM',value:'14:00'},
    {name:'15 PM',value:'15:00'},
    {name:'16 PM',value:'16:00'},
    {name:'17 PM',value:'17:00'},
    {name:'18 PM',value:'18:00'},
    {name:'19 PM',value:'19:00'},
    {name:'20 PM',value:'20:00'},
    {name:'21 PM',value:'21:00'},
    {name:'22 PM',value:'22:00'},
    {name:'23 PM',value:'23:00'},
    {name:'23:59 PM',value:'23:59'}
  ];
  dynamicControls = [
    {que:'MachineName',changeAction:'submit',type:'dropdownVal',default:{name:'Select Machine',value:''},options:[],subque:[]},
    {que:'UserName',changeAction:'submit',type:'dropdownVal',default:{name:'Select Name',value:''},options:[],subque:[]},
    {que:'Date',type:'date','defaultDate':this.maxDate,maxDate:this.maxDate,subque:[]},
    {que:'FromTime',type:'dropdownVal',default:this.time[8],options:this.time,subque:[]},
    {que:'ToTime',type:'dropdownVal',default:this.time[17],options:this.time,subque:[]},
];
private loaderSubscriber: Subscription;
private apiSubscriber: Subscription[]=[];
apiLoader={cadc_list:false,cadc_export:false};
rowCount={f:0,l:0,t:0};
  pageCount=[12,60,120,200,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  currentQuery={"PageNo": 1,"PageSize": this.pageCount[0],"StartDateTime": "","EndDateTime": "","MachineName":"","UserName":""};
  cardData:any = [];
  dataSend:any = [];
  @ViewChild('imageDet') imageDet!:TemplateRef<any>;
  constructor(private apiService:ApiService,private datePipe: DatePipe,private dialog:MatDialog) { }

  ngOnInit(): void {
    this.loaderSubscriber = this.apiService.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.cadc_list=('getScreenReport' in loading)?true:false;
    });
    this.getAllMachines();
    this.GetAllData();
  }
    
  getAllMachines(){
    this.apiService.getRequest(config['machineName'],'machineName').subscribe({
      next:(res:any)=>{
        if(res){
          res.forEach((element) => {
            this.dynamicControls[0].options.push({name:element.MachineName,value:element.MachineName});
          });
        }
      },
      error:(err)=>{
        console.error(err);
      }
    });
  }
  getAllUsersByMachine(param:any) {
    this.dynamicControls[1].options = [];
    let data = {"MachineName":param}
    this.apiService.sendRequest(config['getUserMachine'],data, 'getUserMachine').subscribe({
      next: (res: any) => {
        if (res) {
          res.forEach((element) => {
            this.dynamicControls[1].options.push({ name: element.UserName, value: element.UserName });
          });
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }
  GetAllData(){
    this.cardData =[];
    this.apiSubscriber[0] = this.apiService.sendRequest(config['getScreenReport'],this.currentQuery,'getScreenReport').subscribe({
      next:(res:any)=>{
        if(res[0]){
         res.forEach((element:any,index:any)=>{
            element.Id =((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1) 
         });
         this.cardData = res;
         this.pagesTotal=Math.ceil(this.cardData[0].TotalCount/this.currentQuery.PageSize);
          this.rowCount={f:this.cardData[0].Id,l:this.cardData[this.cardData.length-1].Id,t:this.cardData[0].TotalCount};
          this.setPaginator();
        }else{
          this.rowCount={f:0,l:0,t:0};
        }
      },error(err) {
        console.error(err);
      },
    })
  }
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllData();
  }
  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  getSearchQuery(formVal:any)
  {
    this.currentQuery.StartDateTime =this.datePipe.transform(formVal.Date.value,'yyyy-MM-dd')+" "+formVal.FromTime.value+':00.000';
    this.currentQuery.EndDateTime =this.datePipe.transform(formVal.Date.value,'yyyy-MM-dd')+" "+formVal.ToTime.value+':00.000';
   this.currentQuery.MachineName = formVal.MachineName.value;
   if(this.currentQuery.MachineName){
    this.getAllUsersByMachine(this.currentQuery.MachineName);
  }
   this.currentQuery.UserName = formVal.UserName.value;
   this.currentQuery.PageNo = 1;
   this.GetAllData();
  }
  
 downloadImage(imageUrl) {
      fetch(imageUrl, {
          mode: 'cors',
      })
      .then(response => response.arrayBuffer())
      .then(buffer => {
          const base64Flag = 'data:image/jpeg;base64,'; // Adjust the MIME type as necessary
          const imageStr = this.arrayBufferToBase64(buffer);
          const link = document.createElement('a');
          link.href = base64Flag + imageStr;
          link.download = imageUrl.split('/').pop() || 'image';
        link.target = "__blank"
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
      })
      .catch(err => {
          console.error('Error downloading the image:', err);
      });
  }
 arrayBufferToBase64(buffer) {
      let binary = '';
      const bytes = new Uint8Array(buffer);
      const len = bytes.byteLength;
      for (let i = 0; i < len; i++) {
          binary += String.fromCharCode(bytes[i]);
      }
      return window.btoa(binary);
  }
  selected:number = 0;
  imageDe(item:any,i:number){
    this.dataSend = [];
    this.dataSend = item;
    this.selected = i;
   let dialogRef =  this.dialog.open(this.imageDet, {
      width: '900px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.closePopup();
    })
  }
  closePopup(){
    this.dialog.closeAll();
  }
  handleEvent(event: CustomImageEvent) {
    console.log(`${event.name} has been clicked on img ${event.imageIndex + 1}`);

    switch (event.name) {
      case 'print':
        console.log('run print logic');
        break;
    }
}
}
 