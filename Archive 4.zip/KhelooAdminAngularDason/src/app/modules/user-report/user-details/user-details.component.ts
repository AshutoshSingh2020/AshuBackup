import { DatePipe } from '@angular/common';
import { Component, ElementRef, Inject, OnInit, Optional, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.scss'],
  providers: [DatePipe]
})
export class UserDetailsComponent implements OnInit {
  AllUserinfo: any = [];
  UserinfoData: any = [];
  rowCount = { f: 0, l: 0, t: 0 };
  pageCount = [10, 50, 100, 500, 1000];
  pagesTotal = 1;
  paginatorBlock: any = [];
  myDashboardLoading = [false, false];
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[] = [];
  username: string = ''
  machine: string = ''
  isDialog:boolean = false;
  startDate = new Date();
  maxDate = new Date();
  dynamicControls = [
    { que: 'Date', type: 'date', 'defaultDate': this.maxDate, maxDate: this.maxDate, subque: [] },
    // {que:'Search',type:'input',subque:[]}
  ];
  UserCollumnHeaders: any = [
    [{ value: 'Sr. No.', bg: 'white-drop' }, { value: 'Application Name', bg: 'white-drop' }, { value: 'Title', bg: 'white-drop' }, { value: 'Date', bg: 'white-drop' }]
  ]
  UserDataCollumns = this.UserCollumnHeaders;
  UserCollumnLoading = false;
  machineId: string = '';
  currentQuery = { "PageNo": 1, "PageSize": this.pageCount[0], "MachineName": "", "UserName": "", "StartDateTime": moment(this.startDate).format('YYYY-MM-DD') };
  currentQuery2 = {"MachineName": this.machine, "UserName": this.username, "StartDateTime": moment(this.startDate).format('YYYY-MM-DD') };
  currentQuery1 = { "Date": moment(this.maxDate).format('YYYY-MM-DD') };
  
  constructor(private apiservice: ApiService, private route: ActivatedRoute, private utilities: CommonFunctionService, private datePipe: DatePipe,
  
    @Optional() public dialogRef?: MatDialogRef<UserDetailsComponent>,
    @Optional() @Inject(MAT_DIALOG_DATA) public data?: any
  ) { 
      if (data) {
        this.isDialog = true;
        this.username = data.username;
        this.machine = data.machine;
      }
    }

  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading: any = {}) => {
      this.myDashboardLoading[0] = ('logDetails' in loading) ? true : false;
    });
    if(!this.isDialog){
      let paramId = this.route.snapshot.paramMap.get('id');
      let fragment = this.route.snapshot.fragment;
      if (paramId) {
        this.username = paramId;
      }
      if (fragment) {
        this.machine = fragment;
      }
    }
    this.GetProgress();
    this.getAllData();
    this.GetAllUsers();
  }
  dashboardCount = [
    { "name": 'MachineName', "value": '--', "feather": "user-plus", "color": "#7db39f", "isDownload": "N" },
    { "name": 'UserName', "value": '--', "feather": "user-plus", "color": "#7db39f", "isDownload": "N" },
    { "name": 'Login Time', "value": '--', "feather": "user-plus", "color": "#7db39f", "isDownload": "N" },
    { "name": 'Logout Time', "value": '--', "feather": "user-plus", "color": "#7db39f", "isDownload": "N" },
    { "name": 'Last Track Time', "value": '--', "feather": "user-plus", "color": "#7db39f", "isDownload": "N" },
    { "name": 'Working Time', "value": '--', "feather": "clock", "color": "#009E60", "isDownload": "N" },
    { "name": 'Idle Time', "value": '--', "feather": "clock", "color": "#D22B2B", "isDownload": "N" },
    { "name": 'Total Track Time', "value": '--', "feather": "clock", "color": "#7db39f", "isDownload": "N" }
  ];
  tabsdata() {
    return this.dashboardCount
  }
  getAllData() {
    let param = { "MachineName": this.machine, "UserName": this.username, "Date": moment(this.currentQuery1.Date).format('YYYY-MM-DD') };
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['logDetails'], param, 'logDetails').subscribe((data: any) => {
      data.forEach((depositElement: any, index: any) => {
        this.dashboardCount[0].value = depositElement.MachineName ? depositElement.MachineName : '--'
        this.dashboardCount[1].value = depositElement.UserName ? depositElement.UserName : '--'
        this.dashboardCount[2].value = depositElement.LoginTime ? moment(depositElement.LoginTime).format('YYYY-MM-DD HH:mm') : '--'
        this.dashboardCount[3].value = depositElement.LastTrackingTime ? moment(depositElement.LastTrackingTime).format('YYYY-MM-DD HH:mm') : '--'
        this.dashboardCount[4].value = depositElement.LastTrackingTime ? moment(depositElement.LastTrackingTime).format('YYYY-MM-DD HH:mm') : '--'
        this.dashboardCount[5].value = depositElement.WorkingTime ? depositElement.WorkingTime : '00:00:00'
        this.dashboardCount[6].value = depositElement.IdleTime ? depositElement.IdleTime : '00:00:00'
        this.dashboardCount[7].value = depositElement.TotalTrackingTime ? depositElement.TotalTrackingTime : '00:00:00'
      });
    });
  }
  onValueChange(formVal: any) {
  }
  getSearchQuery(formVal: any) {
    this.currentQuery1.Date = moment(formVal.Date.value).format('YYYY-MM-DD');
    this.currentQuery.StartDateTime = moment(formVal.Date.value).format('YYYY-MM-DD');
    this.currentQuery2.StartDateTime = moment(formVal.Date.value).format('YYYY-MM-DD');

    this.getAllData();
    this.GetAllUsers();
    this.renderChart();
  }
  initializeData() {
    this.UserCollumnLoading = true;
    this.currentQuery.MachineName = this.machine;
    this.currentQuery.UserName = this.username;
    this.AllUserinfo = [];
    this.UserinfoData = [];
    if (this.apiSubscriber[1]) {
      this.apiSubscriber[1].unsubscribe();
    }
  }

  onPaginatorChange(paginatorQuery: any) {
    if (paginatorQuery.action == 'pageSize') {
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if (paginatorQuery.action == 'pageNo') {
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllUsers();
  }

  GetAllUsers() {
    this.initializeData();
    this.apiSubscriber[1] = this.apiservice.sendRequest(config['applicationLog'], this.currentQuery).subscribe((data: any) => {
      this.UserCollumnLoading = false;
      this.AllUserinfo = data;
      if (this.AllUserinfo[0]) {
        this.UserDataCollumns = this.UserCollumnHeaders;
        this.pagesTotal = Math.ceil(this.AllUserinfo[0].TotalCount / this.currentQuery.PageSize);
        this.AllUserinfo.forEach((element: any, index: any) => {
          this.UserinfoData.push([
            { value: ((this.currentQuery.PageNo - 1) * this.currentQuery.PageSize) + (index + 1), bg: 'white-cell' },
            { value: element.Process, bg: 'white-cell' },
            { value: element.WindowTitle, bg: 'white-cell' },
            { value: element.CreatedDate ? moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy") : '', bg: 'white-cell' },
          ])
        });
        this.rowCount = { f: this.UserinfoData[0][0].value, l: this.UserinfoData[this.UserinfoData.length - 1][0].value, t: this.AllUserinfo[0].TotalCount };
        this.setPaginator();
      }
      else {
        this.rowCount = { f: 0, l: 0, t: 0 };
        this.UserDataCollumns = this.utilities.TableDataNone;
      }
    }, (error) => {
      this.UserCollumnLoading = false;
      console.log(error);
    });
  }

  setPaginator() {
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  //chart showing
  @ViewChild('chart', { static: true }) chart!: ElementRef;
  svgWidth = 1350;
  svgHeight = 120;
  barHeight = 30;
  timeData:any =  []
  GetProgress(){ 
    this.currentQuery2.UserName = this.username;
    this.currentQuery2.MachineName = this.machine;
    this.apiSubscriber[2] = this.apiservice.sendRequest(config['progressApi'], this.currentQuery2,'progressApi').subscribe({
      next:(data)=>{
        this.timeData = data;
        this.renderChart();
      },
      error(err){
        console.error(err);
      }
    });
  }
  timeToMinutes(time: string) {
    const [hours, minutes] = time.split(':').map(Number);
    return hours * 60 + minutes;
  }

  // getScaledData() {
  //   const minTime = Math.min(...this.timeData.map(d => this.timeToMinutes(d.start)));
  //   const maxTime = Math.max(...this.timeData.map(d => this.timeToMinutes(d.end)));

  //   return this.timeData.map((d, index) => ({
  //     ...d,
  //     x: ((this.timeToMinutes(d.start) - minTime) / (maxTime - minTime)) * this.svgWidth,
  //     width: ((this.timeToMinutes(d.end) - this.timeToMinutes(d.start)) / (maxTime - minTime)) * this.svgWidth,
  //     color: d.name === 'Working' ? '#28a745' : '#dc3545',
  //     showStartTime: index === 0
  //   }));
  // }
  getScaledData() {
    console.log(this.timeData)
    const minTime = Math.min(...this.timeData.map(d => this.timeToMinutes(d.StartTime)));
    const maxTime = Math.max(...this.timeData.map(d => this.timeToMinutes(d.EndTime)));

    const totalTime = maxTime - minTime;
    const scaleFactor = totalTime > this.svgWidth ? this.svgWidth / totalTime : 1;

    return this.timeData.map((d, index) => ({
      ...d,
      x: ((this.timeToMinutes(d.StartTime) - minTime) * scaleFactor) * (this.svgWidth / totalTime),
      width: ((this.timeToMinutes(d.EndTime) - this.timeToMinutes(d.StartTime)) * scaleFactor) * (this.svgWidth / totalTime),
      color: d.Status === 'Working' ? '#28a745' : '#dc3545',
      showStartTime: index === 0
    }));
  }

  async renderChart() {
    const chart = this.chart.nativeElement;
    chart.innerHTML = '';

    const data = this.getScaledData();
    console.log(data)
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('width', `${this.svgWidth}`);
    svg.setAttribute('height', `${this.svgHeight}`);

    data.forEach(d => {
      const rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', `${d.x}`);
      rect.setAttribute('y', '10');
      rect.setAttribute('width', `${d.width}`);
      rect.setAttribute('height', `${this.barHeight}`);
      rect.setAttribute('fill', d.color);
      svg.appendChild(rect);

      if (d.showStartTime) {
        const startText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
        startText.setAttribute('x', `${d.x + 5}`);
        startText.setAttribute('y', `${this.barHeight + 50}`);
        startText.setAttribute('fill', '#000');
        startText.setAttribute('font-size', '8');
        startText.setAttribute('text-anchor', 'middle');
        startText.setAttribute('transform', `rotate(90, ${d.x + 5}, ${this.barHeight + 50})`);
        startText.textContent = d.StartTime;
        svg.appendChild(startText);
      }

      const endText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      endText.setAttribute('x', `${d.x + d.width - 10}`);
      endText.setAttribute('y', `${this.barHeight + 50}`);
      endText.setAttribute('fill', '#000');
      endText.setAttribute('font-size', '8');
      endText.setAttribute('text-anchor', 'middle');
      endText.setAttribute('transform', `rotate(90, ${d.x + d.width - 10}, ${this.barHeight + 50})`);
      endText.textContent = d.EndTime;
      svg.appendChild(endText);
    });

    chart.appendChild(svg);
  }
  //chart showing


}
