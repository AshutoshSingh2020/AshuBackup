import { Component, OnInit } from '@angular/core';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.scss']
})
export class UserDashboardComponent implements OnInit {
  myDashboardLoading = [false, false];
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[] = [];
  constructor(private apiservice: ApiService) { }

  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.myDashboardLoading[0]=('getUserCount' in loading)?true:false;
    });
    this.getAllData();
  }
  dkCols: boolean = true;
  dashboardCount = [
    { "name":'It Demo', "value":'--' , "feather": "user-plus", "color": this.dkCols ? "#7db39f" : "#1c84ee", "isDownload": "N", "click": true },
    { "name":'Support pc', "value":'--' , "feather": "user-plus", "color": this.dkCols ? "#7db39f" : "#1c84ee", "isDownload": "N", "click": true },
    { "name":'Test', "value": '--', "feather": "user-plus", "color": this.dkCols ? "#7db39f" : "#1c84ee", "isDownload": "N", "click": true },
    { "name":'Total User', "value":'--' , "feather": "user-plus", "color": this.dkCols ? "#7db39f" : "#1c84ee", "isDownload": "N", "click": true }
  ];
  tabsdata() {
    return this.dashboardCount
  }
  getAllData() {
    this.dashboardCount = [];
    this.apiSubscriber[0] = this.apiservice.getRequest(config['getUserCount'], 'getUserCount').subscribe((data: any) => {
      data.forEach((depositElement: any, index: any) => {
        this.dashboardCount.push({ "name": depositElement.MachineName, "value": depositElement.UserCountPerMachine, "feather": "user-plus", "color": this.dkCols ? "#7db39f" : "#1c84ee", "isDownload": "N", "click": true })
      });
    });
  }
  onValueChange(formVal: any) {
    window.open('userreport/userList/'+ formVal.type, '_blank');
  }
}
