import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';
import { UserDetailsComponent } from '../user-details/user-details.component';

@Component({
  selector: 'app-productivity-report',
  templateUrl: './productivity-report.component.html',
  styleUrls: ['./productivity-report.component.scss'],
  providers: [DatePipe]

})
export class ProductivityReportComponent implements OnInit {
  maxDate = new Date();
  dynamicControls = [
    // { que: 'MachineName',changeAction: 'submit',  type: 'dropdownVal', default: { name: 'Select Machine', value: '' }, options: [], subque: [] },
    // { que: 'UserName', type: 'dropdownVal', default: { name: 'Select Name', value: '' }, options: [], subque: [] },
    { que: 'Date', type: 'date', 'defaultDate': this.maxDate, maxDate: this.maxDate, subque: [] }
  ];
  startDate = new Date();
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[] = [];
  apiLoader = { cadc_list: false, cpc_list: false };
  rowCount = { f: 0, l: 0, t: 0 };
  pageCount = [10, 50, 100, 500, 1000];
  pagesTotal = 1;
  modalData:Object = {};
  paginatorBlock: any = [];
  allData: any = [];
  tableInfoData: any = [];
  tableCollumns :any =[]
  collumnHeads: any = [
    [{ value: 'Sr. No.', bg: 'white-drop'},
    { value: 'Machine Name', bg: 'white-drop'},
    { value: 'User Name', bg: 'white-drop'},
    { value: 'Working Time', bg: 'white-drop'},
    { value: 'Idle Time', bg: 'white-drop'},
    { value: 'Productivity', bg: 'white-drop'},
    { value: 'Login', bg: 'white-drop'},
    { value: 'Logout', bg: 'white-drop'},
    { value: 'Action', bg: 'white-drop'},
  ]
  ];
  currentQuery = { "PageNo": 1, "PageSize": this.pageCount[1], "StartDateTime":  moment(this.startDate).format('yyyy-MM-DD') };
  constructor(private apiService: ApiService,private utilities:CommonFunctionService, private datePipe: DatePipe,private dialog:MatDialog) { }

  ngOnInit(): void {
    // this.getAllMachines();
    this.loaderSubscriber = this.apiService.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.cpc_list=('trackingproduct' in loading)?true:false;
    });
    // this.tableCollumns=this.utilities.TableDataNone;

    this.GetMasterData();
  }
  getSearchQuery(formVal: any) {
    this.currentQuery.StartDateTime = this.datePipe.transform(formVal.Date.value, 'yyyy-MM-dd') ;
    // this.currentQuery.MachineName = formVal.MachineName.value;
    // if(this.currentQuery.MachineName){
    //   this.getAllUsersByMachine(this.currentQuery.MachineName);
    // }
    // this.currentQuery.UserName = formVal.UserName.value;
    this.currentQuery.PageNo = 1;
     this.GetMasterData();
  }
  getAllMachines() {
    this.apiService.getRequest(config['machineName'], 'machineName').subscribe({
      next: (res: any) => {
        if (res) {
          res.forEach((element) => {
            // this.dynamicControls[0].options.push({ name: element.MachineName, value: element.MachineName });
          });
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }
  getAllUsersByMachine(param:any) {
    // this.dynamicControls[1].options = [];
    let data = {"MachineName":param}
    this.apiService.sendRequest(config['getUserMachine'],data, 'getUserMachine').subscribe({
      next: (res: any) => {
        if (res) {
          res.forEach((element) => {
            // this.dynamicControls[1].options.push({ name: element.UserName, value: element.UserName });
          });
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }
  setPaginator() {
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
  }
  GetMasterData() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiService.sendRequest(config['trackingproduct'], this.currentQuery, 'trackingproduct').subscribe((data: any) => {
      this.allData = data;
      if (this.allData[0]) {
        this.tableCollumns = this.collumnHeads;
        this.pagesTotal = Math.ceil(this.allData[0].TotalCount / this.currentQuery.PageSize);
        let bg_cell = 'white-cell';
        this.allData.forEach((element: any, index: any) => {
          this.tableInfoData.push([
            { value: ((this.currentQuery.PageNo - 1) * this.currentQuery.PageSize) + (index + 1), bg: bg_cell },
            { value: element.MachineName, bg: bg_cell },
            { value: element.UserName, bg: bg_cell },
            { value: element.WorkingTime, bg: bg_cell },
            { value: element.IdleTime, bg: bg_cell },
            { value: element.WorkingTimePercentage+'%', bg: bg_cell },
            { value: element.LoginTime ? moment(element.LoginTime).format("h:mm:ss A, DD-MMM-yyyy") : '', bg: bg_cell,},
            { value: element.LastTrackingTime ? moment(element.LastTrackingTime).format("h:mm:ss A, DD-MMM-yyyy") : '', bg: bg_cell,},
            { value: '', bg: bg_cell,icon:'View' },
          ])
        });
        this.rowCount = { f: this.tableInfoData[0][0].value, l: this.tableInfoData[this.tableInfoData.length - 1][0].value, t: this.allData[0].TotalCount };
        this.setPaginator();
      }
      else {
        this.rowCount = { f: 0, l: 0, t: 0 };
        this.tableCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }
  onValueChange(formVal: any) {
    if(formVal.type =='View'){
      this.modalData = {username:this.allData[formVal.row].UserName,machine:this.allData[formVal.row].MachineName}
      this.openUserDetails(this.modalData);
    }
  }
  openUserDetails(param:Object){
    let dialog = this.dialog.open(UserDetailsComponent,{
      data:param,
      height:'90vh'
    })
  }
  onPaginatorChange(paginatorQuery: any) {
    if (paginatorQuery.action == 'pageSize') {
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if (paginatorQuery.action == 'pageNo') {
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetMasterData();
  }
  ngOnDestroy(): void {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
}
