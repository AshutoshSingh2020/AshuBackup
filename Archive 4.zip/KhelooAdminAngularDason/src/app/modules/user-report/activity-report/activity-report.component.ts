import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-activity-report',
  templateUrl: './activity-report.component.html',
  styleUrls: ['./activity-report.component.scss'],
  providers: [DatePipe]
})
export class ActivityReportComponent implements OnInit {
  maxDate = new Date();
  time: any = [
    { name: '00 AM', value: '00' },
    { name: '01 AM', value: '01' },
    { name: '02 AM', value: '02' },
    { name: '03 AM', value: '03' },
    { name: '04 AM', value: '04' },
    { name: '05 AM', value: '05' },
    { name: '06 AM', value: '06' },
    { name: '07 AM', value: '07' },
    { name: '08 AM', value: '08' },
    { name: '09 AM', value: '09' },
    { name: '10 AM', value: '10' },
    { name: '11 AM', value: '11' },
    { name: '12 AM', value: '12' },
    { name: '13 PM', value: '13' },
    { name: '14 PM', value: '14' },
    { name: '15 PM', value: '15' },
    { name: '16 PM', value: '16' },
    { name: '17 PM', value: '17' },
    { name: '18 PM', value: '18' },
    { name: '19 PM', value: '19' },
    { name: '20 PM', value: '20' },
    { name: '21 PM', value: '21' },
    { name: '22 PM', value: '22' },
    { name: '23 PM', value: '23' }
  ];
  dynamicControls = [
    { que: 'MachineName', changeAction: 'submit', type: 'dropdownVal', default: { name: 'Select Machine', value: '' }, options: [], subque: [] },
    { que: 'UserName', changeAction: 'submit', type: 'dropdownVal', default: { name: 'Select Name', value: '' }, options: [], subque: [] },
    { que: 'Date', type: 'date', 'defaultDate': this.maxDate, maxDate: this.maxDate, subque: [] }
  ];
  collumnHeads: any = [
    [{ value: 'Sr. No.', bg: 'white-drop'},
    { value: 'User Name', bg: 'white-drop'},
    { value: 'Data', bg: 'white-drop'},
    { value: 'Date', bg: 'white-drop'}]
  ];
  applicationHeads: any = [
    [{ value: 'Sr. No.', bg: 'white-drop'},
    { value: 'User Name', bg: 'white-drop'},
    { value: 'Application', bg: 'white-drop'},
    { value: 'Date', bg: 'white-drop'}]
  ];
  urlHeads: any = [
    [{ value: 'Sr. No.', bg: 'white-drop'},
    { value: 'User Name', bg: 'white-drop'},
    { value: 'Url', bg: 'white-drop'},
    { value: 'Date', bg: 'white-drop'}]
  ];
  tableCollumns :any =[]
  tableCollumns1 :any =[]
  startDate = new Date();
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[] = [];
  apiLoader = { cadc_list: false, cpc_list: false };
  rowCount = { f: 0, l: 0, t: 0 };
  rowCount1 = { f: 0, l: 0, t: 0 };
  pageCount = [10, 50, 100, 500, 1000];
  pageCount1 = [10, 50, 100, 500, 1000];
  pagesTotal = 1;
  pagesTotal1 = 1;
  paginatorBlock: any = [];
  paginatorBlock1: any = [];
  allData: any = [];
  allData1: any = [];
  tableInfoData: any = [];
  tableInfoData1: any = [];
  currentQuery = { "PageNo": 1, "PageSize": this.pageCount[1], "StartDateTime":  moment(this.startDate).format('yyyy-MM-DD'),"MachineName": "", "UserName": "" };
  constructor(private apiService: ApiService,private utilities:CommonFunctionService, private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.getAllMachines();
    this.loaderSubscriber = this.apiService.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.cpc_list=('getClipReport' in loading)?true:false;
      this.apiLoader.cpc_list=('applicationLog' in loading)?true:false;
    });
    this.GetMasterData();
    this.GetMasterData1();
  }
  getAllMachines() {
    this.apiService.getRequest(config['machineName'], 'machineName').subscribe({
      next: (res: any) => {
        if (res) {
          res.forEach((element) => {
            this.dynamicControls[0].options.push({ name: element.MachineName, value: element.MachineName });
          });
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }
  getAllUsersByMachine(param:any) {
    this.dynamicControls[1].options = [];
    let data = {"MachineName":param}
    this.apiService.sendRequest(config['getUserMachine'],data, 'getUserMachine').subscribe({
      next: (res: any) => {
        if (res) {
          res.forEach((element) => {
            this.dynamicControls[1].options.push({ name: element.UserName, value: element.UserName });
          });
        }
      },
      error: (err) => {
        console.error(err);
      }
    });
  }
  getSearchQuery(formVal: any) {
    this.currentQuery.StartDateTime = this.datePipe.transform(formVal.Date.value, 'yyyy-MM-dd') ;
    this.currentQuery.MachineName = formVal.MachineName.value;
    if(this.currentQuery.MachineName){
      this.getAllUsersByMachine(this.currentQuery.MachineName);
    }
    this.currentQuery.UserName = formVal.UserName.value;
    this.currentQuery.PageNo = 1;
     this.GetMasterData();
     this.GetMasterData1();
  }
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
    this.allData1 = [];
    this.tableInfoData1 = [];
  }
  GetMasterData() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiService.sendRequest(config['getClipReport'], this.currentQuery, 'getClipReport').subscribe((data: any) => {
      this.allData = data;
      if (this.allData[0]) {
        this.tableCollumns = this.collumnHeads;
        this.pagesTotal = Math.ceil(this.allData[0].TotalCount / this.currentQuery.PageSize);
        let bg_cell = 'white-cell';
        this.allData.forEach((element: any, index: any) => {
          this.tableInfoData.push([
            { value: ((this.currentQuery.PageNo - 1) * this.currentQuery.PageSize) + (index + 1), bg: bg_cell },
            { value: element.UserName, bg: bg_cell },
            { value: element.CopyData, bg: bg_cell },
            { value: element.CreatedDate ? moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy") : '', bg: bg_cell,},
          ])
        });
        this.rowCount = { f: this.tableInfoData[0][1].value, l: this.tableInfoData[this.tableInfoData.length - 1][1].value, t: this.allData[0].TotalCount };
        this.setPaginator();
      }
      else {
        this.rowCount = { f: 0, l: 0, t: 0 };
        this.tableCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }
 
  GetMasterData1() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiService.sendRequest(config['applicationLog'], this.currentQuery, 'applicationLog').subscribe((data: any) => {
      this.allData1 = data;
      if (this.allData1[0]) {
        this.tableCollumns1 = this.applicationHeads;
        this.pagesTotal1 = Math.ceil(this.allData1[0].TotalCount / this.currentQuery.PageSize);
        let bg_cell = 'white-cell';
        this.allData1.forEach((element: any, index: any) => {
          this.tableInfoData1.push([
            { value: ((this.currentQuery.PageNo - 1) * this.currentQuery.PageSize) + (index + 1), bg: 'white-cell' },
            { value: element.Process, bg: 'white-cell' },
            { value: element.WindowTitle, bg: 'white-cell' },
            { value: element.CreatedDate ? moment(element.StartedAt).format("h:mm:ss A, DD-MMM-yyyy") : '', bg: 'white-cell' },
          ])
        });
        this.rowCount1 = { f: this.tableInfoData1[0][0].value, l: this.tableInfoData1[this.tableInfoData1.length - 1][0].value, t: this.allData1[0].TotalCount };
        this.setPaginator1();
      }
      else {
        this.rowCount1 = { f: 0, l: 0, t: 0 };
        this.tableCollumns1=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }
  onValueChange(formVal: any) {

  }
  onValueChange1(formVal: any) {

  }
  onPaginatorChange(paginatorQuery: any) {
    if (paginatorQuery.action == 'pageSize') {
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if (paginatorQuery.action == 'pageNo') {
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetMasterData();
  }
  onPaginatorChange1(paginatorQuery: any) {
    if (paginatorQuery.action == 'pageSize') {
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if (paginatorQuery.action == 'pageNo') {
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetMasterData1();
  }
  setPaginator() {
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  setPaginator1() {
    this.paginatorBlock1 = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal1; i++) {
        this.paginatorBlock1.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal1; i++) {
        this.paginatorBlock1.push(i);
      }
    }
  }
}
