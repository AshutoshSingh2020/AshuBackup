import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';

import _moment , {default as _rollupMoment} from 'moment';

const moment = _rollupMoment || _moment;

@Component({
  selector: 'app-pgfraud-check',
  templateUrl: './pgfraud-check.component.html',
  styleUrls: ['./pgfraud-check.component.scss']
})

export class PgfraudCheckComponent implements OnInit {
  @ViewChild('BlockPGPopUp') BlockPGPopUp!: TemplateRef<any>;
  allData:any=[];
  currenUPIData :any={};
  tableInfoData:any=[];
  dynamicControls = [
    {changeAction:'submit',type:'select',default:{value:"-1",name:'All'},options:[{value:"0",name:'Active'},{value:"1",name:'Block'}]},
    {placeholder:'Search',type:'text',label:'Search'}
  ];
  collumnHeads:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Mobile Number',bg:'white-drop'},{value:'UPI ID',bg:'white-drop'},
    {value:'IP Address',bg:'white-drop'},{value:'PG Transaction Id',bg:'white-drop'},{value:'Description',bg:'white-drop'},
    {value:'Created Date',bg:'white-drop'},{value:'Updated Date',bg:'white-drop'},{value:'Status',bg:'white-drop'},
    {value:'Action',bg:'white-drop'}]
  ]
  tableCollumns=[];
  currentQuery={ "Search": "", "intParam1": "-1", "PageSize": 10, "PageNo": 1 };
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  apiLoader={uvc_list:false};
  dIndex={status:{row:0,col:0,use:false},depositAccess:{row:0,col:0,use:false},IMPSAccess:{row:0,col:0,use:false},roleChange:{row:0,col:0,use:false}};

  paginatorBlock:any=[];
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];

  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }

  ngOnInit(): void
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.uvc_list=('getPGFrauds' in loading)?true:false;
    });
    this.getAllData();
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }

  initializeData(){
    this.allData=[];
    this.tableInfoData=[];
    this.dIndex={status:{row:0,col:0,use:false},depositAccess:{row:0,col:0,use:false},IMPSAccess:{row:0,col:0,use:false},roleChange:{row:0,col:0,use:false}};
  }

  getAllData()
  {
    this.initializeData();
    this.apiservice.sendRequest(config['getPGFrauds'], this.currentQuery, 'getPGFrauds').subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.tableCollumns=this.collumnHeads;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
            {value:element.MobileNumber,bg:'white-cell'},
            {value:element.UPIID,bg:'white-cell'},
            {value:element.IPAddress,bg:'white-cell'},
            {value:element.PGTransactionId,bg:'white-cell'},
            {value:element.Description,bg:'white-cell'},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell',sufText:element.TimeAgo},
            {value:element.UpdatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell',sufText:element.TimeAgo},
            {value:element.Status==0?'Active':'Block',bg:'white-cell'},
            {value:element.Status,bg:'white-cell',icon:'Toggle'},
          ])
        });
        this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.tableCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  getSearchQuery(formVal:any)
  {
    this.currentQuery.intParam1=formVal.C0;
    this.currentQuery.Search=formVal.C1;
    this.getAllData();
  }

  onValueChange(formVal:any)
  {
    if(formVal.col==9){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      this.currenUPIData=this.allData[formVal.row];
      this.BlockPGOpenPopUp();
    }
    // this.getAllData();
  }

  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.getAllData();
  }

  saveStatusUPI(param:any){
    this.apiservice.sendRequest(config['setPGFrauds'],param,'setPGFrauds').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value=!this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value;
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }

  BlockPGOpenPopUp() {
    this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon='Loading';
    let dialogRef = this.dialog.open(this.BlockPGPopUp, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      if(this.tableInfoData.length>0){
        this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon='Toggle';
      }
    })
  }
  
  closePopup(){
    this.dialog.closeAll();
  }
}
