import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PgfraudCheckComponent } from './pgfraud-check.component';

describe('PgfraudCheckComponent', () => {
  let component: PgfraudCheckComponent;
  let fixture: ComponentFixture<PgfraudCheckComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PgfraudCheckComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PgfraudCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
