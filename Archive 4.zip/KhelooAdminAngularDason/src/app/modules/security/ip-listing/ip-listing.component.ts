import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-ip-listing',
  templateUrl: './ip-listing.component.html',
  styleUrls: ['./ip-listing.component.scss']
})

export class IpListingComponent implements OnInit {
  @ViewChild('AddIPDialogOpen') AddIPDialogOpen!: TemplateRef<any>;
  AllIPinfo:any=[];
  IPinfoData:any=[];
  dynamicControls = [
    {placeholder:'Search',type:'text',label:'Search'}
  ];
  IPCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'IP',bg:'white-drop'},{value:'Description',bg:'white-drop'},
    {value:'Action',bg:'white-drop'}]
  ]
  IPDataCollumns=[];
  currentQuery={ "Search": ""};
  RolesList=[];
  addiploader={getIPData:false};
  dIndex={update:{row:0,col:0,use:false},remove:{row:0,col:0,use:false}};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }
  ngOnInit(): void
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.addiploader.getIPData=('getIPData' in loading)?true:false;
      if(this.dIndex.remove.use)
      {
        this.IPinfoData[this.dIndex.remove.row][this.dIndex.remove.col].icon=('removeIP' in loading)?'Loading':'feather';
      }
      if(this.dIndex.update.use)
      {
        this.IPinfoData[this.dIndex.update.row][this.dIndex.update.col].loader=('updateIPData' in loading)?true:false;
      }
    });
    this.getAllData();
  }

  getAllData()
  {
    this.GetAllIPs();
  }

  initializeData(){
    this.AllIPinfo=[];
    this.IPinfoData=[];
    this.dIndex={update:{row:0,col:0,use:false},remove:{row:0,col:0,use:false}};
  }

  GetAllIPs()
  {
    this.initializeData();
    this.apiservice.sendRequest(config['getIPData'], this.currentQuery, 'getIPData').subscribe((data: any) => {
      this.AllIPinfo=data;
      if(this.AllIPinfo[0]){
        this.IPDataCollumns=this.IPCollumnHeaders;
        this.AllIPinfo.forEach((element:any,index:any) => {
          this.IPinfoData.push([
            {value:index+1,bg:'white-cell'},
            {value:element.IP,bg:'white-cell',icon:'EditInput',loader:false},
            {value:element.Description,bg:'white-cell'},
            {value:'',bg:'white-cell',icon:'feather',iconvalue:'trash'}
          ])
        });
      }
      else{
        this.IPDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.C0;
    this.GetAllIPs();
  }
  onValueChange(formVal:any)
  {
    let ipData = this.AllIPinfo[formVal.row];
    console.log(formVal);
    if(formVal.col==1){
      this.dIndex.update.row=formVal.row;
      this.dIndex.update.col=formVal.col;
      this.dIndex.update.use=true;
      let param = {Id:ipData.Id,IP:formVal.value};
      console.log(param);
      this.updateIP(param);
    }
    else if(formVal.col==3){
      this.dIndex.remove.row=formVal.row;
      this.dIndex.remove.col=formVal.col;
      this.dIndex.remove.use=true;
      let param = "?Id="+ipData.Id;
      console.log(param);
      this.deleteIP(param);
    }
  }

  updateIP(param:any)
  {
    this.apiservice.sendRequest(config['updateIPData'],param,'updateIPData').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.GetAllIPs();
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }

  deleteIP(param:any)
  {
    this.apiservice.getRequest(config['removeIP']+param,'removeIP').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.GetAllIPs();
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }

  AddIPOpenPopup() {
    let dialogRef = this.dialog.open(this.AddIPDialogOpen, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  closePopup(){
    this.dialog.closeAll();
  }
}