import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { IpListingComponent } from './ip-listing/ip-listing.component';
import { PgfraudCheckComponent } from './pgfraud-check/pgfraud-check.component';
import { RiskInvestigationComponent } from './risk-investigation/risk-investigation.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'iplist',
    pathMatch: 'full'
  },
  {
    path: 'iplist',
    component: IpListingComponent
  },
  {
    path: 'pgfrauddetection',
    component: PgfraudCheckComponent
  },
  {
    path: 'investigation',
    component: RiskInvestigationComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SecurityRoutingModule { }
