import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';

import _moment , {default as _rollupMoment} from 'moment';
const moment = _rollupMoment || _moment;
@Component({
  selector: 'app-risk-investigation',
  templateUrl: './risk-investigation.component.html',
  styleUrls: ['./risk-investigation.component.scss']
})
export class RiskInvestigationComponent implements OnInit {
  allData:any=[];
  currenUPIData :any={};
  tableInfoData:any=[];
  dynamicControls = [
    {placeholder:'Search',type:'text',label:'Search'}
  ];
  collumnHeads:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Mobile No',bg:'white-drop'},
    {value:'Company Name',bg:'white-drop'},{value:'Amount',bg:'white-drop'},{value:'AccountNumber',bg:'white-drop'},
    {value:'Bank Name',bg:'white-drop'},{value:'Branch Name',bg:'white-drop'},{value:'Account Holder Name',bg:'white-drop'},
    {value:'Ifsc Code',bg:'white-drop'}]
  ]
  tableCollumns=[];
  currentQuery={ "Search": "", "intParam1": "0", "PageSize": 10, "PageNo": 1,"Status":"" };
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  apiLoader={uvc_list:false};
  dIndex={status:{row:0,col:0,use:false}};

  paginatorBlock:any=[];
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];

  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }

  ngOnInit(): void
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.uvc_list=('riskInvestigation' in loading)?true:false;
    });
    this.getAllData();
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }

  initializeData(){
    this.allData=[];
    this.tableInfoData=[];
    this.dIndex={status:{row:0,col:0,use:false}};
  }

  getAllData()
  {
    this.initializeData();
    this.apiservice.sendRequest(config['riskInvestigation'], this.currentQuery, 'riskInvestigation').subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.tableCollumns=this.collumnHeads;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
            {value:element.Phone,bg:'white-cell'},
            {value:element.CompanyName,bg:'white-cell'},
            {value:element.Amount,bg:'white-cell'},
            {value:element.AccountNumber,bg:'white-cell'},
            {value:element.BankName,bg:'white-cell'},
            {value:element.BranchName,bg:'white-cell'},
            {value:element.AccountHolderName,bg:'white-cell'},
            {value:element.IfscCode,bg:'white-cell'}
          ])
        });
        this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.tableCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.C0;
    // this.currentQuery.intParam1=formVal.C1;
    this.getAllData();
  }

  onValueChange(formVal:any)
  {
    
  }

  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.getAllData();
  }



 
}
