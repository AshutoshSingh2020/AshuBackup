import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RiskInvestigationComponent } from './risk-investigation.component';

describe('RiskInvestigationComponent', () => {
  let component: RiskInvestigationComponent;
  let fixture: ComponentFixture<RiskInvestigationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RiskInvestigationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RiskInvestigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
