import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditErrorListComponent } from './edit-error-list.component';

describe('EditErrorListComponent', () => {
  let component: EditErrorListComponent;
  let fixture: ComponentFixture<EditErrorListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditErrorListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditErrorListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
