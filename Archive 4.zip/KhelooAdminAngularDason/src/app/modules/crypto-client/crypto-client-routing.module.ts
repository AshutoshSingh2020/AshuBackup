import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PayoutComponent } from './payout/payout.component';
import { DepositComponent } from './deposit/deposit.component';
import { AddDepositComponent } from './add-deposit/add-deposit.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'clientpayout',
    pathMatch: 'full'
  },
  {
    path: 'crpclientpayout',
    component: PayoutComponent
  },
  {
    path: 'crpclientdeposit',
    component: DepositComponent
  },
  {
    path: 'crpclientadddeposit',
    component: AddDepositComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CryptoClientRoutingModule { }
