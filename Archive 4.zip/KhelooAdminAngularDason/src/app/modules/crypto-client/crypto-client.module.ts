import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CryptoClientRoutingModule } from './crypto-client-routing.module';
import { DepositComponent } from './deposit/deposit.component';
import { PayoutComponent } from './payout/payout.component';
import { AddDepositComponent } from './add-deposit/add-deposit.component';

import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { SharedModule } from '@shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from "@angular/material/table";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatSnackBarModule } from "@angular/material/snack-bar";
import { MatIconModule } from "@angular/material/icon";
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDialogModule } from '@angular/material/dialog';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

import { FeatherModule } from 'angular-feather';
import { allIcons } from 'angular-feather/icons';
import { CryptoApproveComponent } from './payout/crypto-approve/crypto-approve.component';
import { CryptoResetProviderComponent } from './payout/crypto-reset-provider/crypto-reset-provider.component';

@NgModule({
  declarations: [
    DepositComponent,
    PayoutComponent,
    AddDepositComponent,
    CryptoApproveComponent,
    CryptoResetProviderComponent
  ],
  imports: [
    CommonModule,
    CryptoClientRoutingModule,
    CommonModule,
    SharedModule,
    ReactiveFormsModule,
    MatTableModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatIconModule,
    FormsModule,
    MatButtonModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatTabsModule,
    MatDialogModule,
    MatRadioModule,
    MatSelectModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSlideToggleModule,
    FeatherModule.pick(allIcons)
  ]
})
export class CryptoClientModule { }
