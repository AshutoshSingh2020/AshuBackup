import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-deposit',
  templateUrl: './add-deposit.component.html',
  styleUrls: ['./add-deposit.component.scss']
})
export class AddDepositComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
