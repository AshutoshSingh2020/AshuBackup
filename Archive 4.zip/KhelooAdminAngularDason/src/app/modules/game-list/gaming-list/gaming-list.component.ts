import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';

import _moment , {default as _rollupMoment} from 'moment';

const moment = _rollupMoment || _moment;


@Component({
  selector: 'app-gaming-list',
  templateUrl: './gaming-list.component.html',
  styleUrls: ['./gaming-list.component.scss']
})
export class GamingListComponent implements OnInit {
  @ViewChild('BlockUpiPopUp') BlockUpiPopUp!: TemplateRef<any>;
  allData:any=[];
  currenUPIData={};
  tableInfoData:any=[];
  dynamicControls = [
    {placeholder:'Search',type:'text',label:'Search'}
  ];
  UPIColHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Thumb',bg:'white-drop'},{value:'Category',bg:'white-drop'},
    {value:'Game Code',bg:'white-drop'},{value:'Game Id',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'Platforms',bg:'white-drop'},{value:'Sort',bg:'white-drop'},{value:'Group Name',bg:'white-drop'},{value:'Product',bg:'white-drop'},{value:'Game Category',bg:'white-drop'},{value:'Min-Max',bg:'white-drop'},{value:'Status',bg:'white-drop'},{value:'Action',bg:'white-drop'}]
  ]
  minA :any;
  maxA :any;
  min :any;
  max :any;
  cusrow :any;
  UPIDataCollumns=[];
  currentQuery={ "Search": "", "Pagination": 1 };
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  apiLoader={uvc_list:false};
  dIndex={max:{row:0,col:0,use:false,value:''},min:{row:0,col:0,use:false,value:''},refId:{row:0,col:0,use:false,value:''},refed:{row:0,col:0,use:false},status:{row:0,col:0,use:false}};
  radioValues=[{id:"A",vals:0},{id:"I",vals:1},{id:"M",vals:2}];
  paginatorBlock:any=[];
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];

  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }

  ngOnInit(): void
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.uvc_list=('getGameList' in loading)?true:false;
      if(this.dIndex.status.use){
        this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon=('editGameDetails' in loading)?'Loading':'None';
      }
    });
    this.getAllData();
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.Pagination <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.Pagination - 3; i <= this.currentQuery.Pagination + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }

  initializeData(){
    this.allData=[];
    this.tableInfoData=[];
    this.dIndex={max:{row:0,col:0,use:false,value:''},min:{row:0,col:0,use:false,value:''},refId:{row:0,col:0,use:false,value:''},refed:{row:0,col:0,use:false},status:{row:0,col:0,use:false}};
  }

  getAllData()
  {
    this.initializeData();
    this.apiservice.sendRequest(config['getGameList'], this.currentQuery, 'getGameList').subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.UPIDataCollumns=this.UPIColHeaders;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.pageCount[0]);
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:((this.currentQuery.Pagination-1)*this.pageCount[0])+(index+1),bg:'white-cell'},
            {value: element.url_thumb,bg:'white-cell',icon:'Img'},
            {value:element.category,bg:'white-cell'},
            {value:element.game_code,bg:'white-cell'},
            {value:element.game_id,bg:'white-cell'},
            {value:element.name,bg:'white-cell'},
            {value:element.platforms,bg:'white-cell'},
            {value:element.sort,bg:'white-cell'},
            {value:element.groupname,bg:'white-cell'},
            {value:element.product,bg:'white-cell'},
            {value:element.gamecategory,bg:'white-cell'},
            {value:element.MinAmount +' - '+ element.MaxAmount,bg:'white-cell'},
            {value:element.gamestatusid,refArray:this.radioValues,sKey:'id',sValue:this.radioValues[0].vals,bg:'white-cell',icon:'Radio'},
            {value:'Edit',bg:'white-cell',icon:'None'},
          ])
        });
        this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.UPIDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.C0;
    this.getAllData();
  }

  onValueChange(formVal:any)
  {
    //   this.minA = '';
    // this.maxA = '';
    
    if(formVal.col==11 ){
      if(formVal.type == 'EditInput0' && formVal.value != 'undefined' && formVal.value != '' && formVal.value !=null) {
           this.minA = formVal.value;
        }
        if(formVal.type == 'EditInput1' && formVal.value != 'undefined' && formVal.value != '' && formVal.value !=null){
          this.maxA = formVal.value;
       }
    }

   if(formVal.col==13 && formVal.type=='Edit'){
      if(this.dIndex.refed.use)
      {
        let rowOldVal={min:this.tableInfoData[formVal.row][11].value.split(' - ')[0],max:this.tableInfoData[formVal.row][11].value.split(' - ')[1]};
        this.tableInfoData[this.dIndex.refed.row][11].value[0].value={value:rowOldVal.min,bg:'white-cell'};
        this.tableInfoData[this.dIndex.refed.row][11].value[1].value={value:rowOldVal.max,bg:'white-cell'};
        this.tableInfoData[this.dIndex.refed.row][13].value="Update";
      }
      this.dIndex.refed.row=formVal.row;
      this.dIndex.refed.col=formVal.col;
      this.dIndex.refed.use=true;
      let valstr = this.tableInfoData[formVal.row][11].value;
      this.min = valstr.split(' - ')[0];
      this.max = valstr.split(' - ')[1];
      this.tableInfoData[formVal.row][11]= {bg:'white-cell',icon:'MultiEditInput',value:[
        ...([{value:this.min,bg:'white-cell',loader:false,outSave:true}]),
        ...([{value:this.max,bg:'white-cell',loader:false,outSave:true}])]
      }
      this.tableInfoData[formVal.row][13].value="Update";
    }
    else if(formVal.col==13 && formVal.type=='Update'){
      let dataNow = this.allData[formVal.row];
      let tempmin = this.minA ? this.minA:this.min;
      let tempmax = this.maxA ? this.maxA:this.max;
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      dataNow.MaxAmount = tempmax
      dataNow.MinAmount = tempmin;
      this.updateAmount(dataNow);
      this.maxA = '';
      this.minA = '';
    }else if(formVal.col==12){
      let gamestatusid = formVal.value;  
      let tableId = this.allData[formVal.row];
      let id = tableId.Id;
      let param = {"Id":id,"gamestatusid":gamestatusid }
      this.saveStatusBlock(param);
    }
  }

  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageNo'){
      this.currentQuery.Pagination = paginatorQuery.pageNo;
      
    }
    this.getAllData();
  }

  updateAmount(param:any){
    this.apiservice.sendRequest(config['editGameDetails'],param,'editGameDetails').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value=!this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value;
          this.getAllData();
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  
  }
  saveStatusBlock(param:any){
    this.apiservice.sendRequest(config['updateGameDetail'],param,'updateGameDetail').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value=!this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value;
          this.getAllData();
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }

}
