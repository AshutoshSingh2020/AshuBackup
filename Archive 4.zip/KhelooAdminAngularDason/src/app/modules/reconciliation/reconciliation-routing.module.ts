import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReconComponent } from './recon/recon.component';
import { TallyComponent } from './tally/tally.component';
import { DownloadComponent } from './download/download.component';
import { PayGateComponent } from './pay-gate/pay-gate.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'reconciliation',
    pathMatch: 'full'
  },
  {
    path: 'reconciliation',
    component: ReconComponent
  },
  {
    path: 'tally',
    component: TallyComponent
  },
  {
    path: 'downloadfiles',
    component: DownloadComponent
  },
  {
    path: 'paymentgateway',
    component: PayGateComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReconciliationRoutingModule { }
