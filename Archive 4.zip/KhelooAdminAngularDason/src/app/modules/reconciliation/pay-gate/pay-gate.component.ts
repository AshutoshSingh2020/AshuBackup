import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { DatePipe } from '@angular/common';
import { config } from '@services/config';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-pay-gate',
  templateUrl: './pay-gate.component.html',
  styleUrls: ['./pay-gate.component.scss'],
  providers: [DatePipe]
})

export class PayGateComponent implements OnInit, OnDestroy {
  tableInfoData:any=[];
  maxDate=new Date();
  maxDF=this.datePipe.transform(this.maxDate, 'yyyy-MM-dd');
  dIndex={dlstatus:{row:0,col:0,use:false,data:{}}};
  
  dynamicControls = [
    {changeAction:'submit',que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]}
  ];
  
  collumnHeads:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'Action',bg:'white-drop'}]
  ];
  
  tableCollumns=this.collumnHeads;
  currentQuery={"Search": "","StartDateTime": this.maxDF,"EndDateTime": this.maxDF};
  
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={primary_list:false};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private datePipe: DatePipe) { }
  
  ngOnInit(): void
  {
    this.initSubscribe();
    this.getAllData();
    this.tableInfoData=[[
      {value:1,bg:'white-cell'},
      {value:"Paykun",bg:'white-cell'},
      {value:"",icon:'DownloadBtn',downloadvalue:'dlRecon',bg:'white-cell'}
    ]];
  }
  
  getAllData()
  {
    this.GetPrimaryData();
  }
  
  initSubscribe()
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      if(this.dIndex.dlstatus.use)
      {
        this.tableInfoData[this.dIndex.dlstatus.row][this.dIndex.dlstatus.col].icon=('dlPaykunPmt' in loading)?'Loading':'DownloadBtn';
      }
    });
  }
  
  resetSubscribe()
  {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
  
  initializeData()
  {
    this.resetSubscribe();
    // this.tableInfoData = [];
    this.initSubscribe();
  }
  
  GetPrimaryData()
  {
    this.initializeData();
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'yyyy-MM-dd');
    this.currentQuery.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'yyyy-MM-dd');
    // this.GetPrimaryData();
  }
  
  onValueChange(formVal:any){
    console.log(formVal);
    if(formVal.col==2){
      this.dIndex.dlstatus.row=formVal.row;
      this.dIndex.dlstatus.col=formVal.col;
      this.dIndex.dlstatus.data=formVal.value;
      this.dIndex.dlstatus.use=true;
      this.DownloadExcelData();
    }
  }
  
  DownloadExcelData() {
    // let d1 = (moment(this.currentQuery.StartDateTime).format("DD/MM/yyyy HH:mm"));
    let d1 = this.datePipe.transform(this.currentQuery.StartDateTime, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
    // let d2 = (moment(this.currentQuery.EndDateTime).format("DD/MM/yyyy HH:mm"));
    let d2 = this.datePipe.transform(this.currentQuery.EndDateTime, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
    let request = "?StartDateTime="+d1+"&EndDateTime="+d2;
    let docname = 'WithdrawalRequest_Download';
    this.apiservice.exportExcel(config['dlPaykunPmt'] + request,docname,'dlPaykunPmt');
  }
  
  ngOnDestroy()
  {
    this.resetSubscribe();
  }
}