import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';

import _moment , {default as _rollupMoment} from 'moment';

const moment = _rollupMoment || _moment;

@Component({
  selector: 'app-pg-master',
  templateUrl: './pg-master.component.html',
  styleUrls: ['./pg-master.component.scss']
})

export class PgMasterComponent implements OnInit {
  @ViewChild('AddPGPopUp') AddPGPopUp!: TemplateRef<any>;
  allData:any=[];
  currentPGData={};
  tableInfoData:any=[];
  collumnHeads:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Status',bg:'white-drop'},{value:'PaymentUrl',bg:'white-drop'},
    {value:'Description',bg:'white-drop'},{value:'Date',bg:'white-drop'}]
  ]
  tableCollumns=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  apiLoader={uvc_list:false};
  dIndex={status:{row:0,col:0,use:false}};

  paginatorBlock:any=[];
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];

  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }

  ngOnInit(): void
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.uvc_list=('getPGMstData' in loading)?true:false;
      if(this.dIndex.status.use)
      {
        this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon=('changePGStatus' in loading)?'Loading':'Toggle';
      }
    });
    this.getAllData();
  }

  initializeData(){
    this.allData=[];
    this.tableInfoData=[];
    this.dIndex={status:{row:0,col:0,use:false}};
  }

  getAllData()
  {
    this.initializeData();
    this.apiservice.getRequest(config['getPGMstData'], 'getPGMstData').subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.tableCollumns=this.collumnHeads;
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:index+1,bg:'white-cell'},
            {value:element.StatusId,bg:'white-cell',icon:'Toggle'},
            {value:element.PaymentUrl,bg:'white-cell'},
            {value:element.Description,bg:'white-cell'},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell',sufText:element.TimeAgo}
          ])
        });
      }
      else{
        this.tableCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  onValueChange(formVal:any)
  {
    if(formVal.col==1){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      this.currentPGData=this.allData[formVal.row];
      let param='?Id='+this.currentPGData['Id'];
      this.saveStatusPG(param);
    }
  }

  saveStatusPG(param:any){
    this.apiservice.getRequest(config['changePGStatus']+param,'changePGStatus').subscribe({
      next: (data:any) => {
        if (data) {
          if (data.ErrorCode == "1") {
            this.utilities.toastMsg('success',"Success", data.ErrorMessage);
            this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value=!this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value;
          } else {
            this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
          }
        }
      },
      error: (error)=> {
        console.log(error);
      }
    });
  }

  AddPGOpenPopUp() {
    let dialogRef = this.dialog.open(this.AddPGPopUp, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
    })
  }
  
  closePopup(){
    this.dialog.closeAll();
  }
}