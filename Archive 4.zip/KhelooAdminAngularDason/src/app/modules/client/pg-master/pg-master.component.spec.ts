import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PgMasterComponent } from './pg-master.component';

describe('PgMasterComponent', () => {
  let component: PgMasterComponent;
  let fixture: ComponentFixture<PgMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PgMasterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PgMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
