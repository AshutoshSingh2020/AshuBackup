import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePgUserComponent } from './create-pg-user.component';

describe('CreatePgUserComponent', () => {
  let component: CreatePgUserComponent;
  let fixture: ComponentFixture<CreatePgUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreatePgUserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CreatePgUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
