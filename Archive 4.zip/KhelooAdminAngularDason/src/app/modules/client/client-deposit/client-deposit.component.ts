import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { DatePipe } from '@angular/common';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import moment from 'moment';

@Component({
  selector: 'app-client-deposit',
  templateUrl: './client-deposit.component.html',
  styleUrls: ['./client-deposit.component.scss'],
  providers: [DatePipe]
})

export class ClientDepositComponent implements OnInit, OnDestroy {
  assignList: any = [];
  ClienNameList: any = [];
  
  allData:any=[];
  tableInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,200,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  maxDate=new Date();
  maxDF=this.datePipe.transform(this.maxDate, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
  dIndex={status:{row:0,col:0,use:false},view:{row:0,col:0,use:false}};
  
  dynamicControls = [
    {changeAction:'submit',que:'TempUTR',type:'dropdownVal',default:{value:"0",name:'All'},options:[{value:"1",name:'Temp UTR'}],subque:[]},
    {changeAction:'submit',que:'Type',type:'dropdown',options:['All','Success','Created'],subque:[]},
    {que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]},
    {que:'Search',type:'input',subque:[]}
  ];
  
  collumnHeads:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Client',bg:'white-drop'},{value:'RequestId',bg:'white-drop'},
    {value:'Amount',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'TransactionId / Mobile',bg:'white-drop'},
    {value:'UTR / UPI',bg:'white-drop'},{value:'Status',bg:'white-drop'},{value:'Mode',bg:'white-drop'},
    {value:'Created Date',bg:'white-drop'},{value:'Player Claim Date',bg:'white-drop'},{value:'Bank Transaction Date',bg:'white-drop'},{value:'Updated Date',bg:'white-drop'},{value:'UTR Updated Date',bg:'white-drop'},{value:'Bank Receipt',bg:'white-drop'},{value:'Action',bg:'white-drop'}]
  ]
  tableCollumns=this.collumnHeads;
  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[0],"StartDateTime": this.maxDF,"EndDateTime": this.maxDF,"intParam1":"0","intParam2":'0'}
  
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={cdc_list:false,cdc_export:false};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private datePipe: DatePipe) { }
  
  ngOnInit(): void {
    this.initSubscribe();
    this.getAllData();
  }
  
  getAllData()
  {
    this.GetAllTrx();
  }
  
  initSubscribe(){
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.cdc_list=('getClientDeposit' in loading)?true:false;
      this.apiLoader.cdc_export=('expCDeposit' in loading)?true:false;
      if(this.dIndex.status.use)
      {
        this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon=('doCallback' in loading)?'Loading':'None';
      }
      if(this.dIndex.view.use)
      {
        this.tableInfoData[this.dIndex.view.row][this.dIndex.view.col].icon=('depositutrVia' in loading)?'Loading':'None';
      }
    });
  }
  
  resetSubscribe(){
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
  
  initializeData()
  {
    this.resetSubscribe();
    this.allData = [];
    this.tableInfoData = [];
    this.initSubscribe();
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllTrx();
  }
  
  GetAllTrx() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['getClientDeposit'], this.currentQuery, 'getClientDeposit').subscribe({
      next: (data:any) => {
        this.allData=data;
        if(this.allData[0]){
          this.tableCollumns=this.collumnHeads;
          this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
          this.allData.forEach((element:any,index:any) => {
            this.tableInfoData.push([
              {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
              {value:element.ClientName,bg:'white-cell'},
              {bg:'white-cell',icon:'Multi',value:[{value:element.RequestId},    
                ...(element.ModeData?[{span_values:['UPI : '+element.ModeData],span_classes:["light"]}]:[{}])]},
                {value:element.Amount,bg:'white-cell'},
                {value:element.Name,bg:'white-cell'},
                {bg:'white-cell',icon:'Multi',value:[{value:element.TransactionId,sufText2:element.Phone?"Mobile: "+element.Phone:''},
                ]},
                  {bg:'white-cell',icon:'Multi',value:[{value:element.ReferenceId,sufText:element.TempUTR?"Temp:"+element.TempUTR:'',sufText2:element.BankUPIID?"UPI: "+element.BankUPIID:'',sufText2Class:'break-class'},
                ]},
                  {value:element.TransactionStatus,bg:'white-cell', sufText:element.bankType?'Bank Type:'+ element.bankType:''},
                  {bg:'white-cell',icon:'Multi',value:[{value:element.PaymentMode},    
                    ...(element.PGOrderId?[{span_values:['OrderId : '+element.PGOrderId],span_classes:["light"]}]:[{}])]},
                    {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
                    ...(element.DepositAddedDate?[{value:moment(element.DepositAddedDate).format("h:mm:ss A, DD-MMM-yyyy"),bg:'white-cell',sufText:element.ClaimTime?"Claim : "+element.ClaimTime:''}]:[{value:"",bg:'white-cell'}]),
                    {value:element.BankTransactionDate?element.BankTransactionDate:'',bg:'white-cell'},
                    ...(element.UpdatedDate?[{value:moment(element.UpdatedDate).format("h:mm:ss A, DD-MMM-yyyy"),bg:'white-cell'}]:[{value:"",bg:'white-cell'}]),
                      {value:element.UTRUpdateddate?moment(element.UTRUpdateddate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
                      {bg:'white-cell',icon:'Multi',value:[
                        ...(element.ClientName == 'Kheloo Live'?[{value:element.RequestId,bg:'white-cell',icon:'feather',iconvalue:'file'}]:[{value:'',bg:'white-cell'}])]
                      },
                      {bg:'white-cell',icon:'Multi',value:[
                        ...(element.PaymentMode && element.TransactionStatus != 'FAILED'?[{value:'Callback',bg:'white-cell',icon:'None'}]:[{value:'',bg:'white-cell'}]),
                        ...(element.PaymentMode == 'Web-BANKUPI-payconnect' && element.TransactionStatus != 'SUCCESS' && element.TempUTR && element.BankUPIID?[{value:'View',bg:'white-cell',icon:'None'}]:[]),
                      ]
                    }
                  ])
                });
                this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
                this.setPaginator();
              }
              else{
                this.rowCount={f:0,l:0,t:0};
                this.tableCollumns=this.utilities.TableDataNone;
              }
            },
            error: (error)=> {
              console.log(error);
            }
          });
        }
        
        setPaginator(){
          this.paginatorBlock = [];
          if (this.currentQuery.PageNo <= 4) {
            for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
              this.paginatorBlock.push(i);
            }
          }
          else {
            for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
              this.paginatorBlock.push(i);
            }
          }
        }
        
        doCallBack(param:any){
          this.apiservice.sendRequest(config['doCallback'],param,'doCallback').subscribe((data: any) => {
            this.dIndex.status.use=false;
            if (data) {
              if (data.ErrorCode == "1") {
                this.utilities.toastMsg('success',"Success", data.ErrorMessage);
                this.GetAllTrx();
              } else {
                this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
                this.GetAllTrx();
              }
            }
          }, (error) => {
            console.log(error);
          });
        }
        
        onValueChange(formVal:any)
        {
          if(formVal.col==15 && formVal.type == 'Callback'){
            let dataNow = this.allData[formVal.row];
            this.dIndex.status.row=formVal.row;
            this.dIndex.status.col=formVal.col;
            this.dIndex.status.use=true;
            this.doCallBack(dataNow);
          }else if(formVal.col==15 && formVal.type == 'View'){
            let dataNow = this.allData[formVal.row];
            this.dIndex.view.row=formVal.row;
            this.dIndex.view.col=formVal.col;
            this.dIndex.view.use=true;
            this.doRequest(dataNow);
          }
          if(formVal.type=='file'){
            let image = this.allData[formVal.row].RequestId?'https://rcptapi.fairbet91.com/'+this.allData[formVal.row].RequestId+'.png':''
            window.open(image, '_blank');
          }
        }
        doRequest(data:any){
          let param = '?Amount='+data.Amount+'&TempUTR='+data.TempUTR+'&UPIId='+data.BankUPIID;
          this.apiservice.getRequest(config['depositutrVia']+param,'depositutrVia').subscribe((data: any) => {
            this.dIndex.view.use=false;
            if (data) {
              if (data.ErrorCode == "1") {
                this.utilities.toastMsg('success',"Success", data.ErrorMessage);
                this.GetAllTrx();
              } else {
                this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
                this.GetAllTrx();
              }
            }
          }, (error) => {
            console.log(error);
          });
        }

        
        getSearchQuery(formVal:any)
        {
          this.currentQuery.intParam2=formVal.TempUTR.value;
          this.currentQuery.intParam1=formVal.Type.value=="Success"?"1":formVal.Type.value=="Created"?"2":"0";
          this.currentQuery.Search=formVal.Search.value?formVal.Search.value:'';
          this.currentQuery.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
          this.currentQuery.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
          this.currentQuery.PageNo = 1;
          this.GetAllTrx();
        }
        
        DownloadExcelData() {
          let d1 = this.datePipe.transform(this.currentQuery.StartDateTime, 'dd/MM/yyyy HH:mm');
          let d2 = this.datePipe.transform(this.currentQuery.EndDateTime, 'dd/MM/yyyy HH:mm');
          let request = "?StartDateTime="+d1+"&EndDateTime="+d2+"&SearchText="+this.currentQuery.Search+"&intParam1="+this.currentQuery.intParam1+"&intParam2="+this.currentQuery.intParam2;
          let docname = 'ClientDeposits_'+'_'+moment(new Date()).format("DD/MM/yyyy");
          this.apiservice.exportExcel(config['expCDeposit'] + request,docname,'expCDeposit');
        }
        
        ngOnDestroy() {
          this.resetSubscribe();
        }
      }