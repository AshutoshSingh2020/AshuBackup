import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClientRoutingModule } from './client-routing.module';

import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { SharedModule } from '@shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from "@angular/material/table";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatSnackBarModule } from "@angular/material/snack-bar";
import { MatIconModule } from "@angular/material/icon";
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDialogModule } from '@angular/material/dialog';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

import { FeatherModule } from 'angular-feather';
import { allIcons } from 'angular-feather/icons';

import { ClientPayoutComponent } from './client-payout/client-payout.component';
import { ViewDetailsComponent } from './client-payout/view-details/view-details.component';
import { ApproveDetailsComponent } from './client-payout/approve-details/approve-details.component';
import { ClientDepositComponent } from './client-deposit/client-deposit.component';
import { UservarificationComponent } from './uservarification/uservarification.component';
import { BlockUpiComponent } from './uservarification/block-upi/block-upi.component';
import { ClientAddDepositComponent } from './client-add-deposit/client-add-deposit.component';
import { PgMasterComponent } from './pg-master/pg-master.component';
import { AddPgMasterComponent } from './pg-master/add-pg-master/add-pg-master.component';
import { CreatePgUserComponent } from './create-pg-user/create-pg-user.component';
import { PayoutBalanceComponent } from './payout-balance/payout-balance.component';
import { AddPayoutBalanceComponent } from './payout-balance/add-payout-balance/add-payout-balance.component';
import { PgUserDetailsComponent } from './create-pg-user/pg-user-details/pg-user-details.component';
import { ResetProviderComponent } from './client-payout/reset-provider/reset-provider.component';
import { MissingDepositComponent } from './missing-deposit/missing-deposit.component';
import { UpdateBankComponent } from './client-payout/update-bank/update-bank.component';

@NgModule({
  declarations: [
    ClientPayoutComponent,
    ViewDetailsComponent,
    ApproveDetailsComponent,
    ClientDepositComponent,
    UservarificationComponent,
    BlockUpiComponent,
    ClientAddDepositComponent,
    PgMasterComponent,
    AddPgMasterComponent,
    CreatePgUserComponent,
    PayoutBalanceComponent,
    AddPayoutBalanceComponent,
    PgUserDetailsComponent,
    ResetProviderComponent,
    MissingDepositComponent,
    UpdateBankComponent
  ],
  imports: [
    CommonModule,
    ClientRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    MatTableModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatIconModule,
    FormsModule,
    MatButtonModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatTabsModule,
    MatDialogModule,
    MatRadioModule,
    MatSelectModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSlideToggleModule,
    FeatherModule.pick(allIcons)
  ]
})
export class ClientModule { }
