import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-missing-deposit',
  templateUrl: './missing-deposit.component.html',
  styleUrls: ['./missing-deposit.component.scss']
})
export class MissingDepositComponent implements OnInit {
  @ViewChild('CallRequestCompletePopUp') CallRequestCompletePopUp!: TemplateRef<any>;
  AllData: any = [];
  tableInfoData: any = [];
  udataToView = {};
  rowCount = { f: 0, l: 0, t: 0 };
  pageCount = [10, 50, 100, 500, 1000];
  paginatorBlock: any = [];
  pagesTotal = 1;
  dynamicControls = [
    { placeholder: 'PlayerId', type: 'text', label: 'PlayerId' },
    { changeAction: 'submit', type: 'select', default: { value: "", name: 'All' }, options: [{ value: "Open", name: 'Open' }, { value: "Closed", name: 'Closed' }] },
    { placeholder: 'Search', type: 'text', label: 'Search' }];
  dIndex = { Remarks: { row: 0, col: 0, use: false, value: '' }, refId: { row: 0, col: 0, use: false, value: '' }, refed: { row: 0, col: 0, use: false }, status: { row: 0, col: 0, use: false } };
  UserCollumnHeaders: any = [
    [{ value: 'Sr. No.', bg: 'white-drop' }, { value: 'Id', bg: 'white-drop' }, { value: 'UTR', bg: 'white-drop' }, { value: 'UPI Id', bg: 'white-drop' },
    { value: 'Amount', bg: 'white-drop' }, { value: 'Status', bg: 'white-drop' }, { value: 'Date', bg: 'white-drop' }, { value: 'Remark', bg: 'white-drop' },
    { value: 'Update', bg: 'white-drop' }, { value: 'Update By', bg: 'white-drop' }, { value: 'Action', bg: 'white-drop' }]
  ];
  UserDataCollumns = this.UserCollumnHeaders;
  currentQuery = { "Search": "", "PlayerId": "", "PageNo": 1, "PageSize": this.pageCount[0], "Status": "" };
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[] = [];
  apiLoader = { crc_list: false };
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading: any = {}) => {
      this.apiLoader.crc_list = ('missingDeposit' in loading) ? true : false;
      // if(this.dIndex.refed.use)
      //   {
      //     this.tableInfoData[this.dIndex.refed.row][this.dIndex.refed.col].icon=('changeStatus' in loading)?'Loading':'None';
      //   }
    });
    this.GetAllMissingDeposit();
  }

  initializeData() {
    this.AllData = [];
    this.tableInfoData = [];
    this.udataToView = {};
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }

  GetAllMissingDeposit() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['missingDeposit'], this.currentQuery, 'missingDeposit').subscribe((data: any) => {
      this.AllData = data;
      if (this.AllData[0]) {
        this.UserDataCollumns = this.UserCollumnHeaders;
        this.pagesTotal = Math.ceil(this.AllData[0].TotalCount / this.currentQuery.PageSize);
        let bg_cell = ''
        this.AllData.forEach((element: any, index: any) => {
          bg_cell = element.Priority && element.Priority == 1 && !element.Description ? 'blue-blink-cell' : 'white-cell';
          this.tableInfoData.push([
            { value: ((this.currentQuery.PageNo - 1) * this.currentQuery.PageSize) + (index + 1), bg: bg_cell },
            { value: element.UserId, bg: bg_cell },
            { value: element.UTR, bg: bg_cell },
            { value: element.UpiId, bg: bg_cell },
            { value: element.Amount, bg: bg_cell },
            { value: element.Status, bg: bg_cell },
            { value: element.CreatedDate ? moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy") : '', bg: bg_cell, sufText: element.TimeAgo },
            { value: element.Remarks, bg: bg_cell },
            { value: element.UpdatedDate ? moment(element.UpdatedDate).format("h:mm:ss A, DD-MMM-yyyy") : '', bg: bg_cell },
            { value: element.UpdatedByName, bg: bg_cell },
            ...(element.Remarks ? [{ value: '', bg: bg_cell }] : [{ value: 'Complete', bg: bg_cell, icon: 'None' }]),
          ])
        });
        this.rowCount = { f: this.tableInfoData[0][0].value, l: this.tableInfoData[this.tableInfoData.length - 1][0].value, t: this.AllData[0].TotalCount };
        this.setPaginator();
      }
      else {

        this.rowCount = { f: 0, l: 0, t: 0 };
        this.UserDataCollumns = this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }
  setPaginator() {
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  onValueChange(formVal: any) {
    if (formVal.value != '' && formVal.value != undefined && formVal.value != null && formVal.col == 7) {
      this.dIndex.Remarks = formVal.value;
    }
    if (formVal.col == 10 && formVal.type == 'Complete') {
      if (this.dIndex.refed.use) {
        let rowOldVal = { Remarks: this.tableInfoData[this.dIndex.refed.row][7].value };
        this.tableInfoData[this.dIndex.refed.row][7] = { value: rowOldVal.Remarks, bg: 'white-cell' };
        this.tableInfoData[this.dIndex.refed.row][10].value = "Complete";
      }
      this.dIndex.refed.row = formVal.row;
      this.dIndex.refed.col = formVal.col;
      this.dIndex.refed.use = true;
      let rowVal = { Remarks: this.tableInfoData[formVal.row][7].value };
      this.tableInfoData[formVal.row][7] = { value: rowVal.Remarks, bg: 'white-cell', icon: 'Textarea', loader: false, outSave: true };
      this.tableInfoData[formVal.row][10].value = "Save";
    }
    if (formVal.col == 10 && formVal.type == 'Save') {
      let bg_cell = ''
      let data = this.AllData[formVal.row];
      data.Remarks = this.dIndex.Remarks;
      this.updatedesciption(data);
      this.dIndex.refed.row = formVal.row;
      this.dIndex.refed.col = formVal.col;
      this.dIndex.refed.use = true;
      this.tableInfoData[formVal.row][7] = { value: this.dIndex.Remarks, bg: 'white-cell', icon: '', loader: false, outSave: true };
      this.tableInfoData[formVal.row][10] = { value: '', bg: bg_cell };
    }
  }

  updatedesciption(param: any) {
    this.apiservice.sendRequest(config['changeStatus'], param, 'changeStatus').subscribe((data: any) => {
      if (data) {
        this.dIndex.refed.use = false;
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success', "Success", data.ErrorMessage);
        } else {
          this.utilities.toastMsg('error', "Failed", data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }
  onSavePopup() {
    this.GetAllMissingDeposit();
    this.dialog.closeAll();
  }

  CompleteOpenPopup() {
    let dialogRef = this.dialog.open(this.CallRequestCompletePopUp, {
      height: '900x',
      width: '600px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => { })
  }

  getSearchQuery(formVal: any) {
    this.currentQuery.PlayerId = formVal.C0;
    this.currentQuery.Status = formVal.C1;
    this.currentQuery.Search = formVal.C2;
    this.currentQuery.PageNo = 1;
    this.GetAllMissingDeposit();
  }
  onPaginatorChange(paginatorQuery: any) {
    if (paginatorQuery.action == 'pageSize') {
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if (paginatorQuery.action == 'pageNo') {
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllMissingDeposit();
  }
  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }

}
