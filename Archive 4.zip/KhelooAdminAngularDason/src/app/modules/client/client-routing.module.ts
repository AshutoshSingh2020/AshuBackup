import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ClientPayoutComponent } from './client-payout/client-payout.component';
import { ClientDepositComponent } from './client-deposit/client-deposit.component';
import { UservarificationComponent } from './uservarification/uservarification.component';
import { ClientAddDepositComponent } from './client-add-deposit/client-add-deposit.component';
import { PgMasterComponent } from './pg-master/pg-master.component';
import { CreatePgUserComponent } from './create-pg-user/create-pg-user.component';
import { PayoutBalanceComponent } from './payout-balance/payout-balance.component';
import { MissingDepositComponent } from './missing-deposit/missing-deposit.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'clientpayout',
    pathMatch: 'full'
  },
  {
    path: 'clientpayout',
    component: ClientPayoutComponent
  },
  {
    path: 'clientdeposit',
    component: ClientDepositComponent
  },
  {
    path: 'uservarification',
    component: UservarificationComponent
  },
  {
    path: 'clientadddeposit',
    component: ClientAddDepositComponent
  },
  {
    path: 'pgpaymentgatewaymaster',
    component: PgMasterComponent
  },
  {
    path: 'createpguser',
    component: CreatePgUserComponent
  },
  {
    path: 'clientaddpayoutbalance',
    component: PayoutBalanceComponent
  },
  {
    path: 'missingdeposit',
    component: MissingDepositComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClientRoutingModule { }
