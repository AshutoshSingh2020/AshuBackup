import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientPayoutComponent } from './client-payout.component';

describe('ClientPayoutComponent', () => {
  let component: ClientPayoutComponent;
  let fixture: ComponentFixture<ClientPayoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientPayoutComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClientPayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
