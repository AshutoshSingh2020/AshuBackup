import { Component, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-player-list',
  templateUrl: './player-list.component.html',
  styleUrls: ['./player-list.component.scss']
})
export class PlayerListComponent implements OnInit,OnDestroy {
  @ViewChild('viewConversation') viewConversation!: TemplateRef<any>;
  AllUserinfo:any=[];
  UserinfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  userId :Number=0
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  dynamicControls = [{placeholder:'PlayerId',type:'text',label:'PlayerId'},{placeholder:'Search',type:'text',label:'Search'}];
  UserCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Player Id',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},{value:'Mobile',bg:'white-drop'},{value:'Amount',bg:'white-drop'},{value:'Rating',bg:'white-drop'},{value:'Player Age',bg:'white-drop'},{value:'Date',bg:'white-drop'},{value:'View',bg:'white-drop'}]
  ]
  UserDataCollumns=this.UserCollumnHeaders;
  UserCollumnLoading = false;
  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[0],"PlayerId":""};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private dialog:MatDialog) { }
  
  ngOnInit(): void {
    this.GetAllUsers();
  }
  
  initializeData()
  {
    this.UserCollumnLoading = true;
    this.AllUserinfo = [];
    this.UserinfoData = [];
    if(this.apiSubscriber[0]){
      this.apiSubscriber[0].unsubscribe();
    }
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllUsers();
  }
  
  GetAllUsers() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['getAllPlayer'], this.currentQuery).subscribe((data: any) => {
      this.UserCollumnLoading = false;
      this.AllUserinfo=data;
      if(this.AllUserinfo[0]){
        this.UserDataCollumns=this.UserCollumnHeaders;
        this.pagesTotal=Math.ceil(this.AllUserinfo[0].TotalCount/this.currentQuery.PageSize);
        this.AllUserinfo.forEach((element:any,index:any) => {
          this.UserinfoData.push([
          {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
          {value:element.UserId,bg:'white-cell'},
          {value:element.FName,bg:'white-cell'},
          {value:element.UserName,bg:'white-cell'},
          {value:element.Mobile,bg:'white-cell'},
          {value:element.CurrencyType+' '+this.utilities.roundOffNum(element.AccountBalance),bg:'white-cell'},
          {value:element.Rating,bg:'white-cell'},
          {value:element.PlayerAge,bg:'white-cell'},
          {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
          {bg:'white-cell',icon:'Multi',value:[
            ...([{bg:'white-cell',icon:'None',value:'View'}]),
            // ...([{bg:'white-cell',icon:'None',value:'Add Conversation'}]),
          ]}
          ])
        });
        this.rowCount={f:this.UserinfoData[0][0].value,l:this.UserinfoData[this.UserinfoData.length-1][0].value,t:this.AllUserinfo[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.UserDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      this.UserCollumnLoading = false;
      console.log(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  onValueChange(formVal:any){
    if(formVal.col==9 && formVal.type=='View'){
      window.open('/users/playerdetailview/'+this.AllUserinfo[formVal.row].UserId, '_blank');
    }
    if(formVal.type=='Add Conversation'){
      this.userId = this.AllUserinfo[formVal.row].UserId;
      this.addConver();
    }
  }
  addConver(){
    let dialogRef = this.dialog.open(this.viewConversation, {
      height: '900x',
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  getSearchQuery(formVal:any)
  {
    this.currentQuery.PlayerId=formVal.C0
    this.currentQuery.Search=formVal.C1;
    this.currentQuery.PageNo = 1;
    this.GetAllUsers();
  }
  ngOnDestroy(): void {
    if(this.apiSubscriber[0]){
      this.apiSubscriber[0].unsubscribe();
    }
  }
}