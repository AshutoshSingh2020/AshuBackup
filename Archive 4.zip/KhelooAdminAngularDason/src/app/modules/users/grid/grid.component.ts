import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss']
})
export class GridComponent implements OnInit {
  imageUrls: string[] = [];
  @Output() onCancel = new EventEmitter<any>();
  mediaUrls: string[] = [];
  title: string = 'Media';
  type: 'image' | 'audio' | 'video' = 'image';
  agentName: string = 'Unknown Agent';
  
constructor(
  public dialogRef: MatDialogRef<GridComponent>,
  @Inject(MAT_DIALOG_DATA) public data: any
) {
  this.mediaUrls = Array.isArray(data.mediaUrls) ? data.mediaUrls : data.mediaUrls ? [data.mediaUrls] : [];
  this.title = data.title || 'Media';
  this.type = data.type || 'image';
  this.agentName = data.agentName || 'Unknown Agent';

}
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

closeDialog() {
  this.dialogRef.close();
}
onBack() {
  this.onCancel.emit();
}
}