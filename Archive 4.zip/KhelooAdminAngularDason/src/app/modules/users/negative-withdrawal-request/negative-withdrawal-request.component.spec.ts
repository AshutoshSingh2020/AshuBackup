import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NegativeWithdrawalRequestComponent } from './negative-withdrawal-request.component';

describe('NegativeWithdrawalRequestComponent', () => {
  let component: NegativeWithdrawalRequestComponent;
  let fixture: ComponentFixture<NegativeWithdrawalRequestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NegativeWithdrawalRequestComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NegativeWithdrawalRequestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
