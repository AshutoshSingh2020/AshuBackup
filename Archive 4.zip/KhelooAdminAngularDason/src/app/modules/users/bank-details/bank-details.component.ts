import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-bank-details',
  templateUrl: './bank-details.component.html',
  styleUrls: ['./bank-details.component.scss']
})
export class BankDetailsComponent implements OnInit {
  
  @Input() userData:any;
  @Output() onCancel = new EventEmitter<any>();
  
  DataLoader=false;
  BankDataCollumns=[]
  BankDataRows:any=[];
  
  constructor() { }
  
  ngOnInit(){
    this.BankDataRows=[
    [{value:'Account Number',bg:'white-cell'},{value:this.userData.AccountNumber,bg:'white-cell'}],
    [{value:'Bank Name	',bg:'white-cell'},{value:this.userData.BankName,bg:'white-cell'}],
    [{value:'Branch Name	',bg:'white-cell'},{value:this.userData.BranchName,bg:'white-cell'}],
    [{value:'Holder Name	',bg:'white-cell'},{value:this.userData.AccountHolderName,bg:'white-cell'}],
    [{value:'IFSC Code	',bg:'white-cell'},{value:this.userData.IfscCode,bg:'white-cell'}]
    ]
  }
  
  onBack(){
    this.onCancel.emit();
  }
}