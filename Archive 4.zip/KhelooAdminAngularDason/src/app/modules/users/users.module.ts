import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsersRoutingModule } from './users-routing.module';

import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { SharedModule } from '@shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from "@angular/material/table";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatSnackBarModule } from "@angular/material/snack-bar";
import { MatIconModule } from "@angular/material/icon";
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDialogModule } from '@angular/material/dialog';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

import { FeatherModule } from 'angular-feather';
import { allIcons } from 'angular-feather/icons';

import { CreateUserComponent } from './create-user/create-user.component';
import { PlayerListComponent } from './player-list/player-list.component';
import { PlayerDetailsComponent } from './player-details/player-details.component';
import { PlayerStatementComponent } from './player-statement/player-statement.component';
import { PlayerDepositComponent } from './player-deposit/player-deposit.component';
import { PlayerWithdrawComponent } from './player-withdraw/player-withdraw.component';
import { WithdrawalRequestComponent } from './withdrawal-request/withdrawal-request.component';
import { BankDetailsComponent } from './bank-details/bank-details.component';
import { ApproveDetailsComponent } from './approve-details/approve-details.component';
import { AddAdminComponent } from './add-admin/add-admin.component';
import { AddAdminDetailsComponent } from './add-admin-details/add-admin-details.component';
import { OnlineDepositWithdrawComponent } from './online-deposit-withdraw/online-deposit-withdraw.component';
import { BlockUserComponent } from './block-user/block-user.component';
import { CallRequestComponent } from './call-request/call-request.component';
import { CallRequestCompleteComponent } from './call-request-complete/call-request-complete.component';
import { PlayerCallLogComponent } from './player-call-log/player-call-log.component';
import { PlayerGamePlayedComponent } from './player-game-played/player-game-played.component';
import { PlayerOnlineDepositComponent } from './player-online-deposit/player-online-deposit.component';
import { PaymentClickComponent } from './payment-click/payment-click.component';
import { BlockPayComponent } from './payment-click/block-pay/block-pay.component';
import { NegativeWithdrawalRequestComponent } from './negative-withdrawal-request/negative-withdrawal-request.component';
import { BlockedUsersComponent } from './blocked-users/blocked-users.component';
import { AssignRightsComponent } from './assign-rights/assign-rights.component';
import { PlayerKycInvestigationComponent } from './player-kyc-investigation/player-kyc-investigation.component';
import { ViewCallRequestComponent } from './call-request/view-call-request/view-call-request.component';
import { ConversationComponent } from './conversation/conversation.component';
import { GridComponent } from './grid/grid.component';
import { UpdateBankComponent } from './withdrawal-request/update-bank/update-bank.component';

@NgModule({
  declarations: [
    CreateUserComponent,
    PlayerListComponent,
    PlayerDetailsComponent,
    PlayerStatementComponent,
    PlayerDepositComponent,
    PlayerWithdrawComponent,
    WithdrawalRequestComponent,
    BankDetailsComponent,
    ApproveDetailsComponent,
    AddAdminComponent,
    AddAdminDetailsComponent,
    OnlineDepositWithdrawComponent,
    BlockUserComponent,
    CallRequestComponent,
    CallRequestCompleteComponent,
    PlayerCallLogComponent,
    PlayerGamePlayedComponent,
    PlayerOnlineDepositComponent,
    PaymentClickComponent,
    BlockPayComponent,
    NegativeWithdrawalRequestComponent,
    BlockedUsersComponent,
    AssignRightsComponent,
    PlayerKycInvestigationComponent,
    ViewCallRequestComponent,
    ConversationComponent,
    GridComponent,
    UpdateBankComponent
  ],
  imports: [
    CommonModule,
    UsersRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    MatTableModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatIconModule,
    FormsModule,
    MatButtonModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatTabsModule,
    MatDialogModule,
    MatRadioModule,
    MatSelectModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSlideToggleModule,
    FeatherModule.pick(allIcons)
  ]
})
export class UsersModule { }
