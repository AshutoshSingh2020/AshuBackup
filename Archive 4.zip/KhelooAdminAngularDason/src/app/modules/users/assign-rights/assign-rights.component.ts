import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';

@Component({
  selector: 'app-assign-rights',
  templateUrl: './assign-rights.component.html',
  styleUrls: ['./assign-rights.component.scss']
})
export class AssignRightsComponent implements OnInit {
  dynamicControls = [];
  adminRole:any[];
  adminaccess:any = [];
  dataout:any;
  userVal = new FormControl();
  DataLoader :boolean =false
  constructor( private apiservice: ApiService, private utilities : CommonFunctionService) { }
  
  ngOnInit(): void {
    this.userVal.setValue(10000);
    this.fetchAdminRoles();
    this.fetchMenu();
  }
  getSearchQuery(formVal:any){
    
  }
  
  fetchMenu(){
    this.userVal.valueChanges.subscribe((data)=>{
      this.adminaccess = [];
      this.DataLoader = true;
      let param1 = '?RoleId='+data;
      this.dataout = data;
      if(this.dataout == 10000){
        this.adminaccess = [];
        this.DataLoader = false;
      }else{
        this.apiservice.getRequest(config['getAdminAssignMenu']+param1,'getAdminAssignMenu').subscribe((data: any) => {
          this.adminaccess = data;
          this.DataLoader = false;
        }, (error) => {
          console.error(error);
        });
        
      }
    });
  }

  fetchAdminRoles(){
    this.apiservice.getRequest(config['getAdminRoles'],'getAdminRoles').subscribe((data: any) => {
      this.adminRole = data;
    }, (error) => {
      console.error(error);
    });
  }
  
}
