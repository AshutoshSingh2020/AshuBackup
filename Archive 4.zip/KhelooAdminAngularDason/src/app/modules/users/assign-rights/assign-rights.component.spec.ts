import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignRightsComponent } from './assign-rights.component';

describe('AssignRightsComponent', () => {
  let component: AssignRightsComponent;
  let fixture: ComponentFixture<AssignRightsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssignRightsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AssignRightsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
