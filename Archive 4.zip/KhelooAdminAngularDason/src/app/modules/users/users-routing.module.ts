import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CreateUserComponent } from './create-user/create-user.component';
import { PlayerListComponent } from './player-list/player-list.component';
import { PlayerDetailsComponent } from './player-details/player-details.component';
import { WithdrawalRequestComponent } from './withdrawal-request/withdrawal-request.component';
import { AddAdminComponent } from './add-admin/add-admin.component';
import { CallRequestComponent } from './call-request/call-request.component';
import { PaymentClickComponent } from './payment-click/payment-click.component';
import { NegativeWithdrawalRequestComponent } from './negative-withdrawal-request/negative-withdrawal-request.component'
import { BlockedUsersComponent } from './blocked-users/blocked-users.component';
import { AssignRightsComponent } from './assign-rights/assign-rights.component';
const routes: Routes = [
  {
    path: '',
    redirectTo: 'createuser',
    pathMatch: 'full'
  },
  {
    path: 'createuser',
    component: CreateUserComponent
  },
  {
    path: 'blockuser',
    component: BlockedUsersComponent
  },
  {
    path: 'searchplayer',
    component: PlayerListComponent
  },
  {
    path: 'callrequest',
    component: CallRequestComponent
  },
  {
    path: 'playerdetailview/:id',
    component: PlayerDetailsComponent
  },
  {
    path: 'withdrawalrequest',
    component: WithdrawalRequestComponent
  },
  {
    path: 'negativewithdrawalrequest',
    component: NegativeWithdrawalRequestComponent
  },
  {
    path: 'alladmins',
    component: AddAdminComponent
  },
  {
    path: 'adminsassignrights',
    component: AssignRightsComponent
  },
  {
    path: 'paymentclick',
    component: PaymentClickComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule { }