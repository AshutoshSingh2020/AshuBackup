import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-player-details',
  templateUrl: './player-details.component.html',
  styleUrls: ['./player-details.component.scss']
})

export class PlayerDetailsComponent implements OnInit {
  @ViewChild('DepositWithdrawPopUp') DepositWithdrawPopUp!: TemplateRef<any>;
  @ViewChild('BlockUserPopUp') BlockUserPopUp!: TemplateRef<any>;
  BasicDetail:any=[];
  pagesTotal=1;
  paginatorBlock:any=[];
  dynamicControls = [{placeholder:'Search',type:'text',label:'Search'}];
  userId = 0;
  UserCollumnLoading = false;
  isCredit=false;
  hasDepositAccess=0;
  personRole=JSON.parse(localStorage.getItem('personalDetails')).RoleCode;
  personalID=JSON.parse(localStorage.getItem('personalDetails')).UserId;
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private route: ActivatedRoute, private dialog: MatDialog) { }
  
  ngOnInit(): void {
    let paramId = this.route.snapshot.paramMap.get('id');
    if(paramId){
      this.userId = parseInt(paramId);
      this.GetUserDetails();
    }
  }
  
  copytoclipboard(hashid: any) {
    navigator.clipboard.writeText(hashid);
    this.utilities.toastMsg('success','Copied : ',hashid);
  }

  initializeData()
  {
    this.UserCollumnLoading = true;
    this.BasicDetail = {};
  }
  
  GetUserDetails()
  {
    this.initializeData();
    let params = config['getUserData']+'?UserId='+this.userId;
    this.apiservice.getRequest(params,'getUserData').subscribe((data: any) => {
      if(data){
        this.UserCollumnLoading = false;
        this.BasicDetail=data;
        this.apiservice.getRequest(config['hasDepositAccess'],'hasDepositAccess').subscribe((data2: any) => {
          this.hasDepositAccess = data2;
        }, (error) => {
          this.UserCollumnLoading = false;
          console.log(error);
        });
      }
      else{
        this.UserCollumnLoading = false;
      }
    }, (error) => {
      this.UserCollumnLoading = false;
      console.log(error);
    });
  }

  DepositOpen() {
    this.isCredit=true;
    let dialogRef = this.dialog.open(this.DepositWithdrawPopUp, {
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {});
  }

  BlockToggle(){
    let dialogRef = this.dialog.open(this.BlockUserPopUp, {
      width: '500px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {});    
  }

  WithdrawOpen(){
    this.isCredit=false;
    let dialogRef = this.dialog.open(this.DepositWithdrawPopUp, {
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {});
  }

  closePopup(){
    this.dialog.closeAll();
  }

  onSavePopup(){
    this.GetUserDetails();
  }
}