import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentClickComponent } from './payment-click.component';

describe('PaymentClickComponent', () => {
  let component: PaymentClickComponent;
  let fixture: ComponentFixture<PaymentClickComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaymentClickComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentClickComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
