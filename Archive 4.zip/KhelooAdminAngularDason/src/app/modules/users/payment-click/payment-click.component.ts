import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import moment from 'moment';

@Component({
  selector: 'app-payment-click',
  templateUrl: './payment-click.component.html',
  styleUrls: ['./payment-click.component.scss']
})

export class PaymentClickComponent implements OnInit {
  @ViewChild('BlockPayPopUp') BlockPayPopUp!: TemplateRef<any>;
  allData:any=[];
  tableInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10];
  pagesTotal=1;
  paginatorBlock:any=[];
  maxDate=new Date();
  preData=[];
  
  dynamicControls = [{que:'Search',type:'input',subque:[]}];

  dIndex={status:{row:0,col:0,use:false}};
  
  collumnHeads:any = [[{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},{value:'Mobile',bg:'white-drop'},
    {value:'Amount',bg:'white-drop'},{value:'Date',bg:'white-drop'},{value:'View',bg:'white-drop'},{value:'Action',bg:'white-drop'}]]
  
  tableCollumns=this.collumnHeads;
  
  currentQuery={"Search": "","Pagination": 1}
  
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={primary_list:false,export_list:false};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }
  
  ngOnInit(): void
  {
    this.getAllData();
  }

  initSubscribe()
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.primary_list=('getPayClicks' in loading);
      // if(this.dIndex.status.use)
      // {
      //   this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon=('blockUserPayment' in loading)?'Loading':'None';
      // }
    });
  }
  
  getAllData()
  {
    this.GetAllTrx();
  }
  
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
    this.initSubscribe();
  }
  
  onPaginatorChange(paginatorQuery:any)
  {
    console.log(paginatorQuery);
    if(paginatorQuery.action=='pageNo'){
      this.currentQuery.Pagination = paginatorQuery.pageNo;
    }
    this.GetAllTrx();
  }
  
  GetAllTrx()
  {
    this.initializeData();
    this.apiservice.sendRequest(config['getPayClicks'], this.currentQuery, 'getPayClicks').subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.tableCollumns=this.collumnHeads;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.pageCount[0]);
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:((this.currentQuery.Pagination-1)*this.pageCount[0])+(index+1),bg:'white-cell'},
            {value:element.FName,bg:'white-cell'},
            {value:element.UserName,bg:'white-cell'},
            {value:element.Mobile,bg:'white-cell'},
            {value:element.AccountBalance,bg:'white-cell'},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
            {value:'',bg:'white-cell',icon:'feather',iconvalue:'User'},
            ...(element.CallbackStatusId?[{value:'Blocked',bg:'white-cell'}]:[{value:'Block',bg:'white-cell',icon:'None'}])
          ])
        });
        this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.tableCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
      this.tableCollumns=this.utilities.TableDataNone;
    });
  }
  
  setPaginator()
  {
    this.paginatorBlock = [];
    if (this.currentQuery.Pagination <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.Pagination - 3; i <= this.currentQuery.Pagination + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.Search.value;
    this.currentQuery.Pagination = 1;
    this.GetAllTrx();
  }

  onValueChange(formVal:any)
  {
    if(formVal.col==6){
      window.open('/users/playerdetailview/'+this.allData[formVal.row].UserId, '_blank');
    }
    if(formVal.col==7){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      this.preData=this.allData[formVal.row];
      this.BlockUpiOpenPopUp();
    }
  }

  BlockUpiOpenPopUp() {
    this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon='Loading';
    let dialogRef = this.dialog.open(this.BlockPayPopUp, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      if(this.tableInfoData.length>0){
        this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon='Toggle';
      }
    })
  }
  
  closePopup(){
    this.dialog.closeAll();
  }
  
  onSave(){
    this.GetAllTrx();
  }

}