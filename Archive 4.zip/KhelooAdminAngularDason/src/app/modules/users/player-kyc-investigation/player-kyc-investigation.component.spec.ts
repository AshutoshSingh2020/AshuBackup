import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlayerKycInvestigationComponent } from './player-kyc-investigation.component';

describe('PlayerKycInvestigationComponent', () => {
  let component: PlayerKycInvestigationComponent;
  let fixture: ComponentFixture<PlayerKycInvestigationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlayerKycInvestigationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PlayerKycInvestigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
