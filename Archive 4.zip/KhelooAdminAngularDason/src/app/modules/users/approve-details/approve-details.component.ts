import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { MatTabGroup } from '@angular/material/tabs';
import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';

@Component({
  selector: 'app-approve-details',
  templateUrl: './approve-details.component.html',
  styleUrls: ['./approve-details.component.scss']
})

export class ApproveDetailsComponent implements OnInit {
  
  @Input() userData:any;
  @Input() AcceptRejectVar='A';
  @Output() onCancel = new EventEmitter<any>();
  @ViewChild('tabGroup') tabGroup!: MatTabGroup;
  DataLoader=false;
  BankDataCollumns=[]
  BankDataRows:any=[];
  UTRinput=new FormControl('',Validators.required);
  activeTabIndex=[0,'SharkPe'];
  tabConfigs=[
    {otp:'otpOpenMoney',trx:'trxOpenMoney'},
    {trx:'trxOpenMoney'},
    {otp:'otpOpenMoneyRoyal',trx:'trxOpenMoneyRoyal'},
    {trx:'trxVader'},
    {checkstat:'otpOpenMoney',trx:'trxOpenMoney'}
  ]
  
  approveDisabled=false;
  trxdisabled=false;
  trxdisabled1=false;
  checkState=false;
  assignWBank="0";
  bankList=[
    {val:"ALHB",Name:"Allahabad Bank"},
    {val:"ADRB",Name:"Andhra Bank"},
    {val:"AXSB",Name:"Axis Bank"},
    {val:"BDHN",Name:"Bandhan Bank"},
    {val:"BOBB",Name:"Bank Of Baroda"},
    {val:"BOIB",Name:"Bank of India"},
    {val:"CNRB",Name:"Canara Bank"},
    {val:"HDFC",Name:"HDFC Bank"},
    {val:"FEDB",Name:"Federal Bank LTD"},
    {val:"ICBB",Name:"ICICI Bank"},
    {val:"IDBI",Name:"IDBI Bank"},
    {val:"IDFC",Name:"IDFC Bank"},
    {val:"INDB",Name:"Indian Bank"},
    {val:"IDSB",Name:"IndusInd Bank"},
    {val:"IPPB",Name:"India Post Payment Bank"},
    {val:"JAKB",Name:"Jammu and Kashmir Bank Limited"},
    {val:"KBLB",Name:"Karnataka Bank Limited"},
    {val:"KTKB",Name:"Kotak Mahindra Bank"},
    {val:"LXVB",Name:"Lakshmi Vilas Bank"},
    {val:"PNBB",Name:"Punjab National Bank"},
    {val:"PTMB",Name:"PAYTM Payments Bank LTD"},
    {val:"SINB",Name:"South Indian Bank"},
    {val:"SBOI",Name:"State Bank of India"},
    {val:"UJVB",Name:"Ujjivan Small Finance Bank"},
    {val:"UBOI",Name:"Union Bank of India"},
  ]
  ProviderList=[];
  bankL:any[]=[];
  
  constructor(private apiservice: ApiService, private utilities : CommonFunctionService) { }
  
  ngOnInit(){
    this.getAllData();
    this.BankDataRows=[
      [{value:'Account Number',bg:'white-cell'},{value:this.userData.AccountNumber,bg:'white-cell'}],
      [{value:'Bank Name',bg:'white-cell'},{value:this.userData.BankName,bg:'white-cell'}],
      [{value:'Branch Name',bg:'white-cell'},{value:this.userData.BranchName,bg:'white-cell'}],
      [{value:'Holder Name',bg:'white-cell'},{value:this.userData.AccountHolderName,bg:'white-cell'}],
      [{value:'IFSC Code',bg:'white-cell'},{value:this.userData.IfscCode,bg:'white-cell'}]
    ];
    this.getAllbank();
  }

  getAllData(){
    this.apiservice.getRequest(config['getPGPayoutProvider'],'getPGPayoutProvider').subscribe((data: any) => {
      this.ProviderList = data;
    }, (error) => {
      console.log(error);
    });
  }
  getAllbank(){
    this.apiservice.getRequest(config['bankfpay'],'bankfpay').subscribe((data: any) => {
      this.bankL = data.data;
    }, (error) => {
      console.log(error);
    });

  }
  
  onTabChange(event: any) {
    let activeTab = this.tabGroup._allTabs.toArray()[event];
    this.activeTabIndex[1] = activeTab.textLabel || '';
    this.activeTabIndex[0] = event;
  }
  
  onBack(){
    this.onCancel.emit();
  }

  getOtp(endsPnt:any){
    this.onOTP(endsPnt); 
  }

  onOTP(endsPoint:any){
    let apiEndPoint=this.tabConfigs[this.activeTabIndex[0]].otp;
    console.log(apiEndPoint);
    this.trxdisabled1=true;
    this.apiservice.getRequest(config[endsPoint],endsPoint).subscribe((data: any) => {
      this.trxdisabled1=false;
      if (data.ErrorCode == "1") {
        this.utilities.toastMsg('success',data.Result, data.ErrorMessage);
      }
      else {
        this.utilities.toastMsg('warning',data.Result,data.ErrorMessage);
      }
    }, (error) => {
      this.trxdisabled=false;
      console.log(error);
    }); 
  }


  transferData(endPoint:any){
    let param = this.userData;
    if(endPoint == 'withtransferFundsPlayerViaSafeXPay' && this.assignWBank =='0'){
      this.utilities.toastMsg('warning','Please select Payout Provider','');
      return
    }
    if(endPoint == 'withFpay' && this.assignWBank =='0'){
      this.utilities.toastMsg('warning','Please select Payout Bank','');
      return
    }
    this.assignWBank !='0' && endPoint == 'withFpay'?
      param.bankId = this.assignWBank
    :
    param.bankId =null;
    this.assignWBank !='0' && endPoint == 'withtransferFundsPlayerViaSafeXPay'?
      param.PayoutProviderId = this.assignWBank
    :
    param.PayoutProviderId =null;
    this.onTransfer(endPoint,param);
  }

  getStat(endPoint:any){
    let param = this.userData;
    if(endPoint == 'withcheckstaussafex' && this.assignWBank =='0'){
      this.utilities.toastMsg('warning','Please select Payout Provider','');
      return
    }
    this.assignWBank !='0' && endPoint == 'withcheckstaussafex'?
      param.PayoutProviderId = this.assignWBank
    :
    param.PayoutProviderId =null;
    this.checkStatus(endPoint,param);
  }

  checkStatus(endsPoint:any,param:any){
    this.checkState = true;
    this.apiservice.sendRequest(config[endsPoint],param,endsPoint).subscribe((data: any) => {
      this.trxdisabled=false;
      this.checkState = false;
      if (data.ErrorCode == "1") {
        this.utilities.toastMsg('success',data.Result, data.ErrorMessage);
        this.UTRinput.setValue(data.Result);
      }
      else {
        this.utilities.toastMsg('warning',data.Result,data.ErrorMessage);
      }
    }, (error) => {
      this.trxdisabled=false;
      this.checkState = false;
      console.log(error);
    });
  }
  
  onTransfer(endsPoint:any,param:any){
    this.trxdisabled=true;
    this.apiservice.sendRequest(config[endsPoint],param,endsPoint).subscribe((data: any) => {
      this.trxdisabled=false;
      if (data.ErrorCode == "1") {
        this.utilities.toastMsg('success',data.Result, data.ErrorMessage);
        // let jsonString = data.ErrorMessage;
        // let jsonObject = JSON.parse(jsonString);
        // let statusMessage = jsonObject.Data.statusMessage;
        this.UTRinput.setValue(data.Result);
      }
      else {
        this.utilities.toastMsg('warning',data.Result,data.ErrorMessage);
      }
    }, (error) => {
      this.trxdisabled=false;
      console.log(error);
    });
  }
  
  onApprove(){
    if(this.UTRinput.value){
      let param = {Id:this.userData.Id,StatusCode:(this.AcceptRejectVar=='A'?"A":"R"),Description:this.UTRinput.value};
      this.approveDisabled=true;
      this.apiservice.sendRequest(config['okWithdrawal'],param).subscribe((data: any) => {
        this.approveDisabled=false;
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',data.Result, data.ErrorMessage);
          this.onBack();
        }
        else {
          this.utilities.toastMsg('warning',data.Result,data.ErrorMessage);
          
        }
      }, (error) => {
        this.approveDisabled=false;
        console.log(error);
      });
    }
    else{
      this.utilities.toastMsg('error',(this.AcceptRejectVar=='A'?"Fill UTR to Approve":"Fill Description to Reject"),"");
    }
  }
}