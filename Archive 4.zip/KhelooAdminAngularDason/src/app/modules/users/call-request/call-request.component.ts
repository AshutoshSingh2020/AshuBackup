import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-call-request',
  templateUrl: './call-request.component.html',
  styleUrls: ['./call-request.component.scss']
})

export class CallRequestComponent implements OnInit {
  @ViewChild('CallRequestCompletePopUp') CallRequestCompletePopUp!: TemplateRef<any>;
  @ViewChild('viewCallRequest') viewCallRequest!: TemplateRef<any>;
  AllCallRequestinfo: any = [];
  CallRequestinfoData: any = [];
  udataToView = {};
  dynamicControls = [{ placeholder: 'PlayerId', type: 'text', label: 'PlayerId' }, { placeholder: 'Search', type: 'text', label: 'Search' }];
  dIndex = { Description: { row: 0, col: 0, use: false, value: '' }, refId: { row: 0, col: 0, use: false, value: '' }, refed: { row: 0, col: 0, use: false }, status: { row: 0, col: 0, use: false } };
  UserCollumnHeaders: any = [
    [{ value: 'Sr. No.', bg: 'white-drop' },
    { value: 'Id', bg: 'white-drop' },
    { value: 'Name', bg: 'white-drop' },
    { value: 'User Name', bg: 'white-drop' },
    { value: 'Mobile', bg: 'white-drop' },
    { value: 'Request Category Name', bg: 'white-drop' },
    { value: 'Call Request Name', bg: 'white-drop' },
    { value: 'Date', bg: 'white-drop' },
    { value: 'User Description', bg: 'white-drop' },
    { value: 'Remark', bg: 'white-drop' },
    { value: 'Update', bg: 'white-drop' },
    { value: 'Update By', bg: 'white-drop' },
    { value: 'Action', bg: 'white-drop' }]
  ];
  UserDataCollumns = this.UserCollumnHeaders;
  currentQuery = { "Search": "", "PlayerId": "" };
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[] = [];
  apiLoader = { crc_list: false };
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading: any = {}) => {
      this.apiLoader.crc_list = ('getCallBackRequest' in loading) ? true : false;
    });
    this.GetAllCallRequests();
  }

  initializeData() {
    this.AllCallRequestinfo = [];
    this.CallRequestinfoData = [];
    this.udataToView = {};
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }

  GetAllCallRequests() {
    this.initializeData();
    let param = this.utilities.setnewForGet(this.currentQuery);
    this.apiSubscriber[0] = this.apiservice.getRequest(config['getCallBackRequest'] + param, 'getCallBackRequest').subscribe((data: any) => {
      this.AllCallRequestinfo = data;
      if (this.AllCallRequestinfo[0]) {
        this.UserDataCollumns = this.UserCollumnHeaders;
        let bg_cell = ''
        this.AllCallRequestinfo.forEach((element: any, index: any) => {
          bg_cell = element.Priority && element.Priority == 1 && !element.Description ? 'blue-blink-cell' : 'white-cell';
          this.CallRequestinfoData.push([
            { value: index + 1, bg: bg_cell },
            { value: element.UserId, bg: bg_cell },
            { value: element.FName + ' ' + element.LName, bg: bg_cell },
            { value: element.UserName, bg: bg_cell },
            { value: element.Mobile, bg: bg_cell },
            { value: element.RequestCategoryName, bg: bg_cell },
            { value: element.CallRequestName, bg: bg_cell },
            { value: element.CreatedDate ? moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy") : '', bg: bg_cell, sufText: element.TimeAgo },
            { value: element.UserDescription, bg: bg_cell },
            { value: element.Description, bg: bg_cell },
            { value: element.UpdatedDate ? moment(element.UpdatedDate).format("h:mm:ss A, DD-MMM-yyyy") : '', bg: bg_cell },
            { value: element.UpdatedBy, bg: bg_cell },
             ...(element.Description ? [{ value: '', bg: bg_cell }] : [{ value: 'Complete', bg: bg_cell, icon: 'None' }]),
            // { value: 'Complete', bg: bg_cell, icon: 'None' }
            // {bg: bg_cell, icon: 'Multi', value: [
            //     ...(element.Description ? [{ value: '', bg: bg_cell }] : [{ value: 'Complete', bg: bg_cell, icon: 'None' }]),
            //     // ...(element.Description ? [{ value: '', bg: bg_cell }] : [{ value: 'View', bg: bg_cell, icon: 'None' }]),
            //   ]
            // }
          ])
        });
      }
      else {
        this.UserDataCollumns = this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  onValueChange(formVal: any) {
    if (formVal.value != '' && formVal.value != undefined && formVal.value != null && formVal.col == 9) {
      this.dIndex.Description = formVal.value;
    }
    if (formVal.col == 12 && formVal.type == 'Complete') {
      if (this.dIndex.refed.use) {
        let rowOldVal = { Desciption: this.CallRequestinfoData[this.dIndex.refed.row][9].value };
        this.CallRequestinfoData[this.dIndex.refed.row][9] = { value: rowOldVal.Desciption, bg: 'white-cell' };
      }
      this.dIndex.refed.row = formVal.row;
      this.dIndex.refed.col = formVal.col;
      this.dIndex.refed.use = true;
      let rowVal = { Desciption: this.CallRequestinfoData[formVal.row][9].value };
      this.CallRequestinfoData[formVal.row][9] = { value: rowVal.Desciption, bg: 'white-cell', icon: 'Textarea', loader: false, outSave: true };
      this.CallRequestinfoData[formVal.row][12].value = "Save";
    }
    if (formVal.col == 12 && formVal.type == 'Save') {
      let bg_cell = ''
      let data = this.AllCallRequestinfo[formVal.row];
      data.Description = this.dIndex.Description;
      this.updatedesciption(data);
      this.dIndex.refed.row = formVal.row;
      this.dIndex.refed.col = formVal.col;
      this.dIndex.refed.use = true;
      this.CallRequestinfoData[formVal.row][9] = { value: this.dIndex.Description, bg: 'white-cell', icon: '', loader: false, outSave: true };
      this.CallRequestinfoData[formVal.row][12] = { value: '', bg: bg_cell };
    }
    // else if(formVal.col ==12 && formVal.type == 'View'){
    //   this.openViewRequest();
    // }
  }
  openViewRequest(){
    let defRef = this.dialog.open(this.viewCallRequest);
    defRef.afterClosed().subscribe(result => { })
  }
  updatedesciption(param: any) {
    this.apiservice.sendRequest(config['saveCallRequest'], param, 'saveCallRequest').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success', "Success", data.ErrorMessage);
        } else {
          this.utilities.toastMsg('error', "Failed", data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }
  onSavePopup() {
    this.GetAllCallRequests();
    this.dialog.closeAll();
  }

  CompleteOpenPopup() {
    let dialogRef = this.dialog.open(this.CallRequestCompletePopUp, {
      height: '900x',
      width: '600px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => { })
  }

  getSearchQuery(formVal: any) {
    this.currentQuery.PlayerId = formVal.C0;
    this.currentQuery.Search = formVal.C1;
    this.GetAllCallRequests();
  }

  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
  onBack(){
    this.dialog.closeAll();
  }
}