import { Component, OnInit } from '@angular/core';
import moment from 'moment';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';

@Component({
  selector: 'app-myleads-dashboard',
  templateUrl: './myleads-dashboard.component.html',
  styleUrls: ['./myleads-dashboard.component.scss']
})

export class MyleadsDashboardComponent implements OnInit {
  dateValue1:any;
  dateValue2:any;
  dateValue3:any;
  todayDate = new Date();
  DataLoader1 = false;
  DataLoader2 = false;
  DataLoader3 = false;
  RLCollumns  = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Id',bg:'white-drop'},{value:'User Name',bg:'white-drop'},{value:'User Mobile',bg:'white-drop'},
    {value:'Join Date',bg:'white-drop'},{value:'Status',bg:'white-drop'}]
  ]
  RLDataCollumns = this.RLCollumns;
  allRegLeadData:any=[];
  RegLeadData:any=[];
  rowCount2={f:0,l:0,t:0};
  paginatorBlock:any=[];
  pageCount2=[10,50,100,500,1000];
  pagesTotal2=1;
  currentQuery2={"PageSize":this.pageCount2[0],"PageNo":1,"StartDateTime":new Date(),"EndDateTime":new Date()};
  TPCollumns  = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'Registered',bg:'white-drop'},
    {value:'Deposit',bg:'white-drop'},{value:'Played',bg:'white-drop'}]
  ]
  TPDataCollumns = this.TPCollumns;
  allTopPerData:any=[];
  TopPerData:any=[];

  MyLeadBlockCount: any = [];

  constructor(private apiservice: ApiService, private utilities: CommonFunctionService) { }
  
  ngOnInit(): void {
    this.getAllData();
  }

  getAllData(){
    let currentday = new Date;
    this.dateValue1 = [currentday, currentday];
    this.GetLeadDashhboardCount(this.dateValue1);
    this.dateValue2 = [currentday, currentday];
    this.GetRegisterLead();
    this.dateValue3 = [currentday, currentday];
    this.GetLeadPerformerData(this.dateValue3);
  }

  searchdata1(DatevalueArray:Date[]){
    this.GetLeadDashhboardCount(DatevalueArray);
  }

  onPaginator2Change(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery2.PageNo = 1;
      this.currentQuery2.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery2.PageNo = paginatorQuery.pageNo;
    }
    this.GetRegisterLead();
  }

  searchdata2(DatevalueArray:Date[]){
    this.currentQuery2.StartDateTime=DatevalueArray[0];
    this.currentQuery2.EndDateTime=DatevalueArray[1];
    this.currentQuery2.PageNo=1;
    this.GetRegisterLead();
  }

  searchdata3(DatevalueArray:Date[]){
    this.GetLeadPerformerData(DatevalueArray);
  }
  
  initializeData(){
    this.DataLoader2=true;
    this.RegLeadData=[];
    this.pagesTotal2=1;
  }
  GetRegisterLead() {
    this.initializeData();
    this.apiservice.sendRequest(config['GetRegisterLead'], this.currentQuery2).subscribe((data: any) => {
      this.DataLoader2=false;
      this.allRegLeadData = data;
      if (this.allRegLeadData[0]){
        this.pagesTotal2=Math.ceil(this.allRegLeadData[0].TotalCount/this.currentQuery2.PageSize);
        this.RLDataCollumns = this.RLCollumns;
        this.allRegLeadData.forEach((element:any,index:any) => {
          this.RegLeadData.push([
            {value:((this.currentQuery2.PageNo-1)*this.currentQuery2.PageSize)+(index+1),bg:'white-cell'},
            {value:element.UserId,bg:'white-cell'},
            {value:element.UserName,bg:'white-cell'},
            {value:element.Mobile,bg:'white-cell'},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
            {value:'',bg:'white-cell',span_values:[(element.GamePlayed?'Played':''),(element.DepositCount?'Deposit':'')],span_classes:[(element.GamePlayed?"badge light badge-warning":''),(element.DepositCount?"badge light badge-success":'')]}
          ])
        });
        this.rowCount2={f:this.RegLeadData[0][0].value,l:this.RegLeadData[this.RegLeadData.length-1][0].value,t:this.allRegLeadData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.RLDataCollumns = this.utilities.TableDataNone;
      }
    }, (error) => {
      this.DataLoader2=false;
      console.log(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery2.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal2; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery2.PageNo - 3; i <= this.currentQuery2.PageNo + 6 && i <= this.pagesTotal2; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  GetLeadDashhboardCount(dateValues:any) {
    let request = {
      "StartDateTime": dateValues[0],
      "EndDateTime": dateValues[1]
    }
    this.DataLoader1 = true;
    this.apiservice.sendRequest(config['GetLeadDashhboard'], request).subscribe((data: any) => {
      this.DataLoader1 = false;
      this.MyLeadBlockCount = [
        { "name": "Total Call Dialled", "value": data.TotalDial || 0, "feather": "phone-call", "color": "#1c84ee" },
        { "name": "Total Picked Call", "value": data.TotalPick || 0, "feather": "phone-incoming", "color": "#33c38e" },
        { "name": "Total No of Registration", "value": data.TotalRegister || 0, "feather": "user-plus", "color": "#ffcc5a" },
        { "name": "Total Deposit", "value": data.TotalDeposit || 0, "feather": "credit-card", "color": "#ef6767" },
        { "name": "Game Played", "value": data.TotalPlayed || 0, "feather": "play-circle", "color": "#33c38e" },
        { "name": "Follow up Pending", "value": data.FollowUpCount || 0, "feather": "loader", "color": "#ffcc5a" }
      ]
    }, (error) => {
      this.DataLoader1 = false;
      console.log(error);
    });
  }
  
  GetLeadPerformerData(dateValues:any) {
    let request = { "StartDateTime": dateValues[0],"EndDateTime": dateValues[1] }
    this.DataLoader3 = true;
    this.TopPerData = [];
    this.apiservice.sendRequest(config['GetLeadPerformer'], request).subscribe((data: any) => {
      this.DataLoader3 = false;
      this.allTopPerData=data;
      if(this.allTopPerData[0]){
        this.TPDataCollumns = this.TPCollumns;
        this.allTopPerData.forEach((element:any,index:any) => {
          this.TopPerData.push([
            {value:(index+1),bg:'white-cell'},
            {value:element.UserName,bg:'white-cell'},
            {value:element.RegisterCount,bg:'white-cell'},
            {value:element.DepositCount,bg:'white-cell'},
            {value:element.GamePlayed,bg:'white-cell'}
          ])
        });
      }
      else {
        this.DataLoader3 = false;
        this.TPDataCollumns = this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }
}