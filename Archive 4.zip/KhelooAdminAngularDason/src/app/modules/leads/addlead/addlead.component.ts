import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';

@Component({
  selector: 'app-addlead',
  templateUrl: './addlead.component.html',
  styleUrls: ['./addlead.component.scss']
})

export class AddleadComponent implements OnInit {
  assignList: any = [];
  ClienNameList: any = [];

  showassignButton = false;
  assignadminid = '0';

  @ViewChild('LeadDialogOpen') LeadDialogOpen!: TemplateRef<any>;

  AllLeadinfo:any=[];
  LeadinfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  assignDisabled=false;
  
  dynamicControls = [
    {placeholder:'Search',type:'text',label:'Search'},{type:'select',default:{value:0,name:'All Admin'},options:[{value:10000,name:'Not Assign'}]},
    {type:'select',default:{value:-1,name:'All Status'},options:[{value:0,name:'Open'},{value:1,name:'Closed'},{value:2,name:'Follow Up'}]},
    {type:'select',default:{value:0,name:'All Client'},options:[]}
  ];
  
  LeadCollumnHeaders:any = [
    [{value:false,bg:'white-drop',icon:'Checkbox'},{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'Mobile',bg:'white-drop'},{value:'Date',bg:'white-drop'},
    {value:'Assign',bg:'white-drop'},{value:'Client',bg:'white-drop'},{value:'View',bg:'white-drop'}]
  ]
  
  LeadDataCollumns=this.LeadCollumnHeaders;

  idLeads='';
  
  LeadCollumnLoading = false;
  showListing = true;
  showFormCreate = '';
  leadToView:any={};
  
  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[0],"intParam1": '0',"intParam2": '0',"intParam3": '-1'}
  
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }
  
  ngOnInit(): void {
    this.getAllData();
    this.GetAllLeads();
  }
  
  getAllData()
  {
    this.apiservice.getRequest(config['GetLeadClients']).subscribe((data: any) => {
      this.ClienNameList = data;
      this.ClienNameList.forEach((element:any,index:number) => {
        this.dynamicControls[3].options![index]={value:element.Id,name:element.ClientName}
      });
    }, (error) => {
      console.log(error);
    });
    this.apiservice.getRequest(config['GetAdminDetails']).subscribe((data: any) => {
      this.assignList = data;
      this.assignList.forEach((element:any,index:number) => {
        this.dynamicControls[1].options![index+1]={value:element.Id,name:element.Name}
      });
    }, (error) => {
      console.log(error);
    });
  }
  
  initializeData()
  {
    this.LeadCollumnLoading = true;
    this.AllLeadinfo = [];
    this.LeadinfoData = [];
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllLeads();
  }
  
  GetAllLeads() {
    this.initializeData();
    this.apiservice.sendRequest(config['GetAllLeads'], this.currentQuery).subscribe((data: any) => {
      this.LeadCollumnLoading = false;
      this.AllLeadinfo=data;
      if(this.AllLeadinfo[0]){
        this.LeadDataCollumns=this.LeadCollumnHeaders;
        this.pagesTotal=Math.ceil(this.AllLeadinfo[0].TotalCount/this.currentQuery.PageSize);
        this.AllLeadinfo.forEach((element:any,index:any) => {
          this.LeadinfoData.push([
          {value:false,bg:'white-cell',icon:'Checkbox'},
          {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
          {value:element.FName?(element.FName+' '+(element.LName?element.LName:'')):'',bg:'white-cell'},
          {value:element.Mobile,bg:'white-cell'},
          {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
          {value:element.AssignTo,bg:'white-cell'},
          {value:element.ClientName,bg:'white-cell'},
          {value:'',bg:'white-cell',icon:'View'}
          ])
        });
        this.rowCount={f:this.LeadinfoData[0][1].value,l:this.LeadinfoData[this.LeadinfoData.length-1][1].value,t:this.AllLeadinfo[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.LeadDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      this.LeadCollumnLoading = false;
      console.log(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  onHeaderValueChange(formVal:any){
    if(formVal.row==0&&formVal.col==0){
      this.idLeads='';
      if(formVal.type==true)
      {
        for(let i=0;i<this.LeadinfoData.length;i++)
        {
          this.LeadinfoData[i][0].value=true;
          this.idLeads+=(this.idLeads.length>0?',':'')+this.AllLeadinfo[i].Id;
        }
      }
      else
      {
        for(let i=0;i<this.LeadinfoData.length;i++)
        {
          this.LeadinfoData[i][0].value=false;
        }
      }
    }
  }
  
  onValueChange(formVal:any){
    if(formVal.col==0){
      this.LeadDataCollumns[0][0].value=false;
      if(formVal.type==true)
      {
        this.idLeads+=(this.idLeads.length>0?',':'')+this.AllLeadinfo[formVal.row].Id;
      }
      else
      {
        let idregex = new RegExp('\\b' + this.AllLeadinfo[formVal.row].Id + '\\b');
        let idIndex = this.idLeads.search(idregex);
        let idLength = (this.AllLeadinfo[formVal.row].Id).toString().length;
        if(idIndex==0&&this.idLeads.length!=idLength)
        {
          idLength++;
        }
        else if(idIndex!=0)
        {
          idIndex--;
          idLength++;
        }
        let newIds = this.idLeads.slice(0, idIndex) + this.idLeads.slice(idIndex+idLength);
        this.idLeads = newIds;
      }
    }
    else if(formVal.col==7 && formVal.type=='View'){
      this.leadToView=this.AllLeadinfo[formVal.row];
      this.viewLeadForm();
    }
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.C0;
    this.currentQuery.intParam1=formVal.C1;
    this.currentQuery.intParam2=formVal.C3;
    this.currentQuery.intParam3=formVal.C2;
    this.currentQuery.PageNo = 1;
    this.GetAllLeads();
  }
  
  onCancel(){
    this.showListing = true;
    this.showFormCreate = '';
  }

  onSave(){
    this.showListing = true;
    this.showFormCreate = '';
    this.GetAllLeads();
  }

  showLeadForm(){
    this.showListing = false;
    this.showFormCreate = 'AddLead';
  }

  LeadOpenPopup() {
    let dialogRef = this.dialog.open(this.LeadDialogOpen, {
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.onCancel();
    })
  }

  viewLeadForm(){
    this.showListing = false;
    this.showFormCreate = 'ViewLead';
    this.LeadOpenPopup();
  }

  AssignToAdmin() {
    let idval = this.idLeads;
    if (this.assignadminid == '0') {
      this.utilities.toastMsg("warning", "Failed", "Please select admin from dropdown to assign");
      return false;
    }
    if (idval == '') {
      this.utilities.toastMsg("warning", "Failed", "Please select atleast once record");
      return false;
    }
    let request = {
      "Ids": idval,
      "Id": this.assignadminid
    };
    this.assignDisabled=true;
    this.apiservice.sendRequest(config['AssignLeadToAdmin'], request).subscribe((response: any) => {
      this.assignDisabled=false;
      if (response != null) {
        if (response.ErrorCode === "1")
        {
          this.showassignButton = false;
          this.utilities.toastMsg('success',"Success", response.ErrorMessage);
          this.GetAllLeads();
        }
        else
        {
          this.utilities.toastMsg("error", "Failed", response.Result + " : " + response.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
    return true;
  }

}