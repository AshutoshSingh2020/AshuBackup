import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AddleadComponent } from './addlead/addlead.component';
import { BulkUploadleadComponent } from './bulk-uploadlead/bulk-uploadlead.component';
import { LeadDashboardComponent } from './lead-dashboard/lead-dashboard.component';
import { MyleadsComponent } from './myleads/myleads.component';
import { MyleadsDashboardComponent } from './myleads-dashboard/myleads-dashboard.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'addlead',
    pathMatch: 'full'
  },
  {
    path: 'addlead',
    component: AddleadComponent
  },
  {
    path: 'bulkleadupload',
    component: BulkUploadleadComponent
  },
  {
    path: 'leaddashboard',
    component: LeadDashboardComponent
  },
  {
    path: 'myleads',
    component: MyleadsComponent
  },
  {
    path: 'myleaddashboard',
    component: MyleadsDashboardComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LeadsRoutingModule { }
