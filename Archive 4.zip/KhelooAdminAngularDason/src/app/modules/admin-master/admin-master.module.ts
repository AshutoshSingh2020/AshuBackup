import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdminMasterRoutingModule } from './admin-master-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AdminMasterRoutingModule
  ]
})
export class AdminMasterModule { }
