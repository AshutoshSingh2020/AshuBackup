import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BdDaytrxComponent } from './bd-daytrx.component';

describe('BdDaytrxComponent', () => {
  let component: BdDaytrxComponent;
  let fixture: ComponentFixture<BdDaytrxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BdDaytrxComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BdDaytrxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
