import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { DatePipe } from '@angular/common';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-bd-daytrx',
  templateUrl: './bd-daytrx.component.html',
  styleUrls: ['./bd-daytrx.component.scss'],
  providers: [DatePipe]
})

export class BdDaytrxComponent implements OnInit {
  assignList: any = [];
  apiLoader={cadc_list:false,cadc_export:false,uvc_list:false};
  ClienNameList: any = [];
  @ViewChild('TrxDialogOpen') TrxDialogOpen!: TemplateRef<any>;
  export:boolean = false;
  allTrxinfo:any=[];
  trxInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,200,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  maxDate=new Date();
  maxDF=this.datePipe.transform(this.maxDate, 'yyyy-MM-dd');
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  
  dynamicControls = [
    {que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]},
    {que:'Search',type:'input',subque:[]}
  ];
  
  trxCollumnHeaders:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Date',bg:'white-drop'},{value:'ReferenceId',bg:'white-drop'},{value:'Account Number',bg:'white-drop'},{value:'Bank UPIId',bg:'white-drop'},{value:'Description',bg:'white-drop'},
    {value:'Amount',bg:'white-drop'},{value:'Bank',bg:'white-drop'},{value:'Balance',bg:'white-drop'},{value:'Commision',bg:'white-drop'},{value:'Created Date',bg:'white-drop'}]
  ]
  
  trxDataCollumns=this.trxCollumnHeaders;
  currentQuery={"PageNo": 1,"PageSize": this.pageCount[3],"StartDateTime": this.maxDF,"EndDateTime": this.maxDF,"Search":''}
  
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog, private datePipe: DatePipe) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.uvc_list=('getBDDailyTrx' in loading)?true:false;
      this.apiLoader.cadc_export=('exportBDDailyTrx' in loading)?true:false;
    });
    this.GetAllTrx();
  }
  
  initializeData()
  {
    this.allTrxinfo = [];
    this.trxInfoData = [];
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllTrx();
  }
  
  GetAllTrx() {
    this.initializeData();
    this.apiservice.sendRequest(config['getBDDailyTrx'], this.currentQuery,'getBDDailyTrx').subscribe((data: any) => {
      this.allTrxinfo=data;
      if(this.allTrxinfo[0]){
        this.export = true;
        this.trxDataCollumns=this.trxCollumnHeaders;
        this.pagesTotal=Math.ceil(this.allTrxinfo[0].TotalCount/this.currentQuery.PageSize);
        this.allTrxinfo.forEach((element:any,index:any) => {
          this.trxInfoData.push([
          {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
          {value:element.Date,bg:'white-cell'},
          {value:element.ReferenceId,bg:'white-cell'},
          {value:element.AccountNumber,bg:'white-cell'},
          {value:element.BankUPIIDViaAPI,bg:'white-cell'},
          {value:element.Description,bg:'white-cell break-class'},
          {value:element.Amount,bg:'white-cell'},
          {value:element.BankName,bg:'white-cell'},
          {value:element.AccountBalance,bg:'white-cell'},
          {value:element.Commision,bg:'white-cell'},
          // {value:element.Status?'Active':'Block',bg:'white-cell'},
          {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy")+" "+element.CreatedDateTZ:'',bg:'white-cell'}
          ])
        });
        this.rowCount={f:this.trxInfoData[0][0].value,l:this.trxInfoData[this.trxInfoData.length-1][0].value,t:this.allTrxinfo[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.trxDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.Search.value;
      this.currentQuery.StartDateTime=moment(formVal.Date.value1).format('YYYY-MM-DD');
      this.currentQuery.EndDateTime=moment(formVal.Date.value2).format('YYYY-MM-DD');
    this.currentQuery.PageNo = 1;
    this.GetAllTrx();
  }
  
  closePopup(){
    this.dialog.closeAll();
  }

  onSave(){
    this.GetAllTrx();
  }

  TrxOpenPopup() {
    let dialogRef = this.dialog.open(this.TrxDialogOpen, {
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.closePopup();
    })
  }

  DownloadExcelData(){
    let d1 = this.datePipe.transform(this.currentQuery.StartDateTime, 'dd/MM/yyyy 00:00');
    let d2 = this.datePipe.transform(this.currentQuery.EndDateTime, 'dd/MM/yyyy 23:59');
    let search = this.currentQuery.Search?this.currentQuery.Search:' ';
    d1 = d1?d1:' ';
    d2 = d2?d2:' ';
    let request = "?SearchText="+search+"&StartDateTime="+d1+"&EndDateTime="+d2;
    let docname = 'BDDailyTrx'+'_'+(d1)+'to_'+(d2);
    this.apiservice.exportExcel(config['exportBDDailyTrx'] + request,docname,'exportBDDailyTrx');
  }

}
