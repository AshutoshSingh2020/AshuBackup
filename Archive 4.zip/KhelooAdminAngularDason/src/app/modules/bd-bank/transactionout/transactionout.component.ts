import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { DatePipe } from '@angular/common';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-transactionout',
  templateUrl: './transactionout.component.html',
  styleUrls: ['./transactionout.component.scss'],
  providers: [DatePipe]
})

export class TransactionoutComponent implements OnInit {
  assignList: any = [];
  apiLoader={cadc_list:false,cadc_export:false,uvc_list:false};
  ClienNameList: any = [];
  @ViewChild('TrxDialogOpen') TrxDialogOpen!: TemplateRef<any>;
  export:boolean = false;
  allTrxinfo:any=[];
  trxInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,200,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  maxDate=new Date();
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  
  dIndex={status:{row:0,col:0,use:false}};
  dynamicControls = [{que:'Status',type:'dropdown',options:['All','Active','Blocked'],subque:[]},
  {que:'Type',type:'dropdown',options:['All','Date Range'],
  subque:[{showIf:'Date Range',que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]}]},
  {que:'Search',type:'input',subque:[]}];

//   {
//     "UserName": null,
//     "Mobile": null,
//     "ReferenceId": "41580325802",
//     "CreatedDate": "2024-07-20T11:12:25.253",
//     "TotalCount": 4,
//     "Id": "4",
//     "Description": "IMPS/415803258052-Vallancy-KKBK0004659-9",
//     "Amount": "-90500.00",
//     "RefereceNumber": null,
//     "AccountNumber": null,
//     "Date": "06/06/2024",
//     "AccountBalance": "1000.00",
//     "BankName": "Bkash",
//     "DeviceiId": "",
//     "DeviceInfo": "",
//     "Status": 1,
//     "BankUPIIDViaAPI": "R03162606",
//     "ExtraDescription": null,
//     "Type": "App",
//     "WalletType": "Merchant",
//     "PaymentMethod": null,
//     "CreatedDateTZ": "BST"
// }
  trxCollumnHeaders:any = [
    [{value:'Sr. No',bg:'white-drop'},
      {value:'Status',bg:'white-drop'},
      {value:'Date',bg:'white-drop'},
      // {value:'Mobile',bg:'white-drop'},
      // {value:'User Name',bg:'white-drop'},
      {value:'Reference Id',bg:'white-drop'},
      {value:'Account Number',bg:'white-drop'},
      {value:'Bank UPI Id',bg:'white-drop'},
      {value:'Description',bg:'white-drop'},
      {value:'Extra Description',bg:'white-drop'},
      // {value:'Referece Number',bg:'white-drop'},
      // {value:'Device Id',bg:'white-drop'},
      // {value:'Device Info',bg:'white-drop'},
    {value:'Amount',bg:'white-drop'},
    {value:'Bank',bg:'white-drop'},
    {value:'Balance',bg:'white-drop'},
    {value:'Type',bg:'white-drop'},
    {value:'Wallet Type',bg:'white-drop'},
    {value:'Payment Method',bg:'white-drop'},
    {value:'Created Date',bg:'white-drop'}]
  ]

  trxDataCollumns=this.trxCollumnHeaders;
  
  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[3],"StartDateTime": null,"EndDateTime": null,"intParam1":"-1"}
  
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog, private datePipe: DatePipe) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.uvc_list=('getBDBankTrxOut' in loading)?true:false;
      this.apiLoader.cadc_export=('exportBDBankTransactionOut' in loading)?true:false;
      if(this.dIndex.status.use){
        this.trxInfoData[this.dIndex.status.row][this.dIndex.status.col].icon = ('changeBDBankTransactionOutStatus' in loading)?'Loading':'Toggle'
      }
    });
    this.GetAllTrx();
  }
  
  initializeData()
  {
    this.allTrxinfo = [];
    this.trxInfoData = [];
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllTrx();
  }
  
  GetAllTrx() {
    this.initializeData();
    this.apiservice.sendRequest(config['getBDBankTrxOut'], this.currentQuery,'getBDBankTrxOut').subscribe((data: any) => {
      this.allTrxinfo=data;
      if(this.allTrxinfo[0]){
        this.trxDataCollumns=this.trxCollumnHeaders;
        this.pagesTotal=Math.ceil(this.allTrxinfo[0].TotalCount/this.currentQuery.PageSize);
        this.allTrxinfo.forEach((element:any,index:any) => {
          this.trxInfoData.push([
          {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
          {value:element.Status,bg:'white-cell',icon:'Toggle'},
          {value:element.Date,bg:'white-cell'},
          // {value:element.Mobile,bg:'white-cell'},
          // {value:element.UserName,bg:'white-cell'},
          {value:element.ReferenceId,bg:'white-cell'},
          {value:element.AccountNumber,bg:'white-cell'},
          {value:element.BankUPIIDViaAPI,bg:'white-cell'},
          {value:element.Description,bg:'white-cell'},
          {value:element.ExtraDescription,bg:'white-cell'},
          // {value:element.RefereceNumber,bg:'white-cell'},
          // {value:element.DeviceiId,bg:'white-cell'},
          // {value:element.DeviceInfo,bg:'white-cell'},
          {value:element.Amount,bg:'white-cell'},
          {value:element.BankName,bg:'white-cell'},
          {value:element.AccountBalance,bg:'white-cell'},
          {value:element.Type,bg:'white-cell'},
          {value:element.WalletType,bg:'white-cell'},
          {value:element.PaymentMethod,bg:'white-cell'},
          {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy")+" "+element.CreatedDateTZ:'',bg:'white-cell'}
          ])
        });
        this.rowCount={f:this.trxInfoData[0][0].value,l:this.trxInfoData[this.trxInfoData.length-1][0].value,t:this.allTrxinfo[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.trxDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.Search.value;
    let Status = formVal.Type.value;
    console.log(formVal)
    if(formVal.Status.value=="Active"){
      this.currentQuery.intParam1="1";
    }
    else if(formVal.Status.value=="Blocked"){
      this.currentQuery.intParam1="0"
    }
    else{
      this.currentQuery.intParam1="-1"
    }
    if(Status=='All'){
      this.currentQuery.StartDateTime=null;
      this.currentQuery.EndDateTime=null;
    }
    else if(Status=='Date Range'){
      this.currentQuery.StartDateTime=moment(formVal.Type.subque[0].value1).format('YYYY-MM-DD');
      this.currentQuery.EndDateTime=moment(formVal.Type.subque[0].value2).format('YYYY-MM-DD');
      this.export = true;
    }
    this.currentQuery.PageNo = 1;
    this.GetAllTrx();
  }
  
  closePopup(){
    this.dialog.closeAll();
  }

  onSave(){
    this.GetAllTrx();
  }

  TrxOpenPopup() {
    let dialogRef = this.dialog.open(this.TrxDialogOpen, {
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.closePopup();
    })
  }

  onValueChange(formVal:any){
    let allBankData = this.allTrxinfo[formVal.row];
    if(formVal.col==1){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      let param = '?Id='+ allBankData.Id;
      this.changeStatus(param);
    }
  }

  DownloadExcelData(){
    let d1 = this.datePipe.transform(this.currentQuery.StartDateTime, 'dd/MM/yyyy 00:00');
    let d2 = this.datePipe.transform(this.currentQuery.EndDateTime, 'dd/MM/yyyy 23:59');
    let search = this.currentQuery.Search?this.currentQuery.Search:'';
    let status = this.currentQuery.intParam1;
    d1 = d1?d1:' ';
    d2 = d2?d2:' ';
    let request = "?SearchText="+search+"&StartDateTime="+d1+"&EndDateTime="+d2+"&status="+status;
    let docname = 'BDBankTranscation'+'_'+(d1)+'to_'+(d2);
    this.apiservice.exportExcel(config['exportBDBankTransactionOut'] + request,docname,'exportBDBankTransactionOut');
  }

  changeStatus(data:any){
    this.apiservice.getRequest(config['changeBDBankTransactionOutStatus']+data,'changeBDBankTransactionOutStatus').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.trxInfoData[this.dIndex.status.row][this.dIndex.status.col].value=!this.trxInfoData[this.dIndex.status.row][this.dIndex.status.col].value;
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      this.utilities.toastMsg('error',"Failed","Some thing went Wrong");
    });
  }
}
