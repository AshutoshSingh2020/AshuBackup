import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TransactionoutComponent } from './transactionout.component';

describe('TransactionoutComponent', () => {
  let component: TransactionoutComponent;
  let fixture: ComponentFixture<TransactionoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TransactionoutComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TransactionoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
