import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BdBankRoutingModule } from './bd-bank-routing.module';

import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { SharedModule } from '@shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from "@angular/material/table";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatSnackBarModule } from "@angular/material/snack-bar";
import { MatIconModule } from "@angular/material/icon";
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDialogModule } from '@angular/material/dialog';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

import { FeatherModule } from 'angular-feather';
import { allIcons } from 'angular-feather/icons';

import { BdBankTrxComponent } from './bd-bank-trx/bd-bank-trx.component';
import { AddTrxDetailComponent } from './bd-bank-trx/add-trx-detail/add-trx-detail.component';
import { BdAllbankComponent } from './bd-allbank/bd-allbank.component';
import { AppNotificationComponent } from './app-notification/app-notification.component';
import { BdDaytrxComponent } from './bd-daytrx/bd-daytrx.component';
import { ViewBddetailsComponent } from './bd-allbank/view-bddetails/view-bddetails.component';
import { MerchantBankComponent } from './merchant-bank/merchant-bank.component';
import { ViewMerchantComponent } from './merchant-bank/view-merchant/view-merchant.component';
import { TransactionoutComponent } from './transactionout/transactionout.component';
import { AddTrxoutComponent } from './transactionout/add-trxout/add-trxout.component';


@NgModule({
  declarations: [
    BdBankTrxComponent,
    AddTrxDetailComponent,
    BdAllbankComponent,
    AppNotificationComponent,
    BdDaytrxComponent,
    ViewBddetailsComponent,
    MerchantBankComponent,
    ViewMerchantComponent,
    TransactionoutComponent,
    AddTrxoutComponent
  ],
  imports: [
    CommonModule,
    BdBankRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    MatTableModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatIconModule,
    FormsModule,
    MatButtonModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatTabsModule,
    MatDialogModule,
    MatRadioModule,
    MatSelectModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSlideToggleModule,
    FeatherModule.pick(allIcons)
  ]
})
export class BdBankModule { }
