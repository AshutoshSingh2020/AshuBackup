import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BdBankTrxComponent } from './bd-bank-trx.component';

describe('BdBankTrxComponent', () => {
  let component: BdBankTrxComponent;
  let fixture: ComponentFixture<BdBankTrxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BdBankTrxComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BdBankTrxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
