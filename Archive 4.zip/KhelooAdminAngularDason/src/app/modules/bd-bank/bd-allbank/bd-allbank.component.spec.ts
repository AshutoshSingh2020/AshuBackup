import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BdAllbankComponent } from './bd-allbank.component';

describe('BdAllbankComponent', () => {
  let component: BdAllbankComponent;
  let fixture: ComponentFixture<BdAllbankComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BdAllbankComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BdAllbankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
