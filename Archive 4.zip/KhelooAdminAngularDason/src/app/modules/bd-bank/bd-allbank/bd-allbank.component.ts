import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { DatePipe } from '@angular/common';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-bd-allbank',
  templateUrl: './bd-allbank.component.html',
  styleUrls: ['./bd-allbank.component.scss'],
  providers: [DatePipe]
})
export class BdAllbankComponent implements OnInit {
  @ViewChild('VewClientDetailsOpen') VewClientDetailsOpen!: TemplateRef<any>;
  assignList: any = [];
  detailsToView={};
  apiLoader={bdbank_list:false};
  ClienNameList: any = [];
  export:boolean = false;
  allTrxinfo:any=[];
  trxInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,200,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  maxDate=new Date();
  dIndex={status:{row:0,col:0,use:false},isVisible:{row:0,col:0,use:false}};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  trxCollumnHeaders:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Status',bg:'white-drop'},{value:'Is Visible',bg:'white-drop'},
    {value:'User Name',bg:'white-drop'},{value:'UPI Id',bg:'white-drop'},{value:'App Name',bg:'white-drop'},
    {value:'Wallet Name',bg:'white-drop'},{value:'Date',bg:'white-drop'},{value:'Updated BY',bg:'white-drop'},
    {value:'Last Update',bg:'white-drop'},
    {value:'Action',bg:'white-drop'}]
  ]
  
  trxDataCollumns=this.trxCollumnHeaders;

  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[3],"StartDateTime": null,"EndDateTime": null,"intParam1":"-1"}
  
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog, private datePipe: DatePipe) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.bdbank_list='getBDAllBankDetails' in loading;
      if(this.dIndex.status.use)
      {
        this.trxInfoData[this.dIndex.status.row][this.dIndex.status.col].icon=('changeBDBankUpiStatus' in loading)?'Loading':'Toggle';
      }
      if(this.dIndex.isVisible.use)
      {
        this.trxInfoData[this.dIndex.isVisible.row][this.dIndex.isVisible.col].icon=('changeBDBankUpiIsVisible' in loading)?'Loading':'Toggle';
      }
    });
    this.getAllData();
  }
  
  getAllData()
  {
    this.GetAllTrx();
  }
  
  initializeData()
  {
    this.allTrxinfo = [];
    this.trxInfoData = [];
  }
  
  GetAllTrx() {
    this.initializeData();
    this.apiservice.getRequest(config['getBDAllBankDetails'] ,'getBDAllBankDetails').subscribe((data: any) => {
      this.allTrxinfo=data;
      if(this.allTrxinfo[0]){
        this.trxDataCollumns=this.trxCollumnHeaders;
        let bg_cell = '';
        this.pagesTotal=Math.ceil(this.allTrxinfo[0].TotalCount/this.currentQuery.PageSize);
        this.allTrxinfo.forEach((element:any,index:any) => {
          bg_cell = element.IsUpdatedStatus == 'Y'?'blue-blink-cell':'white-cell';
          this.trxInfoData.push([
          {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:bg_cell},
          {value:element.StatusId,bg:bg_cell,icon:'Toggle'},
          ...(element.StatusId?[{value:element.IsVisible,bg:bg_cell,icon:'Toggle'}]:[{value:'',bg:bg_cell,icon:''}]),
          {value:element.UserName,bg:bg_cell},
          {bg:bg_cell,icon:'Multi',value:[{value:element.UpiId},
            ...(element.ClientName?[{span_values:['Client : '+element.ClientName],span_classes:["badge light badge-primary badge-mrtop"]}]:[{value:''}])
            // {brLine:element.IsVisible?true:false},
            // ...(element.IsVisible?[{href_values:['15 Minutes : '+'loading...','30 Minutes : '+'loading...','1 Hour : '+'loading...'],href_classes:["","",""]}]:[{value:''}])
          ]},
          {value:element.AppName,bg:bg_cell},
          {value:element.WalletName,bg:bg_cell},          
          {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy")+" "+element.CreatedDateTZ:'',bg:bg_cell},
          {value:element.UpdatedBy,bg:bg_cell},
          {value:element.UpdatedDate?moment(element.UpdatedDate).format("h:mm:ss A, DD-MMM-yyyy")+" "+element.UpdatedDateTZ:'',bg:bg_cell},
          {value:'View',bg:bg_cell,icon:'None'}        
          ])
        });
        this.rowCount={f:this.trxInfoData[0][0].value,l:this.trxInfoData[this.trxInfoData.length-1][0].value,t:this.allTrxinfo[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.trxDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }

  onValueChange(formVal:any){
    let allBankData = this.allTrxinfo[formVal.row];
    if(formVal.col==1){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      let param = '?Id='+ allBankData.Id;
      this.changeStatus(param);
    }
    if(formVal.col==2){
      this.dIndex.isVisible.row=formVal.row;
      this.dIndex.isVisible.col=formVal.col;
      this.dIndex.isVisible.use=true;
      let param = '?Id='+ allBankData.Id;
      this.changeVisible(param);
    }else if(formVal.col==10){
      this.detailsToView = this.allTrxinfo[formVal.row];
      this.ClientDetailsOpenPopup();
    }
  }
  ClientDetailsOpenPopup() {
    let dialogRef = this.dialog.open(this.VewClientDetailsOpen, {
      panelClass: 'screen-dialog',
      width:'800px',
      height:'700px'
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  changeStatus(data:any){
    this.apiservice.getRequest(config['changeBDBankUpiStatus']+data,'changeBDBankUpiStatus').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.GetAllTrx();
          // this.trxInfoData[this.dIndex.status.row][this.dIndex.status.col].value=!this.trxInfoData[this.dIndex.status.row][this.dIndex.status.col].value;
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      this.utilities.toastMsg('error',"Failed","Some thing went Wrong");
    });
  }
  changeVisible(data:any){
    this.apiservice.getRequest(config['changeBDBankUpiIsVisible']+data,'changeBDBankUpiIsVisible').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.trxInfoData[this.dIndex.isVisible.row][this.dIndex.isVisible.col].value=!this.trxInfoData[this.dIndex.isVisible.row][this.dIndex.isVisible.col].value;
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      this.utilities.toastMsg('error',"Failed","Some thing went Wrong");
    });
  }
}
