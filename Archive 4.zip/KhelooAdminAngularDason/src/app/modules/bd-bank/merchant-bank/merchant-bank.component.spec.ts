import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantBankComponent } from './merchant-bank.component';

describe('MerchantBankComponent', () => {
  let component: MerchantBankComponent;
  let fixture: ComponentFixture<MerchantBankComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MerchantBankComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MerchantBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
