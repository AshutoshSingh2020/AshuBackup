import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { BdBankTrxComponent } from './bd-bank-trx/bd-bank-trx.component';
import { BdAllbankComponent } from './bd-allbank/bd-allbank.component';
import { AppNotificationComponent } from './app-notification/app-notification.component';
import { BdDaytrxComponent } from './bd-daytrx/bd-daytrx.component';
import { MerchantBankComponent } from './merchant-bank/merchant-bank.component';
import { TransactionoutComponent } from './transactionout/transactionout.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'bdbanktransaction',
    pathMatch: 'full'
  },
  {
    path: 'bdbanktransaction',
    component: BdBankTrxComponent
  },
  {
    path: 'transactionout',
    component: TransactionoutComponent
  },
  {
    path: 'bdallbank',
    component: BdAllbankComponent
  },
  {
    path: 'bdappnotification',
    component: AppNotificationComponent
  },
  {
    path: 'bddailybanktransaction',
    component: BdDaytrxComponent
  },
  {
    path: 'bdmerchantbank',
    component: MerchantBankComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BdBankRoutingModule { }
