import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-app-notification',
  templateUrl: './app-notification.component.html',
  styleUrls: ['./app-notification.component.scss'],
  providers: [DatePipe]
})
export class AppNotificationComponent implements OnInit {

  assignList: any = [];
  export:boolean=false;
  ClienNameList: any = [];
  @ViewChild('TrxDialogOpen') TrxDialogOpen!: TemplateRef<any>;
  apiLoader={cadc_list:false,cadc_export:false};
  allTrxinfo:any=[];
  trxInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,200,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  maxDate=new Date();
  
  dynamicControls = [{que:'Type',type:'dropdown',options:['All','Date Range'],
  subque:[{showIf:'Date Range',que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]}]},
  {que:'Search',type:'input',subque:[]}];
  
  trxCollumnHeaders:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Date',bg:'white-drop'},{value:'Description',bg:'white-drop'},{value:'Bank',bg:'white-drop'},
    {value:'Created Date',bg:'white-drop'}]
  ]
  
  trxDataCollumns=this.trxCollumnHeaders;
  
  trxCollumnLoading = false;

  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[3],"StartDateTime": null,"EndDateTime": null}
  
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog,private datePipe:DatePipe) { }
  
  ngOnInit(): void {
    this.getAllData();
  }
  
  getAllData()
  {
    this.GetAllTrx();
  }
  
  initializeData()
  {
    this.trxCollumnLoading = true;
    this.allTrxinfo = [];
    this.trxInfoData = [];
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllTrx();
  }
  
  GetAllTrx() {
    this.initializeData();
    this.apiservice.sendRequest(config['getBDBankAppNotification'], this.currentQuery).subscribe((data: any) => {
      this.trxCollumnLoading = false;
      this.allTrxinfo=data;
      if(this.allTrxinfo[0]){
        this.trxDataCollumns=this.trxCollumnHeaders;
        this.pagesTotal=Math.ceil(this.allTrxinfo[0].TotalCount/this.currentQuery.PageSize);
        this.allTrxinfo.forEach((element:any,index:any) => {
          this.trxInfoData.push([
          {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
          {value:element.TransactionDate,bg:'white-cell'},
          {value:element.Description,bg:'white-cell'},
          {value:element.BankName,bg:'white-cell'},
          {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy")+" "+element.CreatedDateTZ:'',bg:'white-cell'}
          ])
        });
        this.rowCount={f:this.trxInfoData[0][0].value,l:this.trxInfoData[this.trxInfoData.length-1][0].value,t:this.allTrxinfo[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.trxDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      this.trxCollumnLoading = false;
      console.log(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  getSearchQuery(formVal:any)
  {
    console.log(formVal);
    this.currentQuery.Search=formVal.Search.value;
    let typeVal = formVal.Type.value;
    if(typeVal=='All'){
      this.currentQuery.StartDateTime=null;
      this.currentQuery.EndDateTime=null;
    }
    else if(typeVal=='Date Range'){
      this.currentQuery.StartDateTime=moment(formVal.Type.subque[0].value1).format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
      this.currentQuery.EndDateTime=moment(formVal.Type.subque[0].value2).format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
      this.export = true;
    }
    this.currentQuery.PageNo = 1;
    this.GetAllTrx();
  }
  

}
