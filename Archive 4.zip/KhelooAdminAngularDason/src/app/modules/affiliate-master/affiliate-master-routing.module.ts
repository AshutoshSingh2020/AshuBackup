import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { AddAffiliateComponent } from './add-affiliate/add-affiliate.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'add-affiliate',
    pathMatch: 'full'
  },
  {
    path: 'add-affiliate',
    component: AddAffiliateComponent
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AffiliateMasterRoutingModule { }
