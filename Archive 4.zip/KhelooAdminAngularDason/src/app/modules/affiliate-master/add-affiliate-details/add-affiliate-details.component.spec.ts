import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAffiliateDetailsComponent } from './add-affiliate-details.component';

describe('AddAffiliateDetailsComponent', () => {
  let component: AddAffiliateDetailsComponent;
  let fixture: ComponentFixture<AddAffiliateDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddAffiliateDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddAffiliateDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
