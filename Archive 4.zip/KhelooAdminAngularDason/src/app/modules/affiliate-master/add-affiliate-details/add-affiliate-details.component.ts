import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators,ValidatorFn ,AbstractControl} from "@angular/forms";

import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';

const passwordMatchValidator: ValidatorFn = (control: AbstractControl): {[key: string]: any} | null => {
  let password = control.get('Password')?.value;
  let confirmPassword = control.get('ConfirmPassword')?.value;

  return password !== confirmPassword ? {mismatch: true } :null ;
};

@Component({
  selector: 'app-add-affiliate-details',
  templateUrl: './add-affiliate-details.component.html',
  styleUrls: ['./add-affiliate-details.component.scss']
})

export class AddAffiliateDetailsComponent implements OnInit {

  @Input() submitBtn!:boolean;
  @Output() onSave = new EventEmitter<any>();
  @Output() onCancel = new EventEmitter<any>();
  
  submitDisabled=false;
  
  resetBtn = true;
  affiliate!: FormGroup;
  adminPass = '';

  constructor(private formBuilder: FormBuilder, private apiservice: ApiService, private utilities : CommonFunctionService) { }

  ngOnInit(){
    this.initializeForm();
  }
  
  initializeForm(){
    this.affiliate = this.formBuilder.group({
      CompanyName: ["", [Validators.required]],
      PersonName: ["", [Validators.required]],
      Gender: ["M", [Validators.required]],
      Mobile: ["", [Validators.required,Validators.pattern('[6-9]\\d{9}')]],
      Email: ["", [Validators.required,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
      Password: ["", [Validators.required]],
      ConfirmPassword: ["", [Validators.required]],

      }
      ,{
        validators: passwordMatchValidator
       }
       );
  }
  
  onBack(){
    this.onCancel.emit();
  }
  



  onSubmit(){
    if(this.affiliate.invalid){
      this.utilities.toastMsg('warning','Please Remove All Errors From Form!','');
    }
    else{
      this.submitDisabled=true;
      let FormValue = this.affiliate.getRawValue();
      if(!FormValue.id){
        delete FormValue.id;
        this.apiservice.sendRequest(config['saveAffiliate'],FormValue).subscribe((data: any) => {
          this.submitDisabled=false;
          if (data.ErrorCode === "1") {
            this.utilities.toastMsg('success',"Success", data.ErrorMessage);
            this.adminPass=data.ErrorMessage;
            this.affiliate.disable();
            this.onCancel.emit();
          }
          else {
            this.utilities.toastMsg('warning',"Failed",data.Result + " : " + data.ErrorMessage);
          }
          this.onSave.emit();
        }, (error) => {
          console.log(error);
        });
      }
    }
  }

}
