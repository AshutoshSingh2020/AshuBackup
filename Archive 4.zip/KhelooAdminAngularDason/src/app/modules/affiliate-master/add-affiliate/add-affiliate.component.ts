import { Component, OnInit , TemplateRef, ViewChild } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import moment from 'moment';

@Component({
  selector: 'app-add-affiliate',
  templateUrl: './add-affiliate.component.html',
  styleUrls: ['./add-affiliate.component.scss']
})
export class AddAffiliateComponent implements OnInit {


  @ViewChild('AddAdminDialogOpen') AddAdminDialogOpen!: TemplateRef<any>;
  AllAffiliateinfo:any=[];
  AffiliateinfoData:any=[];
  dynamicControls = [
    {changeAction:'submit',type:'select',default:{value:"",name:'All Status'},options:[{value:"1",name:'Active'},{value:"0",name:'Blocked'}]},
    {placeholder:'Search',type:'text',label:'Search'}
  ];
  AdminCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Company Name',bg:'white-drop'},{value:'Person Name',bg:'white-drop'},
    {value:'Gender',bg:'white-drop'},{value:'Mobile',bg:'white-drop'},{value:'Email',bg:'white-drop'},
    {value:'Created Date',bg:'white-drop'},{value:'Status',bg:'white-drop'}]
  ]
  AdminDataCollumns=[];
  paginatorBlock:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  apiLoader={uvc_list:false};
  currentQuery={ "Search": "", "intParam1": "-1", "intParam2": "0","PageNo" : 1,"PageSize": 10};
  RolesList=[];
  addadminloader={getAdminRoles:false,getAllAffiliate:false};
  dIndex={status:{row:0,col:0,use:false}};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }
  ngOnInit(): void
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.addadminloader.getAllAffiliate=('getAllAffiliate' in loading)?true:false;
      if(this.dIndex.status.use)
      {
        this.AffiliateinfoData[this.dIndex.status.row][this.dIndex.status.col].icon=('saveBlockAffiliate' in loading)?'Loading':'Toggle';
      }
    });
    this.GetAllAffiliate();
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }


  initializeData(){
    this.AllAffiliateinfo=[];
    this.AffiliateinfoData=[];
    this.dIndex={status:{row:0,col:0,use:false}};
  }
  onPaginatorChange(paginatorQuery:any){
    
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllAffiliate();
  }
  GetAllAffiliate()
  {
    this.initializeData();
    this.apiservice.sendRequest(config['getAllAffiliate'], this.currentQuery, 'getAllAffiliate').subscribe((data: any) => {
      this.AllAffiliateinfo=data;
      if(this.AllAffiliateinfo[0]){
        this.AdminDataCollumns=this.AdminCollumnHeaders;
        this.pagesTotal=Math.ceil(this.AllAffiliateinfo[0].TotalCount/this.currentQuery.PageSize);
        this.AllAffiliateinfo.forEach((element:any,index:any) => {
          this.AffiliateinfoData.push([
            {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
            {value:element.CompanyName,bg:'white-cell'},
            {value:element.PersonName,bg:'white-cell'},
            {value:element.Gender,bg:'white-cell'},
            {value:element.Mobile,bg:'white-cell'},
            {value:element.Email,bg:'white-cell'},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
            {value:element.Status,bg:'white-cell',icon:'Toggle'},
          ])
        });
        this.rowCount={f:this.AffiliateinfoData[0][0].value,l:this.AffiliateinfoData[this.AffiliateinfoData.length-1][0].value,t:this.AllAffiliateinfo[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.AdminDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.error(error);
    });
  }
  getSearchQuery(formVal:any)
  {
    this.currentQuery.intParam1=formVal.C0?formVal.C0:"-1";
    this.currentQuery.Search=formVal.C1;
    this.GetAllAffiliate();
  }
  onValueChange(formVal:any)
  {
    let adminData = this.AllAffiliateinfo[formVal.row];
    if(formVal.col == 7){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      let param = '?Id='+ adminData.Id;
      this.changeAffiliateStatus(param);
    }
    
  }
  changeAffiliateStatus(param:any)
  {
    this.apiservice.getRequest(config['saveBlockAffiliate'] + param,'saveBlockAffiliate').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
         this.utilities.toastMsg('success',"Success", data.ErrorMessage);
         this.AffiliateinfoData[this.dIndex.status.row][this.dIndex.status.col].value=!this.AffiliateinfoData[this.dIndex.status.row][this.dIndex.status.col].value;
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.error(error);
    });
  }

  AddAdminOpenPopup() {
    let dialogRef = this.dialog.open(this.AddAdminDialogOpen, {
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  closePopup(){
    this.dialog.closeAll();
  }
}