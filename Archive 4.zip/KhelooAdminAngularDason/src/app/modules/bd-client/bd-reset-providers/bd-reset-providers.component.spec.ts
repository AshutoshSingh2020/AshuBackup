import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BdResetProvidersComponent } from './bd-reset-providers.component';

describe('BdResetProvidersComponent', () => {
  let component: BdResetProvidersComponent;
  let fixture: ComponentFixture<BdResetProvidersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BdResetProvidersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BdResetProvidersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
