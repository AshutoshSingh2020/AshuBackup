import { Component, OnInit,Input,EventEmitter, Output} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
@Component({
  selector: 'app-bd-reset-providers',
  templateUrl: './bd-reset-providers.component.html',
  styleUrls: ['./bd-reset-providers.component.scss']
})
export class BdResetProvidersComponent implements OnInit {
  @Input() userData:any;
  @Input() submitBtn!:boolean;
  @Output() onSave = new EventEmitter<any>();
  @Output() onCancel = new EventEmitter<any>();
  submitDisabled=false;
  todayDate = new Date();
  
  resetBtn = true;
  playerForm!: FormGroup;
  adminPass = '';

  constructor(private formBuilder: FormBuilder, private apiservice: ApiService, private utilities : CommonFunctionService) { }

  ngOnInit(){
    this.initializeForm();
  }
  
  initializeForm(){
    this.playerForm = this.formBuilder.group({
      UserId:[this.userData.UserId],
      UserName:[this.userData.UserName, [Validators.required]],
      FName:[this.userData.FName, [Validators.required]],
      LName:[this.userData.LName, [Validators.required]],
      DOB:[this.userData.DOB, [Validators.required]]
      });
  }
  
  onBack(){
    this.onCancel.emit();
  }

  onSubmit(){
    let param = '?Id='+this.userData.Id;
    this.submitDisabled=true;
    this.apiservice.getRequest(config['bdresetpayout']+param,'bdresetpayout').subscribe((data: any) => {
      this.submitDisabled=false;
      if (data.ErrorCode === "1") {
        this.utilities.toastMsg('success',"Success", data.ErrorMessage);
        this.adminPass=data.ErrorMessage;
        this.onCancel.emit();
      }
      else {
        this.utilities.toastMsg('warning',"Failed",data.Result + " : " + data.ErrorMessage);
        this.onCancel.emit();
      }
    }, (error) => {
      console.log(error);
      this.utilities.toastMsg('warning',"Failed","Please try later");
      this.onCancel.emit();
    });
  }

}
