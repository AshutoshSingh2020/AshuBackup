import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

import _moment , {default as _rollupMoment} from 'moment';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'DD MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'DD MMMM YYYY',
  },
};

@Component({
  selector: 'app-bdclient-payout',
  templateUrl: './bdclient-payout.component.html',
  styleUrls: ['./bdclient-payout.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },
    
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ]
})
export class BdclientPayoutComponent implements OnInit {
  @ViewChild('VewDetailsOpen') VewDetailsOpen!: TemplateRef<any>;
  @ViewChild('ApproveDialogOpen') ApproveDialogOpen!: TemplateRef<any>;
  @ViewChild('SupportApproveDialogOpen') SupportApproveDialogOpen!: TemplateRef<any>;
  @ViewChild('ManualApproveDialogOpen') ManualApproveDialogOpen!: TemplateRef<any>;

  @ViewChild('ResetDialogOpen') ResetDialogOpen!: TemplateRef<any>;
  allData:any=[];
  tableInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  detailsToView={};
  AcceptRejectVar="AP";
  paginatorBlock:any=[];
  
  dynamicControls = [
    {changeAction:'submit',type:'select',default:{value:"",name:'All'},options:[{value:"PD",name:'Pending'},{value:"PR",name:'In Process'},{value:"AP",name:'Approved'},{value:"AS",name:'Approve Support'},{value:"RJ",name:'Rejected'}]},
    {placeholder:'Search',type:'text',label:'Search'}
  ];
  collumnHeads:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Client',bg:'white-drop'},{value:'Request Id',bg:'white-drop'},
    {value:'Amount',bg:'white-drop'},{value:'AccountHolderName',bg:'white-drop'},{value:'Account',bg:'white-drop'},
    {value:'Status',bg:'white-drop'},{value:'UTR',bg:'white-drop'},{value:'Description',bg:'white-drop'},
    {value:'Date',bg:'white-drop'},{value:'Updated',bg:'white-drop'},{value:'View',bg:'white-drop'},
    {value:'Action',bg:'white-drop'}]
  ];
  tableCollumns=this.collumnHeads;
  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[2],"Status":""};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={wrc_list:false,wrc_export:false};
  dateValue: any=[new Date(),new Date()];
  maxDate=new Date();
  showExportDates=false;
  ExportClicked=false;
  payoutList=[];
  WithdrawBankList=[];
  PGPayoutProviderList=[];
  safeXPayBal=[];
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private dialog: MatDialog) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.wrc_list=('getBDClientPayout' in loading)?true:false;
      if('exportBdClientPayout_Download' in loading){
        this.apiLoader.wrc_export=this.ExportClicked=true;
      }
      else{
        this.apiLoader.wrc_export=false;
        if(this.ExportClicked){
          this.showExportDates=false;
        }
      }
    });
    this.getAllData();
  }
  
  getAllData(){
    this.GetMasterData();
    this.apiSubscriber[0] = this.apiservice.getRequest(config['getPayoutList'],'getPayoutList').subscribe({
      next: (data:any) => {
        this.payoutList=data;
        // this.dynamicControls[1].options = this.dynamicControls[1].filteredOptions = this.payoutList.map(({ Id, CompanyName }) => ({
        //   value: Id,
        //   name: CompanyName
        // }));
      },
      error: (error)=> {
        console.log(error);
      }
    });
    this.apiSubscriber[1] = this.apiservice.getRequest(config['getWithdrawBank'],'getWithdrawBank').subscribe({
      next: (data:any) => {
        this.WithdrawBankList=data;
      },
      error: (error)=> {
        console.log(error);
      }
    });
    this.apiSubscriber[2] = this.apiservice.getRequest(config['getPGPayoutProvider'],'getPGPayoutProvider').subscribe({
      next: (data:any) => {
        this.PGPayoutProviderList=data;
      },
      error: (error)=> {
        console.log(error);
      }
    });
    this.apiSubscriber[3] = this.apiservice.getRequest(config['getSafeXPayBal'],'getSafeXPayBal').subscribe({
      next: (data:any) => {
        this.safeXPayBal=data;
      },
      error: (error)=> {
        console.log(error);
      }
    });
  }
  
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetMasterData();
  }
  personRole=JSON.parse(localStorage.getItem('personalDetails')).RoleCode;
  GetMasterData() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['getBDClientPayout'], this.currentQuery, 'getBDClientPayout').subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.tableCollumns=this.collumnHeads;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
        let bg_cell = '';
        this.allData.forEach((element:any,index:any) => {
          bg_cell = element.FirstDeposit && (element.StatusCode == 'PR' || element.StatusCode == 'P')?'blue-blink-cell':'white-cell';
          this.tableInfoData.push([
            {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:bg_cell},
            {value:element.CompanyName,bg:bg_cell},
            {value:element.RequestId,bg:bg_cell,sufText:element.PaymentRequestId},
            {value:element.Amount,bg:bg_cell},
            {value:element.AccountHolderName,bg:bg_cell},
            {value:element.AccountNumber,bg:bg_cell},
            {value:element.StatusName,bg:bg_cell},
            {value:element.UTRNumber,bg:bg_cell,sufText:element.RefTransactionId?element.RefTransactionId:'',span_values:[element.PayoutVia],span_classes:["badge light badge-primary"]},
            {value:element.Description,bg:bg_cell},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy")+" "+element.CreatedDateTZ:'',bg:bg_cell,sufText:element.TimeAgo},
            ...(element.UpdatedDate?[{value:moment(element.UpdatedDate).format("h:mm:ss A, DD-MMM-yyyy")+" "+element.UpdatedDateTZ,bg:bg_cell,sufText:"Claim : "+element.ClaimTime}]:[{value:"",bg:'white-cell'}]),
            {value:'',bg:bg_cell,icon:'View'},
            {bg:bg_cell,icon:'Multi',value:[
              ...((element.StatusCode=='PD' || element.StatusCode=='PR' )?[{value:'SApprove',bg:bg_cell,icon:'None',hrefvalue:element.FileNameServer}]:[]),
              ...((element.StatusCode=='PD' || element.StatusCode=='PR')?[{value:'MApprove',bg:bg_cell,icon:'None',hrefvalue:element.FileNameServer}]:[]),
              // ...([{value:'MApprove',bg:bg_cell,icon:'None',hrefvalue:element.FileNameServer}]),

              ...((element.StatusCode=='PD' || element.StatusCode=='PR' || element.StatusCode=='MA')?[{value:'Approve',bg:bg_cell,icon:'None',hrefvalue:element.FileNameServer}]:[]),
              ...(element.StatusCode=='AP'?[]:[]),
              ...((element.StatusCode=='PD' || element.StatusCode=='PR' || element.StatusCode=='MA')?[{value:'Reject',bg:bg_cell,icon:'None'}]:[]),
              ...((((((element.PayoutVia=='AGENTPAY' || element.PayoutVia=='PRONTOPAY' ) && !element.RefTransactionId) || element.StatusCode=='MA') && this.personRole=='SA'))?[{value:'Reset Provider',bg:bg_cell,icon:'None'}]:[]),
              ...((((element.PayoutVia=='Scrapper' && !element.RefTransactionId) && this.personRole=='SA'))?[{value:'Reset Scrapper',bg:bg_cell,icon:'None'}]:[]),
              ...(((element.StatusCode=='PD' || element.StatusCode=='PR') && element.UTRNumber)?[]:[])]
            }
          ])
        });
        this.rowCount={f:this.tableInfoData[0][1].value,l:this.tableInfoData[this.tableInfoData.length-1][1].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.tableCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }
  
  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  onValueChange(formVal:any){
    if(formVal.col==10 && formVal.type=='Users'){
      window.open('/users/playerdetailview/'+this.allData[formVal.row].UserId, '_blank');
    }
    if(formVal.col==11 && formVal.type=='View'){
      this.detailsToView=this.allData[formVal.row];
      this.BDataOpenPopup()
    }
    if(formVal.col==12 && formVal.type=='Process'){
      this.detailsToView=this.allData[formVal.row];
      this.ProcessWithdrawal();
    }
    if(formVal.col==12 && formVal.type=='Approve'){
      this.AcceptRejectVar="AP";
      this.detailsToView=this.allData[formVal.row];
      this.ApproveOpenPopup();
    }
    if(formVal.col==12 && formVal.type=='Reject'){
      this.AcceptRejectVar="RJ";
      this.detailsToView=this.allData[formVal.row];
      this.ApproveOpenPopup();
    }
    if(formVal.col==12 && formVal.type=='Reset Provider'){
      this.AcceptRejectVar="Reset";
      this.detailsToView=this.allData[formVal.row];
      this.ResetOpenPopup();
    }
    if(formVal.col==12 && formVal.type=='SApprove'){
      this.AcceptRejectVar="SAP";
      this.detailsToView=this.allData[formVal.row];
      this.SupportApproveOpenPopup();
    }
    if(formVal.col==12 && formVal.type=='MApprove'){
      // this.AcceptRejectVar="SAP";
      this.detailsToView=this.allData[formVal.row];
      this.ManualApproveOpenPopup();
    }
    
    if(formVal.col==12 && formVal.type=='Reset Scrapper'){
      this.AcceptRejectVar="RTS";
      this.detailsToView=this.allData[formVal.row];
      this.SupportApproveOpenPopup();
    }
  }
  ResetOpenPopup() {
    let dialogRef = this.dialog.open(this.ResetDialogOpen, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  BDataOpenPopup() {
    let dialogRef = this.dialog.open(this.VewDetailsOpen, {
      width: '600px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  closePopup(){
    this.GetMasterData();
    this.dialog.closeAll();
  }
  SupportApproveOpenPopup(){
    let dialogRef = this.dialog.open(this.SupportApproveDialogOpen, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})

  }

  ManualApproveOpenPopup(){
    let dialogRef = this.dialog.open(this.ManualApproveDialogOpen, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})

  }
  ApproveOpenPopup() {
    let dialogRef = this.dialog.open(this.ApproveDialogOpen, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  ProcessWithdrawal(){
    this.apiservice.sendRequest(config['processWithdrawal'], this.detailsToView).subscribe((data: any) => {
      if(data.ErrorCode=='1'){
        this.utilities.toastMsg("success", "Success", data.ErrorMessage);
        this.GetMasterData();
      }
      else{
        this.utilities.toastMsg("error", "Error", data.ErrorMessage);
      }
    }, (error) => {
      this.utilities.toastMsg("error", "Can not process", '');
      console.log(error);
    });
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Status=formVal.C0;
    // this.currentQuery.ClientId=formVal.C1;
    this.currentQuery.Search=formVal.C1;
    this.currentQuery.PageNo = 1;
    this.GetMasterData();
  }
  
  DownloadWithdrawalRequestData() {
    let d1 = (moment(this.dateValue[0]).format("DD/MM/yyyy HH:mm"));
    let d2 = (moment(this.dateValue[1]).format("DD/MM/yyyy HH:mm"));
    let request = "?Search="+this.currentQuery.Search+"&TransactionStatus="+this.currentQuery.Status+"&StartDateTime="+d1+"&EndDateTime="+d2;
    let docname = 'BdClientPayout_Download'+d1+'_'+d2;
    this.apiservice.exportExcel(config['exportBdClientPayout_Download'] + request,docname,'exportBdClientPayout_Download');
  }
  
  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    this.apiSubscriber.forEach(subscription => {
      subscription.unsubscribe();
    });
  }
}
