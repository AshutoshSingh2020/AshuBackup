import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BdClientRoutingModule } from './bd-client-routing.module';
import { BdclientDepositComponent } from './bdclient-deposit/bdclient-deposit.component';
import { BdclientPayoutComponent } from './bdclient-payout/bdclient-payout.component';
import { BdclientAddDepositComponent } from './bdclient-add-deposit/bdclient-add-deposit.component';

import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { SharedModule } from '@shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from "@angular/material/table";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatSnackBarModule } from "@angular/material/snack-bar";
import { MatIconModule } from "@angular/material/icon";
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDialogModule } from '@angular/material/dialog';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

import { FeatherModule } from 'angular-feather';
import { allIcons } from 'angular-feather/icons';
import { BdViewDetailsComponent } from './bdclient-payout/bd-view-details/bd-view-details.component';
import { BdApprovalComponent } from './bdclient-payout/bd-approval/bd-approval.component';
import { BdResetProvidersComponent } from './bd-reset-providers/bd-reset-providers.component';
import { SupportWithdrawComponent } from './bdclient-payout/support-withdraw/support-withdraw.component';
import { ConfirmPopupComponent } from './bdclient-payout/confirm-popup/confirm-popup.component';

@NgModule({
  declarations: [
    BdclientDepositComponent,
    BdclientPayoutComponent,
    BdclientAddDepositComponent,
    BdViewDetailsComponent,
    BdApprovalComponent,
    BdResetProvidersComponent,
    SupportWithdrawComponent,
    ConfirmPopupComponent
  ],
  imports: [
    CommonModule,
    BdClientRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    MatTableModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatIconModule,
    FormsModule,
    MatButtonModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatTabsModule,
    MatDialogModule,
    MatRadioModule,
    MatSelectModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSlideToggleModule,
    FeatherModule.pick(allIcons)
  ]
})
export class BdClientModule { }
