import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BdclientAddDepositComponent } from './bdclient-add-deposit.component';

describe('BdclientAddDepositComponent', () => {
  let component: BdclientAddDepositComponent;
  let fixture: ComponentFixture<BdclientAddDepositComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BdclientAddDepositComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BdclientAddDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
