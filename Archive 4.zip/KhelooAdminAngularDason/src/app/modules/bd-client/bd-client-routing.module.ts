import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BdclientDepositComponent } from './bdclient-deposit/bdclient-deposit.component';
import { BdclientPayoutComponent } from './bdclient-payout/bdclient-payout.component';
import { BdclientAddDepositComponent } from './bdclient-add-deposit/bdclient-add-deposit.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'bdbanktransaction',
    pathMatch: 'full'
  },
  {
    path: 'bdclientdeposit',
    component: BdclientDepositComponent
  },
  {
    path: 'bdclientpayout',
    component: BdclientPayoutComponent
  },
  {
    path: 'bdclientadddeposit',
    component: BdclientAddDepositComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BdClientRoutingModule { }
