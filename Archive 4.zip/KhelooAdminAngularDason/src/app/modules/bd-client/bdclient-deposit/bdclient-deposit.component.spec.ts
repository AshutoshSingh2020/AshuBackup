import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BdclientDepositComponent } from './bdclient-deposit.component';

describe('BdclientDepositComponent', () => {
  let component: BdclientDepositComponent;
  let fixture: ComponentFixture<BdclientDepositComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BdclientDepositComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BdclientDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
