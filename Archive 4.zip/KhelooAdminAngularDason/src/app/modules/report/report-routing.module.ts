import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisteredUserComponent } from './registered-user/registered-user.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'register-user',
    pathMatch: 'full'
  },
  {
    path: 'register-user',
    component: RegisteredUserComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportRoutingModule { }
