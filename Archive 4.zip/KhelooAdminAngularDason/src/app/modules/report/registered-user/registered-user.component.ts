import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { DatePipe } from '@angular/common';
import moment from 'moment';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-registered-user',
  templateUrl: './registered-user.component.html',
  styleUrls: ['./registered-user.component.scss'],
  providers: [DatePipe]
})
export class RegisteredUserComponent implements OnInit ,OnDestroy{
  apiLoader={cadc_list:false,cadc_export:false};
  maxDate=new Date();
  maxDF=this.datePipe.transform(this.maxDate, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  AllLeadinfo:any=[];
  LeadinfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  apiSub:Subscription;

  dynamicControls = [
    {changeAction:'submit',que:'Type',type:'dropdown',options:['All','Depositor','Non Depositor'],subque:[]},
    {que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]},
    {que:'PlayerId',type:'input',subque:[]}
  ];
  
  LeadCollumnHeaders:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Id',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},
    {value:'Mobile',bg:'white-drop'},{value:'Amount',bg:'white-drop'},{value:'Register',bg:'white-drop'},{value:'Game Played',bg:'white-drop'},{value:'Deposit Count',bg:'white-drop'},{value:'View',bg:'white-drop'}]
  ]
  
  LeadDataCollumns=this.LeadCollumnHeaders;

  idLeads='';
  
  LeadCollumnLoading = false;
  showListing = true;
  showFormCreate = '';
  leadToView:any={};
  
  currentQuery={"StartDateTime": this.maxDF,"PageNo": 1,"PageSize": this.pageCount[0],"intParam1": '0',"EndDateTime": this.maxDF,"PlayerId":""};
  personRole=JSON.parse(localStorage.getItem('personalDetails')).RoleCode;
  
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog, private datePipe: DatePipe) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      // this.apiLoader.cadc_list = ('getRegisterUser' in loading)?true:false;
      if('downloadAllReportData' in loading){
        this.apiLoader.cadc_export=true;
      }
      else{
        this.apiLoader.cadc_export=false;  
      }
    });
    this.getAllregisterList();
  }
  initializeData()
  {
    this.LeadCollumnLoading = true;
    this.AllLeadinfo = [];
    this.LeadinfoData = [];
    if(this.apiSubscriber[0]){
      this.apiSubscriber[0].unsubscribe();
    }
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.getAllregisterList();
  }
  
  getAllregisterList() {
    this.initializeData();
    this.apiSubscriber[0] =  this.apiservice.sendRequest(config['getRegisterUser'], this.currentQuery,'getRegisterUser').subscribe((data: any) => {
      this.LeadCollumnLoading = false;
      this.AllLeadinfo=data;
      if(this.AllLeadinfo[0]){
        this.LeadDataCollumns=this.LeadCollumnHeaders;
        this.pagesTotal=Math.ceil(this.AllLeadinfo[0].TotalCount/this.currentQuery.PageSize);
        this.AllLeadinfo.forEach((element:any,index:any) => {
          this.LeadinfoData.push([
          {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
          {value:element.UserId,bg:'white-cell'},
          {value:element.FName?(element.FName+' '+(element.LName?element.LName:'')):'',bg:'white-cell'},
          {value:element.UserName,bg:'white-cell'},
          {value:element.Mobile,bg:'white-cell'},
          {value:'INR '+ element.AccountBalance,bg:'white-cell'},
          {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
          {value:element.GamePlayed==1?'Yes':'',bg:'white-cell'},
          {value:element.DepositCount,bg:'white-cell'},
          {value:'',bg:'white-cell',icon:'View'}
          ])
        });
        this.rowCount={f:this.LeadinfoData[0][0].value,l:this.LeadinfoData[this.LeadinfoData.length-1][0].value,t:this.AllLeadinfo[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.LeadDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      this.LeadCollumnLoading = false;
      console.log(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  onValueChange(formVal:any){
   if(formVal.col==9 && formVal.type=='View'){
      window.open('/users/playerdetailview/'+this.AllLeadinfo[formVal.row].UserId, '_blank');
    }
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.PlayerId=formVal.PlayerId.value?formVal.PlayerId.value:'';
    this.currentQuery.intParam1=formVal.Type.value=="Depositor"?"1":formVal.Type.value=="Non Depositor"?"2":"0";
    this.currentQuery.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
    this.currentQuery.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
    this.currentQuery.PageNo = 1;
    this.getAllregisterList();
  }
  DownloadExcelData() {
    let d1 = this.datePipe.transform(this.currentQuery.StartDateTime, 'dd/MM/yyyy HH:mm');
    let d2 = this.datePipe.transform(this.currentQuery.EndDateTime, 'dd/MM/yyyy HH:mm');
    let request = "?intParam1="+ this.currentQuery.intParam1+"&StartDateTime="+d1+"&EndDateTime="+d2+"&PlayerId="+this.currentQuery.PlayerId;
    let docname = 'Regiter_List'+'_'+moment(new Date()).format("DD/MM/yyyy");
    this.apiservice.exportExcel(config['downloadAllReportData'] + request,docname,'downloadAllReportData');
  }
  ngOnDestroy(): void {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]){
      this.apiSubscriber[0].unsubscribe();
    }
  }
  
}
