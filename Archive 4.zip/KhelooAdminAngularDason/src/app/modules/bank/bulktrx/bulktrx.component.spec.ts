import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BulktrxComponent } from './bulktrx.component';

describe('BulktrxComponent', () => {
  let component: BulktrxComponent;
  let fixture: ComponentFixture<BulktrxComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulktrxComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BulktrxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
