import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BankRoutingModule } from './bank-routing.module';

import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { SharedModule } from '@shared/shared.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MatTableModule } from "@angular/material/table";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatSnackBarModule } from "@angular/material/snack-bar";
import { MatIconModule } from "@angular/material/icon";
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatNativeDateModule } from '@angular/material/core';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDialogModule } from '@angular/material/dialog';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

import { FeatherModule } from 'angular-feather';
import { allIcons } from 'angular-feather/icons';

import { BanktransactionComponent } from './banktransaction/banktransaction.component';
import { AddTrxDetailComponent } from './banktransaction/add-trx-detail/add-trx-detail.component';
import { AllbankComponent } from './allbank/allbank.component';
import { PayGatewayComponent } from './pay-gateway/pay-gateway.component';
import { AddPgDetailsComponent } from './pay-gateway/add-pg-details/add-pg-details.component';
import { ViewDetailsComponent } from './allbank/view-details/view-details.component';
import { ViewClientDetailsComponent } from './allbank/view-client-details/view-client-details.component';
import { BulktrxComponent } from './bulktrx/bulktrx.component';
import { AllBankSmsComponent } from './all-bank-sms/all-bank-sms.component';
import { BankTransferComponent } from './bank-transfer/bank-transfer.component';
import { AddBeneficiaryComponent } from './bank-transfer/add-beneficiary/add-beneficiary.component';
import { AddConfigureComponent } from './bank-transfer/add-configure/add-configure.component';
import { AddTransferTransactionComponent } from './add-transfer-transaction/add-transfer-transaction.component';
import { AddTransferTrxDetailComponent } from './add-transfer-transaction/add-transfer-trx-detail/add-transfer-trx-detail.component';
import { TransferTrxApprovalComponent } from './add-transfer-transaction/transfer-trx-approval/transfer-trx-approval.component';
import { UpdateTransferTrxDetailComponent } from './add-transfer-transaction/update-transfer-trx-detail/update-transfer-trx-detail.component';
import { GridComponent } from '@modules/users/grid/grid.component';
import { GridImgComponent } from './add-transfer-transaction/grid-img/grid-img.component';


@NgModule({
  declarations: [
    BanktransactionComponent,
    AddTrxDetailComponent,
    AllbankComponent,
    PayGatewayComponent,
    AddPgDetailsComponent,
    ViewDetailsComponent,
    ViewClientDetailsComponent,
    BulktrxComponent,
    AllBankSmsComponent,
    BankTransferComponent,
    AddBeneficiaryComponent,
    AddConfigureComponent,
    AddTransferTransactionComponent,
    AddTransferTrxDetailComponent,
    TransferTrxApprovalComponent,
    UpdateTransferTrxDetailComponent,
    GridImgComponent,

    
  ],
  imports: [
    CommonModule,
    BankRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    MatTableModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatIconModule,
    FormsModule,
    MatButtonModule,
    MatDatepickerModule,
    MatInputModule,
    MatNativeDateModule,
    MatTabsModule,
    MatDialogModule,
    MatRadioModule,
    MatSelectModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,
    MatSlideToggleModule,
    FeatherModule.pick(allIcons),

  ]
})
export class BankModule { }
