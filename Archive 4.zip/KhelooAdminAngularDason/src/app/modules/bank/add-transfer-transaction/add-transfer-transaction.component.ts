import { Component, CUSTOM_ELEMENTS_SCHEMA, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { DatePipe } from '@angular/common';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-add-transfer-transaction',
  templateUrl: './add-transfer-transaction.component.html',
  styleUrls: ['./add-transfer-transaction.component.scss'],
  providers: [DatePipe],

})
export class AddTransferTransactionComponent implements OnInit, OnDestroy {
  assignList: any = [];
  export: boolean = false;
  ClienNameList: any = [];
  @ViewChild('TrxDialogOpen') TrxDialogOpen!: TemplateRef<any>;
  apiLoader = { btc_list: false, btc_export: false };
  allData: any = [];
  tableInfoData: any = [];
  rowCount = { f: 0, l: 0, t: 0 };
  pageCount = [10, 50, 100, 200, 500, 1000];
  pagesTotal = 1;
  personRole = JSON.parse(localStorage.getItem('personalDetails')).RoleCode;
  paginatorBlock: any = [];
  maxDate = new Date();
  dynamicControls = [{
    que: 'Type', type: 'dropdown', options: ['All', 'Date Range'],
    subque: [{ showIf: 'Date Range', que: 'Date', type: 'daterange', minDate: null, maxDate: this.maxDate, startDate: this.maxDate, endDate: this.maxDate, subque: [] }]
  },
  { que: 'Search', type: 'input', subque: [] }];
  trxCollumnHeaders: any = [
    [{ value: 'Sr. No', bg: 'white-drop' },
    { value: 'Transaction Type', bg: 'white-drop' },
    { value: 'From Bank', bg: 'white-drop' },
    { value: 'To Bank', bg: 'white-drop' },
    { value: 'Transfer Type', bg: 'white-drop' },
    { value: 'Amount', bg: 'white-drop' },
    { value: 'Transaction Id', bg: 'white-drop' },
    { value: 'Status', bg: 'white-drop' },
    { value: 'Transaction Screenshot', bg: 'white-drop' },
    { value: 'CreatedBy', bg: 'white-drop' },
    { value: 'Created Date', bg: 'white-drop' },
    { value: 'Action', bg: 'white-drop' }]
  ]

  trxDataCollumns = this.trxCollumnHeaders;
  currentQuery = { "Search": "", "Pagination": 1, "PageSize": this.pageCount[1], "StartDateTime": null, "EndDateTime": null, "TransactionType": null };
  dIndex = { info: { row: 0, col: 0, use: false } };
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[] = [];

  detailsToView = {};
  AcceptRejectVar = "AP";
  @ViewChild('ApproveDialogOpen') ApproveDialogOpen!: TemplateRef<any>;
  @ViewChild('AddPBPopUp') AddPBPopUp!: TemplateRef<any>;
  @ViewChild('UpdatePBPopUp') UpdatePBPopUp!: TemplateRef<any>;
  @ViewChild('GridDialogOpen') GridDialogOpen!: TemplateRef<any>;

  companyList = [];
  TobankList: any = [];
  TransactionType = [];
  adminData: any = []

  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog, private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading: any = {}) => {
      this.apiLoader.btc_list = ('GetTransferTransaction' in loading) ? true : false;
      if (this.dIndex.info.use) {
        if (this.dIndex.info && this.dIndex.info.row !== undefined && this.dIndex.info.col !== undefined) {
          let row = this.dIndex.info.row;
          let col = this.dIndex.info.col;
          if (row >= 0 && row < this.tableInfoData.length && col >= 0 && col < this.tableInfoData[row].length) {
            this.tableInfoData[row][col].loader = 'setBTrxDesc' in loading ? true : false;
          }
        }
      }

    });
    this.getAllData();
  }

  getAllData() {

    this.getBankName();
    this.getBankToName();
    this.getTransactionType();
  }
  getBankName() {
    this.apiservice.getRequest(config['GetTransactionBanks']).subscribe((data: any) => {
      this.companyList = data;
    }, (error) => {
      console.log(error);
    });
    this.GetAllTrx();

  }
  getBankToName() {
    this.apiservice.getRequest(config['Tobank'], 'Tobank').subscribe((data: any) => {
      this.TobankList = data;
    }, (error) => {
      console.log(error);
    });
    this.GetAllTrx();

  }
  getTransactionType() {
    this.apiservice.getRequest(config['GetTransactionType']).subscribe((data: any) => {
      this.TransactionType = data;
    }, (error) => {
      console.log(error);
    });
    this.GetAllTrx();
  }
  initializeData() {
    this.allData = [];
    this.tableInfoData = [];
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }


  setPaginator() {
    this.paginatorBlock = [];
    if (this.currentQuery.Pagination <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.Pagination - 3; i <= this.currentQuery.Pagination + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  onPaginatorChange(paginatorQuery: any) {
    console.log(paginatorQuery)
    if (paginatorQuery.action == 'pageSize') {
      this.currentQuery.Pagination = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if (paginatorQuery.action == 'pageNo') {
      this.currentQuery.Pagination = paginatorQuery.pageNo;
    }
    this.GetAllTrx();
  }

  GetAllTrx() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['GetTransferTransaction'], this.currentQuery, 'GetTransferTransaction').subscribe((data: any) => {
      this.allData = data;
      if (this.allData[0]) {
        this.trxDataCollumns = this.trxCollumnHeaders;
        this.pagesTotal = Math.ceil(this.allData[0].TotalCount / this.currentQuery.PageSize);
        let bg_cell = '';
        this.allData.forEach((element: any, index: any) => {
          this.tableInfoData.push([
            { value: ((this.currentQuery.Pagination - 1) * this.currentQuery.PageSize) + (index + 1), bg: 'white-cell' },
            { value: element.TransactionType, bg: 'white-cell' },
            { value: element.FromBank, bg: 'white-cell break-class' },
            { value: element.ToBank, bg: 'white-cell break-class' },
            { value: element.TransferType, bg: 'white-cell' },
            { value: element.Amount, bg: 'white-cell' },
            { value: element.TransactionId, bg: 'white-cell break-class' },
            { value: this.getStatusLabel(element.Status), bg: 'white-cell' },
            {
              bg: 'white-cell', icon: 'Multi', value: [

                ...(element.TransactionScreenshot ? [{
                  value: 'image',
                  bg: 'white-cell',
                  icon: element.TransactionScreenshot,
                  iconvalue: 'image',
                  label: 'T img'
                }] : []),
              ]
            },

            { value: element.CreatedBy, bg: 'white-cell' },
            { value: element.CreatedDate ? moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy") : '', bg: 'white-cell' },
            {
              bg: bg_cell, icon: 'Multi', value: [
                ...((element.Status == 'P') ? [{ value: 'Approve', bg: bg_cell, icon: 'None', hrefvalue: element.FileNameServer }] : []),
                ...((element.Status == 'P') ? [{ value: 'Reject', bg: bg_cell, icon: 'None' }] : []),
                ...((element.Status == 'A' && (this.personRole == 'SA' || this.personRole == 'BOH')) ? [{ value: 'Edit', bg: bg_cell, icon: 'None' }] : []),
              ]
            }
          ])
        });

        this.rowCount = { f: this.tableInfoData[0][0].value, l: this.tableInfoData[this.tableInfoData.length - 1][0].value, t: this.allData[0].TotalCount };
        this.setPaginator();
      }
      else {
        this.rowCount = { f: 0, l: 0, t: 0 };
        this.trxDataCollumns = this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  getStatusLabel(status: string): string {
    switch (status) {
      case 'P': return 'Pending';
      case 'R': return 'Rejected';
      case 'A': return 'Approved';
      default: return status;
    }
  }

  onValueChange(formVal: any) {
    this.detailsToView = {};

    this.adminData = []
    this.adminData = this.allData[formVal.row];

    let allBankData = this.allData[formVal.row];
    // console.log(allBankData);
    if (formVal.col == 3) {
      let param = allBankData;
      this.dIndex.info.row = formVal.row;
      this.dIndex.info.col = formVal.col;
      this.dIndex.info.use = true;
      this.updateDescription(param, formVal.value);
    }
    if (formVal.type == 'Approve') {
      this.AcceptRejectVar = "AP";
      this.detailsToView = this.allData[formVal.row];
      this.ApproveOpenPopup();
    }
    if (formVal.type == 'Reject') {
      this.AcceptRejectVar = "RJ";
      this.detailsToView = this.allData[formVal.row];
      this.ApproveOpenPopup();
    }
    if (formVal.type == 'Edit') {
      this.detailsToView = this.allData[formVal.row];
      this.UpdateOpenPopup();
    }
    const agentName = this.adminData.TransactionId;

    if (formVal.type == 'image') {
      this.openGridPopup([this.adminData.TransactionScreenshot], 'Transaction Screenshot', 'image', agentName);
    }
  }

  openGridPopup(mediaUrls: string[], title: string, type: 'image' | 'audio' | 'video', agentName: string) {
    let dialogRef = this.dialog.open(this.GridDialogOpen, {
      width: '800px',
      panelClass: 'screen-dialog',
      data: { mediaUrls, title, type, agentName },
    });
    dialogRef.afterClosed().subscribe(result => { })

  }

  AddPBOpenPopUp() {
    let dialogRef = this.dialog.open(this.AddPBPopUp, {
      panelClass: 'screen-dialog',
      width: '800px',

    });
    dialogRef.afterClosed().subscribe(result => {
    })
  }
  UpdateOpenPopup() {
    let dialogRef = this.dialog.open(this.UpdatePBPopUp, {
      panelClass: 'screen-dialog',
      width: '800px',

    });
    dialogRef.afterClosed().subscribe(result => {
    })
  }

  ApproveOpenPopup() {
    let dialogRef = this.dialog.open(this.ApproveDialogOpen, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.closePopup();

    })
  }

  updateDescription(data: any, description: any) {
    let param = { Id: data.Id, Description: description };
    this.apiservice.sendRequest(config['setBTrxDesc'], param, 'setBTrxDesc').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
          this.utilities.toastMsg('success', "Success", data.ErrorMessage);
          this.getAllData();
        } else {
          this.utilities.toastMsg('error', "Failed", data.ErrorMessage);
        }
      }
    }, (error) => {
      this.utilities.toastMsg('error', "Failed", "Some thing went Wrong");
    });
  }

  getSearchQuery(formVal: any) {
    this.currentQuery.Search = formVal.Search.value;
    let typeVal = formVal.Type.value;

    if (typeVal === 'All') {
      this.currentQuery.StartDateTime = null;
      this.currentQuery.EndDateTime = null;
    } else if (typeVal === 'Date Range') {
      this.currentQuery.StartDateTime =moment(formVal.Type.subque[0].value1).format('YYYY-MM-DDTHH:mm:ss.SSS');
      this.currentQuery.EndDateTime = moment(formVal.Type.subque[0].value2).format('YYYY-MM-DDTHH:mm:ss.SSS');
      this.export = true;
    }
    this.currentQuery.Pagination = 1;
    this.GetAllTrx();
  }
  closePopup() {
    this.dialog.closeAll();
  }

  onSave() {
    this.GetAllTrx();
  }

  TrxOpenPopup() {
    let dialogRef = this.dialog.open(this.TrxDialogOpen, {
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.closePopup();
    })
  }

  DownloadExcelData() {
    let d1 = this.datePipe.transform(this.currentQuery.StartDateTime, 'dd/MM/yyyy HH:mm');
    let d2 = this.datePipe.transform(this.currentQuery.EndDateTime, 'dd/MM/yyyy HH:mm');
    // console.log("d2:-", d2, "d1:-", d1);
    let search = this.currentQuery.Search ? this.currentQuery.Search : ' ';
    d1 = d1 ? d1 : ' ';
    d2 = d2 ? d2 : ' ';
    let request = "?SearchText=" + search + "&StartDateTime=" + d1 + "&EndDateTime=" + d2 + "&TransactionType=" + '';
    let docname = 'ExportTransferTransaction' + '_' + moment(d1) + 'to_' + moment(d2);
    this.apiservice.exportExcel(config['ExportTransferTransaction'] + request, docname, 'ExportTransferTransaction');
  }
  ngOnDestroy(): void {
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
}
