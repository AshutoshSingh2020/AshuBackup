import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-allbank',
  templateUrl: './allbank.component.html',
  styleUrls: ['./allbank.component.scss']
})

export class AllbankComponent implements OnInit {
  @ViewChild('VewDetailsOpen') VewDetailsOpen!: TemplateRef<any>;
  @ViewChild('VewClientDetailsOpen') VewClientDetailsOpen!: TemplateRef<any>;
  allData:any=[];
  showBankActive=0;
  showBankVisible=0;
  tableInfoData:any=[];
  tableCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},
    {value:'Status',bg:'white-drop'},
    {value:'Is visible',bg:'white-drop'},
    {value:'User name',bg:'white-drop'},
    {value:'Upi Id',bg:'white-drop'},
    {value:'Bank Name',bg:'white-drop'},
    {value:'Balance',bg:'white-drop'},
    {value:'Account Holder Name',bg:'white-drop'},
    {value:'Account Number',bg:'white-drop'},
    {value:'IFSC Code',bg:'white-drop'},
    {value:'Date',bg:'white-drop'},
    {value:'Updated by',bg:'white-drop'},
    {value:'Last Update',bg:'white-drop'},
    {value:'Description',bg:'white-drop'},
    {value:'Action',bg:'white-drop'},
  ]
];
tableDataCollumns=this.tableCollumnHeaders;
dIndex={status:{row:0,col:0,use:false},depositAccess:{row:0,col:0,use:false},isVisible:{row:0,col:0,use:false},update:{row:0,col:0,use:false}};
private loaderSubscriber: Subscription;
private apiSubscriber: Subscription[]=[];
apiLoader={crc_list:false};
detailsToView={};
statBClients=[];
constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private dialog: MatDialog) { }

ngOnInit(): void {
  this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
    this.apiLoader.crc_list=('getAllBanks' in loading)?true:false;
    if(this.dIndex.status.use)
    {
      this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon=('changeUpiStat' in loading)?'Loading':'Toggle';
    }
    if(this.dIndex.isVisible.use)
    {
      this.tableInfoData[this.dIndex.isVisible.row][this.dIndex.isVisible.col].icon=('changeUpiVisibility' in loading)?'Loading':'Toggle';
    }
    if(this.dIndex.update.use)
    {
      // this.tableInfoData[this.dIndex.update.row][this.dIndex.update.col].loader=('updateBankUPIDescription' in loading)?true:false;
      if (this.dIndex.update && this.dIndex.update.row !== undefined && this.dIndex.update.col !== undefined) {
        let row = this.dIndex.update.row;
        let col = this.dIndex.update.col;
        if (row >= 0 && row < this.tableInfoData.length && col >= 0 && col < this.tableInfoData[row].length) {
          this.tableInfoData[row][col].loader = 'updateBankUPIDescription' in loading ? true : false;
        }
      } 
    }
    
  });
  this.GetMasterData();
}

initializeData()
{
  this.allData = [];
  this.tableInfoData = [];
}

GetMasterData() {
  this.initializeData();
  this.apiSubscriber[0] = this.apiservice.getRequest(config['getAllBanks'],'getAllBanks').subscribe((data: any) => {
    this.allData=data;
    if(this.allData[0]){
      this.tableDataCollumns=this.tableCollumnHeaders;
      let bg_cell = '';
      let acBankCount=0;
      let viBankCount=0;
      this.allData.forEach((element:any,index:any) => {
        bg_cell = element.IsUpdatedStaus == 'Y'?'blue-blink-cell':'white-cell';
        if (element.StatusId){
          acBankCount++;
        }
        if (element.IsVisible){
          viBankCount++;
        }
        this.tableInfoData.push([
          {value:index+1,bg:bg_cell},
          {value:element.StatusId,bg:bg_cell,icon:'Toggle'},
          ...(element.StatusId?[{value:element.IsVisible,bg:bg_cell,icon:'Toggle'}]:[{value:'',bg:bg_cell,icon:''}]),
          {value:element.UserName,bg:bg_cell},
          {bg:bg_cell,icon:'Multi',value:[{value:element.UpiId},
            ...(element.ClientName?[{span_values:['Client : '+element.ClientName],span_classes:["badge light badge-primary badge-mrtop"]}]:[{value:''}]),{brLine:element.IsVisible?true:false},
            ...(element.IsVisible?[{href_values:['15 Minutes : '+'loading...','30 Minutes : '+'loading...','1 Hour : '+'loading...'],href_classes:["","",""]}]:[{value:''}])]},
            // ...(element.IsVisible?[{href_values:['15 Minutes : '+element.Last15Minites+' %','30 Minutes : '+element.LastHalfHours+' %','1 Hour : '+element.LastOneHours+' %'],href_classes:["","",""]}]:[{value:''}])]},
            {value:element.BankName,bg:bg_cell},
            {value:element.Balance,bg:bg_cell},
            {value:element.isBankShow == 'Y'?element.AccountHolderName:'',bg:bg_cell},
            {value:element.isBankShow == 'Y'?element.AccountNumber:'',bg:bg_cell},
            {value:element.isBankShow == 'Y'?element.IfscCode:'',bg:bg_cell},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:bg_cell,sufText:element.TimeAgo},
            {value:element.UpdatedBy,bg:bg_cell},
            {value:element.UpdatedDate?moment(element.UpdatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:bg_cell},
            {value:element.Description,bg:bg_cell,icon:'Textarea',loader:false},
            {value:'View',bg:bg_cell,icon:'None'}
          ])
        });
        this.showBankActive=acBankCount;
        this.showBankVisible=viBankCount;
        this.apiSubscriber[1] = this.apiservice.getRequest(config['getBankPercentage'],'getBankPercentage').subscribe((dataPer: any) => {
          let allPerc=dataPer;
          if(allPerc[0]){
            for(let iD=0;iD<this.allData.length;iD++){
              if(this.allData[iD].IsVisible){
                for(let pI=0;pI<allPerc.length;pI++){
                  if(allPerc[pI].Id == this.allData[iD].Id){
                    this.tableInfoData[iD][4].value[3].href_values=['15 Minutes : '+allPerc[pI].Last15Minites+' %','30 Minutes : '+allPerc[pI].LastHalfHours+' %','1 Hour : '+allPerc[pI].LastOneHours+' %'];
                    break;
                  }
                }
              }
            }
          }
        });
      }
      else{
        this.tableDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
    
    this.apiSubscriber[1] = this.apiservice.getRequest(config['getBClientStat'],'getBClientStat').subscribe((data: any) => {
      if(data.length>0){
        this.statBClients = data.map((item: { Result: string; }) => item.Result);
      }
    });
  }
  
  onValueChange(formVal:any){
    let allBankData = this.allData[formVal.row];
    if(formVal.col==1){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      let param = '?Id='+ allBankData.Id;
      this.saveStatusAllBank(param);
    }
    else if(formVal.col==2){
      this.dIndex.isVisible.row=formVal.row;
      this.dIndex.isVisible.col=formVal.col;
      this.dIndex.isVisible.use=true;
      let param = '?Id='+ allBankData.Id;
      this.saveVisibilityAllBank(param);
    }
    else if(formVal.col==4){
      this.detailsToView=this.allData[formVal.row];
      this.ViewOpenPopup();
    }
    else if(formVal.col==14){
      this.detailsToView=this.allData[formVal.row];
      this.ClientDetailsOpenPopup();
    }else if(formVal.col==13){
      let param =this.allData[formVal.row];
      this.dIndex.update.row=formVal.row;
      this.dIndex.update.col=formVal.col;
      this.dIndex.update.use=true;
      this.updateDescription(param,formVal.value);
    }
  }
  
  updateDescription(data:any,description:any){
    let param = {Id:data.Id,Description:description};
    this.apiservice.sendRequest(config['updateBankUPIDescription'],param,'updateBankUPIDescription').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.GetMasterData();
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      this.utilities.toastMsg('error',"Failed","Some thing went Wrong");
      // console.log(error);
    });
    
  }
  closePopup(){
    this.GetMasterData();
    this.dialog.closeAll();
  }
  
  ViewOpenPopup() {
    let dialogRef = this.dialog.open(this.VewDetailsOpen, {
      panelClass: 'screen-dialog',
      width:'800px'
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  ClientDetailsOpenPopup() {
    let dialogRef = this.dialog.open(this.VewClientDetailsOpen, {
      panelClass: 'screen-dialog',
      width:'800px',
      height:'700px'
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  saveStatusAllBank(param:any){
    this.apiservice.getRequest(config['changeUpiStat'] + param,'changeUpiStat').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value=!this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value;
          this.GetMasterData();
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }
  
  saveVisibilityAllBank(param:any){
    this.apiservice.getRequest(config['changeUpiVisibility'] + param,'changeUpiVisibility').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.tableInfoData[this.dIndex.isVisible.row][this.dIndex.isVisible.col].value=!this.tableInfoData[this.dIndex.isVisible.row][this.dIndex.isVisible.col].value;
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }
  
  onSavePopup(){
    this.GetMasterData();
    this.dialog.closeAll();
  }
  
  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
}
