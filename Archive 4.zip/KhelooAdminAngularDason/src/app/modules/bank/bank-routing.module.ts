import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { BanktransactionComponent } from './banktransaction/banktransaction.component';
import { AllbankComponent } from './allbank/allbank.component';
import { PayGatewayComponent } from './pay-gateway/pay-gateway.component';
import { BulktrxComponent } from './bulktrx/bulktrx.component';
import { AllBankSmsComponent } from './all-bank-sms/all-bank-sms.component';
import { BankTransferComponent } from './bank-transfer/bank-transfer.component';
import { AddTransferTransactionComponent } from './add-transfer-transaction/add-transfer-transaction.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'banktransaction',
    pathMatch: 'full'
  },
  {
    path: 'banktransaction',
    component: BanktransactionComponent
  },
  {
    path: 'allbank',
    component: AllbankComponent
  },
  {
    path: 'bulktrx',
    component: BulktrxComponent
  },
  {
    path: 'paymentgatewaymaster',
    component: PayGatewayComponent
  },
  {
    path: 'allbanksms',
    component: AllBankSmsComponent
  },
  {
    path: 'transferbank',
    component: BankTransferComponent
  },
  {
    path: 'addtransfertransaction',
    component:AddTransferTransactionComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BankRoutingModule { }
