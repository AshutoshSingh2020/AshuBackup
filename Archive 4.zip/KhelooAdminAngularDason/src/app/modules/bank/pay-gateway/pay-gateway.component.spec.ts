import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayGatewayComponent } from './pay-gateway.component';

describe('PayGatewayComponent', () => {
  let component: PayGatewayComponent;
  let fixture: ComponentFixture<PayGatewayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PayGatewayComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PayGatewayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
