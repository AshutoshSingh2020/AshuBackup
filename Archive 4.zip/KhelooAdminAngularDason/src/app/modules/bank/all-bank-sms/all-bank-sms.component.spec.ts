import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AllBankSmsComponent } from './all-bank-sms.component';

describe('AllBankSmsComponent', () => {
  let component: AllBankSmsComponent;
  let fixture: ComponentFixture<AllBankSmsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AllBankSmsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AllBankSmsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
