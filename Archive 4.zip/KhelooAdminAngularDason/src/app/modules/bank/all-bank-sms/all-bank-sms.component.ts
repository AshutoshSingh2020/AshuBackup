import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { DatePipe } from '@angular/common';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-all-bank-sms',
  templateUrl: './all-bank-sms.component.html',
  styleUrls: ['./all-bank-sms.component.scss'],
  providers: [DatePipe]
})
export class AllBankSmsComponent implements OnInit {
  assignList: any = [];
  export:boolean=false;
  ClienNameList: any = [];
  apiLoader={btc_list:false,btc_export:false};
  allData:any=[];
  tableInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,200,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  maxDate=new Date();
  
  dynamicControls = [
    // {changeAction:'submit',que:'Type',type:'search-select',default:{name:'Select',value:'Select'},options:[],filteroptions:[],subque:[]},
  {que:'Search',type:'input',subque:[]}];
  
  trxCollumnHeaders:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Message',bg:'white-drop'},{value:'Created Date',bg:'white-drop'},{value:'Action',bg:'white-drop'}]
  ]
  
  trxDataCollumns=this.utilities.TableDataNone;

  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[1]};
  dIndex={info:{row:0,col:0,use:false}};
  private loaderSubscriber: Subscription;
private apiSubscriber: Subscription[]=[];
  
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog,private datePipe:DatePipe) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.btc_list=('banksmslog' in loading)?true:false;
      if(this.dIndex.info.use)
      {
        this.tableInfoData[this.dIndex.info.row][this.dIndex.info.col].icon=('viewSms' in loading)?'Loading':'None';
      }
  
    });
    this.selectUpi();
  }
  
  getAllData()
  {
    this.GetAllTrx();
  }
  
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
    if(this.apiSubscriber[0]){
      this.apiSubscriber[0].unsubscribe();
    }
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllTrx();
  }
  
  GetAllTrx() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['banksmslog'], this.currentQuery,'banksmslog').subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.trxDataCollumns=this.trxCollumnHeaders;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
          {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
          {value:element.Message,bg:'white-cell'},
          {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
          {value:'View',bg:'white-cell',icon:'None'},
          ])
        });
        this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.trxDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  onValueChange(formVal:any){
    let allBankData = this.allData[formVal.row];
    console.log(allBankData);
    if(formVal.col==3){
      let param =allBankData;
      this.dIndex.info.row=formVal.row;
      this.dIndex.info.col=formVal.col;
      this.dIndex.info.use=true;
      this.showMessage(param,formVal.value);
    }
  }

  showMessage(data:any,description:any){
    let param = '?Id='+data.Id;
    this.apiservice.getRequest(config['viewSms']+param,'viewSms').subscribe((data: any) => {
      if (data) {
          this.tableInfoData[this.dIndex.info.row][1].value = data.Message
      }else{
        this.utilities.toastMsg('warning',"","Message is not fetching.");
        
      }
    }, (error) => {
      this.utilities.toastMsg('error',"Failed","Some thing went Wrong");
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  getSearchQuery(formVal:any)
  {
  
    // if(formVal.Type.value != 'Select'){
    //   this.currentQuery.Search=formVal.Type.value;
    // }else
     if(formVal.Search.value){
      this.currentQuery.Search=formVal.Search.value;
    }
    this.currentQuery.PageNo = 1;
    this.GetAllTrx();
  }



  selectUpi(){
    this.apiservice.getRequest(config['bankupiList'],'bankupiList').subscribe((data: any) => {
      console.log("bankupiList:-" ,data);
      if (data) {
        data.forEach((item)=>{
          console.log(item.UserName);
          // this.dynamicControls[0].options.push({name:item.UserName,value:item.UserName});
          // this.dynamicControls[0].filteroptions.push({name:item.UserName,value:item.UserName});
        });
      }
    }, (error) => {
      this.utilities.toastMsg('error',"Failed","Some thing went Wrong");
    });
  }

}
