import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import moment from 'moment';
import Chart from 'chart.js/auto';

@Component({
  selector: 'app-payment-gateway',
  templateUrl: './payment-gateway.component.html',
  styleUrls: ['./payment-gateway.component.scss']
})

export class PaymentGatewayComponent implements OnInit, OnDestroy {
  dkCols=localStorage.getItem('dkMode')=='sd-dark'?true:false;
  dateValue: any;
  blankData = false;
  PGinfoData: any = [];
  AllPGinfo: any = [];
  display: boolean = false;
  errormessage: string = "";
  todayDate = new Date();
  showAdd=true;
  showSearch=true;
  showListing=true;
  refCodeData=[];
  showFormCreate = 'CreateClient';
  refClientData = {};
  PGIPData = [];
  GraphSearchType = 'DMY';
  GraphDateValue = {StartDateTime:this.todayDate,Type:"D"};
  PGDataCollumns:any = [
    [{value:'',bg:'white-bg'},{value:'',colspan:3,bg:'white-bg'},{value:'',bg:'white-bg'},{value:'Payment Gateway',colspan:3,bg:'blue-bg'},{value:'Payout Gateway',colspan:4,bg:'red-bg'},{value:'',colspan:2,bg:'white-bg'}],
    [{value:'Sr. No',bg:'white-drop'},{value:'Payin',bg:'white-drop'},{value:'Payout',bg:'white-drop'},{value:'IP',bg:'white-drop'},{value:'Name',bg:'white-drop'},
    {value:'Payment Balance',bg:'blue-drop'},{value:'Fees',bg:'blue-drop'},{icon:'Download',downloadvalue:'AllPGData',value:'PG On Date',bg:'blue-drop'},
    {icon:'Download',value:'Payout On Date',bg:'red-drop',downloadvalue:'AllRData'},{value:'Fees',bg:'red-drop'},{value:'Pending Withdraw',bg:'red-drop'},{value:'Withdraw Balance',bg:'red-drop'},
    {value:'Total',bg:'white-drop'},{value:'Action',bg:'white-drop'}]
  ]
  totalPGData:any={};
  
  apiLoader={pgc_list:false,pgc_pgstatus:false,pgc_ppstatus:false,pgc_pgipstatus:false,pgc_pgrefcode:false,pgc_graph:false};
  
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  dIndex={dlPGstatus:{row:0,col:0,use:false,data:{}},dlPOstatus:{row:0,col:0,use:false,data:{}},chPPstatus:{row:0,col:0,use:false,data:{}},chPGstatus:{row:0,col:0,use:false,data:{}}};
  dIndexh={dlPGstatus:{row:0,col:0,use:false,data:{}},dlPOstatus:{row:0,col:0,use:false,data:{}}};
  constructor(private apiservice: ApiService,private utilities: CommonFunctionService) { }

  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.pgc_list=('GetClientGatewayData' in loading)?true:false;
      this.apiLoader.pgc_pgrefcode=('getRefCodelead' in loading)?true:false;
      this.apiLoader.pgc_graph=('getpgGraphData' in loading)?true:false;
      if(this.dIndexh.dlPGstatus.use)
        {
          this.PGDataCollumns[this.dIndexh.dlPGstatus.row][this.dIndexh.dlPGstatus.col].icon=('downLoadAllPaymentGatewayExcell1' in loading)?'Loading':'Download';
        }

      if(this.dIndexh.dlPOstatus.use)
        {
          this.PGDataCollumns[this.dIndexh.dlPOstatus.row][this.dIndexh.dlPOstatus.col].icon=('downLoadAllPayoutExcell1' in loading)?'Loading':'Download';
        }

        if(this.dIndex.chPPstatus.use)
        {
          this.PGinfoData[this.dIndex.chPPstatus.row][this.dIndex.chPPstatus.col].icon=('downLoadAllPaymentGatewayExcell' in loading)?'Loading':'Download';
        }

        if(this.dIndex.chPGstatus.use)
        {
          this.PGinfoData[this.dIndex.chPGstatus.row][this.dIndex.chPGstatus.col].icon=('downLoadAllPayoutExcell' in loading)?'Loading':'Download';
        }
    });
    this.getAllData();
  }
  
  getAllData(){
    let currentday = new Date;
    this.dateValue = [currentday, currentday];
    this.GetClientGatewayData(this.dateValue);
    this.GetClientRefCodeData();
    this.GetTotalPGChart(this.GraphDateValue);
  }
  
  onSave(){
    this.getAllData();
    this.showAdd=true;
    this.showSearch=true;
    this.showListing=true;
    this.showFormCreate = 'CreateClient';
  }
  
  showForm(){
    this.showAdd=false;
    this.showSearch=false;
    this.showListing=false;
  }
  
  onCancel(){
    this.showAdd=true;
    this.showSearch=true;
    this.showListing=true;
    this.showFormCreate = 'CreateClient';
  }
  
  GetClientRefCodeData() {
    let params = {RCType:"PaymentSite"};
    this.apiservice.sendRequest(config['getRefCodelead'],params,'getRefCodelead').subscribe((data: any) => {
      this.refCodeData=data;
    }, (error) => {
      console.log(error);
    });
  }
  
  GetClientGatewayData(DateValues:Date[]) {
    let request = {
      "StartDateTime": moment(DateValues[0]).format("MM-DD-yyyy"),
      "EndDateTime": moment(DateValues[1]).format("MM-DD-yyyy")
    };
    this.PGinfoData = [];
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['GetClientGatewayData'], request,'GetClientGatewayData').subscribe((data: any) => {
      if(data){
        let DataPGInfo = data;
        this.AllPGinfo = DataPGInfo;
        DataPGInfo.forEach((element:any,index:any) => {
          this.PGinfoData.push([
            {value:index+1,bg:'white-cell'},
            {value:element.StatusId,bg:'white-cell',icon:'Toggle'},
            {value:element.PPStatusId,bg:'white-cell',icon:'Toggle'},
            {value:element.PGIPStatusId,bg:'white-cell',icon:'Toggle'},
            {value:element.ClientName,bg:'white-cell'},
            {value:'₹ '+this.utilities.roundOffNum(element.PaymentBalance),bg:'blue-cell'},
            {value:'₹ '+this.utilities.roundOffNum(element.PaymentFees),bg:'blue-cell'},
            (element.TotalTransactionOnDate ? {value:'₹ '+this.utilities.roundOffNum(element.TotalTransactionOnDate),bg:'blue-cell',icon:'Download',downloadvalue:'ClientPGData'}:{value:'₹ '+this.utilities.roundOffNum(element.TotalTransactionOnDate),bg:'blue-cell'}),
            (element.TotalPayoutTransactionOnDate ? {value:'₹ '+this.utilities.roundOffNum(element.TotalPayoutTransactionOnDate),bg:'red-cell',icon:'Download',downloadvalue:'ClientRData'}:{value:'₹ '+this.utilities.roundOffNum(element.TotalPayoutTransactionOnDate),bg:'red-cell'}),
            {value:'₹ '+this.utilities.roundOffNum(element.PayoutFees),bg:'red-cell'},
            {value:'₹ '+this.utilities.roundOffNum(element.PayoutPendingBalance),bg:'red-cell'},
            {value:'₹ '+this.utilities.roundOffNum(element.PayoutBalance),bg:'red-cell'},
            {value:'₹ '+this.utilities.roundOffNum(element.TotalBalance),bg:'white-cell'},
            {value:'IP',bg:'white-cell',icon:'Add'}
          ])
        });
      }
      else{
        this.blankData=true;
      }      
    }, (error) => {
      console.log(error);
    });
  }
  
  searchdata(DatevalueArray:Date[]) {
    this.GetClientGatewayData(DatevalueArray);
  }
  
  DownloadAllPaymentGatewayData(ClientId: any, InpVal:any) {
    let param = "?ClientId=" + ClientId + "&StartDateTime=" + moment(this.dateValue[0]).format("DD/MM/yyyy HH:MM") + "&EndDateTime=" + moment(this.dateValue[1]).format("DD/MM/yyyy HH:MM");
    let docname = 'dashboard_payment_pg'
    this.apiservice.exportExcel(config['downLoadAllPaymentGatewayExcell']+param,docname,'downLoadAllPaymentGatewayExcell');
  }
  
  DownLoadAllReconciliationData(ClientId: any,InpVal:any) {
    let param = "?ClientId=" + ClientId + "&StartDateTime=" + moment(this.dateValue[0]).format("DD/MM/yyyy HH:MM") + "&EndDateTime=" + moment(this.dateValue[1]).format("DD/MM/yyyy HH:MM");
    let docname = 'dashboard_payment_payout'
    this.apiservice.exportExcel(config['downLoadAllPayoutExcell']+param,docname,'downLoadAllPayoutExcell');
  }
  DownloadAllPaymentGatewayData1(ClientId: any, InpVal:any) {
    let param = "?ClientId=" + ClientId + "&StartDateTime=" + moment(this.dateValue[0]).format("DD/MM/yyyy HH:MM") + "&EndDateTime=" + moment(this.dateValue[1]).format("DD/MM/yyyy HH:MM");
    let docname = 'dashboard_payment_pg'
    this.apiservice.exportExcel(config['downLoadAllPaymentGatewayExcell']+param,docname,'downLoadAllPaymentGatewayExcell1');
  }
  
  DownLoadAllReconciliationData1(ClientId: any,InpVal:any) {
    let param = "?ClientId=" + ClientId + "&StartDateTime=" + moment(this.dateValue[0]).format("DD/MM/yyyy HH:MM") + "&EndDateTime=" + moment(this.dateValue[1]).format("DD/MM/yyyy HH:MM");
    let docname = 'dashboard_payment_payout'
    this.apiservice.exportExcel(config['downLoadAllPayoutExcell']+param,docname,'downLoadAllPayoutExcell1');
  }
  
  // filterValue(event: any) {
  //   this.utilities.filterValue(event);
  // }
  
  onValueChange(InpVal:any){
    let RowDetails=this.AllPGinfo[InpVal.row];
    this.PGinfoData[InpVal.row][InpVal.col].icon='Loading';
    if(InpVal.type=='Toggle'){
      if(InpVal.col==1){
        let param = [config['ChangeClientPGStatus'] + "?Id=" + RowDetails.ClientId,'GetClientGatewayData1'];
        this.HandleAPI(param,InpVal,RowDetails);
      }
      else if(InpVal.col==2){
        let param =  [config['ChangeClientPPStatus'] + "?Id=" + RowDetails.PPClientId,'ChangeClientPPStatus'];
        this.HandleAPI(param,InpVal,RowDetails);
      }
      else if(InpVal.col==3){
        let param = [config['ChangeClientPGIPStatus'] + "?Id="+RowDetails.ClientId,'ChangeClientPGIPStatus'];
        this.HandleAPI(param,InpVal,RowDetails);
      }
    }
    else if(InpVal.type=='Add'){
      this.refClientData=RowDetails;
      this.showFormCreate = 'AddIp';
      this.PGinfoData[InpVal.row][InpVal.col].icon='Add';
      this.showForm();
    }
    else if(InpVal.type=='ClientPGData'){
      
      this.dIndex.chPPstatus.row=InpVal.row;
      this.dIndex.chPPstatus.col=InpVal.col;
      this.dIndex.chPPstatus.data=InpVal.value;
      this.dIndex.chPPstatus.use=true;
      this.DownloadAllPaymentGatewayData(RowDetails.ClientId,InpVal);
    }
    else if(InpVal.type=='ClientRData'){
      this.dIndex.chPGstatus.row=InpVal.row;
      this.dIndex.chPGstatus.col=InpVal.col;
      this.dIndex.chPGstatus.data=InpVal.value;
      this.dIndex.chPGstatus.use=true;
      this.DownLoadAllReconciliationData(RowDetails.ClientId,InpVal);
    }
  }
  
  onHeaderValueChange(InpVal:any){
    this.PGDataCollumns[InpVal.row][InpVal.col].icon='Loading';
    if(InpVal.type=='AllPGData'){
      this.dIndexh.dlPGstatus.row=InpVal.row;
      this.dIndexh.dlPGstatus.col=InpVal.col;
      this.dIndexh.dlPGstatus.data=InpVal.value;
      this.dIndexh.dlPGstatus.use=true;
      this.DownloadAllPaymentGatewayData1(0,InpVal);
    }
    else if(InpVal.type=='AllRData'){
      this.dIndexh.dlPOstatus.row=InpVal.row;
      this.dIndexh.dlPOstatus.col=InpVal.col;
      this.dIndexh.dlPOstatus.data=InpVal.value;
      this.dIndexh.dlPOstatus.use=true;
      this.DownLoadAllReconciliationData1(0,InpVal);
  }
  }
  
  HandleAPI(param:any,InpVal:any,RowDetails:any){
    this.apiSubscriber[InpVal.col] = this.apiservice.getRequest(param[0],param[1]).subscribe((data: any) => {
      this.HandleServerResponse(data,InpVal,RowDetails);
    }, (error) => {
      this.HandleServerError(InpVal,RowDetails);
    });
  }
  
  HandleServerResponse(data:any,InpVal:any,RowDetails:any){
    if(data.Result=="Success"){
      this.PGinfoData[InpVal.row][InpVal.col].value=InpVal.value?1:0;
      this.PGinfoData[InpVal.row][InpVal.col].icon='Toggle';
      this.utilities.toastMsg('success',"Success", data.ErrorMessage);
    }
    else{
      this.utilities.toastMsg('error',"Failed", 'Changes to '+RowDetails.ClientName+'not Done.');
      this.PGinfoData[InpVal.row][InpVal.col].value=InpVal.value?0:1;
      this.PGinfoData[InpVal.row][InpVal.col].icon='Toggle';
    }
  }
  
  HandleServerError(InpVal:any,RowDetails:any){
    this.utilities.toastMsg('error',"Failed", 'Changes to '+RowDetails.ClientName+'not Done.');
    this.PGinfoData[InpVal.row][InpVal.col].value=InpVal.value?0:1;
    this.PGinfoData[InpVal.row][InpVal.col].icon='Toggle';
  }
  
  GetTotalPGChart(DateValues:any={}) {
    this.GraphDateValue = DateValues;
    let request = {StartDateTime:moment(this.GraphDateValue.StartDateTime).format("yyyy-MM-DD"),Type:this.GraphDateValue.Type};
    this.totalPGData = {};
    this.apiservice.sendRequest(config['getpgGraphData'], request, 'getpgGraphData').subscribe((data: any) => {
      let DataDummy=data;
      let label:any = [];
      let totalPG: any = [];
      if(!data.ErrorCode){
        this.totalPGData = {
          labels: label,
          datasets: [
            {
              label: 'PG on Date',
              data: totalPG,
              fill: false,
              borderColor: '#3e95cd',
              tension: .4
            }
          ]
        };
        let chartStatus = Chart.getChart("line_chart");
        if (chartStatus != undefined) {
          chartStatus.destroy();
        }
        let tCol=this.dkCols?'#ddd':'#666';
        let gCol=this.dkCols?'#888':'#e5e5e5';
        const lineCanvasEle: any = document.getElementById('line_chart')
        new Chart(lineCanvasEle.getContext('2d'), {
          type: 'line',
          data: this.totalPGData,
          options: {
            responsive: true,
            plugins:{
              legend: { labels: { font:{ family:'BeVietnamPro' } ,color:tCol } }
            },
            scales:{
              x: { ticks:{ font:{ family:'BeVietnamPro' }, color:tCol },grid: { color:gCol} },
              y: { grid: { color: gCol}, ticks:{ font:{ family:'BeVietnamPro' },color:tCol, callback(index) {
                let numData:any = index;
                let signage = '';
                if(numData && numData<0){
                  signage='-';
                  numData=Math.abs(numData);
                }
                if(numData && ((numData%1)!=0)){
                  let x=numData.toFixed(2);
                  x=x.toString();
                  let afterPoint = '';
                  if(x.indexOf('.') > 0){
                    afterPoint = x.substring(x.indexOf('.'),x.length);
                  }
                  x = Math.floor(x);
                  x=x.toString();
                  let lastThree = x.substring(x.length-3);
                  let otherNumbers = x.substring(0,x.length-3);
                  if(otherNumbers != ''){
                    lastThree = ',' + lastThree;
                  }
                  let res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree + afterPoint;
                  return(signage+res);
                }
                else if(numData){
                  let x=numData;
                  x=x.toString();
                  let lastThree = x.substring(x.length-3);
                  let otherNumbers = x.substring(0,x.length-3);
                  if(otherNumbers != ''){
                    lastThree = ',' + lastThree;
                  }
                  let res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
                  return(signage+res);
                }
                else{
                  return('0.00');
                }
              }, } }
            }
          }
        });
        DataDummy.forEach((element:any,index:any) => {
          label[index]=element.DateString;
          totalPG[index]=element.TotalPGOnDate;
        });
      }      
    }, (error) => {
      console.log(error)
    });
  }
  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    for(let i=0; i<this.apiSubscriber.length;i++){
      if(this.apiSubscriber[i]) {
        this.apiSubscriber[i].unsubscribe();
      }
    }
  }
}