import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrptoPgComponent } from './crpto-pg.component';

describe('CrptoPgComponent', () => {
  let component: CrptoPgComponent;
  let fixture: ComponentFixture<CrptoPgComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CrptoPgComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CrptoPgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
