import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MyDashboardComponent } from './my-dashboard/my-dashboard.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { PaymentGatewayComponent } from './payment-gateway/payment-gateway.component';
import { ChargebackComponent } from './chargeback/chargeback.component';
import { AddclientpayoutComponent } from './addclientpayout/addclientpayout.component';
import { BdpginfoComponent } from './bdpginfo/bdpginfo.component';
import { CrptoPgComponent } from './crypto-pg/crpto-pg.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'index',
    pathMatch: 'full'
  },
  {
    path: 'index',
    component: MyDashboardComponent
  },
  {
    path: 'analytics',
    component: AnalyticsComponent
  },
  {
    path: 'pginfo',
    component: PaymentGatewayComponent
  },
  {
    path: 'chargeback',
    component: ChargebackComponent
  },
  {
    path: 'addclientpayout',
    component: AddclientpayoutComponent
  },
  {
    path: 'bdpginfo',
    component: BdpginfoComponent
  },
  {
    path: 'crppginfo',
    component: CrptoPgComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DashboardRoutingModule { }
