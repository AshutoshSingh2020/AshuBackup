import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';

@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.scss']
})

export class AnalyticsComponent implements OnInit, OnDestroy {
  todayDate = new Date();
  startEnd1: Date[]=[new Date,new Date];
  startEnd2: Date[]=[new Date,new Date];
  depositData: any = [];
  WithdrawalData: any = [];
  depositDataCollumns=[
    [{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},
    {value:'Percentage',bg:'white-drop'},{value:'Amount',bg:'white-drop'},{value:'Withdraw',bg:'white-drop'}]
  ];
  withdrawDataCollumns=[[{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},{value:'Percentage',bg:'white-drop'},{value:'Withdraw',bg:'white-drop'}]];
  analyticsLoading = [false,false];
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  constructor(private apiservice: ApiService,private utilities: CommonFunctionService) { }

  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.analyticsLoading[0]=('GetTopDepositors' in loading)?true:false;
      this.analyticsLoading[1]=('GetTopWithdraw' in loading)?true:false;
  });
    this.GetTopDepositors(this.startEnd1);
    this.GetTopWithdraw(this.startEnd2);
  }

  GetTopDepositors(DateValues:Date[]) {
    let request = {
      "StartDateTime": moment(DateValues[0]).format("MM-DD-yyyy"),
      "EndDateTime": moment(DateValues[1]).format("MM-DD-yyyy")
    };
    this.depositData=[];
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['GetTopDepositors'], request, 'GetTopDepositors').subscribe((data: any) => {
      let DataDeposit = data;
      if(DataDeposit[0]){
        DataDeposit.forEach((element:any,index:any) => {
          this.depositData.push([
            {value:index+1,bg:'white-drop'},
            {value:element.FName,bg:'white-drop'},
            {value:element.UserName,bg:'white-drop'},
            {value:element.DepositPercentage+' %',bg:'white-drop'},
            {value:'₹ '+this.utilities.roundOffNum(element.DepositAmount),bg:'white-drop'},
            {value:'₹ '+this.utilities.roundOffNum(element.WithdrawAmount),bg:'white-drop'}
          ])
        });
      }
      else{
        this.depositData=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  GetTopWithdraw(DateValues:Date[]) {
    let request = {
      "StartDateTime": moment(DateValues[0]).format("MM-DD-yyyy"),
      "EndDateTime": moment(DateValues[1]).format("MM-DD-yyyy")
    };
    this.WithdrawalData=[];
    this.apiSubscriber[1] = this.apiservice.sendRequest(config['GetTopWithdraw'], request, 'GetTopWithdraw').subscribe((data: any) => {
      let DataWithdrawal = data;
      DataWithdrawal.forEach((element:any,index:any) => {
        this.WithdrawalData.push([
          {value:index+1,bg:'white-drop'},
            {value:element.FName,bg:'white-drop'},
            {value:element.UserName,bg:'white-drop'},
            {value:element.WithdrawPercentage+' %',bg:'white-drop'},
            {value:'₹ '+this.utilities.roundOffNum(element.WithdrawAmount),bg:'white-drop'}
        ])
      });
    }, (error) => {
      console.log(error);
    });
  }

  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
    if(this.apiSubscriber[1]) {
      this.apiSubscriber[1].unsubscribe();
    }
  }
}