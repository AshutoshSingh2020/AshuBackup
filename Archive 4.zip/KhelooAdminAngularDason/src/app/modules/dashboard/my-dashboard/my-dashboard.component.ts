import {Component, OnInit, OnDestroy} from '@angular/core';
import { Subscription } from 'rxjs';
import moment from 'moment';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { CommonFunctionService } from '@services/common-function.service';
import Chart from 'chart.js/auto';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-my-dashboard',
  templateUrl: './my-dashboard.component.html',
  styleUrls: ['./my-dashboard.component.scss'],
  providers: [DatePipe]
})

export class MyDashboardComponent implements OnInit, OnDestroy {
  todayDate = new Date();
  startEnd1: Date[]=[new Date,new Date];
  startEnd2: Date[]=[new Date((new Date()).setMonth(this.todayDate.getMonth()-1)),new Date];
  userid = JSON.parse(localStorage.getItem('personalDetails'));
  dkCols=localStorage.getItem('dkMode')=='sd-dark'?true:false;
  dIndex3 = { row: 0, col: 0, status: false };
  dashboardCount1 =[
    { "name": "New User", "value": '0', "feather": "user-plus", "color": this.dkCols?"#86afd9":"#1c84ee", "isDownload": "N" },
    { "name": "New Depositor", "value": '0', "feather": "pie-chart", "color": this.dkCols?"#7db39f":"#33c38e", "isDownload": "N" },
    { "name": "All Depositor", "value": '0', "feather": "bar-chart", "color": this.dkCols?"#86afd9":"#ffcc5a", "isDownload": "N" },
    { "name": "Bonus", "btnDownload": true, "btnLoader": false, "value": '0.00', "feather": "lock", "color": this.dkCols?"#be9090":"#ef6767", "isDownload": "Y" },
    { "name": "Total TRX", "value": '0', "feather": "send", "color": this.dkCols?"#86afd9":"#1c84ee", "isDownload": "N" },
    
    { "name": "Deposit", "btnDownload": true, "btnLoader": false, "value": '0.00', "feather": "lock", "color": this.dkCols?"#7db39f":"#33c38e", "isDownload": "Y" },
    { "name": "Deposit Average", "value": '0.00', "feather": "trending-up", "color": this.dkCols?"#86afd9":"#ffcc5a", "isDownload": "N" },
    { "name": "Withdraw", "btnDownload": true, "btnLoader": false, "value": '0.00', "feather": "credit-card", "color": this.dkCols?"#be9090":"#ef6767", "isDownload": "Y" },
    { "name": "Difference", "value": '0.00', "feather": "flag", "color": this.dkCols?"#7db39f":"#33c38e", "isDownload": "N" },


    { "name": "Bet", "value": '0.00', "feather": "user-check", "color": this.dkCols?"#86afd9":"#1c84ee", "isDownload": "N" },
    { "name": "Win", "value": '0.00', "feather": "pie-chart", "color": this.dkCols?"#be9090":"#ef6767", "isDownload": "N" },
    { "name": "Diff", "value": '0.00', "feather": "bar-chart-2", "color": this.dkCols?"#86afd9":"#ffcc5a", "isDownload": "N" }
  ];
  dashboardCount = [
    { "name": "New User", "value": '0', "feather": "user-plus", "color": this.dkCols?"#86afd9":"#1c84ee", "isDownload": "N" },
    { "name": "New Depositor", "value": '0', "feather": "pie-chart", "color": this.dkCols?"#7db39f":"#33c38e", "isDownload": "N" },
    { "name": "All Depositor", "value": '0', "feather": "bar-chart", "color": this.dkCols?"#86afd9":"#ffcc5a", "isDownload": "N" },
    { "name": "Bonus", "btnDownload": true, "btnLoader": false, "value": '0.00', "feather": "lock", "color": this.dkCols?"#be9090":"#ef6767", "isDownload": "Y" },
    { "name": "Total TRX", "value": '0', "feather": "send", "color": this.dkCols?"#86afd9":"#1c84ee", "isDownload": "N" },
    
    // { "name": "Deposit", "btnDownload": true, "btnLoader": false, "value": '0.00', "feather": "lock", "color": this.dkCols?"#7db39f":"#33c38e", "isDownload": "Y" },
    // { "name": "Deposit Average", "value": '0.00', "feather": "trending-up", "color": this.dkCols?"#86afd9":"#ffcc5a", "isDownload": "N" },
    // { "name": "Withdraw", "btnDownload": true, "btnLoader": false, "value": '0.00', "feather": "credit-card", "color": this.dkCols?"#be9090":"#ef6767", "isDownload": "Y" },
    // { "name": "Difference", "value": '0.00', "feather": "flag", "color": this.dkCols?"#7db39f":"#33c38e", "isDownload": "N" },


    { "name": "Bet", "value": '0.00', "feather": "user-check", "color": this.dkCols?"#86afd9":"#1c84ee", "isDownload": "N" },
    { "name": "Win", "value": '0.00', "feather": "pie-chart", "color": this.dkCols?"#be9090":"#ef6767", "isDownload": "N" },
    { "name": "Diff", "value": '0.00', "feather": "bar-chart-2", "color": this.dkCols?"#86afd9":"#ffcc5a", "isDownload": "N" }
  ];
 
  myDashboardLoading = [false,false];
  dIndex={deposit:0,withdraw:0,bonus:0};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  currentDates =this.startEnd1;


  maxDate = new Date();
  maxDateM1 = new Date();
  maxDF = this.datePipe.transform(this.maxDate, 'MM-dd-yyyy');
  maxDFM1 = this.datePipe.transform(this.maxDateM1.setMonth(this.maxDateM1.getMonth() - 1), 'MM-dd-yyyy');

  currentQuery3 = { "StartDateTime": this.maxDFM1, "EndDateTime": this.maxDF,"RequestType": "", "RequestStatus": "" }
  UserCollumnHeaders: any = [
    [{ value: 'Sr. No.', bg: 'white-drop' }, { value: 'SubCategory Name', bg: 'white-drop' }, { value: 'Count', bg: 'white-drop' }, { value: 'Action', bg: 'white-drop' }]
  ]
  AllUserinfo: any = [];
  UserinfoData: any = [];
  rowCount = { f: 0, l: 0, t: 0 };
  pageCount = [10, 50, 100, 500, 1000];
  pagesTotal = 1;
  paginatorBlock: any = [];

  UserCollumnLoading = false;
  UserDataCollumns = [];
  constructor(private apiservice :ApiService, private utilities:CommonFunctionService,private datePipe: DatePipe) {
   
  }
  dynamicControls3 = [
    {changeAction:'submit',que:'RequestType',type:'dropdownVal',default:{value:"",name:'All'},options:[{value:"whatsapp",name:'Whatsapp'},{value:"telegram",name:'Telegram'},{value:"livechat",name:'Live Chat'},{value:"callrequest",name:'Call Request'}],subque:[]},
    {changeAction:'submit',que:'RequestStatus',type:'dropdownVal',default:{value:"",name:'All'},options:[{value:'0',name:'Open'},{value:'1',name:'Close'}],subque:[]},
    { que: 'Date', type: 'daterange', minDate: null, maxDate: this.maxDate, startDate: this.maxDateM1, endDate: this.maxDate, subque: [] }
  ];
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
        this.myDashboardLoading[0]=('DashBoardCount' in loading)?true:false;
        this.myDashboardLoading[1]=('DashboardChart' in loading)?true:false;
        this.UserCollumnLoading=('dashboardChart' in loading)?true:false;
        if(this.dashboardCount[this.dIndex.deposit])
        {
          this.dashboardCount[this.dIndex.deposit].btnLoader=('dlUserDeposits' in loading)?true:false;
        }
        if(this.dashboardCount[this.dIndex.withdraw])
        {
          this.dashboardCount[this.dIndex.withdraw].btnLoader=('dlUserWithdraws' in loading)?true:false;
        }
        if(this.dashboardCount[this.dIndex.bonus])
        {
          this.dashboardCount[this.dIndex.bonus].btnLoader=('dlUserBnusDeposits' in loading)?true:false;
        }
        if(this.dashboardCount1[this.dIndex.deposit])
        {
          this.dashboardCount1[this.dIndex.deposit].btnLoader=('dlUserDeposits' in loading)?true:false;
        }
        if(this.dashboardCount1[this.dIndex.withdraw])
        {
          this.dashboardCount1[this.dIndex.withdraw].btnLoader=('dlUserWithdraws' in loading)?true:false;
        }
        if(this.dashboardCount1[this.dIndex.bonus])
        {
          this.dashboardCount1[this.dIndex.bonus].btnLoader=('dlUserBnusDeposits' in loading)?true:false;
        }
        if (this.dIndex3.status) {
          this.UserinfoData[this.dIndex3.row][this.dIndex3.col].icon = ('reportDetails' in loading) ? 'Loading' : 'Download';
        }
    });
    
    this.GetDashboardCount(this.startEnd1);
    this.GetDashboardChart(this.startEnd2);
    this.getDashboardChart1();
  }

  GetDashboardCount(DateValues:Date[]) {
    let request = {"StartDateTime": moment(DateValues[0]).format("MM-DD-yyyy"),"EndDateTime": moment(DateValues[1]).format("MM-DD-yyyy")};
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['GetDashBoardCount'], request, 'DashBoardCount').subscribe((data: any) => {
        this.dashboardCount[0].value = this.utilities.roundOffNum(data.NewRegisterCount);
        this.dashboardCount[1].value = this.utilities.roundOffNum(data.NewDepositorCount);
        this.dashboardCount[2].value = this.utilities.roundOffNum(data.DepositorCount);
        this.dashboardCount[3].value = this.utilities.roundOffNum(data.TotalDepositBonusAmount);
        this.dashboardCount[4].value = this.utilities.roundOffNum(data.TransactionCount);
        // this.dashboardCount[4].value = this.utilities.roundOffNum(data.TotalDepositAmount);
        // this.dashboardCount[5].value = this.utilities.roundOffNum(data.AverageDepositAmount);
        // this.dashboardCount[6].value = this.utilities.roundOffNum(data.TotalWithdrawAmount);
        // this.dashboardCount[7].value = this.utilities.roundOffNum(data.DepositWithdrawDiff);
        this.dashboardCount[5].value = this.utilities.roundOffNum(data.TotalBetAmount);
        this.dashboardCount[6].value = this.utilities.roundOffNum(data.TotalWinAmount);
        this.dashboardCount[7].value = this.utilities.roundOffNum(data.BetWinDiff);

        this.dashboardCount1[0].value = this.utilities.roundOffNum(data.NewRegisterCount);
        this.dashboardCount1[1].value = this.utilities.roundOffNum(data.NewDepositorCount);
        this.dashboardCount1[2].value = this.utilities.roundOffNum(data.DepositorCount);
        this.dashboardCount1[3].value = this.utilities.roundOffNum(data.TotalDepositBonusAmount);
        this.dashboardCount1[4].value = this.utilities.roundOffNum(data.TransactionCount);
        this.dashboardCount1[5].value = this.utilities.roundOffNum(data.TotalDepositAmount);
        this.dashboardCount1[6].value = this.utilities.roundOffNum(data.AverageDepositAmount);
        this.dashboardCount1[7].value = this.utilities.roundOffNum(data.TotalWithdrawAmount);
        this.dashboardCount1[8].value = this.utilities.roundOffNum(data.DepositWithdrawDiff);
        this.dashboardCount1[9].value = this.utilities.roundOffNum(data.TotalBetAmount);
        this.dashboardCount1[10].value = this.utilities.roundOffNum(data.TotalWinAmount);
        this.dashboardCount1[11].value = this.utilities.roundOffNum(data.BetWinDiff);
    }, (error) => {
      console.log(error);
    });
  }
  tabsdata(){
    if(this.userid.UserId == '131'){
      return this.dashboardCount1;
    }
    return this.dashboardCount
}
  onValueChange(formVal:any){
    let d1 = (moment(this.currentDates[0]).format("DD/MM/yyyy HH:mm"));
    let d2 = (moment(this.currentDates[1]).format("DD/MM/yyyy HH:mm"));
    if(formVal.type=='Deposit')
    {
      this.dIndex.deposit=formVal.id;
      let request = "?StartDateTime=" + d1+'&EndDateTime='+d2;
      let docname = 'Download_Deposit_'+moment(this.currentDates[0]).format("DD/MM/yyyy")+'_to_'+moment(this.currentDates[1]).format("DD/MM/yyyy");
      this.apiservice.exportExcel(config['dlUserDeposits'] + request,docname,'dlUserDeposits');
    }
    else if(formVal.type=='Withdraw'){
      this.dIndex.withdraw=formVal.id;
      let request = "?StartDateTime=" + d1 +'&EndDateTime='+d2;
      let docname = 'Download_Withdraw_'+moment(this.currentDates[0]).format("DD/MM/yyyy")+'_to_'+moment(this.currentDates[1]).format("DD/MM/yyyy");
      this.apiservice.exportExcel(config['dlUserWithdraws'] + request,docname,'dlUserWithdraws');
    }
    else if(formVal.type=='Bonus'){
      this.dIndex.bonus=formVal.id;
      let request = "?StartDateTime=" + d1 +'&EndDateTime='+d2;
      let docname = 'Download_BonusDeposit_'+moment(this.currentDates[0]).format("DD/MM/yyyy")+'_to_'+moment(this.currentDates[1]).format("DD/MM/yyyy");
      this.apiservice.exportExcel(config['dlUserBnusDeposits'] + request,docname,'dlUserBnusDeposits');
    }
  }

  GetDashboardChart(DateValues:Date[]) {
    let request = {
      "StartDateTime": moment(DateValues[0]).format("MM-DD-yyyy"),
      "EndDateTime": moment(DateValues[1]).format("MM-DD-yyyy")
    };
    this.apiSubscriber[1] = this.apiservice.sendRequest(config['GetDashboardChart'], request,'DashboardChart').subscribe((data: any) => {
      var newUser: any = [];
      var newDepositor: any = [];
      var allDepositUser: any = [];
      let label = this.utilities.getDatesInRange(new Date(request.StartDateTime), new Date(request.EndDateTime));
      var displayLable: any = [];
      data.NewUser.forEach((depositElement: any, index: any) => {
        data.NewUser[index]['Date'] = moment(new Date(depositElement.Date)).format("MMM Do YY")
      });
      data.NewDepositor.forEach((depositElement: any, index: any) => {
        data.NewDepositor[index]['Date'] = moment(new Date(depositElement.Date)).format("MMM Do YY")
      });
      data.AllDepositor.forEach((depositElement: any, index: any) => {
        data.AllDepositor[index]['Date'] = moment(new Date(depositElement.Date)).format("MMM Do YY")
      });
      label.forEach((element: any) => {
        let newUserIndex = data.NewUser.map((x: any) => {
          return x.Date;
        }).indexOf(moment(element).format("MMM Do YY"))
        if (newUserIndex != -1) {
          newUser.push(data.NewUser[newUserIndex].TotalCount);
        } else {
          newUser.push(0);
        }
        let nwDepoIndex = data.NewDepositor.map((x: any) => {
          return x.Date;
        }).indexOf(moment(element).format("MMM Do YY"))
        if (nwDepoIndex != -1) {
          newDepositor.push(data.NewDepositor[nwDepoIndex].TotalCount);
        } else {
          newDepositor.push(0);
        }
        let allDepoIndex = data.AllDepositor.map((x: any) => {
          return x.Date;
        }).indexOf(moment(element).format("MMM Do YY"))
        if (allDepoIndex != -1) {
          allDepositUser.push(data.AllDepositor[allDepoIndex].TotalCount);
        } else {
          allDepositUser.push(0);
        }
        displayLable.push(moment(element).format("DD  MMM"))
      });
      let basicData = {
        labels: displayLable,
        datasets: [
          { label: 'New User', data: newUser, fill: false, borderColor: '#3e95cd', tension: .4 },
          { label: 'New Depositor', data: newDepositor, fill: false, borderColor: '#87599a', tension: .4 },
          { label: 'All Depositor', data: allDepositUser, fill: false, borderColor: '#88f39a', tension: .4 }
        ]
      };
      let chartStatus = Chart.getChart("line_chart");
      if (chartStatus != undefined) {
        chartStatus.destroy();
      }
      const lineCanvasEle: any = document.getElementById('line_chart');
      let tCol=this.dkCols?'#ddd':'#666';
      let gCol=this.dkCols?'#888':'#e5e5e5';
      let nc = new Chart(lineCanvasEle.getContext('2d'), {
        type: 'line',
        data: basicData,
        options: {
          responsive: true,
          plugins:{
            legend: { labels: { font:{ family:'BeVietnamPro' }, color:tCol  } }
          },
          scales:{
            x: { ticks:{ font:{ family:'BeVietnamPro' } , color:tCol } ,grid: { color:gCol} },
            y: {grid: { color: gCol}, ticks:{ font:{ family:'BeVietnamPro' }, color:tCol,callback(index) {
              let numData:any = index;
              let signage = '';
              if(numData && numData<0){
                signage='-';
                numData=Math.abs(numData);
              }
              if(numData && ((numData%1)!=0)){
                let x=numData.toFixed(2);
                x=x.toString();
                let afterPoint = '';
                if(x.indexOf('.') > 0){
                  afterPoint = x.substring(x.indexOf('.'),x.length);
                }
                x = Math.floor(x);
                x=x.toString();
                let lastThree = x.substring(x.length-3);
                let otherNumbers = x.substring(0,x.length-3);
                if(otherNumbers != ''){
                  lastThree = ',' + lastThree;
                }
                let res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree + afterPoint;
                return(signage+res);
              }
              else if(numData){
                let x=numData;
                x=x.toString();
                let lastThree = x.substring(x.length-3);
                let otherNumbers = x.substring(0,x.length-3);
                if(otherNumbers != ''){
                  lastThree = ',' + lastThree;
                }
                let res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
                return(signage+res);
              }
              else{
                return('0.00');
              }
            }, } }
          }
        }
      });
    }, (error) => {
      console.log(error)
    });
  }

  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
    if(this.apiSubscriber[1]) {
      this.apiSubscriber[1].unsubscribe();
    }
  }

  getDashboardChart1() {
    this.UserinfoData = []
    this.UserDataCollumns = [];
    this.AllUserinfo = [];
    this.apiSubscriber[2] = this.apiservice.sendRequest(config['dashboardChart'], this.currentQuery3, 'dashboardChart')
      .subscribe((data: any) => {
        this.UserCollumnLoading = false;
        this.AllUserinfo = data;
        if (this.AllUserinfo[0]) {
          this.UserDataCollumns = this.UserCollumnHeaders;
          // this.pagesTotal=Math.ceil(this.AllUserinfo[0].TotalCount/this.currentQuery3.PageSize);
          this.AllUserinfo.forEach((element: any, index: any) => {
            let ctz = element.CreatedDateTZ ? " " + element.CreatedDateTZ : '';
            this.UserinfoData.push([
              // {value:((this.currentQuery3.PageNo-1)*this.currentQuery3.PageSize)+(index+1),bg:'white-cell'},
              { value: (index + 1), bg: 'white-cell' },
              { value: element.SubCategoryName, bg: 'white-cell' },
              { value: element.RequestCount, bg: 'white-cell' },
              { value: '', bg: 'white-cell', icon: 'Download',downloadvalue:"Download" },
            ])
          });
          this.rowCount = { f: this.UserinfoData[0][0].value, l: this.UserinfoData[this.UserinfoData.length - 1][0].value, t: this.AllUserinfo[0].TotalCount };
          // this.setPaginator();
        }
        else {
          this.rowCount = { f: 0, l: 0, t: 0 };
          this.UserDataCollumns = this.utilities.TableDataNone;
        }
      }, (error) => {
        console.log(error);
      });

  }
  onValueChange1(formVal: any) {
    console.log(formVal)
    if (formVal.type == 'Download') {
      this.dIndex3.status = true;
      this.dIndex3.row = formVal.row;
      this.dIndex3.col = formVal.col;
      let param = this.AllUserinfo[formVal.row].SubCategoryName;
      // console.log(this.AllUserinfo[formVal.row].SubCategoryId)
      this.downloadexceldata(param);
    }
  }
  downloadexceldata(id:any){
    let status = this.currentQuery3.RequestStatus?this.currentQuery3.RequestStatus:2;
    let start = moment(this.currentQuery3.StartDateTime).format('DD/MM/YYYY 00:00');
    let end  = moment(this.currentQuery3.EndDateTime).format('DD/MM/YYYY 00:00');
     let param = '?SubCategoryName='+id+'&RequestType='+this.currentQuery3.RequestType+'&RequestStatus='+status+'&StartDateTime='+start+'&EndDateTime='+end
     this.apiservice.exportExcel(config['reportDetails']+param,'reportDetails');
  }
  getSearchQuery3(formVal: any) {
    this.currentQuery3.RequestType = formVal.RequestType.value?formVal.RequestType.value:"";
    this.currentQuery3.RequestStatus = formVal.RequestStatus.value;
    this.currentQuery3.StartDateTime = this.datePipe.transform(formVal.Date.value1, 'MM-dd-yyyy');
    this.currentQuery3.EndDateTime = this.datePipe.transform(formVal.Date.value2, 'MM-dd-yyyy');
    this.getDashboardChart1();
  }
}