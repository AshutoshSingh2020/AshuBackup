import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import moment from 'moment';

@Component({
  selector: 'app-chargeback',
  templateUrl: './chargeback.component.html',
  styleUrls: ['./chargeback.component.scss']
})

export class ChargebackComponent implements OnInit {
  @ViewChild('CBPopUp') CBPopUp!: TemplateRef<any>;
  
  allData:any=[];
  tableInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,200,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  maxDate=new Date();
  preData=[];
  
  dynamicControls = [{que:'Type',type:'dropdown',options:['All','Chargeback'],
  subque:[{showIf:'All',que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]}]},
  {que:'Search',type:'input',subque:[]}];

  dIndex={status:{row:0,col:0,use:false}};
  
  collumnHeads:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Client',bg:'white-drop'},{value:'RequestId',bg:'white-drop'},{value:'Amount',bg:'white-drop'},
    {value:'Name',bg:'white-drop'},{value:'Phone',bg:'white-drop'},{value:'TransactionId',bg:'white-drop'},{value:'UTR',bg:'white-drop'},
    {value:'Status',bg:'white-drop'},{value:'Mode',bg:'white-drop'},{value:'Created Date',bg:'white-drop'},{value:'Updated Date',bg:'white-drop'},
    {value:'Action',bg:'white-drop'}]
  ]
  
  tableCollumns=this.collumnHeads;
  
  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[0],
  "StartDateTime": moment(this.maxDate).format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z',
  "EndDateTime": moment(this.maxDate).format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z',"intParam1":"0"}
  
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={primary_list:false,export_list:false};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }
  
  ngOnInit(): void
  {
    this.getAllData();
  }

  initSubscribe()
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.primary_list=('getClientCb' in loading);
      this.apiLoader.export_list=('dlClientCb' in loading);
    });
  }
  
  getAllData()
  {
    this.GetAllTrx();
  }
  
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
    this.initSubscribe();
  }
  
  onPaginatorChange(paginatorQuery:any)
  {
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllTrx();
  }
  
  GetAllTrx()
  {
    this.initializeData();
    this.apiservice.sendRequest(config['getClientCb'], this.currentQuery, 'getClientCb').subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.tableCollumns=this.collumnHeads;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
            {value:element.ClientName,bg:'white-cell'},
            {value:element.RequestId,bg:'white-cell'},
            {value:element.Amount,bg:'white-cell'},
            {value:element.Name,bg:'white-cell'},
            {value:element.Phone,bg:'white-cell'},
            {value:element.TransactionId,bg:'white-cell'},
            {value:element.ReferenceId,bg:'white-cell'},
            {value:element.TransactionStatus,bg:'white-cell'},
            {value:element.PaymentMode,bg:'white-cell'},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
            {value:element.UpdatedDate?moment(element.UpdatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
            ...(element.IsChargeback?[{value:'Chargeback Request',bg:'white-cell'}]:[{value:'Chargeback',bg:'white-cell',icon:'None'}])
          ])
        });
        this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.tableCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
      this.tableCollumns=this.utilities.TableDataNone;
    });
  }
  
  setPaginator()
  {
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.Search.value;
    let typeVal = formVal.Type.value;
    if(typeVal=='All'){
      this.currentQuery.StartDateTime=moment(formVal.Type.subque[0].value1).format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
      this.currentQuery.EndDateTime=moment(formVal.Type.subque[0].value2).format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
      this.currentQuery.intParam1="0";
    }
    else if(typeVal=='Chargeback'){
      this.currentQuery.intParam1="1";
    }
    this.currentQuery.PageNo = 1;
    this.GetAllTrx();
  }
  
  closePopup(){
    this.dialog.closeAll();
  }
  
  onSave(){
    this.GetAllTrx();
  }

  onValueChange(formVal:any)
  {
    if(formVal.col==12){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      this.preData=this.allData[formVal.row];
      this.CBOpenPopUp();
    }
  }
  
  CBOpenPopUp() {
    let dialogRef = this.dialog.open(this.CBPopUp, {
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.closePopup();
    })
  }

  DownloadChargebackData() {
    let docname = 'Chargeback_Download';
    this.apiservice.exportExcel(config['dlClientCb'],docname,'dlClientCb');
  }
}