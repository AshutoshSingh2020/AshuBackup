import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BdpginfoComponent } from './bdpginfo.component';

describe('BdpginfoComponent', () => {
  let component: BdpginfoComponent;
  let fixture: ComponentFixture<BdpginfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BdpginfoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BdpginfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
