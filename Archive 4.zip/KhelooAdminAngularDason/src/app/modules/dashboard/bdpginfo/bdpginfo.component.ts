import { Component, OnDestroy, OnInit, ViewChild, TemplateRef} from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { DatePipe } from '@angular/common';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import moment from 'moment';
import Chart from 'chart.js/auto';

@Component({
  selector: 'app-bdpginfo',
  templateUrl: './bdpginfo.component.html',
  styleUrls: ['./bdpginfo.component.scss'],
  providers: [DatePipe]
})

export class BdpginfoComponent implements OnInit, OnDestroy {
  @ViewChild('AddNewPopUp') AddNewPopUp!: TemplateRef<any>;
  dkCols=localStorage.getItem('dkMode')=='sd-dark'?true:false;
  allData:any=[];
  tableInfoData:any=[];
  refCodeData:any=[];
  maxDate=new Date();
  maxDF=this.datePipe.transform(this.maxDate, 'MM-dd-yyyy');
  dIndexh={dlPGstatus:{row:0,col:0,use:false,data:{}},dlPOstatus:{row:0,col:0,use:false,data:{}}};
  dIndex={dlPGstatus:{row:0,col:0,use:false,data:{}},dlPOstatus:{row:0,col:0,use:false,data:{}},chPPstatus:{row:0,col:0,use:false,data:{}},chPGstatus:{row:0,col:0,use:false,data:{}}};
  
  dynamicControls = [{que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]}];
  
  collumnHeads:any = [
    [{value:'',bg:'white-bg'},{value:'',colspan:2,bg:'white-bg'},{value:'',bg:'white-bg'},{value:'Payment Gateway',colspan:3,bg:'blue-bg'},{value:'Payout Gateway',colspan:4,bg:'red-bg'},{value:'',bg:'white-bg'}],
    [{value:'Sr. No',bg:'white-drop'},{value:'Payin',bg:'white-drop'},{value:'Payout',bg:'white-drop'},{value:'Name',bg:'white-drop'},
    {value:'Payment Balance',bg:'blue-drop'},{value:'Fees',bg:'blue-drop'},{icon:'Download',downloadvalue:'AllPGData',value:'PG On Date',bg:'blue-drop'},
    {icon:'Download',value:'Payout On Date',bg:'red-drop',downloadvalue:'AllRData'},{value:'Fees',bg:'red-drop'},{value:'Pending Withdraw',bg:'red-drop'},{value:'Withdraw Balance',bg:'red-drop'},
    {value:'Total',bg:'white-drop'}]
  ]
  totalPGData:any={};
  tableCollumns=this.collumnHeads;
  GraphSearchType = 'DMY';
  GraphDateValue = {StartDateTime:this.maxDate,Type:"D"};
  
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={list:false,graph:false};
  
  currentQuery={"StartDateTime": this.maxDF,"EndDateTime": this.maxDF};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private datePipe: DatePipe, private dialog: MatDialog) { }
  
  ngOnInit(): void
  {
    this.initSubscribe();
    this.getAllData();
  }
  
  getAllData()
  {
    let params = {RCType:"PaymentSite"};
    this.apiservice.sendRequest(config['GetPGRefCode'],params,'GetPGRefCode').subscribe((data: any) => {
      this.refCodeData=data;
    }, (error) => {
      console.log(error);
    });
    this.GetPrimaryData();
    this.GetTotalPGChart(this.GraphDateValue);
  }
  
  initSubscribe()
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.list=('getDataBDCG' in loading)?true:false;
      this.apiLoader.graph=('getGraphBDCG' in loading)?true:false;
      if(this.allData.length>0){
        if(this.dIndexh.dlPGstatus.use)
        {
          this.collumnHeads[this.dIndexh.dlPGstatus.row][this.dIndexh.dlPGstatus.col].icon=('dlBDCGPayIn0' in loading)?'Loading':'Download';
        }
        if(this.dIndexh.dlPOstatus.use)
        {
          this.collumnHeads[this.dIndexh.dlPOstatus.row][this.dIndexh.dlPOstatus.col].icon=('dlBDCGPayOut0' in loading)?'Loading':'Download';
        }
        if(this.dIndex.dlPGstatus.use)
        {
          this.tableInfoData[this.dIndex.dlPGstatus.row][this.dIndex.dlPGstatus.col].icon=('dlBDCGPayIn' in loading)?'Loading':'Download';
        }
        if(this.dIndex.dlPOstatus.use)
        {
          this.tableInfoData[this.dIndex.dlPOstatus.row][this.dIndex.dlPOstatus.col].icon=('dlBDCGPayOut' in loading)?'Loading':'Download';
        }
        if(this.dIndex.chPGstatus.use)
        {
          this.tableInfoData[this.dIndex.chPGstatus.row][this.dIndex.chPGstatus.col].icon=('changeBDCPG' in loading)?'Loading':'Toggle';
        }
        if(this.dIndex.chPPstatus.use)
        {
          this.tableInfoData[this.dIndex.chPPstatus.row][this.dIndex.chPPstatus.col].icon=('changeBDCPP' in loading)?'Loading':'Toggle';
        }
      }
    });
  }
  
  resetSubscribe()
  {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
  
  initializeData()
  {
    this.resetSubscribe();
    this.allData = [];
    this.tableInfoData = [];
    this.initSubscribe();
  }
  
  GetPrimaryData()
  {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['getDataBDCG'], this.currentQuery,'getDataBDCG').subscribe((data: any) => {
      if(data){
        this.allData = data;
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:index+1,bg:'white-cell'},
            {value:element.StatusId,bg:'white-cell',icon:'Toggle'},
            {value:element.PPStatusId,bg:'white-cell',icon:'Toggle'},
            {value:element.ClientName,bg:'white-cell'},
            {value:'BDT '+this.utilities.roundOffNum(element.PaymentBalance),bg:'blue-cell'},
            {value:'BDT '+this.utilities.roundOffNum(element.PaymentFees),bg:'blue-cell'},
            (element.TotalTransactionOnDate ? {value:'BDT '+this.utilities.roundOffNum(element.TotalTransactionOnDate),bg:'blue-cell',icon:'Download',downloadvalue:'ClientPGData'}:{value:'BDT '+this.utilities.roundOffNum(element.TotalTransactionOnDate),bg:'blue-cell'}),
            (element.TotalPayoutTransactionOnDate ? {value:'BDT '+this.utilities.roundOffNum(element.TotalPayoutTransactionOnDate),bg:'red-cell',icon:'Download',downloadvalue:'ClientRData'}:{value:'BDT '+this.utilities.roundOffNum(element.TotalPayoutTransactionOnDate),bg:'red-cell'}),
            {value:'BDT '+this.utilities.roundOffNum(element.PayoutFees),bg:'red-cell'},
            {value:'BDT '+this.utilities.roundOffNum(element.PayoutPendingBalance),bg:'red-cell'},
            {value:'BDT '+this.utilities.roundOffNum(element.PayoutBalance),bg:'red-cell'},
            {value:'BDT '+this.utilities.roundOffNum(element.TotalBalance),bg:'white-cell'}
          ]);
        });
      }
      else{
        this.tableCollumns=this.utilities.TableDataNone;
      }      
    }, (error) => {
      console.log(error);
    });
  }

  GetTotalPGChart(DateValues:any={}) {
    this.GraphDateValue = DateValues;
    let request = {StartDateTime:moment(this.GraphDateValue.StartDateTime).format("yyyy-MM-DD"),Type:this.GraphDateValue.Type};
    this.totalPGData = {};
    this.apiservice.sendRequest(config['getGraphBDCG'], request, 'getGraphBDCG').subscribe((data: any) => {
      let DataDummy=data;
      let label:any = [];
      let totalPG: any = [];
      if(!data.ErrorCode){
        this.totalPGData = {
          labels: label,
          datasets: [
            {
              label: 'PG on Date',
              data: totalPG,
              fill: false,
              borderColor: '#3e95cd',
              tension: .4
            }
          ]
        };
        let chartStatus = Chart.getChart("line_chart");
        if (chartStatus != undefined) {
          chartStatus.destroy();
        }
        let tCol=this.dkCols?'#ddd':'#666';
        let gCol=this.dkCols?'#888':'#e5e5e5';
        const lineCanvasEle: any = document.getElementById('line_chart')
        new Chart(lineCanvasEle.getContext('2d'), {
          type: 'line',
          data: this.totalPGData,
          options: {
            responsive: true,
            plugins:{
              legend: { labels: { font:{ family:'BeVietnamPro' }  ,color:tCol} }
            },
            scales:{
              x: { ticks:{ font:{ family:'BeVietnamPro' }  , color:tCol },grid: { color:gCol} },
              y: { grid: { color: gCol},ticks:{ font:{ family:'BeVietnamPro' }, color:tCol, callback(index) {
                let numData:any = index;
                let signage = '';
                if(numData && numData<0){
                  signage='-';
                  numData=Math.abs(numData);
                }
                if(numData && ((numData%1)!=0)){
                  let x=numData.toFixed(2);
                  x=x.toString();
                  let afterPoint = '';
                  if(x.indexOf('.') > 0){
                    afterPoint = x.substring(x.indexOf('.'),x.length);
                  }
                  x = Math.floor(x);
                  x=x.toString();
                  let lastThree = x.substring(x.length-3);
                  let otherNumbers = x.substring(0,x.length-3);
                  if(otherNumbers != ''){
                    lastThree = ',' + lastThree;
                  }
                  let res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree + afterPoint;
                  return(signage+res);
                }
                else if(numData){
                  let x=numData;
                  x=x.toString();
                  let lastThree = x.substring(x.length-3);
                  let otherNumbers = x.substring(0,x.length-3);
                  if(otherNumbers != ''){
                    lastThree = ',' + lastThree;
                  }
                  let res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
                  return(signage+res);
                }
                else{
                  return('0.00');
                }
              }, } }
            }
          }
        });
        DataDummy.forEach((element:any,index:any) => {
          label[index]=element.DateString;
          totalPG[index]=element.TotalPGOnDate;
        });
      }      
    }, (error) => {
      console.log(error)
    });
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'yyyy-MM-dd');
    this.currentQuery.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'yyyy-MM-dd');
    this.GetPrimaryData();
  }
  

  onValueChange(formVal:any){
    if(formVal.col==1){
      let cId = this.allData[formVal.row].ClientId;
      let param='?Id='+cId;
      this.dIndex.chPGstatus.row=formVal.row;
      this.dIndex.chPGstatus.col=formVal.col;
      this.dIndex.chPGstatus.data=formVal.value;
      this.dIndex.chPGstatus.use=true;
      this.saveStatusBDPG('PG',param);
    }
    else if(formVal.col==2){
      let cId = this.allData[formVal.row].PPClientId;
      let param='?Id='+cId;
      this.dIndex.chPPstatus.row=formVal.row;
      this.dIndex.chPPstatus.col=formVal.col;
      this.dIndex.chPPstatus.data=formVal.value;
      this.dIndex.chPPstatus.use=true;
      this.saveStatusBDPG('PP',param);
    }
    else if(formVal.col==6){
      let cId = this.allData[formVal.row].ClientId;
      this.dIndex.dlPGstatus.row=formVal.row;
      this.dIndex.dlPGstatus.col=formVal.col;
      this.dIndex.dlPGstatus.data=formVal.value;
      this.dIndex.dlPGstatus.use=true;
      this.DownloadExcelData('PG',cId);
    }
    else if(formVal.col==7){
      let cId = this.allData[formVal.row].ClientId;
      this.dIndex.dlPOstatus.row=formVal.row;
      this.dIndex.dlPOstatus.col=formVal.col;
      this.dIndex.dlPOstatus.data=formVal.value;
      this.dIndex.dlPOstatus.use=true;
      this.DownloadExcelData('PO',cId);
    }
  }
  
  onHeaderValueChange(formVal:any){
    if(formVal.col==6){
      this.dIndexh.dlPGstatus.row=formVal.row;
      this.dIndexh.dlPGstatus.col=formVal.col;
      this.dIndexh.dlPGstatus.data=formVal.value;
      this.dIndexh.dlPGstatus.use=true;
      this.DownloadExcelDatah('PG');
    }
    else if(formVal.col==7){
      this.dIndexh.dlPOstatus.row=formVal.row;
      this.dIndexh.dlPOstatus.col=formVal.col;
      this.dIndexh.dlPOstatus.data=formVal.value;
      this.dIndexh.dlPOstatus.use=true;
      this.DownloadExcelDatah('PO');
    }
  }

  saveStatusBDPG(id:string,param:any){
    if(id=="PG"){
      this.apiservice.getRequest(config['changeBDCPG']+param,'changeBDCPG').subscribe({
        next: (data:any) => {
          if (data) {
            if (data.ErrorCode == "1") {
              this.utilities.toastMsg('success',"Success", data.ErrorMessage);
              this.tableInfoData[this.dIndex.chPGstatus.row][this.dIndex.chPGstatus.col].value=!this.tableInfoData[this.dIndex.chPGstatus.row][this.dIndex.chPGstatus.col].value;
            } else {
              this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
            }
          }
        },
        error: (error)=> {
          console.log(error);
        }
      });
    }
    else if(id=="PP"){
      this.apiservice.getRequest(config['changeBDCPP']+param,'changeBDCPP').subscribe({
        next: (data:any) => {
          if (data) {
            if (data.ErrorCode == "1") {
              this.utilities.toastMsg('success',"Success", data.ErrorMessage);
              this.tableInfoData[this.dIndex.chPPstatus.row][this.dIndex.chPPstatus.col].value=!this.tableInfoData[this.dIndex.chPPstatus.row][this.dIndex.chPPstatus.col].value;
            } else {
              this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
            }
          }
        },
        error: (error)=> {
          console.log(error);
        }
      });
    }
  }
  
  DownloadExcelDatah(id:string) {
    let d1 = this.datePipe.transform(this.currentQuery.StartDateTime, 'dd/MM/yyyy 00:00');
    let d2 = this.datePipe.transform(this.currentQuery.EndDateTime, 'dd/MM/yyyy 23:59');
    let request = "?ClientId="+0+"&StartDateTime="+d1+"&EndDateTime="+d2;
    if(id=='PG')
    {
      let docname = 'PayementGatewayRecord_'+this.datePipe.transform(this.currentQuery.StartDateTime, 'dd_MM_yyyy_00_00')+'_'+this.datePipe.transform(this.currentQuery.EndDateTime, 'dd_MM_yyyy_23_59');
      this.apiservice.exportExcel(config['dlBDCGPayIn'] + request,docname,'dlBDCGPayIn0');
    }
    else if(id=='PO')
    {
      let docname = 'PayoutRecord_'+this.datePipe.transform(this.currentQuery.StartDateTime, 'dd_MM_yyyy_00_00')+'_'+this.datePipe.transform(this.currentQuery.EndDateTime, 'dd_MM_yyyy_23_59');
      this.apiservice.exportExcel(config['dlBDCGPayOut'] + request,docname,'dlBDCGPayOut0');
    }
  }
  
  DownloadExcelData(id:string,cid:string) {
    let d1 = this.datePipe.transform(this.currentQuery.StartDateTime, 'dd/MM/yyyy 00:00');
    let d2 = this.datePipe.transform(this.currentQuery.EndDateTime, 'dd/MM/yyyy 23:59');
    let request = "?ClientId="+cid+"&StartDateTime="+d1+"&EndDateTime="+d2;
    if(id=='PG')
    {
      let docname = 'PayementGatewayRecord_'+this.datePipe.transform(this.currentQuery.StartDateTime, 'dd_MM_yyyy_00_00')+'_'+this.datePipe.transform(this.currentQuery.EndDateTime, 'dd_MM_yyyy_23_59');
      this.apiservice.exportExcel(config['dlBDCGPayIn'] + request,docname,'dlBDCGPayIn');
    }
    else if(id=='PO')
    {
      let docname = 'PayoutRecord_'+this.datePipe.transform(this.currentQuery.StartDateTime, 'dd_MM_yyyy_00_00')+'_'+this.datePipe.transform(this.currentQuery.EndDateTime, 'dd_MM_yyyy_23_59');
      this.apiservice.exportExcel(config['dlBDCGPayOut'] + request,docname,'dlBDCGPayOut');
    }
  }

  AddNewData() {
    let dialogRef = this.dialog.open(this.AddNewPopUp, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
    })
  }
  
  closePopup(){
    this.dialog.closeAll();
  }
  
  ngOnDestroy()
  {
    this.resetSubscribe();
  }
}
