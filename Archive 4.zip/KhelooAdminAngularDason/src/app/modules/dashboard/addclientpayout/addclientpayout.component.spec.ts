import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddclientpayoutComponent } from './addclientpayout.component';

describe('AddclientpayoutComponent', () => {
  let component: AddclientpayoutComponent;
  let fixture: ComponentFixture<AddclientpayoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddclientpayoutComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddclientpayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
