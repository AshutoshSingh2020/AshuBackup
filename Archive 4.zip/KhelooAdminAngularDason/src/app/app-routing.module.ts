import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import {MainComponent} from '@common/main/main.component';
import {LoginComponent} from '@auth/login/login.component';
import {RegisterComponent} from '@auth/register/register.component';
import {AuthGuard} from '@guards/auth.guard';
import {RoleauthGuard} from '@guards/role-auth.guard';
import {NonAuthGuard} from '@guards/non-auth.guard';
import {ForgotPasswordComponent} from '@auth/forgot-password/forgot-password.component';
import {RecoverPasswordComponent} from '@auth/recover-password/recover-password.component';

const routes: Routes = [
    {
        path: '',
        component: MainComponent,
        canActivate: [AuthGuard],
        canActivateChild: [AuthGuard],
        children: [
            {
                path: '',
                pathMatch: 'full',
                redirectTo: 'dashboard'
            },
            {
                path: 'lead',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/leads/leads.module').then(m => m.LeadsModule)
            },
            {
                path: 'dashboard',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/dashboard/dashboard.module').then(m => m.DashboardModule)
            },
            {
                path: 'users',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/users/users.module').then(m => m.UsersModule)
            },
            {
                path: 'bdbank',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/bd-bank/bd-bank.module').then(m => m.BdBankModule)
            },
            {
                path: 'bank',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/bank/bank.module').then(m => m.BankModule)
            },
            {
                path: 'client',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/client/client.module').then(m => m.ClientModule)
            },
            {
                path: 'security',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/security/security.module').then(m => m.SecurityModule)
            },
            {
                path: 'recon',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/reconciliation/reconciliation.module').then(m => m.ReconciliationModule)
            },
            {
                path: 'affiliate',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/affiliate-master/affiliate-master.module').then(m => m.AffiliateMasterModule)
            },
            {
                path: 'report',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/report/report.module').then(m => m.ReportModule)
            },
            {
                path: 'bdbank',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/bd-bank/bd-bank.module').then(m=>m.BdBankModule)
            },
            {
                path: 'bdclient',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/bd-client/bd-client.module').then(m=>m.BdClientModule)
            },
            {
                path: 'gamelist',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/game-list/game-list.module').then(m=>m.GameListModule)
            },
            {
                path: 'editerror',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/edit-error/edit-error.module').then(m=>m.EditErrorModule)
            },
            {
                path: 'crpclient',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/crypto-client/crypto-client.module').then(m=>m.CryptoClientModule)
            },
            {
                path: 'userreport',
                canActivate: [RoleauthGuard],
                canActivateChild: [RoleauthGuard],
                loadChildren: () => import('@modules/user-report/user-report.module').then(m=>m.UserReportModule)
            },
        ]
    },
    {
        path: 'login',
        component: LoginComponent,
        canActivate: [NonAuthGuard]
    },
    {
        path: 'register',
        component: RegisterComponent,
        canActivate: [NonAuthGuard]
    },
    {
        path: 'forgot-password',
        component: ForgotPasswordComponent,
        canActivate: [NonAuthGuard]
    },
    {
        path: 'change-password',
        component: RecoverPasswordComponent,
        canActivate: [AuthGuard]
    },
    {path: '**', redirectTo: ''}
];

@NgModule({
    imports: [RouterModule.forRoot(routes, {relativeLinkResolution: 'legacy'})],
    exports: [RouterModule]
})
export class AppRoutingModule {}
