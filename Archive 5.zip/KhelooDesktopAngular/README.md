# KhelooDesktopAngular
This project is build in angular. Not to make live just for a reference to develop the flutter app.
