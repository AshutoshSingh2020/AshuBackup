import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import  Swal  from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class UserAuthService {

  // constructor() { }

  private logingSubject = new BehaviorSubject<{ [key: string]: boolean }>({});
  public loging$ = this.logingSubject.asObservable();
  
  startloging(keyid: string) {
    const loging = this.logingSubject.value;
    this.logingSubject.next({
      ...loging,
      [keyid]: true
    });
  }
  stoploging(keyid: string) {
    const logArr = this.logingSubject.value;
    delete logArr[keyid];
    this.logingSubject.next(logArr);
  }

showAlert( ErrorMessage :string ,description:string,iconstr:any){
 return Swal.fire({
    title: ErrorMessage,
    text: description,
    icon: iconstr,
    timer: 3000,
    confirmButtonText: 'Ok'

  });
}


}
