import { TestBed } from '@angular/core/testing';

import { StrogeService } from './stroge.service';

describe('StrogeService', () => {
  let service: StrogeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StrogeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
