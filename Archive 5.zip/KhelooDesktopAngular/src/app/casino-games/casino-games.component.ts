import { Component,OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { UserAuthService } from '../service/user-auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-casino-games',
  templateUrl: './casino-games.component.html',
  styleUrls: ['./casino-games.component.scss']
})
export class CasinoGamesComponent implements OnInit {
  gamelists:any [] = [];
  gamelists2:any [] = [];
  defaultcnt: number  = 10;
  defaultcnt2: number  = 10;
  constructor(private api :ApiService,private alert:UserAuthService,private routing:Router){

  }
  ngOnInit(): void {
    this.getMostPopularGames();
    this.getTableGame();
  }

  getMostPopularGames(){
    this.api.getGameList('Most Popular','LiveGame').subscribe({
      next:data=>{
        this.gamelists = data;
      },
      error:err=>{
        this.alert.showAlert('Something went wrong','Please check your Internect Connection','error');
      }
    });

  }
  getTableGame(){
    this.api.getGameList('Relax Gaming','TableGame').subscribe({
      next:data=>{
        this.gamelists2 = data;
      },
      error:err=>{
        this.alert.showAlert('Something went wrong','Please check your Internect Connection','error');
      }
    });

  }
  navigateGamePlateform(id:number){
    this.routing.navigate(['/games',id]);
  }

  updateFormmore( act:any){
    if(act.action == 1){
      this.defaultcnt = this.gamelists.length
      
    }else if(act.action ==2){
      this.defaultcnt2 = this.gamelists2.length

    }
  }
}
