import { Component } from '@angular/core';

@Component({
  selector: 'app-casinopage',
  templateUrl: './casinopage.component.html',
  styleUrls: ['./casinopage.component.scss']
})
export class CasinopageComponent {

}
