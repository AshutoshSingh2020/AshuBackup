import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CasinopageComponent } from './casinopage.component';

describe('CasinopageComponent', () => {
  let component: CasinopageComponent;
  let fixture: ComponentFixture<CasinopageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CasinopageComponent]
    });
    fixture = TestBed.createComponent(CasinopageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
