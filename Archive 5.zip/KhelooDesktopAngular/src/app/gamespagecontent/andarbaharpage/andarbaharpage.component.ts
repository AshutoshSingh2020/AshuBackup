import { Component } from '@angular/core';

@Component({
  selector: 'app-andarbaharpage',
  templateUrl: './andarbaharpage.component.html',
  styleUrls: ['./andarbaharpage.component.scss']
})
export class AndarbaharpageComponent {

}
