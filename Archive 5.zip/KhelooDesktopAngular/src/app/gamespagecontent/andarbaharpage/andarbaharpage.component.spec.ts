import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AndarbaharpageComponent } from './andarbaharpage.component';

describe('AndarbaharpageComponent', () => {
  let component: AndarbaharpageComponent;
  let fixture: ComponentFixture<AndarbaharpageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AndarbaharpageComponent]
    });
    fixture = TestBed.createComponent(AndarbaharpageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
