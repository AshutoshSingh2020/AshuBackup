import { Component } from '@angular/core';

@Component({
  selector: 'app-teenpatti',
  templateUrl: './teenpatti.component.html',
  styleUrls: ['./teenpatti.component.scss']
})
export class TeenpattiComponent {

}
