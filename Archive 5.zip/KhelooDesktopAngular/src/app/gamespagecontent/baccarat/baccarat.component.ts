import { Component } from '@angular/core';

@Component({
  selector: 'app-baccarat',
  templateUrl: './baccarat.component.html',
  styleUrls: ['./baccarat.component.scss']
})
export class BaccaratComponent {

}
