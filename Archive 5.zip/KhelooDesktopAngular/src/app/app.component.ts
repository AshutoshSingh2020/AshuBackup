import { Component, OnInit } from '@angular/core';
import { Router,NavigationEnd } from '@angular/router';
import { UserAuthService } from 'src/app/service/user-auth.service'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'kheloo.com';
  constructor(private router: Router, public userauth: UserAuthService
  ) {
  }
  ngOnInit(): void {
    
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.refreshHeader(); 
      }
    });

    // console.log('oninitApp');
    // let LoginToken = localStorage.getItem('LoginToken');
    // if (LoginToken != '' && LoginToken != null) {
    //   this.userauth?.startloging('login');
    // } else {
    //   this.userauth?.stoploging('login');
    // }
  }
  refreshHeader(){
    let LoginToken = localStorage.getItem('LoginToken');
    if (LoginToken != '' && LoginToken != null) {
      this.userauth?.startloging('login');
    } else {
      this.userauth?.stoploging('login');
    }
    // this.username = this.storage.getData('name'); 
    // if(this.username != '' && this.username !=null){
  
    //   this.logincheck = true;
    // }
  
  }


}
