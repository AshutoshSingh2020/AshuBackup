import { Component,OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';
import { UserAuthService } from 'src/app/service/user-auth.service';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit{

constructor(private auth:ApiService,private showalert:UserAuthService){}
userdetails :any = '';
isLoading :boolean = false;
ngOnInit(): void {
  this.auth.isLoading$.subscribe((isLoading) => {
    this.isLoading = isLoading;
  });
   this.getUserDetails();
}

getUserDetails(){
  this.auth.loaderShow();
  this.auth.getUserDetails().subscribe({
    next: data=>{
      if(data){
        this.userdetails = data;
        this.auth.loaderHide();
       }
    },
    error: err=>{
      this.showalert.showAlert('Something Went Wrong','Please check Your Internet Connection','error');
    }
    
  });
}

}
