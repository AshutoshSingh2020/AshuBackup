import { Component,OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';

@Component({
  selector: 'app-statements',
  templateUrl: './statements.component.html',
  styleUrls: ['./statements.component.scss']
})
export class StatementsComponent implements OnInit {
  isLoading:boolean=false;
  details :any = 0 ;
  ttl :number = 0;
  ttlpage :number = 0;
  datacount :number = 10;
  pagecnt :number []= [];
  paginatorBlock:any=[];
  selectedOption:any;
  showspinner :boolean = false;
pages = {
    "PageNumber": 1,
    "RecordCount": 10
  };
  constructor(private apiservice:ApiService){

  }

ngOnInit(): void {
  this.getall();
  this.apiservice.isLoading$.subscribe((isLoading) => {
    this.isLoading = isLoading;
  });
}

getall(){
  this.apiservice.loaderShow();
  return this.apiservice.fetchuserstatements(this.pages).subscribe({
    next :data=>{
      this.details = data;
      this.ttl = data[0].TotalCount;
      this.ttlpage = Math.ceil(this.ttl/this.pages.RecordCount);
        this.setPaginator();
        this.apiservice.loaderHide();
      },
      error :err=> {
      this.apiservice.loaderHide();
      
    },
  });
}

  setPaginator()
  {
    this.paginatorBlock = [];
    if (this.pages.PageNumber <= 4) {
      for (let i = 1; i <= 10 && i <= this.ttlpage; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.pages.PageNumber - 3; i <= this.pages.PageNumber + 6 && i <= this.ttlpage; i++) {
        this.paginatorBlock.push(i);
      }
    }
   
  }
  
  onPaginatorChange(paginatorQuery:any)
  {
    this.pages.PageNumber = paginatorQuery;

    let selectedValue = (event?.target as HTMLSelectElement).value;
    this.selectedOption = selectedValue;

    if(paginatorQuery.action=='pagesize'){
      this.pages.PageNumber = 1;
      this.pages.RecordCount = this.selectedOption;
    }
    else if(paginatorQuery.action=='pagechange'){
      this.pages.PageNumber = paginatorQuery.pageno;
    }
    this.getall();
  }



}
