import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject, finalize ,throwError } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { StrogeService } from 'src/app/service/stroge.service';
import { Router } from '@angular/router';
import { catchError } from 'rxjs/operators';
// import { throwError } from 'rxjs';

// import { config } from './config';
const AUTH_API = 'https://dev.kheloo.com/api/';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private isLoadingSubject = new BehaviorSubject<boolean>(false);
  public isLoading$ = this.isLoadingSubject.asObservable();
  private userDetails :any;
  //url='https://api.quotable.io/random';
  private apiUrl = 'https://kheloo.com/Home/GetRecentWithdraw';
  data: any = [];
  public headers: any;
  public options: any;
  public headers_object: any;
  constructor(private http: HttpClient,private storage:StrogeService,private router:Router) { }
  // getdata() {
  //   return this.http.get('https://kheloo.com/Home/GetRecentWithdraw');
  // }
  initHeaders() {
    this.headers_object = new HttpHeaders();
    if (this.storage.getData('LoginToken')) {
      this.headers_object = this.headers_object.append('Token', this.storage.getData('LoginToken'));
      this.headers_object = this.headers_object.append('userId', this.storage.getData('UserId'));
    }
    this.options = {
      headers: this.headers_object
    };
  }
  getQuote(): Observable<any> {
    return this.http.get<any>('https://kheloo.com/api/GameV1/GetRecentWithdraw');
  }

// Register
  getOtp(mobilenumber : any ): Observable<any>{
    return this.http.get(AUTH_API + 'GameV1/GenerateOTP?Mobile='+mobilenumber);
  }

  verifyotp(mobilenumber : any, otp:any ): Observable<any>{
    return this.http.get(AUTH_API + 'GameV1/VerifyOTP?Mobile='+mobilenumber+'&OTP='+otp);
  }

  register(detailsform :any): Observable<any>{
    return this.http.post(AUTH_API + 'GameV1/RegisterUser',detailsform);
  }
  
  login(mobilenumber:any, password:any): Observable<any>{
    return this.http.get(AUTH_API + 'LoginAPI/UserLogin?Mobile='+mobilenumber+'&Password='+password);
  }
  
  forgotOtp(detailnumber :any) : Observable<any>{
    return this.http.post(AUTH_API + 'GameV1/GenerateOTPForgotPassword',detailnumber);
  }
  
  newPassword(newPassworddetails :any) : Observable<any> {
    return this.http.post(AUTH_API + 'GameV1/ResetPassword',newPassworddetails);

  }

  isLoggedin(){
    let userid  = this.storage.getData('UserId');
    let LoginToken  = this.storage.getData('LoginToken');
    if(userid != '' && LoginToken != '' && LoginToken != null ){
      return true;
    }else{
      return false;

    }
  }

  logout(){
    this.storage.clearData();
    this.router.navigate(['/login']);
  }

  fetchbalance()  : Observable<any>{
    this.initHeaders();
    return this.http.get(AUTH_API + 'MyProfileAPI/GetUserBalance',this.options);
  }
 
  setUserDetails(details: any) {
    this.userDetails = details;
  }
  
  getUserDetails()  : Observable<any>{
    this.initHeaders();
    return this.http.get(AUTH_API + 'MyProfileAPI/GetUserProfile',this.options);
    
  }
  changePassword(passdetail:any)  : Observable<any>{
    this.initHeaders();
    return this.http.post(AUTH_API + 'GameV1/ChangePassword',passdetail,this.options);
  }
  
  fetchuserstatements(pagedetails:any) : Observable<any>{
    this.initHeaders();
    return this.http.post(AUTH_API + 'MyProfileAPI/GetUserStatement',pagedetails,this.options);
  }
  
  depositRequest(depositAmount:any): Observable<any>{
    this.initHeaders();
    return this.http.post(AUTH_API + 'MyProfileAPI/DepositeUserAmount',depositAmount,this.options);
  }
  
  getPaymentGateway(): Observable<any>{
    this.initHeaders();
    return this.http.get(AUTH_API + 'AppPayment/GetPaymentGatewayMasterDetails',this.options);
  }
  
  getWithdrawRequest(requestDetails:any): Observable<any>{
     this.initHeaders();
     return this.http.post(AUTH_API + 'MyProfileAPI/WithdrawRequest',requestDetails,this.options);
  }

  getWithdrawStatus(): Observable<any>{
    this.initHeaders();
    return this.http.get(AUTH_API + 'MyProfileAPI/GetWithdrawalStatement',this.options);
  }

  getGameCategory(): Observable<any>{
    return this.http.get(AUTH_API + 'GameV1/GetAllCategoryName');
  }
  
  getGameList(subcategory:any,category:any): Observable<any>{
    return this.http.get(AUTH_API + 'GameV1/GetGameBySubCategory?SubCategory='+subcategory+'&Category='+category);
  }
  getCategoryGameList(subcategory:any): Observable<any>{
    return this.http.get(AUTH_API + 'GameV1/GetGameList?GameCategory='+subcategory);
  }
  
  getGamesPlat(id:number) : Observable<any>{
    this.initHeaders();
    return this.http.get(AUTH_API + 'MyProfileApi/GetUrlBasedOnGameProvider?game_id='+id,this.options);
  }

  loaderShow(){
    this.isLoadingSubject.next(true);
  }
  loaderHide(){
    this.isLoadingSubject.next(false);
  }

  
}

