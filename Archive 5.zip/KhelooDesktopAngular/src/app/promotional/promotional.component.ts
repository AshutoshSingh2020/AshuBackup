import { Component } from '@angular/core';

@Component({
  selector: 'app-promotional',
  templateUrl: './promotional.component.html',
  styleUrls: ['./promotional.component.scss']
})
export class PromotionalComponent {

}
