import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LogoComponent } from './header/logo/logo.component';
import { AuthComponent } from './header/auth/auth.component';
import { LoginComponent } from './header/auth/login/login.component';
import { RegisterComponent } from './header/auth/register/register.component';
import { ForgotPasswordComponent } from './header/auth/forgot-password/forgot-password.component';
import { RecoverPasswordComponent } from './header/auth/recover-password/recover-password.component';
import { JackpotComponent } from './jackpot/jackpot.component';
import { PromotionalComponent } from './promotional/promotional.component';
import { HurryUpTmpComponent } from './hurry-up-tmp/hurry-up-tmp.component';
import { FooterComponent } from './footer/footer.component';
import { GamingPartnersComponent } from './footer/gaming-partners/gaming-partners.component';
import { PaymentMethodsComponent } from './footer/payment-methods/payment-methods.component';
import { ConnectWithUsComponent } from './footer/connect-with-us/connect-with-us.component';
import { FooterContentComponent } from './footer/footer-content/footer-content.component';
import { DepositComponent } from './header/auth/deposit/deposit.component';
import { GamesSlideComponent } from './games-slide/games-slide.component';
import { FooterLinksComponent } from './footer/footer-links/footer-links.component';
import { GamesSlotComponent } from './games-slot/games-slot.component';
import { BannerComponent } from './banner/banner.component';
import { CasinoGamesComponent } from './casino-games/casino-games.component';
import { AboutComponent } from './footer/other-pages/about/about.component';
import { FAQComponent } from './footer/other-pages/faq/faq.component';
import { HeaderBarComponent } from './header/header-bar/header-bar.component';
import { NavbarComponent } from './header/navbar/navbar.component';
import { HttpClientModule} from '@angular/common/http';
import { MainpageComponent } from './mainpage/mainpage.component';
import { DownloadappsectionComponent } from './footer/footer-content/downloadappsection/downloadappsection.component';
import { SocialmedialinksComponent } from './footer/footer-content/socialmedialinks/socialmedialinks.component';
import { AffiliatesComponent } from './footer/other-pages/affiliates/affiliates.component';
import { ContactComponent } from './footer/other-pages/contact/contact.component';
import { CasinopageComponent } from './gamespagecontent/casinopage/casinopage.component';
import { AndarbaharpageComponent } from './gamespagecontent/andarbaharpage/andarbaharpage.component';
import { SlotsComponent } from './gamespagecontent/slots/slots.component';
import { TeenpattiComponent } from './gamespagecontent/teenpatti/teenpatti.component';
import { RouletteComponent } from './gamespagecontent/roulette/roulette.component';
import { PokerComponent } from './gamespagecontent/poker/poker.component';
import { BaccaratComponent } from './gamespagecontent/baccarat/baccarat.component';
import { BlackjackComponent } from './gamespagecontent/blackjack/blackjack.component';
import { InviteFriendComponent } from './footer/other-pages/invite-friend/invite-friend.component';
import { PrivacypolicyComponent } from './footer/other-pages/privacypolicy/privacypolicy.component';
import { DisclaimerComponent } from './footer/other-pages/disclaimer/disclaimer.component';
import { TermsconditionsComponent } from './footer/other-pages/termsconditions/termsconditions.component';
import { CookiepolicyComponent } from './footer/other-pages/cookiepolicy/cookiepolicy.component';
import { DisconnectionpolicyComponent } from './footer/other-pages/disconnectionpolicy/disconnectionpolicy.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { StatementsComponent } from './profile/statements/statements.component';
import { SettingsComponent } from './profile/settings/settings.component';
import { IplBattingComponent } from './sports/ipl-batting/ipl-batting.component';
import { WithdrawalTempComponent } from './withdrawal-temp/withdrawal-temp.component';
import { GamePlatformComponent } from './game-platform/game-platform.component';
import { LoaderComponent } from './loader/loader.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LogoComponent,
    AuthComponent,
    LoginComponent,
    RegisterComponent,
    ForgotPasswordComponent,
    RecoverPasswordComponent,
    JackpotComponent,
    PromotionalComponent,
    HurryUpTmpComponent,
    FooterComponent,
    GamingPartnersComponent,
    PaymentMethodsComponent,
    ConnectWithUsComponent,
    FooterContentComponent,
    DepositComponent,
    WithdrawalTempComponent,
   
    GamesSlideComponent,
    FooterLinksComponent,
    GamesSlotComponent,
    BannerComponent,
    CasinoGamesComponent,
    AboutComponent,
    FAQComponent,
    HeaderBarComponent,
    NavbarComponent,
    MainpageComponent,
    DownloadappsectionComponent,
    SocialmedialinksComponent,
    AffiliatesComponent,
    ContactComponent, 
    CasinopageComponent,
    InviteFriendComponent,
    BlackjackComponent,
    BaccaratComponent,
    PokerComponent,
    RouletteComponent,
    TeenpattiComponent,
    SlotsComponent,
    AndarbaharpageComponent,
    PrivacypolicyComponent,
    DisclaimerComponent,
    TermsconditionsComponent,
    CookiepolicyComponent,
    DisconnectionpolicyComponent,
    StatementsComponent,
    SettingsComponent,
    IplBattingComponent,
    GamePlatformComponent,
    LoaderComponent,
   
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
