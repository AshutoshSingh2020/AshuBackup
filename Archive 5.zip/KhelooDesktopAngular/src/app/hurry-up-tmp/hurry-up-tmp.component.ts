import { Component } from '@angular/core';

@Component({
  selector: 'app-hurry-up-tmp',
  templateUrl: './hurry-up-tmp.component.html',
  styleUrls: ['./hurry-up-tmp.component.scss']
})
export class HurryUpTmpComponent {

}
