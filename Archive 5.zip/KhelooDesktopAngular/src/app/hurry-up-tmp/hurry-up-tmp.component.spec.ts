import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HurryUpTmpComponent } from './hurry-up-tmp.component';

describe('HurryUpTmpComponent', () => {
  let component: HurryUpTmpComponent;
  let fixture: ComponentFixture<HurryUpTmpComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HurryUpTmpComponent]
    });
    fixture = TestBed.createComponent(HurryUpTmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
