import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GamesSlideComponent } from './games-slide.component';

describe('GamesSlideComponent', () => {
  let component: GamesSlideComponent;
  let fixture: ComponentFixture<GamesSlideComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GamesSlideComponent]
    });
    fixture = TestBed.createComponent(GamesSlideComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
