import { Component,OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../api.service';
import { forkJoin } from 'rxjs';
import { UserAuthService } from '../service/user-auth.service';

@Component({
  selector: 'app-games-slide',
  templateUrl: './games-slide.component.html',
  styleUrls: ['./games-slide.component.scss']
})
export class GamesSlideComponent implements OnInit{
  isLoading : boolean = false;
  subcategory:any = '';
  searchQuery:string = '';
  allcategories :any[] = [];
  allgames:any[] = [];
  itemsToShow: number = 20;
  itemsToLoad: number = 20;
 constructor(private router:ActivatedRoute,private api:ApiService, private alert:UserAuthService,private routing:Router){

 }
  ngOnInit(): void {
    this.router.params.subscribe(params => {
      this.subcategory = params['category'];
      this.getAllsubcategory();
     });
     this.api.isLoading$.subscribe((isLoading) => {
      this.isLoading = isLoading;
    });
  }

  onViewMoreClick() {
    this.itemsToShow += this.itemsToLoad;
  }

getAllsubcategory(){
  this.api.loaderShow();
    this.api.getGameCategory().subscribe(  {
      next:data=>{
        this.allcategories = data.filter((category : { GameCategory: string })=> category.GameCategory === this.subcategory)
      .map((filteredCategory : { SubCategory: string })=> filteredCategory.SubCategory);
       this.fetchAllDataForSubcategories(this.allcategories);
       this.api.loaderHide();
      },
      error :err=>{
        this.alert.showAlert('Something Went Wrong','Please check your internet connection','error');
        this.api.loaderHide();
    }
    });
      
    }

fetchAllDataForSubcategories(subcategories: any[]) {
  const observables = subcategories.map(subcategory =>
    this.api.getCategoryGameList(subcategory)
  );

  forkJoin(observables).subscribe((responses: any[]) => {
    const allData: any[] = [];
    responses.forEach(subcategoryData => {
      allData.push(...subcategoryData);
    });
    this.allgames = allData; 
  });
}

navigateGamePlateform(id:number){
  this.routing.navigate(['/games',id]);
}


updateSearchQuery(query: any) {
  this.searchQuery = (event?.target as HTMLSelectElement).value;
  this.filterGames();
}

filterGames() {
  if (this.searchQuery) {
    this.allgames= this.allgames.filter(game =>
      game.name.toLowerCase().includes(this.searchQuery.toLowerCase())
    );
  } else {
    this.getAllsubcategory();
    this.allgames = this.allgames;
  }
}



}

