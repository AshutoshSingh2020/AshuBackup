// import { inject } from '@angular/core';
// import { CanActivateFn ,Router} from '@angular/router';
// import { ApiService} from 'src/app/api.service';

// export const authGuardGuard: CanActivateFn = (route , state) => {
//   const authservice = inject(ApiService);
//   const router = inject(Router);
//   if (authservice.isLoggedin()) {
//      return router.createUrlTree(['/']);
//     //  return router.parseUrl('/');
//   }
//   return true;
// };

import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private authService: ApiService, private router: Router) {}

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean | UrlTree {
    if (!this.authService.isLoggedin()) {
      // If the user is not logged in, allow access to the register page
      if (state.url === '/deposits' && !this.authService.isLoggedin()) {
        // If the user is trying to access 'deposits' and is not logged in, redirect to login
        return this.router.parseUrl('/login'); // Change '/login' to your login route
      }
      // Redirect to the login page
      return this.router.parseUrl('/login'); // Change '/login' to the actual login route
    }
    
    // If the user is already logged in, redirect to the main root
    return true;
}
}
