// export const config = {
//   apiUrl: 'https://kheloo.com/Home/GetRecentWithdraw',
//   apiKey: 'your-openweathermap-api-key'
// };
