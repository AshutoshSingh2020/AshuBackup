import { Component } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {
  isDropdownOpen: { [key: string]: boolean } = {};

  openDropdown(key: string): void {
    this.isDropdownOpen[key] = true;
  }

  closeDropdown(key: string): void {
    this.isDropdownOpen[key] = false;
  }

  toggleDropdown(key: string): void {
    this.isDropdownOpen[key] = !this.isDropdownOpen[key];
  }
}
