import { Component,OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { StrogeService } from '../service/stroge.service';
import { UserAuthService } from 'src/app/service/user-auth.service';
import { Subscription } from 'rxjs';
import { Router ,NavigationEnd} from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  private logcheck !: Subscription;
  logincheck :boolean = false;
 username :any = '';
 balance : any; 
 showmenu :boolean = false;
constructor(private login:ApiService,private storage:StrogeService ,private userauth:UserAuthService,private router:Router){
  // this.router.events.subscribe((event) => {
  //   if (event instanceof NavigationEnd) {
  //     this.refreshHeader(); 
  //   }
  // });
 
}

ngOnInit(): void {
  this.logcheck = this.userauth.loging$.subscribe((loging:any={}) => {
        this.logincheck=('login' in loging)?true:false;
        this.username = this.storage.getData('name');
        this.login.fetchbalance().subscribe({
          next: data=>{
            if(data.ErrorCode == '0'){
              this.storage.clearData();
            }else{
              this.balance = data.Balance;
            }
          },
          error:err=>{
            this.userauth.showAlert('Something Went Wrong','Please check your Internet Connection','error');
          }
        });
    });
  
//   loading$.subscribe((loading:any={}) => {
//     this.PGCollumnLoading=('getPGMaster' in loading)?true:false;
// });
  // this.logincheck = this.login.isLoggedin();
  
  
}
// refreshHeader(){
//   this.username = this.storage.getDataurda('name'); 
//   if(this.username != '' && this.username !=null){

//     this.logincheck = true;
//   }

// }

logout(){
  this.login.logout();
  this.logincheck = false;
}

showmenubar(){
if(this.showmenu == false){
  this.showmenu = true;
}else if(this.showmenu == true){
  this.showmenu = false;
}
}

}
