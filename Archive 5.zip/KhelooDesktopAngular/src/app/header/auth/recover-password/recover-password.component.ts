import { Component,OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators,ValidatorFn,AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from 'src/app/api.service';
import { UserAuthService } from 'src/app/service/user-auth.service';

const passwordMatchValidator: ValidatorFn = (control: AbstractControl): {[key: string]: any} | null => {
  let password = control.get('NewPassword')?.value;
  let confirmPassword = control.get('ConfirmPassword')?.value;

  return password !== confirmPassword ? { mismatch: true } : null;
};


@Component({
  selector: 'app-recover-password',
  templateUrl: './recover-password.component.html',
  styleUrls: ['./recover-password.component.scss']
})
export class RecoverPasswordComponent implements OnInit {
  showsubmitbtn :boolean=false;
  show = 'fa fa-eye';
  password = "password";
  show1 = 'fa fa-eye';
  password1 = "password";
  show2 = 'fa fa-eye';
  password2 = "password";
  changepassword : FormGroup;
  constructor( private api:ApiService, private fb:FormBuilder,private auth:UserAuthService,private router:Router){
    this.changepassword = this.fb.group({
      Password: ['',Validators.required],
      NewPassword: ['',Validators.required],
      ConfirmPassword: ['',Validators.required]
    },{
       validators: passwordMatchValidator
      });
  }
  ngOnInit(): void {
    
  }

  showpassword() {
    if (this.password === "password") {
      this.password = "text";
      this.show = 'fa fa-eye-slash';
    } else {
      this.password = "password";
      this.show = 'fa fa-eye';
    }
  }
  showpassword1() {
    if (this.password1 === "password") {
      this.password1 = "text";
      this.show1 = 'fa fa-eye-slash';
    } else {
      this.password1= "password";
      this.show1 = 'fa fa-eye';
    }
  }
  showpassword2() {
    if (this.password2 === "password") {
      this.password2 = "text";
      this.show2 = 'fa fa-eye-slash';
    } else {
      this.password2 = "password";
      this.show2 = 'fa fa-eye';
    }
  }
  changePassword(){
    this.showsubmitbtn  = true
    this.api.changePassword(this.changepassword.value).subscribe({
      next: data=>{
        console.log(data);
        if(data.ErrorCode == '1'){
          this.auth.showAlert(data.Result,data.ErrorMessage,'success');
          this.router.navigate(['/settings']);
        }else{
          this.auth.showAlert(data.Result,data.ErrorMessage,'warning');
        }
        this.showsubmitbtn = false;
      },
      error:err=>{
        this.auth.showAlert('Something Went Wrong','Please check your Internet Connection','error');
        this.showsubmitbtn = false;
      },
    });
  }
}
