import { Component , OnInit} from '@angular/core';
import { FormBuilder, FormGroup ,Validators} from '@angular/forms';
import { ApiService } from 'src/app/api.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { UserAuthService } from 'src/app/service/user-auth.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent  implements OnInit{
  showVerification = false;
  showsubmitbtn :boolean = false;
  countofnumber !:number;
  forgototpform :FormGroup;
  resetpasswordform :FormGroup;
  constructor(private auth:ApiService, private fb:FormBuilder,private route:Router,private userauth:UserAuthService){
    this.forgototpform = this.fb.group({
      Mobile: [ "",[Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
    });

    this.resetpasswordform = this.fb.group({
      OTP: [ "",[Validators.required,Validators.minLength(4)]],
      Password: [ "",[Validators.required,Validators.minLength(6)]],
    });
  }
ngOnInit(): void {
  this.forgototpform.get('mobilenumber')?.valueChanges.subscribe((val)=>
  {
    let oldVal = val;
    oldVal =  oldVal.replace(/\D/g, '');
    oldVal = oldVal.substring(0,10);
    this.countofnumber = oldVal.length;
    this.forgototpform.get('mobilenumber')?.setValue(oldVal,{emitEvent :false});
  });
}
  get_code(){
    this.showsubmitbtn = true;
    this.auth.forgotOtp(this.forgototpform.value).subscribe({
      next: data => {
        if( data.RStatus == 'Success'){
          this.showVerification = true;
          this.showsubmitbtn = false;
        }
      },
      error : err=>{
        this.userauth.showAlert('Something Went Wrong','Please check your Internet connection','error');
        this.showsubmitbtn = false;
       }
     });


  }
  newpassword(){
    this.showsubmitbtn = true;
    let verificationform = this.resetpasswordform.value;
    verificationform.Mobile = this.forgototpform.controls['Mobile'].value;
    this.auth.newPassword(verificationform).subscribe({
      next: data=>{
        if(data.RStatus == 'Success'){
          this.userauth.showAlert(data.Msg,'','success');
          this.route.navigate(['/login']);
        }else{
          this.showsubmitbtn = false;
        }

      },
      error: err=>{
        this.userauth.showAlert('Something Went Wrong','Please check your Internet connection','error');
        this.showsubmitbtn = false;
      }
    })


  }

}
