import { Component ,ChangeDetectorRef} from "@angular/core";
import { FormBuilder,FormGroup, Validators } from "@angular/forms";
import { ApiService } from 'src/app/api.service';
import { StrogeService } from 'src/app/service/stroge.service';
import { Router } from "@angular/router";
import { UserAuthService } from "src/app/service/user-auth.service";
@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.scss"],
})
export class LoginComponent {
  //password: any;
  show = 'fa fa-eye';
  Mobile: string = "";
  UserPassword: string = "";
  password = "password";
  showsubmitbtn :boolean = false


  constructor(private fb:FormBuilder,private auth:ApiService,private storage:StrogeService,private router:Router,private cdr: ChangeDetectorRef, private userauth : UserAuthService){
    
   }

  ngOnInit() {
    // this.storage.clearData();
  }
  loginform = this.fb.group({
    mobile : ['',Validators.required],
    password : ['',Validators.required],
  });

  showpassword() {
    if (this.password === "password") {
      this.password = "text";
      this.show = 'fa fa-eye-slash';
    } else {
      this.password = "password";
      this.show = 'fa fa-eye';
    }
  }

  login(){
    this.showsubmitbtn = true;
    let {mobile,password} = this.loginform.value;
    this.auth.login(mobile,password).subscribe({
      next: data=>{
        if(data.ErrorCode == '1'){
          this.showsubmitbtn = false;
          this.storage.saveData('UserId',data.UserId);
          this.storage.saveData('LoginToken',data.LoginToken);
          this.storage.saveData('name',data.UserName);
          this.userauth.showAlert(data.ErrorMessage,'','success');
          this.auth.setUserDetails(data)
          this.router.navigate(['/']);
        }else if(data.ErrorCode == '4'){
          this.userauth.showAlert(data.ErrorMessage,'','error');
          
        }
      },
      error: err => {
        this.userauth.showAlert('Something Went Wrong','','error');
      }
    });
  }
  
  
}
