import { Component, OnInit} from '@angular/core';
import { FormBuilder,FormControlName,FormGroup, Validators,AbstractControl ,ValidatorFn} from '@angular/forms'
import { ApiService } from 'src/app/api.service';
import { UserAuthService } from 'src/app/service/user-auth.service';



const USER_KEY = 'auth-user';
const passwordMatchValidator: ValidatorFn = (control: AbstractControl): {[key: string]: any} | null => {
  let password = control.get('password')?.value;
  let confirmPassword = control.get('OTP')?.value;

  return password !== confirmPassword ? { mismatch: true } : null;
};
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})


export class RegisterComponent implements OnInit{
   Swal :any;
  showVerification = false;
  showRegister = false;
  showsubmitbtn :boolean = false;
  alreadyregister :boolean = false;
  countofnumber !:number;
  registerform : FormGroup;
  verifyform : FormGroup;
  detailsform : FormGroup;
   mobilenumber : any;

   passwordtype = "password";
   passwordtvisibility = "fa fa-eye";
   passwordtype1 = "password";
   passwordtvisibility1 = "fa fa-eye";


  private phoneNumberKey = 'mobilenumber';
  constructor(private fb:FormBuilder,private auth:ApiService,private alert: UserAuthService){
    this.registerform = this.fb.group({
      mobilenumber: [ "",[Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
    });
    this.verifyform = this.fb.group({
      otpnumber: [ "",[Validators.required,Validators.minLength(4)]],

    });
    this.detailsform = this.fb.group({
      UserName: [ "",[ Validators.required,Validators.minLength(3),Validators.pattern('[a-zA-z]+')]],
      FName: [ "",[ Validators.required,Validators.minLength(3),Validators.pattern('[a-zA-z]+')]],
      LName: [ "",[ Validators.required,,Validators.minLength(3),Validators.pattern('[a-zA-z]+')]],
      DOB: [ "",[ Validators.required]],
      password: [ "",[ Validators.required,Validators.minLength(6)]],
      OTP: [ "",[ Validators.required,Validators.minLength(6)]],
      // Mobile: [ "",[ Validators.required]],
    },{
      validators: passwordMatchValidator

    }
    );
    

  }

  ngOnInit(): void {
    this.registerform.get('mobilenumber')?.valueChanges.subscribe((val)=>
    {
      let oldVal = val;
      oldVal =  oldVal.replace(/\D/g, '');
      oldVal = oldVal.substring(0,10);
      this.countofnumber = oldVal.length;
      this.registerform.get('mobilenumber')?.setValue(oldVal,{emitEvent :false});
    });
    this.verifyform.get('otpnumber')?.valueChanges.subscribe((val)=>
    {
      let oldVal = val;
      oldVal =  oldVal.replace(/\D/g, '');
      this.registerform.get('otpnumber')?.setValue(oldVal,{emitEvent :false});
    });
    
    
    
  }
  
  register(){
    this.showsubmitbtn = true;
    this.auth.getOtp(this.registerform.controls['mobilenumber'].value).subscribe( {
      next: data => {
        if(data.ErrorCode == '1'){
          //  sessionStorage.setItem(this.phoneNumberKey, mobilenumber);
          this.showsubmitbtn = false;
          this.showVerification = true;
        } else if(data.ErrorCode == '3'){
          // alert('Already Register');
          this.alert.showAlert(data.ErrorMessage,'','warning');
          this.alreadyregister = true;
          this.showsubmitbtn = false;
        }
      },
      error: err => {
        this.alert.showAlert('Error','Please Check Internet Connection','error');
        
      }
    });
  }
  
  verifyOtp(){
    this.showsubmitbtn = true;
    let otpnumber  = this.verifyform.controls['otpnumber'].value;
    let mobilenumber  = this.registerform.controls['mobilenumber'].value;
    
    this.auth.verifyotp(mobilenumber, otpnumber).subscribe( {
      next: data => {
        
        if(data.ErrorCode == '1'){
          this.showsubmitbtn = false;
          this.showVerification = false;
          this.showRegister = true;
        }else if(data.ErrorCode == '2'){
          this.alert.showAlert(data.ErrorMessage,'','error');
          this.alreadyregister = true;
          this.showsubmitbtn = false;
        }
        
      },
      error: err => {
        this.alert.showAlert('Error','Please Check Internet Connection','errorß');
      }
    });
  

  }
  registerDetails(){
    let detailsformValue  = this.detailsform.value;
    detailsformValue.Mobile = this.registerform.controls['mobilenumber'].value;

    this.auth.register(detailsformValue).subscribe( {
      next: data => {
        console.log(data);
      },
      error: err => {
        
      }
    });
  }

  showpassword(){
    if(this.passwordtype == 'password'){
      this.passwordtype = "text";
      this.passwordtvisibility = "fa fa-eye-slash";
    }else if(this.passwordtype == 'text'){
      this.passwordtype = "password";
      this.passwordtvisibility = "fa fa-eye-slash";

    }
  }
  showConfirmpassword(){
    if(this.passwordtype1 == 'password'){
      this.passwordtype1 = "text";
      this.passwordtvisibility1 = "fa fa-eye-slash";
    }else if(this.passwordtype1 == 'text'){
      this.passwordtype1 = "password";
      this.passwordtvisibility1 = "fa fa-eye";

    }
  }



}


