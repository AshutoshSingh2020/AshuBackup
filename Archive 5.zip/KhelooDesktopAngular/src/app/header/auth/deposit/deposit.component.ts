import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ApiService } from 'src/app/api.service';
import { UserAuthService } from 'src/app/service/user-auth.service';
declare var $: any;
@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.scss']
})
export class DepositComponent {
  weight = 40;
  height = 160;
  result = 0;
  myWeight='';
  bmi='';
  centimeter = 0;
  meter = 0;
  transcationId:any ;
  paymentGateway:any;
  paymenting:any;
  paymentinput :boolean =true;
  showsubmitbtn:boolean = false;
constructor(private fb:FormBuilder,private api:ApiService,private useralert:UserAuthService){

}

deposits = this.fb.group({
  Amount : ['100',Validators.required],
  ramount : ['100'],
});

WeightvalueChanged(e:any) {
  this.weight = (e);
}

showValWeight1(e:any) {
  this.weight = (e);
}

setAmount(amount:any){
  this.deposits.controls['Amount'].setValue(amount);
}

requestDeposit(){
  this.showsubmitbtn = true;
  this.api.getPaymentGateway().subscribe({
    next:data=>{
      this.paymenting  = data;
      this.showsubmitbtn = false;
    },
    error:err=>{
    this.showsubmitbtn = false;
    this.useralert.showAlert('Something Went Wrong','Please check your internet connection','error');

  }
});
this.api.depositRequest(this.deposits.value).subscribe({
  next: data=>{
    if(data.ErrorCode == '1'){
      let trans = data.Result.split("=");
      this.transcationId = trans[1];
      this.paymentGateway = this.paymenting;
      this.paymentinput = false;
     }else{
        this.useralert.showAlert(data.ErrorMessage,'','error');
      }
    },
    error:err=>{
    this.useralert.showAlert('Something Went Wrong','Please check your Internet Connection','error');

  } 
});

}


}
