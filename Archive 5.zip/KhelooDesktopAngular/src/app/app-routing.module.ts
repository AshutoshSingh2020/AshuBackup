import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './footer/other-pages/about/about.component';
import { AppComponent } from './app.component';
import { MainpageComponent } from './mainpage/mainpage.component';
import { JackpotComponent } from './jackpot/jackpot.component';
import { DepositComponent } from './header/auth/deposit/deposit.component';
import { DownloadappsectionComponent } from './footer/footer-content/downloadappsection/downloadappsection.component';
import { LoginComponent } from './header/auth/login/login.component';
import { RegisterComponent } from './header/auth/register/register.component';
import { AffiliatesComponent } from './footer/other-pages/affiliates/affiliates.component';
import { InviteFriendComponent } from './footer/other-pages/invite-friend/invite-friend.component';
import { FAQComponent } from './footer/other-pages/faq/faq.component';
import { PrivacypolicyComponent } from './footer/other-pages/privacypolicy/privacypolicy.component';
import { DisclaimerComponent } from './footer/other-pages/disclaimer/disclaimer.component';
import { TermsconditionsComponent } from './footer/other-pages/termsconditions/termsconditions.component';
import { CookiepolicyComponent } from './footer/other-pages/cookiepolicy/cookiepolicy.component';
import { DisconnectionpolicyComponent } from './footer/other-pages/disconnectionpolicy/disconnectionpolicy.component';
import { ContactComponent } from './footer/other-pages/contact/contact.component';
import { CasinopageComponent } from './gamespagecontent/casinopage/casinopage.component';
import { AndarbaharpageComponent } from './gamespagecontent/andarbaharpage/andarbaharpage.component';
import { PokerComponent } from './gamespagecontent/poker/poker.component';
import { RouletteComponent } from './gamespagecontent/roulette/roulette.component';
import { SlotsComponent } from './gamespagecontent/slots/slots.component';
import { TeenpattiComponent } from './gamespagecontent/teenpatti/teenpatti.component';
import { BaccaratComponent } from './gamespagecontent/baccarat/baccarat.component';
import { BlackjackComponent } from './gamespagecontent/blackjack/blackjack.component';
import { ForgotPasswordComponent } from './header/auth/forgot-password/forgot-password.component'
// import { authGuardGuard } from './auth-guard.guard';
import { AuthGuard } from './auth-guard.guard';
import { StatementsComponent } from './profile/statements/statements.component';
import { SettingsComponent } from './profile/settings/settings.component';
import { RecoverPasswordComponent } from './header/auth/recover-password/recover-password.component';
import { IplBattingComponent } from './sports/ipl-batting/ipl-batting.component'
import { WithdrawalTempComponent } from './withdrawal-temp/withdrawal-temp.component';
import { GamesSlideComponent } from './games-slide/games-slide.component';

import { GamePlatformComponent } from './game-platform/game-platform.component';
const routes: Routes = [
  //{ path: '' pathMatch: 'full', component: MainpageComponent  },
  { path: '', component: MainpageComponent, data: { title: 'Kheloo- Best Online Sports Betting Sites | Play Casino Games Online', desciption: 'Kheloo offers the safest and best casino games in India. Join now &amp; play online casino games like Roulette, Baccarat, Blackjack, and more to win real money.' }  },
  { path: 'about', component: AboutComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'affiliates', component: AffiliatesComponent },
  { path: 'deposits', component: DepositComponent ,canActivate: [AuthGuard]},
  { path: 'invitefridend', component: InviteFriendComponent },
  { path: 'faq', component: FAQComponent },
  { path: 'privacypolicy', component: PrivacypolicyComponent },
  { path: 'disclaimer', component: DisclaimerComponent },
  { path: 'termsconditions', component: TermsconditionsComponent },
  { path: 'cookiepolicy', component: CookiepolicyComponent },
  { path: 'disconnectionpolicy', component: DisconnectionpolicyComponent },
  { path: 'iplbatting', component: IplBattingComponent },
  { path: 'withdraw', component: WithdrawalTempComponent },
  { path: 'gameslide/:category', component: GamesSlideComponent },
  { path: 'games/:id', component: GamePlatformComponent },
  
  { path: 'contact', component: ContactComponent },
  { path: 'casino', component: CasinopageComponent },
  { path: 'anadarbahar', component: AndarbaharpageComponent },
  { path: 'poker', component: PokerComponent },
  { path: 'roulette', component: RouletteComponent },
  { path: 'slots', component: SlotsComponent },
  { path: 'teenpati', component: TeenpattiComponent },
  { path: 'baccarat', component: BaccaratComponent },
  { path: 'blackjack', component: BlackjackComponent },
  { path: 'forgotpassword', component: ForgotPasswordComponent },
  { path: 'statements', component: StatementsComponent },
  { path: 'settings', component: SettingsComponent },
  { path: 'resetpassword', component: RecoverPasswordComponent },
  
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
