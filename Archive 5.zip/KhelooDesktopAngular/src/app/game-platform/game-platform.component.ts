import { Component ,OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../api.service';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { UserAuthService } from '../service/user-auth.service';

@Component({
  selector: 'app-game-platform',
  templateUrl: './game-platform.component.html',
  styleUrls: ['./game-platform.component.scss']
})
export class GamePlatformComponent implements OnInit{
  id:number = 0;
  pltSource:any ;
  isLoading :boolean=false;
constructor(private router:ActivatedRoute,private api:ApiService,private sanitizer: DomSanitizer,private alert:UserAuthService){


}
ngOnInit(): void {
  this.router.params.subscribe(params => {
    this.id = params['id'];
    this.getGames(this.id);
   });

   this.api.isLoading$.subscribe((isLoading) => {
    this.isLoading = isLoading;
  });
}


getGames(id:number){
  this.api.loaderShow();
  this.api.getGamesPlat(id).subscribe({
    next: data=>{
      this.api.loaderHide();
      if(data.ErrorCode == '1'){
        // this.pltSource = data.Result;
        this.pltSource = this.sanitizer.bypassSecurityTrustResourceUrl(data.Result);
        console.log(this.pltSource );
      }else{
        this.alert.showAlert(data.ErrorMessage,'','error');

      }
    },
    error:err=>{
      this.alert.showAlert('Something Went Wrong','please check your Internet Connection','error');
      this.api.loaderHide();
    }
  });
}
}
