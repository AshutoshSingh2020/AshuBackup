import { Component, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";

import { ApiService } from "../api.service";
// Import the ApiResponse interface

@Component({
  selector: "app-jackpot",
  templateUrl: "./jackpot.component.html",
  styleUrls: ["./jackpot.component.scss"],
})
export class JackpotComponent implements OnInit {
  recentWithdraws: any[] = [];
  number: any;
  result: any = "";
  completed: string = "";
  id: string = "";
  title: string = "";

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.syncNumber();
    this.getQuote();

    // this.apiService.getdata().subscribe((data) => {
    //   this.result = data;
    //   console.log(data);
    // });
    // this.apiService.getQuote().subscribe((data) => {
    //   console.log(data);
    //   this.Quote = data[content];
    // });
  }
  getQuote() {
    this.apiService.getQuote().subscribe(
      (data: any) => {
        console.log(data);
        this.result = data;
      },
      (error) => {
        console.error("Error fetching quote", error);
      }
    );
  }
  syncNumber() {
    const startNumber = 5910072; // Specify the initial number
    const endNumber = 9999999;
    const resetNumber = 8889989;

    let currentNumber = startNumber;

    setInterval(() => {
      currentNumber++;

      if (currentNumber > endNumber) {
        currentNumber = resetNumber;
      }

      this.number = currentNumber;
    }, 1000);
  }
}
