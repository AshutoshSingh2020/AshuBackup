import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WithdrawalTempComponent } from './withdrawal-temp.component';

describe('WithdrawalTempComponent', () => {
  let component: WithdrawalTempComponent;
  let fixture: ComponentFixture<WithdrawalTempComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [WithdrawalTempComponent]
    });
    fixture = TestBed.createComponent(WithdrawalTempComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
