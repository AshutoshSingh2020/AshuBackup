import { Component,OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApiService } from '../api.service';
import { UserAuthService } from '../service/user-auth.service';

@Component({
  selector: 'app-withdrawal-temp',
  templateUrl: './withdrawal-temp.component.html',
  styleUrls: ['./withdrawal-temp.component.scss']
})
export class WithdrawalTempComponent implements OnInit{
  withdrawStatement:any;
  isLoading :boolean = false;
  showsubmitbtn :boolean = false;
withdrawState :boolean =false;
  constructor(private fb:FormBuilder,private api:ApiService,private useralert : UserAuthService){
    
  }
  ngOnInit(): void {
    this.api.isLoading$.subscribe((isLoading) => {
      this.isLoading = isLoading;
    });
  }
  
  withdrawform = this.fb.group({
    AccountHolderName: ['',Validators.required],
    AccountNumber: ['',Validators.required],
    BankName: ['',Validators.required],
    BranchName: ['',Validators.required],
    Amount: ['',Validators.required],
    IfscCode: ['',Validators.required],
  });


  withdraw(){
    this.showsubmitbtn = true;
    this.api.loaderShow();
    this.api.getWithdrawRequest(this.withdrawform.value).subscribe({
      next: data=>{
        if(data.ErrorCode == '1'){
          this.useralert.showAlert(data.Result,data.ErrorMessage,'success');    
        }else{
          this.useralert.showAlert('',data.ErrorMessage,'error');    
        }
        this.showsubmitbtn = false;
        this.api.loaderHide();
      },
      error : err=>{
        this.useralert.showAlert('Something Went Wrong','Please check your internet Connection','error');    
        this.showsubmitbtn = false;
        this.api.loaderHide();
        
      }
    });
  }
  
  withdrawStatus(){
    this.api.loaderShow();
    this.api.getWithdrawStatus().subscribe({
      next:data=>{
        this.withdrawStatement = data;
        this.withdrawState = true;
        this.api.loaderHide();
      },
      error:err=>{
        this.useralert.showAlert('Something Went Wrong','Please check your internet Connection','error');
        this.api.loaderHide();
      }
    })
  }
  bankStatus(){
    this.withdrawState = false;
  }
}
