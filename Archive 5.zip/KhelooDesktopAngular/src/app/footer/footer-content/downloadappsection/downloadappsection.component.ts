import { Component } from '@angular/core';

@Component({
  selector: 'app-downloadappsection',
  templateUrl: './downloadappsection.component.html',
  styleUrls: ['./downloadappsection.component.scss']
})
export class DownloadappsectionComponent {

}
