import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DownloadappsectionComponent } from './downloadappsection.component';

describe('DownloadappsectionComponent', () => {
  let component: DownloadappsectionComponent;
  let fixture: ComponentFixture<DownloadappsectionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DownloadappsectionComponent]
    });
    fixture = TestBed.createComponent(DownloadappsectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
