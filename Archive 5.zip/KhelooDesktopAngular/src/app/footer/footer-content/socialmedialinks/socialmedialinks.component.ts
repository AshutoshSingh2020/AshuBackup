import { Component } from '@angular/core';

@Component({
  selector: 'app-socialmedialinks',
  templateUrl: './socialmedialinks.component.html',
  styleUrls: ['./socialmedialinks.component.scss']
})
export class SocialmedialinksComponent {

}
