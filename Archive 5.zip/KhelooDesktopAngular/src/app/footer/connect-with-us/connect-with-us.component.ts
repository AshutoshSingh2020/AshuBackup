import { Component } from '@angular/core';

@Component({
  selector: 'app-connect-with-us',
  templateUrl: './connect-with-us.component.html',
  styleUrls: ['./connect-with-us.component.scss']
})
export class ConnectWithUsComponent {

}
