import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GamingPartnersComponent } from './gaming-partners.component';

describe('GamingPartnersComponent', () => {
  let component: GamingPartnersComponent;
  let fixture: ComponentFixture<GamingPartnersComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GamingPartnersComponent]
    });
    fixture = TestBed.createComponent(GamingPartnersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
