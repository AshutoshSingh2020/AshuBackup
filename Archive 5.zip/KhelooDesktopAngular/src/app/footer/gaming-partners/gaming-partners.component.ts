import { Component } from '@angular/core';

@Component({
  selector: 'app-gaming-partners',
  templateUrl: './gaming-partners.component.html',
  styleUrls: ['./gaming-partners.component.scss']
})
export class GamingPartnersComponent {

}
