import { Component } from '@angular/core';

@Component({
  selector: 'app-disconnectionpolicy',
  templateUrl: './disconnectionpolicy.component.html',
  styleUrls: ['./disconnectionpolicy.component.scss']
})
export class DisconnectionpolicyComponent {

}
