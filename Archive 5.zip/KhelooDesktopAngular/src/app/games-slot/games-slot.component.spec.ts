import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GamesSlotComponent } from './games-slot.component';

describe('GamesSlotComponent', () => {
  let component: GamesSlotComponent;
  let fixture: ComponentFixture<GamesSlotComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [GamesSlotComponent]
    });
    fixture = TestBed.createComponent(GamesSlotComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
