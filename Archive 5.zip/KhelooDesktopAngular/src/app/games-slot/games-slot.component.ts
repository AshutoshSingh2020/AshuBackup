import { Component } from '@angular/core';
import { Router,NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-games-slot',
  templateUrl: './games-slot.component.html',
  styleUrls: ['./games-slot.component.scss']
})
export class GamesSlotComponent {


  constructor(private router:Router){
    // this.router.events.subscribe(event => {
    //   if (event instanceof NavigationEnd) {
    //     const fullRoute = window.location.origin + this.router.url;
    //     console.log('Full Route:', fullRoute);
    //   }
    // });
  }

  navigateCategory(sports:string){
    this.router.navigate(['/gameslide',sports]);
  }
}
