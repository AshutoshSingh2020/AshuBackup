import { Component } from '@angular/core';

@Component({
  selector: 'app-ipl-batting',
  templateUrl: './ipl-batting.component.html',
  styleUrls: ['./ipl-batting.component.scss']
})
export class IplBattingComponent {

}
