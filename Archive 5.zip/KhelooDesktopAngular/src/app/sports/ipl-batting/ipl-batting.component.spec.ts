import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IplBattingComponent } from './ipl-batting.component';

describe('IplBattingComponent', () => {
  let component: IplBattingComponent;
  let fixture: ComponentFixture<IplBattingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IplBattingComponent]
    });
    fixture = TestBed.createComponent(IplBattingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
