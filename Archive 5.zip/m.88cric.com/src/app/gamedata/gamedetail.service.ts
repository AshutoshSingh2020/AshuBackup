import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GamedetailService {


  globalstring = "";


  constructor() { }

  ngOnInit(): void {

     
    this.globalstring = "123";
    // alert("callfromserviceoninit"+this.globalstring);
  }
}
