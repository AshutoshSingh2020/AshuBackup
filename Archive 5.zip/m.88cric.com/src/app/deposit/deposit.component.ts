import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { strict } from 'assert';
import { UserService } from '../user.service';

declare var swal: any;

//declare var $: any;
class DepositModel {
  Amount: string;
}

class DepositMethod {
  Id: number;
  PaymentUrl: string;
  Description: string;
  StatusId: number;
  Tag: string;
  ImageUrl: string;
  Title: string;
  SubTitle: string;

}



@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css'],
})
export class DepositComponent implements OnInit {

  constructor(private UserService: UserService, private Router: Router) {
  }


  ngOnInit(): void {
    if (
      localStorage.getItem('UserId') != null &&
      localStorage.getItem('LoginToken')
    ) {
    } else {
      this.Router.navigate(['login']);
    }
    this.GetPaymentGatewayMethod();

  }


  DepositMethod
  DepositAmount: string;
  popup: boolean;

  classToggled = false;
  Title = '';
  PgCodeSelected = '';
  HindiLink = "https://www.youtube.com/embed/LwgW3vKikw8";



  promotions = [

    //{
    //  title: 'UPI & Wallet',
    //  heading: '',
    //  image: './assets/images/deposit/UPI.svg',
    //  ribbon: 'Silver Pay',
    //  PGCode: 'UPI3',
    //  tab: 'instant',
    //  UPIType: 3
    //},
    //{
    //  title: 'UPI',
    //  heading: '',
    //  image: './assets/images/deposit/UPI.svg',
    //  ribbon: 'Silver Pay', 
    //  PGCode: 'UPI',
    //  tab: 'instant',
    //  UPIType: 5
    //},
    //{
    //  title: 'UPI & Net Banking',
    //  heading: '',
    //  image: './assets/images/deposit/netbanking.svg',
    //  ribbon: 'Silver Pay',
    //  PGCode: 'UPI',
    //  tab: 'instant', 
    //  UPIType: 0
    //},
    {
      title: 'UPI',
      heading: 'Per transaction upto 50,000',
      image: './assets/images/deposit/UPI.svg',
      ribbon: 'Gold Pay',
      ribbon1: 'How to Deposit?',
      PGCode: 'UPI1',
      tab: 'other',
      UPIType: 3
    },

    //{
    //  title: 'UPI Fast',
    //  heading: 'Per transaction upto 50,000',
    //  image: './assets/images/deposit/UPI.svg',
    //  ribbon: 'Gold Pay',
    //  ribbon1: 'How to Deposit?',
    //  PGCode: 'UPI1',
    //  tab: 'other',
    //  UPIType: 1
    //},






    //{
    //  title: 'UPI',
    //  heading: '',
    //  image: './assets/images/deposit/UPI.svg',
    //  ribbon: 'Gold Pay',
    //  PGCode: 'NB',
    //  tab: 'other',
    //  UPIType: 2
    //},
    //{
    //  title: 'UPI, NetBanking & Wallet ',
    //  heading: 'Per transaction upto 2000',
    //  image: './assets/images/deposit/UPI.svg',
    //  ribbon: 'Gold Pay',
    //  PGCode: 'UPI1',
    //  tab: 'other',
    //  UPIType: 4
    //},


  ];


  depositmodel = new DepositModel();

  AmountDeposit(UPIType, DepositAmount) {
    if (!DepositAmount) {
      swal('Oops!', 'Please enter valid amount', 'error');
      return;
    }

    if (UPIType == 2) {
      window.open(
        'https://api.whatsapp.com/send?phone=447888894588&text=I%20want%20to%20make%20a%20deposit%20on%2088cric.',
        '_blank'
      );
      return;
    }
    if (UPIType == 4) {
      if (Number(DepositAmount) >= 2001) {
        swal('Oops!', 'Amount should not be more than 2000', 'error');
        return;
      }

    }
    if (UPIType == 1) {
      if (Number(DepositAmount) >= 50001) {
        swal('Oops!', 'Amount should not be more than 50,000', 'error');
        return;
      }

    }
    if (UPIType == 3) {
      if (Number(DepositAmount) >= 50001) {
        swal('Oops!', 'Amount should not be more than 50,000', 'error');
        return;
      }

    }

    this.depositmodel.Amount = DepositAmount;

    this.UserService.DepositUserAmount(this.depositmodel).subscribe((data) => {
      if (data['ErrorCode'] == '1') {
        if (UPIType == 0) {
          window.location.href = data['Result'].replace('payv11', 'payv26');
        } else if (UPIType == 1) {
          window.location.href = data['Result'].replace('payv11', 'payv10');
        }
        //else if (UPIType == 5) {
        //  window.location.href = data['Result'].replace('payv11', 'payv30');
        //}
        else if (UPIType == 3) {
          window.location.href = data['Result'].replace('payv11', 'payv33');
        } else if (UPIType == 4) {
          window.location.href = data['Result'].replace('payv11', 'payv26');
        } else {
          window.location.href = data['Result'];
        }
      } else {
        swal('Oops!', data['ErrorMessage'], 'error');
      }
    });
  }


  GetPaymentGatewayMethod() {

    this.UserService.GetPaymentGatewayMethod().subscribe((data) => {
      this.DepositMethod = data as DepositMethod;

    
    });
  }

  SelectedDepositMethod(Deposit) {
    if (!this.DepositAmount) {
      swal('Oops!', 'Please enter valid amount', 'error');
      return;
    }



    if (Number(this.DepositAmount) >= 50001) {
      swal('Oops!', 'Amount should not be more than 50,000', 'error');
      return;
    }


    this.depositmodel.Amount = this.DepositAmount;

    console.log(Deposit.PaymentUrl);

    this.UserService.DepositUserAmount(this.depositmodel).subscribe((data) => {
      if (data['ErrorCode'] == '1') {

        var paymentArray = data['Result'].split("=");
        var paymentlink = Deposit.PaymentUrl + paymentArray[paymentArray.length - 1];

        window.location.href = paymentlink;

       
      } else {
        swal('Oops!', data['ErrorMessage'], 'error');
      }
    });
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    return !(charCode > 31 && (charCode < 48 || charCode > 57));
  }


}
