import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SettlementsportsComponent } from './settlementsports.component';

describe('SettlementsportsComponent', () => {
  let component: SettlementsportsComponent;
  let fixture: ComponentFixture<SettlementsportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SettlementsportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SettlementsportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
