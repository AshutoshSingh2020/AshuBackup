import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settlementsports',
  templateUrl: './settlementsports.component.html',
  styleUrls: ['./settlementsports.component.css']
})
export class SettlementsportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
