import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {UserService} from '../user.service';

declare var swal: any;

//declare var $: any;
class DepositModel {
  Amount: string;
}

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css'],

})
export class DemoComponent implements OnInit {



  constructor(private UserService: UserService, private Router: Router) {
  }


  ngOnInit(): void {
    if (
      localStorage.getItem('UserId') != null &&
      localStorage.getItem('LoginToken')
    ) {
    } else {
      this.Router.navigate(['login']);
    }


  }

  DepositAmount: string;


  classToggled = false;
  Title = '';
  PgCodeSelected = '';


  promotions = [

    {
      title: 'UPI & Wallet',
      heading: 'instantly',
      image: './assets/images/deposit/UPI.svg',
      ribbon: 'Silver Pay',
      PGCode: 'UPI3',
      tab: 'instant',
      UPIType: 3

    },
    {
      title: 'UPI & Net Banking',
      heading: 'instantly',
      image: './assets/images/deposit/netbanking.svg',
      ribbon: 'Silver Pay',
      PGCode: 'UPI',
      tab: 'instant',
      UPIType: 0
    },
    {
      title: 'UPI Fast',
      heading: 'up to 10 min',
      image: './assets/images/deposit/UPI.svg',
      ribbon: 'Gold Pay',
      PGCode: 'UPI1',
      tab: 'other',
      UPIType: 1
    },


    {
      title: 'Other Method',
      heading: 'up to 10 min',
      image: './assets/images/deposit/netbanking.svg',
      ribbon: 'Gold Pay',
      PGCode: 'NB',
      tab: 'other',
      UPIType: 2
    },


  ];


  depositmodel = new DepositModel();

  AmountDeposit(UPIType,DepositAmount) {
    if (!DepositAmount) {
      swal('Oops!', 'Please enter valid amount', 'error');
      return;
    }

    if (UPIType == 2) {
      window.open(
        'https://api.whatsapp.com/send?phone=447888894588&text=I%20want%20to%20make%20a%20deposit%20on%2088cric.',
        '_blank'
      );
      return;
    }


    this.depositmodel.Amount = DepositAmount;

    this.UserService.DepositUserAmount(this.depositmodel).subscribe((data) => {
      if (data['ErrorCode'] == '1') {
        if (UPIType == 0) {
          window.location.href = data['Result'].replace('payv11', 'payv26');
        } else if (UPIType == 1) {
          window.location.href = data['Result'].replace('payv11', 'payv10');
        } else if (UPIType == 3) {
          window.location.href = data['Result'].replace('payv11', 'payv18');
        } else {
          window.location.href = data['Result'];
        }
      } else {
        swal('Oops!', data['ErrorMessage'], 'error');
      }
    });
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    return !(charCode > 31 && (charCode < 48 || charCode > 57));
  }


}




