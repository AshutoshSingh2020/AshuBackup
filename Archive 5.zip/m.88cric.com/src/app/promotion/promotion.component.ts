import { Component, OnInit } from '@angular/core';
declare var swal: any;

@Component({
  selector: 'app-promotion',
  templateUrl: './promotion.component.html',
  styleUrls: ['./promotion.component.css'],

})
export class PromotionComponent implements OnInit {

  classToggled = false;

  public toggleField() {
    this.classToggled = !this.classToggled;
  }

  objectKeys = Object.keys;
  promotions = [
    {
      "img": "./assets/images/promotion_vip.png",
      "title": "VIP",
      "heading": "VIP Royal Club",
      "description": "Play BIG, Win BIGGER",
      "image": "./assets/images/promotion_1.png"
    },
    //{
    //  "img": "./assets/images/promotion_sport.png",
    //  "title": "Sports",
    //  "heading": "Sportsbook",
    //  "description": "Get 130% Welcome..",
    //  "image": "./assets/images/promotion_2.png"
    //},
    {
      "img": "./assets/images/promotion_casino.png",
      "title": "Casino",
      "heading": "Casino Sexy Gaming",
      "description": "Grab Your Refill Bonus",
      "image": "./assets/images/promotion_3.png"

    },
    {
      "img": "./assets/images/promotion_vip.png",
      "title": "VIP",
      "heading": "VIP Royal Club",
      "description": "Play BIG, Win BIGGER",
      "image": "./assets/images/promotion_1.png"
    },
    //{
    //  "img": "./assets/images/promotion_sport.png",
    //  "title": "Sports",
    //  "heading": "Sportsbook",
    //  "description": "Get 130% Welcome..",
    //  "image": "./assets/images/promotion_2.png"
    //},
    {
      "img": "./assets/images/promotion_casino.png",
      "title": "Casino",
      "heading": "Casino Sexy Gaming",
      "description": "Grab Your Refill Bonus",
      "image": "./assets/images/promotion_3.png"

    }
  ]
  games = [
    {
      "title": "Poker"
    },
    {
      "title": "Sports"
    },
    {
      "title": "Teenpatti"
    },
    {
      "title": "VIP"
    },
    {
      "title": "Casino"
    },
    {
      "title": "Special"
    },
    {
      "title": "Roulette"
    },

  ]

  constructor() { }

  ngOnInit(): void {
  }
  promotionofferpopup(data) {

    swal({
      imageUrl: data.image,
      icon: data.img,
      title: data.heading,
      text: data.description,
      showCancelButton: true,
      confirmButtonText: "Yes!",
      cancelButtonText: "No",
      closeOnConfirm: false,
      closeOnCancel: false
    }).then(() => {
      window.location.href = "https://api.whatsapp.com/send?phone=447888894588&text=" + "*Promotion* %0a" + data.heading + "%0a" + data.description;
    });

  }

  TermsConditions() {
    swal({
      title: 'FIRST DEPOSIT BONANZA',
      //type: 'info',
      html:
        '<b>Terms & Conditions:</b>' +
        '<ul style="padding: 0 0px 0 10px; font-size: 14px; line-height: 1.5; text-align: left;">' +
       ' <li> The first deposit bonus would be credited upon successful deposit. </li>' +
        '<li> The Wagering Requirement on the first deposit offer is 25X. </li>' +
            '<li> Only 10% of the total bet amount would count towards wagering on the Games – Roulette and Baccarat.On rest of the games, they count 100%. </li>' +
        ' <li> Withdrawals prior to meeting the Wagering Requirement, will be forfeited. </li>' +
        ' <li> Wagering means using your Real Money Balance to play cash games on the site. </li>' +
        ' <li> This offer cannot be clubbed with any other offer. </li>' +
        '  <li> Multiple registrations are not entitled for this offer. </li>' +
        '   <li> Management has the right to remove/ edit the offer at any time. </li>' +
        ' <li> All standard site terms and conditions apply. </li>' +
        '</ul>' ,

    });
  }

}
