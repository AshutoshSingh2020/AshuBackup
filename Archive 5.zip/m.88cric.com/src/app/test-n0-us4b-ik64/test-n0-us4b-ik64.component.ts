import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-test-n0-us4b-ik64',
  templateUrl: './test-n0-us4b-ik64.component.html',
  styleUrls: ['./test-n0-us4b-ik64.component.css']
})
export class TestN0US4bIk64Component implements OnInit {

  constructor(private UserService: UserService, private Router: Router) { }

  ngOnInit(): void {
  }
  LaunchSportURL() {
     
    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {

    
 
      this.UserService.GetSportGameUrl().subscribe(
        data => {
          if (data["ErrorCode"] == "1") {
         
            window.location.href = data["Result"];

          } else {
            alert(data["ErrorMessage"]);
          }
        });

    } else {

      this.Router.navigate(['login']);

    }

  }
}
