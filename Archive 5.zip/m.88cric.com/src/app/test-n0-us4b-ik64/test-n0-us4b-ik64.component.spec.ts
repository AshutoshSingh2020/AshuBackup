import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestN0US4bIk64Component } from './test-n0-us4b-ik64.component';

describe('TestN0US4bIk64Component', () => {
  let component: TestN0US4bIk64Component;
  let fixture: ComponentFixture<TestN0US4bIk64Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestN0US4bIk64Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestN0US4bIk64Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
