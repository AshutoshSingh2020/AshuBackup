import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceholderlodingComponent } from './placeholderloding.component';

describe('PlaceholderlodingComponent', () => {
  let component: PlaceholderlodingComponent;
  let fixture: ComponentFixture<PlaceholderlodingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlaceholderlodingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaceholderlodingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
