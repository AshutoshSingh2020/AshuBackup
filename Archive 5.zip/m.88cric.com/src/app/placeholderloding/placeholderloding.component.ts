import { Component, OnInit } from '@angular/core';
//declare var $: any
import * as $ from 'jquery';
@Component({
  selector: 'app-placeholderloding',
  templateUrl: './placeholderloding.component.html', 
  styleUrls: ['./placeholderloding.component.css']
})
export class PlaceholderlodingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    setTimeout(function () {
      $('.card').hide();
    }, 5000);
  }

}
