import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GametabviewComponent } from './gametabview.component';

describe('GametabviewComponent', () => {
  let component: GametabviewComponent;
  let fixture: ComponentFixture<GametabviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GametabviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GametabviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
