import {Component, OnInit} from '@angular/core';
import {UserService} from '../user.service';
import {Router} from '@angular/router';

class Gamelaunchdata {
  game_id: string;
  game_code: string;
  platform = "GPL_MOBILE";
}

@Component({
  selector: 'app-gametabview',
  templateUrl: './gametabview.component.html',
  styleUrls: ['./gametabview.component.css']
})

export class GametabviewComponent implements OnInit {
  gamelaunchdata = new Gamelaunchdata();
  gameview = true;
  gameimg = false;
  loadingtwo = false;

  casinoTab: boolean = true;

  casinoTabFunction(clickedgamecategory) {
    this.gameview = false;
    this.gameimg = true;
    this.GameCategory = clickedgamecategory;
    this.casino = null;
    this.GetGameList(clickedgamecategory);
  }


  constructor(private UserService: UserService, private Router: Router) {

  }

  GameCategory: string;

  GetGameList(GameCategory) {
    this.loadingtwo = true;

    this.UserService.GetGameList(GameCategory).subscribe(
      data => {
        this.casino = data;
        //console.log(data);
        this.loadingtwo = false;

      });

  }

  LaunchGame(casinoTab) {
    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {
      this.gamelaunchdata.game_code = casinoTab["game_code"];
      this.gamelaunchdata.game_id = casinoTab["game_id"];


      this.UserService.GetLaunchGameUrl1(this.gamelaunchdata.game_id).subscribe(
        data => {
          if (data["ErrorCode"] == "1") {
            /*   alert(data["ErrorMessage"]);*/
            window.location.href = data["Result"];

          } else {
            alert(data["ErrorMessage"]);
          }

        });

    } else {

      this.Router.navigate(['login']);

    }

  }

  LaunchGameDirectGame(gamecode) {

    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {

      this.gamelaunchdata.game_code = gamecode;

      this.UserService.GetGameUrlLobby(this.gamelaunchdata).subscribe(
        data => {
          if (data["ErrorCode"] == "1") {

            window.location.href = data["Result"];

          } else {
            alert(data["ErrorMessage"]);
          }
        });

    } else {

      this.Router.navigate(['login']);

    }
  }

  getbgimage(img) {
    if (img == "null") {
      return 'assets/images/not-found.jpg';

    } else {
      return img;
    }

  }

  casino: any;

  back() {
    this.gameview = true;
    this.gameimg = false;
  }

  ngOnInit(): void {
    /* this.GetGameList(this.GameCategory);*/
  }

  LaunchSportURL() {

    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {


      window.location.href = "/betfair";


    } else {

      this.Router.navigate(['login']);

    }

  }

}
