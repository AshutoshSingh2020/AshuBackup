import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
declare var swal: any;
class DepositModel {
  Amount: string
}

@Component({
  selector: 'app-old-deposit',
  templateUrl: './old-deposit.component.html',
  styleUrls: ['./old-deposit.component.css']
})
export class OldDepositComponent implements OnInit {
  loader = false;
  IsDepositer = false;

  constructor(private UserService: UserService, private Router: Router) { }
  DepositAmount: string;
  paymentoption = "Bmethod";
  ngOnInit(): void {

    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {


    } else {
      this.Router.navigate(['login']);

    }


  }


  depositmodel = new DepositModel();
  AmountDeposit() {

    if (this.paymentoption == 'select') {
      swal("Oops!", "Please select payment Mode", "error");
      return;
    }

    if (!this.DepositAmount) {
      swal("Oops!", "Please enter valid amount", "error");
      return;
    }

    if (Number(this.DepositAmount) > 25000 && this.paymentoption == "Amethod") {
      swal("Oops!", "Please select Net banking for above ₹ 25,000", "error");
      return;

    }

    this.depositmodel.Amount = this.DepositAmount;

    this.loader = true;
    this.UserService.DepositUserAmount(this.depositmodel).subscribe(
      data => {
        if (data["ErrorCode"] == "1") {
          //  window.location.href = data["Result"];
          if (this.paymentoption == "Amethod") {

            window.location.href = data["Result"].replace("payv3", "payv2");
            // window.location.href = data["Result"];

          }
          else if (this.paymentoption == "Allmethod") {


            window.location.href = "https://pay.playludo.app/Home/payv5?TransactionId=" + data["Result"].split("=")[1];

            // window.location.href = ""

          }
          else {
            window.location.href = data["Result"];
          }



        } else {
          // alert(data["ErrorMessage"]);
          swal("Oops!", data["ErrorMessage"], "error");
        }
        this.loader = false;
      });

  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
    if (Number(this.DepositAmount) >= 25000) {
      this.paymentoption == "Bmethod";
    } else {
      this.paymentoption == "Amethod";
    }
  }

}

