import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OldDepositComponent } from './old-deposit.component';

describe('OldDepositComponent', () => {
  let component: OldDepositComponent;
  let fixture: ComponentFixture<OldDepositComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OldDepositComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OldDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
