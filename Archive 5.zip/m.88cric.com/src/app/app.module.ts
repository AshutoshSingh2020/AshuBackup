import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CountdownModule } from 'ngx-countdown';
import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
// import { HeroDetailComponent } from './hero-detail/hero-detail.component';
// import { HeroesComponent } from './heroes/heroes.component';
// import { HeroSearchComponent } from './hero-search/hero-search.component';
// import { MessagesComponent } from './messages/messages.component';
import { HeaderComponent } from './header/header.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgImageSliderModule } from 'ng-image-slider';
import { LoginComponent } from './login/login.component';
import { BannerComponent } from './banner/banner.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { OtploginComponent } from './otplogin/otplogin.component';
import { RegisterComponent } from './register/register.component';
import { SupportComponent } from './support/support.component';
import { FooterComponent } from './footer/footer.component';
import { DepositComponent } from './deposit/deposit.component';
import { PromotionComponent } from './promotion/promotion.component';
import { GamestabComponent } from './gamestab/gamestab.component';
import { TabletabComponent } from './tabletab/tabletab.component';
import { GamesnavtabComponent } from './gamesnavtab/gamesnavtab.component';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { GametabviewComponent } from './gametabview/gametabview.component';
import { BrandetabviewComponent } from './brandetabview/brandetabview.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { PlaceholderlodingComponent } from './placeholderloding/placeholderloding.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { SettingsComponent } from './settings/settings.component';
import { SportsComponent } from './sports/sports.component';
import { GamesComponent } from './games/games.component';
import { SportsnavtabComponent } from './sportsnavtab/sportsnavtab.component';
import { SportsbetComponent } from './sportsbet/sportsbet.component';
import { FancysportsComponent } from './fancysports/fancysports.component';
import { SettlementsportsComponent } from './settlementsports/settlementsports.component';
import { PrivacypolicyComponent } from './privacypolicy/privacypolicy.component';
import { TermsconditionsComponent } from './termsconditions/termsconditions.component';
import { ResponsiblegamblingComponent } from './responsiblegambling/responsiblegambling.component';
import { ShareandearnComponent } from './shareandearn/shareandearn.component';
import { DisconnectionpolicyComponent } from './disconnectionpolicy/disconnectionpolicy.component';
import { PaymentoptionsComponent } from './paymentoptions/paymentoptions.component';
import { CardinfoComponent } from './cardinfo/cardinfo.component';
import { FAQsComponent } from './faqs/faqs.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { RegisterFooterComponent } from './register-footer/register-footer.component';
import { LoginFooterComponent } from './login-footer/login-footer.component';
import { MainfooterComponent } from './mainfooter/mainfooter.component';
import { StatementsComponent } from './statements/statements.component';
import { AccountInfoComponent } from './account-info/account-info.component';
import { AffiliatesComponent } from './affiliates/affiliates.component';
import { from } from 'rxjs';
import { AllgamesComponent } from './allgames/allgames.component';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { KYCComponent } from './kyc/kyc.component';
import { TestN0US4bIk64Component } from './test-n0-us4b-ik64/test-n0-us4b-ik64.component';
import { MAINTENANCEComponent } from './maintenance/maintenance.component';
//import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';
import { ToastrModule } from 'ngx-toastr';
import { BetfairComponent } from './betfair/betfair.component';
import { ReferenceComponent } from './reference/reference.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { LaunchGameComponent } from './launch-game/launch-game.component';
import { TestComponent } from './test/test.component';
import { OldDepositComponent } from './old-deposit/old-deposit.component';
import { DemoComponent } from './demo/demo.component';
import { DepositBackup2Component } from './deposit-backup2/deposit-backup2.component';
import { InstallAppComponent } from './install-app/install-app.component';
import { DisclaimerComponent } from './disclaimer/disclaimer.component';
import { CookiePolicyComponent } from './cookie-policy/cookie-policy.component';
import { LinksComponent } from './links/links.component';
import { AppPaymentComponent } from './app-payment/app-payment.component';
import { ThankyouComponent } from './thankyou/thankyou.component';


@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NgbModule,
    TabsModule,
    NgImageSliderModule,
    Ng2SearchPipeModule,
    CountdownModule,
     ToastrModule.forRoot({
      timeOut: 2000,
      positionClass: 'toast-bottom-right',
      preventDuplicates: true,
    }),
     ServiceWorkerModule.register('ngsw-worker.js', {
       enabled: environment.production,
       // Register the ServiceWorker as soon as the app is stable
       // or after 30 seconds (whichever comes first).
       registrationStrategy: 'registerWhenStable:30000'
     })

  ],
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderComponent,
    LoginComponent,
    BannerComponent,
    OtploginComponent,
    RegisterComponent,
    SupportComponent,
    FooterComponent,
    DepositComponent,
    PromotionComponent,
    GamestabComponent,
    TabletabComponent,
    GamesnavtabComponent,
    GametabviewComponent,
    BrandetabviewComponent,
    WithdrawComponent,
    PlaceholderlodingComponent,
    ChangepasswordComponent,
    ForgotpasswordComponent,
    SettingsComponent,
    SportsComponent,
    GamesComponent,
    SportsnavtabComponent,
    SportsbetComponent,
    FancysportsComponent,
    SettlementsportsComponent,
    PrivacypolicyComponent,
    TermsconditionsComponent,
    ResponsiblegamblingComponent,
    ShareandearnComponent,
    DisconnectionpolicyComponent,
    PaymentoptionsComponent,
    CardinfoComponent,
    FAQsComponent,
    AboutusComponent,
    RegisterFooterComponent,
    LoginFooterComponent,
    MainfooterComponent,
    StatementsComponent,
    AccountInfoComponent,
    AffiliatesComponent,
    AllgamesComponent,
    KYCComponent,
    TestN0US4bIk64Component,
    MAINTENANCEComponent,
    BetfairComponent,
    ReferenceComponent,
    LaunchGameComponent,
    TestComponent,
    OldDepositComponent,
    DemoComponent,
    DepositBackup2Component,
    InstallAppComponent,
    DisclaimerComponent,
    CookiePolicyComponent,
    LinksComponent,
    AppPaymentComponent,
    ThankyouComponent
    
  ],
  bootstrap: [AppComponent]

  //SweetAlert2Module
})
export class AppModule { }
