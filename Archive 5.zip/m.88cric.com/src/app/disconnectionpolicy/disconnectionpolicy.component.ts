import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disconnectionpolicy',
  templateUrl: './disconnectionpolicy.component.html',
  styleUrls: ['./disconnectionpolicy.component.css']
})
export class DisconnectionpolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
