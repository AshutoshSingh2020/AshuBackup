import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisconnectionpolicyComponent } from './disconnectionpolicy.component';

describe('DisconnectionpolicyComponent', () => {
  let component: DisconnectionpolicyComponent;
  let fixture: ComponentFixture<DisconnectionpolicyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DisconnectionpolicyComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DisconnectionpolicyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
