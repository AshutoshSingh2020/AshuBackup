import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

class PaginationDate {
  PageNumber: string;
  RecordCount: string;
}

@Component({
  selector: 'app-statements',
  templateUrl: './statements.component.html',
  styleUrls: ['./statements.component.css']
})
export class StatementsComponent implements OnInit {

  constructor(private UserService: UserService) { }
  PaginationDate = new PaginationDate();
  
  GetUserStatement() { 
    this.UserService.GetUserStatement(this.PaginationDate).subscribe(
      data => {
        this.userstatementlist = data;
       // console.log(data);
      });
  }
  userstatementlist: any;
  ngOnInit(): void {
    this.PaginationDate.PageNumber = "1";
    this.PaginationDate.RecordCount = "100";
    this.GetUserStatement();
  }

}
