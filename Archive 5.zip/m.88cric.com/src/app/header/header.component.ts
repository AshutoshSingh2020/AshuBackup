import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  classToggled = false;
  isuserlog: boolean;
  username: string;
  userbalance: string;
  showHeaderLogin: boolean;
  public toggleField() {
    this.classToggled = !this.classToggled;
  }

  constructor(private Router: Router, private UserService: UserService) { }

  ngOnInit(): void {

    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {

      // this.username = localStorage.getItem("UserName");
      this.userbalance = localStorage.getItem("Balance");
      //// this.username = localStorage.getItem("UserName");
      // this.isuserlog = true;
      //alert(this.userbalance);
      // localStorage.setItem('userbalance', data["Balance"]);

      this.UserService.GetUserBalance().subscribe(
        data => {
          if (data["ErrorCode"] == "1") {
            this.username = localStorage.getItem("UserName");
            this.userbalance = data["Balance"];
            localStorage.setItem('userbalance', data["Balance"]);
           // this.showHeaderLogin = true;
            this.isuserlog = true;
          } else {
            this.LogOutUser();
        
          }
        });
    } else {
      this.showHeaderLogin = true;
    }

  }


  LogOutUser() {
    localStorage.clear();
    window.location.reload();
  }



}
