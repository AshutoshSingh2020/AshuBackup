import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paymentoptions',
  templateUrl: './paymentoptions.component.html',
  styleUrls: ['./paymentoptions.component.css']
})
export class PaymentoptionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
