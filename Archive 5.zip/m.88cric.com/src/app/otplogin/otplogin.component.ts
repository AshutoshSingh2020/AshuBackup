import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-otplogin',
  templateUrl: './otplogin.component.html',
  styleUrls: ['./otplogin.component.css']
})
export class OtploginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  otpphonenumber = "";

}
