import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GamesnavtabComponent } from './gamesnavtab.component';

describe('GamesnavtabComponent', () => {
  let component: GamesnavtabComponent;
  let fixture: ComponentFixture<GamesnavtabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GamesnavtabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GamesnavtabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
