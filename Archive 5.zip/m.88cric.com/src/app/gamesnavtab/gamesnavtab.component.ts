import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

class Gamelaunchdata {
  game_id: string;
  game_code: string;
  platform = "GPL_MOBILE";
}
@Component({
  selector: 'app-gamesnavtab',
  templateUrl: './gamesnavtab.component.html',
  styleUrls: ['./gamesnavtab.component.css'],
  encapsulation: ViewEncapsulation.None,
  styles: [` 
		.bl_games_nav_tab_container ul  { 
			border: none; 
			flex-wrap: initial;
		}
		.bl_games_nav_tab_container ul li { 
			display: inline-flex;
			background: #000;
			padding: 3px 10px;
			margin: 5px;
			margin-left: 0;
			border-radius: 5px; 
			width: 100%;
		}
		.bl_games_nav_tab_container ul li:last-child {
			margin-right: 0;
		}
		.bl_games_nav_tab_container ul.nav-tabs li a {
			color: #fff;
			border: none;
			background: transparent;
			padding: 0;
			text-align: center;
			width: 100%;
		}
		.bl_games_nav_tab_container ul.nav-tabs li.active {
			background: #af0000;
		}

		.bl_games_nav_tab_container ul.nav-tabs li.active a.active {
			background: transparent;
			color: #fff;
		}

	`]
})

export class GamesnavtabComponent implements OnInit {
  gamelaunchdata = new Gamelaunchdata();
  GameCategory = "LiveGame";
  GetGameList(GameCategory) {
    this.UserService.GetGameList(GameCategory).subscribe(
      data => {
        if (GameCategory == "LiveGame") {
          this.tablegame = data;
        } else if (GameCategory == "Poker") {
          this.PokerGame = data;
        } else if (GameCategory == "Slots") {
          this.SlotsGame = data;
        } else if (GameCategory == "TableGame") {
          this.GameTable = data;
        } else if (GameCategory == "Lottery") {
          this.Lottery = data;
        } else if (GameCategory == "Esports") {
          this.Esports = data;
        }

        console.log(data);
      });
  }
  //GetGameList(GameCategory) {
  //  this.UserService.GetGameList(GameCategory).subscribe(
  //    data => {
  //      this.search = data;
  //     // console.log(data);
  //    });

  //}
  constructor(private UserService: UserService, private Router: Router) { }
  search: any;
  allgame = false;
  tabgame = true;
  searchText = "";
  ngOnInit(): void {
    
    this.GameCategory = "LiveGame";
    this.GetGameList(this.GameCategory);

    this.GameCategory = "Poker";
    this.GetGameList(this.GameCategory);

    this.GameCategory = "Slots";
    this.GetGameList(this.GameCategory);

    this.GameCategory = "TableGame";
    this.GetGameList(this.GameCategory);

    this.GameCategory = "Lottery";
    this.GetGameList(this.GameCategory);

    this.GameCategory = "Esports";
    this.GetGameList(this.GameCategory);
  }
  getbgimage(img) {
    if (img == "null") {
      return 'assets/images/not-found.jpg';

    } else {
      return img;
    }

  }

  tablegame: any;
  PokerGame: any;
  SlotsGame: any;
  GameTable: any;
  Lottery: any;
  Esports: any;

  LaunchGame(casinoTab) {
    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {
      this.gamelaunchdata.game_code = casinoTab["game_code"];
      this.gamelaunchdata.game_id = casinoTab["game_id"];

console.log(this.gamelaunchdata.game_id);
      this.UserService.GetLaunchGameUrl1(this.gamelaunchdata.game_id).subscribe( 
        data => {
          if (data["ErrorCode"] == "1") {
            /*   alert(data["ErrorMessage"]);*/
            window.location.href = data["Result"];

          } else {
            alert(data["ErrorMessage"]);
          }

        });
    } else {

      this.Router.navigate(['login']);

    }
  }
  searchbox() {
    window.scrollTo(2000, 2000);
    
    if (this.searchText.length > 0) {
      this.allgame = true;
      this.tabgame = false;

    } else {
      this.tabgame = true;
      this.allgame = false;

    }

  }
}
