import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { UserService } from '../user.service';

declare var swal: any;

//declare var $: any;
class DepositModel {
  Amount: string;

}
class DepositMethod {
  Id: number;
  PaymentUrl: string;
  Description: string;
  StatusId: number;
  Tag: string;
  ImageUrl: string;
  Title: string;
  SubTitle: string;

}

@Component({
  selector: 'app-app-payment',
  templateUrl: './app-payment.component.html',
  styleUrls: ['./app-payment.component.css']
})
export class AppPaymentComponent implements OnInit {
  TransactionId: string;
  UserName: string;
  UserAmount: any;
  loader = false;
  cards = '';
  Paymentloader = false;


  constructor(private UserService: UserService, private Router: Router, private route: ActivatedRoute) {
  }


  ngOnInit(): void {
    //if (
    //  localStorage.getItem('UserId') != null &&
    //  localStorage.getItem('LoginToken')
    //) {
    //} else {
    //  this.Router.navigate(['login']);
    //}
    this.TransactionId = this.route.snapshot.queryParams["transactionid"];
    this.GetAppPaymentDetails();
    this.GetPaymentGatewayMethodAPP();


  }



  GetAppPaymentDetails() {


    this.UserService.AppPayment(this.TransactionId).subscribe(
      data => {

        if (data["ErrorCode"] == "1") {
          this.UserName = data["UserName"];
          this.UserAmount = data["Balance"];

        } else {
          alert(data["ErrorMessage"]);
        }

      });

  }
  GetPaymentGatewayMethodAPP() {
    this.UserService.GetPaymentGatewayMethodApp().subscribe((data) => {
      this.DepositMethod = data as DepositMethod;
     

    });

  }
  AmountDeposit(deposit) {
    this.Paymentloader = true;

    this.UserService.AppPaymentResponse(this.TransactionId).subscribe(
      data => {
        if (data["ErrorCode"] == "1") {
          var paymentArray = data['Result'].split("=");
          var paymentlink = deposit.PaymentUrl + paymentArray[paymentArray.length - 1];

          window.location.href = paymentlink;


        } else {
          swal('Oops!', data['ErrorMessage'], 'error');
          this.Paymentloader = false;
        }
     


      });
  }




  classToggled = false;
  Title = '';
  PgCodeSelected = '';
  HindiLink = "https://www.youtube.com/embed/LwgW3vKikw8";
  DepositMethod;
  //promotions = [

  //  {
  //    title: 'UPI Fast',
  //    heading: 'Per transaction upto 50,000',
  //    image: './assets/images/deposit/UPI.svg',
  //    ribbon: 'Gold Pay',
  //    ribbon1: 'How to Deposit?',
  //    PGCode: 'UPI1',
  //    tab: 'other',
  //    UPIType: 1,
  //    Loading: false
  //  },
  //  {
  //    title: 'UPI',
  //    heading: 'Per transaction upto 50,000',
  //    image: './assets/images/deposit/UPI.svg',
  //    ribbon: 'Gold Pay',
  //    ribbon1: 'How to Deposit?',
  //    PGCode: 'UPI1',
  //    tab: 'other',
  //    UPIType: 3
  //  },

  //];

  


}

