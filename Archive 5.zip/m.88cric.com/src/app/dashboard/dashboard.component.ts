import { Component, OnInit } from '@angular/core';
import { OneSignal } from 'onesignal-ngx';
// import { Hero } from '../hero';
// import { HeroService } from '../hero.service';
//declare var $: any
import * as $ from 'jquery';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: [ './dashboard.component.css' ]
})
export class DashboardComponent implements OnInit {
  // heroes: Hero[] = [];

  constructor(private oneSignal: OneSignal) {
    this.oneSignal.init({
      appId: "eda4dd0b-593c-4850-ae8e-97d0a4dd3754",
    });
  }

  ngOnInit() {
     //this.getHeroes();
    setTimeout(function () {
      $('.main.hide').show();
    }, 1000);

   
  }







  // getHeroes(): void {
  //   this.heroService.getHeroes()
  //     .subscribe(heroes => this.heroes = heroes.slice(1, 5));
  // }
}
