import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
class Gamelaunchdata {
  game_id: string;
  game_code: string;
  platform = "GPL_MOBILE";
}
@Component({
  selector: 'app-allgames',
  templateUrl: './allgames.component.html',
  styleUrls: ['./allgames.component.css']
})
export class AllgamesComponent implements OnInit {

  allgame = false;
  tabgame = true;


  gamelaunchdata = new Gamelaunchdata();
  GameCategory = "LiveGame";
  GetGameList(GameCategory) {
    this.UserService.GetGameList(GameCategory).subscribe(
      data => {
        if (GameCategory == "LiveGame") {
          this.tablegame = data;
        } else if (GameCategory == "Poker") {
          this.PokerGame = data;
        } else if (GameCategory == "Slots") {
          this.SlotsGame = data;
        } else if (GameCategory == "TableGame") {
          this.GameTable = data;
        } else if (GameCategory == "Lottery") {
          this.Lottery = data;
        } else if (GameCategory == "Esports") {
          this.Esports = data;
        }

        /*console.log(this.tablegame);*/
      });
  }
  constructor(private UserService: UserService, private Router: Router) {

  }


  getbgimage(img) {
    if (img == "null") {
      return 'assets/images/not-found.jpg';

    } else {
      return img;
    }

  }

  tablegame: any;
  PokerGame: any;
  SlotsGame: any;
  GameTable: any;
  Lottery: any;
  Esports: any;

  ngOnInit(): void {
    this.GameCategory = "LiveGame";
    this.GetGameList(this.GameCategory);

    this.GameCategory = "Poker";
    this.GetGameList(this.GameCategory);

    this.GameCategory = "Slots";
    this.GetGameList(this.GameCategory);

    this.GameCategory = "TableGame";
    this.GetGameList(this.GameCategory);

    this.GameCategory = "Lottery";
    this.GetGameList(this.GameCategory);

    this.GameCategory = "Esports";
    this.GetGameList(this.GameCategory);
  }

  LaunchGame(casinoTab) {
    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {
      this.gamelaunchdata.game_code = casinoTab["game_code"];
      this.gamelaunchdata.game_id = casinoTab["game_id"];


      this.UserService.GetLaunchGameUrl(this.gamelaunchdata).subscribe(
        data => {
          if (data["ErrorCode"] == "1") {
            /* alert(data["ErrorMessage"]);*/
            window.location.href = data["Result"];

          } else {
            alert(data["ErrorMessage"]);
          }

        });
    } else {

      this.Router.navigate(['login']);

    }
  }

  searchbox() {
    this.tabgame = false;
    this.allgame = true;
  }
}
