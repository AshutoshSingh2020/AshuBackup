import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { UserService } from 'src/app/user.service';
import { Router } from '@angular/router';
import { from } from 'rxjs';
declare var swal: any;


class WithdrawalModel {
  Amount: string;
  AccountNumber: string;
  BankName: string;
  BranchName: string;
  AccountHolderName: string;
  IfscCode: string;

}
class withdrawaluserdetail {
  AccountHolderName: string;
  AccountNumber: string;
  Amount: number;
  BankName: string;
  BranchName: string;
  CreatedDate: string;
  Description: string;
  Id: string;
  IfscCode: string;
  StatusCode: string;
  StatusName: string;

}

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css'],
  encapsulation: ViewEncapsulation.None,
  styles: [` 
  .custom-image-main img { 
    border-radius: 50% !important; 
    border: 2px solid #feb30b; 
  }
  .ng-image-slider .ng-image-slider-container .main {
    padding-left: 10px;
    padding-right: 10px;
  }
  .ng-image-slider-container .main .prev, 
  .ng-image-slider .ng-image-slider-container .main .next {
    color: #900000 !important;
    font-size: 40px !important;
  }
  .ng-image-slider .ng-image-slider-container .main .next  {
    right: 0 !important;
  }
  .ng-image-slider .ng-image-slider-container .main .prev  {
    left: 0 !important;
  }
  `]
})
export class WithdrawComponent implements OnInit {

  imageObject = [
    {
      image: 'assets/images/with_car_1.png',
      thumbImage: 'assets/images/with_car_1.png'
    },
    {
      image: 'assets/images/with_car_1.png',
      thumbImage: 'assets/images/with_car_2.png'
    },
    {
      image: 'assets/images/with_car_1.png',
      thumbImage: 'assets/images/with_car_1.png'
    },
    {
      image: 'assets/images/with_car_1.png',
      thumbImage: 'assets/images/with_car_3.png'
    },
    {
      image: 'assets/images/with_car_1.png',
      thumbImage: 'assets/images/with_car_4.png'
    }
  ]
  someDate: Date;
  constructor(public UserService: UserService, private Router: Router) { }
  loader = false;
  reverse = false;
  ngOnInit(): void {
    this.someDate = new Date(Date.now() + (30 * 60 + 12) * 1000);

    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {
      this.GetWithdrawalStatement();

    } else {
      this.Router.navigate(['login']);

    }
  }



  withdrawalmodel = new WithdrawalModel();
  Withdrawaluserdetail = new withdrawaluserdetail();
  BankDetails() {
    let message = "";

    if (!this.withdrawalmodel.AccountHolderName) {
      message += "Please Enter Account Holder Name \n";
    }
    if (!this.withdrawalmodel.AccountNumber) {
      message += "Please Enter Account Number \n";
    }
    if (!this.withdrawalmodel.BankName) {
      message += "Please Enter BankName \n";
    }
    if (!this.withdrawalmodel.BranchName) {
      message += "Please Enter Branch Name \n";
    }
    if (!this.withdrawalmodel.Amount) {
      message += "Please Enter Amount \n";
    }
    if (!this.withdrawalmodel.IfscCode) {
      message += "Please Enter IFSC Code \n";
     
    }
    this.withdrawalmodel.IfscCode.toUpperCase();
    if (message) {
      alert(message);
      return;
    }
    this.loader = true;

    this.UserService.WithdrawalBankDetails(this.withdrawalmodel).subscribe(
      data => {
        if (data["ErrorCode"] == "1") {
          swal("Success", data["ErrorMessage"], "success");
          //alert(data["ErrorMessage"])
          window.location.href = "/";
        } else {
          //alert(data["ErrorMessage"]);
          swal("info", data["ErrorMessage"], "error");
//          swal({
//            text: data["ErrorMessage"],
//           html: `<table id="table" border=1>
//        <thead>
//            <tr>
//                <th>Account</th>
//                <th>Number Of Withdrawal</th>
               
//            </tr>
//        </thead>
//        <tbody>
//            <tr>
//                <td>Basic</td>
//                <td>3 withdrawals per day</td>
//            </tr>
//           <tr>
//                <td><img src="./assets/images/gold.png"> Gold</td>
//                <td>5 withdrawals per day</td>
//            </tr>
//            <tr>
//                <td><img src="assets/images/Platinum.png"> Platinum</td>
//                <td> 8 withdrawals per day</td>
//            </tr>
//           <tr>
//                <td><img src="assets/images/dimond.png"> Dimond</td>
//                <td>10 withdrawals per day</td>
//            </tr>
//</tbody>
//</table>`,
//            confirmButtonText: 'Upgrade your account'
//          })
          this.loader = false;
        }

      });

  }
  //withdrawaluserdetail: any;

  //withdrawalstatus = new WithdrawalModel();
  //GameCategory = "LiveGame";
  GetWithdrawalStatement() {
    this.UserService.GetWithdrawalStatement().subscribe(
      data => {
        this.Withdrawaluserdetail = data as withdrawaluserdetail;
        //if (data["StatusCode"]=="p") {
        //  this.reverse = true;
        //}
        // console.log(data);
        //alert(this.sd);
      });
  }
  Withdrawaluserdetail1 = new withdrawaluserdetail();


  ReverseWithdrawal(userdetail) {

    this.Withdrawaluserdetail1 = new withdrawaluserdetail();

    this.Withdrawaluserdetail1 = userdetail as withdrawaluserdetail;


    swal({
      title: "Reverse Withdrawal ?",
      text: "Your Withdrawal will be Reverse and reflect in your balance ",
      type: "info",
      showCancelButton: true,
      confirmButtonText: "Yes!",
      cancelButtonText: "No",
      closeOnConfirm: false,
      closeOnCancel: false
    }).then(() => {
      this.UserService.CancellWithdrawRequest(this.Withdrawaluserdetail1).subscribe(
        data => {
          if (data["ErrorCode"] == "1") {
            swal({
              title: 'Success!',
              text: data["ErrorMessage"],
              timer: 1000,
              type: "success",
            }).then(function () {
              swal.close();

            })

            window.location.href = "/";
            /*  this.Router.navigate(['']);*/

            //  alert(data["ErrorMessage"])
            this.GetWithdrawalStatement();
            /*   this.Router.navigate(['']);*/
          } else {
            alert(data["ErrorMessage"]);
            /* this.loader = false;*/
          }

        }, error => {

        });
    }

    );

  }




  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
     
  }

  //CalculateDifference(createdDate) {
  //  const current = new Date()
  //   var createdDateTime = new Date(createdDate)
  // let time = (current.getTime() - createdDateTime.getTime()) / 60000;

  //  return (10 - time) *60;
  //}
}


