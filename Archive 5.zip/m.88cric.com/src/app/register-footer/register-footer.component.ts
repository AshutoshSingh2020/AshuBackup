import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-footer',
  templateUrl: './register-footer.component.html',
  styleUrls: ['./register-footer.component.css']
})
export class RegisterFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
