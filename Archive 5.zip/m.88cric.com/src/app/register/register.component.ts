import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
declare var swal: any;
class UserModel {
  UserName: string;
  Mobile: string;
  OTP: string;
  FName: string;
  LName: string;
  DOB: string;
  Password: string;
  ConfirmPassword: string;
}

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private UserService: UserService, private Router: Router) { }

  ngOnInit(): void {
    this.showsendotp = true;
  }

  usermodel = new UserModel();

  showuserdetail: boolean;
  showotp: boolean;
  showsendotp: boolean;
  loader = false;
  otpmobile = false;

  SendOTP() {
    if (!this.usermodel.Mobile) {
      //alert("");
      swal("Oops!", "Please provide mobile number", "error");
      return;
    }
    this.loader = true;
    this.UserService.SendOTPNumber(this.usermodel.Mobile).subscribe(
      data => {
        if (data["ErrorCode"] == "1") {
          //alert(data["ErrorMessage"]);
          this.showsendotp = false;
          this.showotp = true;
        } else {
          this.loader = false;
          //alert();
          swal("Oops!", data["ErrorMessage"], "");
        }
        this.loader = false;
      });
  }
 
  VarifyOTP() {
    if (!this.usermodel.OTP) {
      //alert("Please provide OTP");
      return;
    }
    if (!this.usermodel.Mobile) {
      alert("Please provide  mobile number");
      return;
    }
    this.loader = true;
    this.UserService.VerifyWithOTP(this.usermodel.Mobile, this.usermodel.OTP).subscribe(
      data => {
        if (data["ErrorCode"] == "1") {
              alert(data["ErrorMessage"]);
          this.showotp = false;
          this.showuserdetail = true;
        } else {
          this.loader = false;
          alert(data["ErrorMessage"]);
        }
       
      });

  }

  CreateUser() {

    let message = "";

    if (!this.usermodel.UserName) {
      message += "Please provide user name";
    }
    if (!this.usermodel.FName) {
      message += "Please provide first name";
    }
    if (!this.usermodel.LName) {
      message += "Please provide last name";
    }
    if (!this.usermodel.Password) {
      message += "Please provide password";
    } else if (this.usermodel.Password.length < 6) {
      message += "Password must be six characters long";
    }
    if (!this.usermodel.ConfirmPassword) {
      message += "Please provide confirm password";
    } else if (this.usermodel.Password != this.usermodel.Password) {
      message += "password and confirm password does not match";
    }

    if (message) {
      alert(message);
      return;
    }
    this.loader = true;

    this.UserService.CreateUser(this.usermodel).subscribe(
      data => {
        if (data["ErrorCode"] == "1") {
          //alert(data["ErrorMessage"]);

          localStorage.setItem('UserId', data["UserId"]);
          localStorage.setItem('UserName', data["UserName"]);
          localStorage.setItem('LoginToken', data["LoginToken"]);
          this.Router.navigate(['/thankyou']);
          //this.showotp = false;
          //this.showuserdetail = true;
        } else {
          alert(data["ErrorMessage"]);
        }

      });
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }
}
