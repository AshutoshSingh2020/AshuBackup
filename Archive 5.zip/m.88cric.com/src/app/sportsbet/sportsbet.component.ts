import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sportsbet',
  templateUrl: './sportsbet.component.html',
  styleUrls: ['./sportsbet.component.css']
})
export class SportsbetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
