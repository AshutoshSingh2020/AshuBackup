import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SportsbetComponent } from './sportsbet.component';

describe('SportsbetComponent', () => {
  let component: SportsbetComponent;
  let fixture: ComponentFixture<SportsbetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SportsbetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SportsbetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
