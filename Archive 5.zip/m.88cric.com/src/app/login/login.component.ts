import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
//import Swal from 'sweetalert2/dist/sweetalert2.js';
declare var swal: any;

/*import * as $ from 'jquery';*/
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  password;
  show = false;
  Mobile: string;
  UserPassword: string;
  loader = false;

  constructor(private UserService: UserService, private Router: Router) { }

  ngOnInit() {
    this.password = 'password';
  }
  //simpleAlert() {
  //  swal.fire('Hello world!');
  //}

  //alertWithSuccess() {

  //}


  showPassword() {
    if (this.password === 'password') {
      this.password = 'text';
      this.show = true;
    } else {
      this.password = 'password';
      this.show = false;
    }
  }

  LoginUserclick() {
    if (!this.Mobile) {
     // alert("Please provide mobile number");
      swal("Oops!", "Please provide mobile number", "error");
      return;
    }
    if (!this.UserPassword) {
     // alert("Please provide password");
      swal("Oops!", "Please provide password", "error");
      return;
    }
    this.loader = true;

    this.UserService.LoginUser(this.Mobile, this.UserPassword).subscribe(

      data => {
        if (data["ErrorCode"] == "1") {


          swal({
            title: 'Success!',
            text: data["ErrorMessage"],
            timer: 1000,
            type: "success",
          }).then(function () {
            swal.close();
            
          })


          //alert(data["ErrorMessage"]);
         // swal('Success!', data["ErrorMessage"], 'success', 1000)
          localStorage.setItem('UserId', data["UserId"]);
          localStorage.setItem('UserName', data["UserName"]);
          localStorage.setItem('LoginToken', data["LoginToken"]);

          this.Router.navigate(['']);

        } else {
          this.loader = false;
          //alert(data["ErrorMessage"]);
          swal("Oops!", data["ErrorMessage"], "error");
        


        }

      });

  }


}
