import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { DomSanitizer, SafeResourceUrl, } from '@angular/platform-browser';
import * as $ from 'jquery';


@Component({
  selector: 'app-betfair',
  templateUrl: './betfair.component.html',
  styleUrls: ['./betfair.component.css']
})
export class BetfairComponent implements OnInit {
  constructor(private UserService: UserService, private Router: Router, public sanitizer: DomSanitizer) { }
  url: SafeResourceUrl;
 
  HomeBtn;
  ngOnInit(): void {
    this.HomeBtn = true;
   
    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {
   
      this.UserService.GetSportGameUrl().subscribe(
        data => {
          if (data["ErrorCode"] == "1") {
           
            this.url = this.sanitizer.bypassSecurityTrustResourceUrl(data["Result"]);
           // setTimeout(' this.HomeBtn = false', 3000)
            //setTimeout(function () { this.HomeBtn = false; }, 3000);
            this.HomeBtn = false
           
          } else {
            alert(data["ErrorMessage"]);
          }
        });

     /* window.location.href = "/betfair";*/
    } else {

      this.Router.navigate(['login']);

    }
   
    //setTimeout(function () { this.HomeBtn = false; }, 3000);
  
  }


}
