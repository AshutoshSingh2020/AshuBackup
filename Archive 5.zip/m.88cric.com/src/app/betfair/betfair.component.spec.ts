import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BetfairComponent } from './betfair.component';

describe('BetfairComponent', () => {
  let component: BetfairComponent;
  let fixture: ComponentFixture<BetfairComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BetfairComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BetfairComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
