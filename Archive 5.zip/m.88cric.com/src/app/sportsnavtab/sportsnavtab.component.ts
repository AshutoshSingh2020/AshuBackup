import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-sportsnavtab',
  templateUrl: './sportsnavtab.component.html',
  styleUrls: ['./sportsnavtab.component.css'],
  encapsulation: ViewEncapsulation.None,
  styles: [` 
		.bl_games_nav_tab_container ul  { 
			border: none; 
			flex-wrap: initial;
		}
		.bl_games_nav_tab_container ul li { 
			display: inline-flex;
			background: #000;
			padding: 3px 10px;
			margin: 5px;
			margin-left: 0;
			border-radius: 5px; 
			width: 100%;
		}
		.bl_games_nav_tab_container ul li:last-child {
			margin-right: 0;
		}
		.bl_games_nav_tab_container ul.nav-tabs li a {
			color: #fff;
			border: none;
			background: transparent;
			padding: 0;
			text-align: center;
			width: 100%;
		}
		.bl_games_nav_tab_container ul.nav-tabs li.active {
			background: #af0000;
		}

		.bl_games_nav_tab_container ul.nav-tabs li.active a.active {
			background: transparent;
			color: #fff;
		}
	`]
})
export class SportsnavtabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
