import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SportsnavtabComponent } from './sportsnavtab.component';

describe('SportsnavtabComponent', () => {
  let component: SportsnavtabComponent;
  let fixture: ComponentFixture<SportsnavtabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SportsnavtabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SportsnavtabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
