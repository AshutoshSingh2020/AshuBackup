import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-install-app',
  templateUrl: './install-app.component.html',
  styleUrls: ['./install-app.component.css']
})
export class InstallAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {


  }
  //installPwa(): void {
  //  //this.Pwa.promptEvent.prompt();
  //}
}
