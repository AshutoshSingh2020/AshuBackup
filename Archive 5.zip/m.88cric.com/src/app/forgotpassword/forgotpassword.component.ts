import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';


class ForgotModel {
  Mobile: string;
  DOB: Date;
  OTP: string;
  Password: string;
}

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {

  constructor(private UserService: UserService) { }

  ngOnInit(): void {
    this.PanelName = "SendOTP";

  }

  forgotModel = new ForgotModel();


  otpphonenumber = "";

  PanelName: string;


  SendOTP() {

     
    var message = "";
    if (!this.forgotModel.Mobile) {
      message = "Please enter mobile number";
    }

    //if (!this.forgotModel.DOB) {
    //  message += "\nPlease enter date of birth";
    //}
    if (message) {
      alert(message);
      return;

    }

    this.UserService.GenerateOTPForgotPassword(this.forgotModel).subscribe(
      data => {
        if (data["ErrorCode"] == "1") {
          alert(data["ErrorMessage"]);
          this.PanelName = "EnterOtpPanel";
          
        } else {
          alert(data["ErrorMessage"]);
        }

      });

  


  }

  ChangeForgotPassword() {

    var message = "";
    if (!this.forgotModel.OTP) {
      message = "Please enter OTP";
    }

    if (!this.forgotModel.Password) {
      message += "\nPlease enter new password";
    }
    if (message) {
      alert(message);
      return;

    }

    this.UserService.ResetPassword(this.forgotModel).subscribe(
      data => {
        if (data["ErrorCode"] == "1") {
          alert(data["ErrorMessage"]);
          window.location.href = "/";

        } else {
          alert(data["ErrorMessage"]);
        }

      });
     
  }
}
