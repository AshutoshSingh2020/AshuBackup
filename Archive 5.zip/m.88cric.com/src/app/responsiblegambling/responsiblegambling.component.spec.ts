import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResponsiblegamblingComponent } from './responsiblegambling.component';

describe('ResponsiblegamblingComponent', () => {
  let component: ResponsiblegamblingComponent;
  let fixture: ComponentFixture<ResponsiblegamblingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResponsiblegamblingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResponsiblegamblingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
