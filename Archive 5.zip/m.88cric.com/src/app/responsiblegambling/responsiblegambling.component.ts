import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-responsiblegambling',
  templateUrl: './responsiblegambling.component.html',
  styleUrls: ['./responsiblegambling.component.css']
})
export class ResponsiblegamblingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
