import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

class UserModel {
  UserName: string;
  Mobile: string;
  FName: string;
  LName: string;
  DOB: string;
  Email: string;
}

@Component({
  selector: 'app-account-info',
  templateUrl: './account-info.component.html',
  styleUrls: ['./account-info.component.css']
})
export class AccountInfoComponent implements OnInit {

  constructor(private UserService: UserService) { }
 
  usermodel = new UserModel();
  GetUserDetail() {
    this.UserService.GetUserDetail().subscribe(
      data => {
        this.usermodel = data as UserModel;
        console.log(data);
      });
  }
  
  ngOnInit(): void {
    //this.usermodel;
    this.GetUserDetail();
  }

}
