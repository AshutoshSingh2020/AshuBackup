import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
declare var swal: any;
@Component({
  selector: 'app-support',
  templateUrl: './support.component.html',
  styleUrls: ['./support.component.css']
})
export class SupportComponent implements OnInit {

  constructor(private UserService: UserService, private Router: Router) { }

  ngOnInit(): void {
  }
  RequestCallBack() {
    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {
      swal({
        title: "Request a call back ?",
        text: "",
        type: "info",
        showCancelButton: true,
        confirmButtonText: "Yes!",
        cancelButtonText: "No",
        closeOnConfirm: false,
        closeOnCancel: false
      }).then(() => {
        this.UserService.RequestCallBack().subscribe(
          data => {
            if (data["ErrorCode"] == "1") {

              swal("success", data["ErrorMessage"], "success");

            } else {

              swal("Oops!", data["ErrorMessage"], "error");

            }

          }, error => {

          });
      }

      );

    } else {
      this.Router.navigate(['login']);
    }
  }
}
