import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DepositBackup2Component } from './deposit-backup2.component';

describe('DepositBackup2Component', () => {
  let component: DepositBackup2Component;
  let fixture: ComponentFixture<DepositBackup2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DepositBackup2Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DepositBackup2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
