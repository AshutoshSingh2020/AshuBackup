import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
declare var swal: any;
class DepositModel {
  Amount: string;
}
@Component({
  selector: 'app-deposit-backup2',
  templateUrl: './deposit-backup2.component.html',
  styleUrls: ['./deposit-backup2.component.css']
})
export class DepositBackup2Component implements OnInit {

  loader = false;
  IsDepositer = false;
  banner = true;
  CryptoAmount = '';
  constructor(private UserService: UserService, private Router: Router) { }
  DepositAmount: string;
  paymentoption = 'Bmethod';
  ngOnInit(): void {
    if (
      localStorage.getItem('UserId') != null &&
      localStorage.getItem('LoginToken')
    ) {
    } else {
      this.Router.navigate(['login']);
    }
  }
  classToggled = false;
  Title = '';
  Processing = '10 min - 5 hours';
  PgCodeSelected = '';

  CopiedText = '';
  public toggleField() {
    this.classToggled = !this.classToggled;
  }

  objectKeys = Object.keys;
  promotions = [

    {
      title: 'UPI & Wallet',
      heading: 'instantly',
      image: './assets/images/deposit/UPI.svg',
      ribbon: 'UPI & wallet',
      PGCode: 'UPI3',
    },
    {
      title: 'UPI & Net Banking',
      heading: 'instantly',
      image: './assets/images/deposit/netbanking.svg',
      ribbon: 'UPI & NetBanking',
      PGCode: 'UPI',
    },
    //{
    //  title: 'UPI',
    //  heading: 'up to 10 min',
    //  image: './assets/images/deposit/UPI.svg',
    //  ribbon: 'UPI',
    //  PGCode: 'UPI2',
    //},
    {
      title: 'UPI Fast',
      heading: 'up to 10 min',
      image: './assets/images/deposit/UPI.svg',
      ribbon: 'UPI Fast',
      PGCode: 'UPI1',
    },


    {
      title: 'Other Method',
      heading: 'up to 10 min',
      image: './assets/images/deposit/netbanking.svg',
      ribbon: '2% Extra',
      icons: './assets/images/fire.png',
      PGCode: 'NB',
    },

    // {
    //   "title": "UPI",
    //   "heading": "up to 10 min",
    //   "image": "./assets/images/deposit/UPI.svg",
    //   "ribbon": "UPI",
    //   "PGCode": "UPI"
    // },

    // {
    //   "title": "Net Banking",
    //   "heading": "up to 10 min",
    //   "image": "./assets/images/deposit/netbanking.svg",
    //   "ribbon": "2% Extra",
    //   "icons": "./assets/images/fire.png",
    //   "PGCode": "NB"

    // },
    // {
    //   "title": "IMPS",
    //   "heading": "up to 10 min",
    //   "image": "./assets/images/deposit/netbanking.svg",
    //   "ribbon": "2% Extra",
    //   "icons": "./assets/images/fire.png",
    //   "PGCode": "NB"

    // },
    // {
    //   "title": "Crypto payment",
    //   "heading": "instantly",
    //   "image": "./assets/images/deposit/cryptocurrency.png",
    //   "ribbon": "10% Extra",
    //   "icons": "./assets/images/energy.png",
    //   "PGCode": "Crypto"
    // }
  ];

  //choosepaymentmethod = true;

  depositmodel = new DepositModel();
  AmountDeposit(UPIType) {
    if (!this.DepositAmount) {
      swal('Oops!', 'Please enter valid amount', 'error');
      return;
    }

    //if (!UPIType && Number(this.DepositAmount) > 5000) {
    //  swal(
    //    'Oops!',
    //    'Amount should not be more than 5000 per transaction',
    //    'error'
    //  );
    //  return;
    //}

    this.depositmodel.Amount = this.DepositAmount;

    this.loader = true;
    this.UserService.DepositUserAmount(this.depositmodel).subscribe((data) => {
      if (data['ErrorCode'] == '1') {
        if (UPIType == 0) {
          window.location.href = data['Result'].replace('payv11', 'payv26');
        }
        else
          if (UPIType == 1) {
            window.location.href = data['Result'].replace('payv11', 'payv10');
          }
          //else if (UPIType == 2) {
          //  window.location.href = data['Result'].replace('payv11', 'payv12');
          //}
          else if (UPIType == 3) {
            window.location.href = data['Result'].replace('payv11', 'payv18');
          } else {
            window.location.href = data['Result'];
          }

        //window.location.href = data["Result"];
      } else {
        swal('Oops!', data['ErrorMessage'], 'error');
        this.loader = false;
      }
    });
  }

  numberOnly(event): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
    if (Number(this.DepositAmount) >= 25000) {
      this.paymentoption == 'Bmethod';
    } else {
      this.paymentoption == 'Amethod';
    }
  }
  errormsg;
  validateamount() {
    if (Number(this.DepositAmount) <= 5000) {
      this.errormsg = '';
    } else {
      this.errormsg = 'Amount should not be more than 5000';
    }
  }

  paymentmethod(data) {
    if (data.PGCode == 'NB') {
      window.open(
        'https://api.whatsapp.com/send?phone=447888894588&text=I%20want%20to%20make%20a%20deposit%20on%2088cric.',
        '_blank'
      );

      return;
    }

    this.banner = false;
    this.PgCodeSelected = data.PGCode;
    this.Title = data.title;
  }
  loadercrypto;
  CryptoDeposit(CryptoAmount) {
    if (!this.CryptoAmount) {
      swal('Oops!', 'Please enter valid amount', 'error');
      return;
    }
    this.banner = true;
    this.loadercrypto = true;
    this.depositmodel.Amount = CryptoAmount;
    this.UserService.DepositUserAmount(this.depositmodel).subscribe((data) => {
      if (data['ErrorCode'] == '1') {
        window.location.href =
          'https://pay.playludo.app/Home/payv5?TransactionId=' +
          data['Result'].split('=')[1];
        // this.loadercrypto = false;
      } else {
        swal('Oops!', data['ErrorMessage'], 'error');
        this.loadercrypto = false;
      }
    });
  }

  copy(val: string) {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = val;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
    this.CopiedText = val;
  }
}
