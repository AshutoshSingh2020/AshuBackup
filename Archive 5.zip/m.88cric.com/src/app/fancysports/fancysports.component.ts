import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fancysports',
  templateUrl: './fancysports.component.html',
  styleUrls: ['./fancysports.component.css']
})
export class FancysportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
