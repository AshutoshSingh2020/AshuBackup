import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FancysportsComponent } from './fancysports.component';

describe('FancysportsComponent', () => {
  let component: FancysportsComponent;
  let fixture: ComponentFixture<FancysportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FancysportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FancysportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
