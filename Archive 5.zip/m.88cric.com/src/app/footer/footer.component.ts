import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import * as $ from 'jquery';
declare var swal: any;
class Gamelaunchdata {
  game_id: string;
  game_code: string;
  platform = "GPL_MOBILE";

}
@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  isuserlog: boolean;
  gamelaunchdata = new Gamelaunchdata();
  constructor(private UserService: UserService, private Router: Router) { }

  ngOnInit(): void {


    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {
      this.isuserlog = true;

    }




    var theToggle = document.getElementById('toggle');
    function hasClass(elem, className) {
      return new RegExp(' ' + className + ' ').test(' ' + elem.className + ' ');
    }
    function addClass(elem, className) {
      if (!hasClass(elem, className)) {
        elem.className += ' ' + className;
      }
    }
    function removeClass(elem, className) {
      var newClass = ' ' + elem.className.replace(/[\t\r\n]/g, ' ') + ' ';
      if (hasClass(elem, className)) {
        while (newClass.indexOf(' ' + className + ' ') >= 0) {
          newClass = newClass.replace(' ' + className + ' ', ' ');
        }
        elem.className = newClass.replace(/^\s+|\s+$/g, '');
      }
    }
    function toggleClass(elem, className) {
      var newClass = ' ' + elem.className.replace(/[\t\r\n]/g, " ") + ' ';
      if (hasClass(elem, className)) {
        while (newClass.indexOf(" " + className + " ") >= 0) {
          newClass = newClass.replace(" " + className + " ", " ");
        }
        elem.className = newClass.replace(/^\s+|\s+$/g, '');
      } else {
        elem.className += ' ' + className;
      }
    }
    theToggle.onclick = function () {
      toggleClass(this, 'on');
      return false;
    }
  }
  Deposit() {
    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {
      this.Router.navigate(['deposit']);
    } else {

      this.Router.navigate(['login']);

    }
  }
  RequestCallBack() {
    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {
      swal({
        title: "Request a call back ?",
        text: "",
        type: "info",
        showCancelButton: true,
        confirmButtonText: "Yes!",
        cancelButtonText: "No",
        closeOnConfirm: false,
        closeOnCancel: false
      }).then(() => {
        this.UserService.RequestCallBack().subscribe(
          data => {
            if (data["ErrorCode"] == "1") {

              swal("success", data["ErrorMessage"], "success");

            } else {

              swal("Oops!", data["ErrorMessage"], "error");

            }

          }, error => {

          });
      }

      );

    } else {
      this.Router.navigate(['login']);
    }
  }
  LaunchGame(gamecode) {

    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {

      this.gamelaunchdata.game_code = gamecode;
      //this.gamelaunchdata.game_id = "20000"; //Just copy paste this for all brand
      // window.location.href = "/GameLaunch";
      this.UserService.GetGameUrlLobby(this.gamelaunchdata).subscribe(
        data => {
          if (data["ErrorCode"] == "1") {
            /*   alert(data["ErrorMessage"]);*/
            window.location.href = data["Result"];

          } else {
            alert(data["ErrorMessage"]);
          }
        });

    } else {

      this.Router.navigate(['login']);

    }
  }
}
