import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { GamedetailService } from '../gamedata/gamedetail.service';
class Gamelaunchdata {
  game_id: string;
  game_code: string;
  platform = "GPL_MOBILE";

}
@Component({
  selector: 'app-brandetabview',
  templateUrl: './brandetabview.component.html',
  styleUrls: ['./brandetabview.component.css']
})
export class BrandetabviewComponent implements OnInit {
  // loadingtwo = false;
  gamelaunchdata = new Gamelaunchdata();
  GameCategory = "LiveGame";


  constructor(private UserService: UserService, private Router: Router,
    private toastr: ToastrService, private GamedetailService: GamedetailService) {

  }
  LaunchGame(gamecode) {

    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {

      this.gamelaunchdata.game_code = gamecode;

      this.UserService.GetLaunchGameUrl(this.gamelaunchdata).subscribe(
        data => {
          
          if (data["ErrorCode"] == "1") {
            /*   alert(data["ErrorMessage"]);*/
            window.location.href = data["Result"];

          } else {
            alert(data["ErrorMessage"]);
          }
        });

    } else {

      this.Router.navigate(['login']);

    }

  }

  ComingSoon() {
    this.toastr.success('Coming soon..', '');
  }

  Inmaintainance() {
    this.toastr.success('Game in maintenance. try after some time', '');
  }

  LaunchSportURL() {

    if (localStorage.getItem("UserId") != null && localStorage.getItem("LoginToken")) {

      window.location.href = "/betfair", "_blank";

    } else {

      this.Router.navigate(['login']);

    }

  }

  getbgimage(img) {
    if (img == "null") {
      return 'assets/images/not-found.jpg';

    } else {
      return img;
    }

  }
  casino: any;

  ngOnInit(): void {

  }

}
