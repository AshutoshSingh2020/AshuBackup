import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BrandetabviewComponent } from './brandetabview.component';

describe('BrandetabviewComponent', () => {
  let component: BrandetabviewComponent;
  let fixture: ComponentFixture<BrandetabviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BrandetabviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BrandetabviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
