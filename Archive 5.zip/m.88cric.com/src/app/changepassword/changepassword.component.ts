import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
declare var swal: any;
//class ChangePasswordModel {
//  CurrentPassword: string;
//  NewPassword: string;
//  ConfirmPassword: string;
//}

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {

  constructor(private UserService: UserService) { }

  ngOnInit(): void {
  }
  //ChangePasswordModel = new ChangePasswordModel();
  CurrentPassword: string;
  NewPassword: string;
  ConfirmPassword: string;

  ChangePassword() {

    var message = "";
    if (!this.CurrentPassword) {
      message = "Please enter current password";
    }

    if (!this.NewPassword) {
      message += "\nPlease enter new password";
    }
    else if (this.NewPassword.length < 6) {
      message += "Password must be six characters long";
    }
    if (!this.ConfirmPassword) {
      message += "\nPlease enter confirm password";
    }
    else if (this.ConfirmPassword !== this.NewPassword) {
      message += "New password and confirm password does not match";
    }
    if (message) {
      swal("Oops!", message, "error");
      //alert(message);
      return;
    }

    this.UserService.ChangeUserPassword({ "Password": this.CurrentPassword, "NewPassword": this.NewPassword, "ConfrimPassword": this.ConfirmPassword }).subscribe(
      data => {
        if (data["ErrorCode"] == "1") {
         // alert(data["ErrorMessage"]);
          swal("Success", data["ErrorMessage"], "success");
          window.location.href = "/";

        } else {
          swal("Oops!", data["ErrorMessage"], "error");
          //alert(data["ErrorMessage"]);
        }

      });

  }

}
