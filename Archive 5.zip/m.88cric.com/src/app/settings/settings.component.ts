import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  settings = [
    {
      "img": "/assets/images/icons/user.png",
      "menu": "Account",
      "location": "/account-info"

    },
    {
      "img": "/assets/images/icons/cards.png",
      "menu": "Credit Details",
      "location": "/deposit"
    },
    {
      "img": "/assets/images/icons/notification.png",
      "menu": "Notifications",
      "location": "#"
    },
    {
      "img": "/assets/images/icons/security-lock.png",
      "menu": "Privacy & Security",
      "location": "#"
    },
    {
      "img": "/assets/images/icons//commenting.png",
      "menu": "Help & Support",
      "location": "#"
    },
    //{
    //  "img": "/assets/images/icons//info.png",
    //  "menu": "About",
    //  "location": "#"
    //},
    

  ]
}
