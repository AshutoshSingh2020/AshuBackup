import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { NgbCarouselConfig } from '@ng-bootstrap/ng-bootstrap';
import * as $ from 'jquery';

@Component({
  selector: 'app-banner',
  templateUrl: './banner.component.html',
  styleUrls: ['./banner.component.css'],
  providers: [NgbCarouselConfig],
  encapsulation: ViewEncapsulation.None,
  styles: [` 
  .carousel-control-next { display: none; }
  .carousel-control-prev { display: none; }
  .carousel-indicators li {width: 15px;}
  .carousel-indicators li.active { background-color: #fffc00; } 
  `]
})
export class BannerComponent implements OnInit {
  images = [0, 1, 2, 3].map((n) => `assets/images/banner/${n}.png`);

  constructor(config: NgbCarouselConfig) {
    // customize default values of carousels used by this component tree
    config.interval = 10000;
    config.keyboard = true;
    config.pauseOnHover = true;
    config.showNavigationArrows = true;
  }
  popup: boolean;
  ngOnInit(): void {

    var headerImage = $(".header-image");
    var imageContainer = $(".site-header");

    // Hacky object-fit polyfill
    function setImageSize(container, image) {
      if (image.css("object-fit") != "cover") {
        var headerWidth = container.outerWidth();
        var headerHeight = container.outerHeight();

        var imageWidth = image.outerWidth();
        var imageHeight = image.outerHeight();
        var imageRatio = imageHeight / imageWidth;

        if (headerWidth * imageRatio > headerHeight) {
          image.css("width", "100%");
          image.css("height", "auto");
        } else {
          image.css("height", "100%");
          image.css("width", "auto");
        }
      }
    }
   
    // Hacky image loading
    function imageIsLoaded(image) {
      if (image.prop("complete")) {
        setImageSize(imageContainer, headerImage);
        image.addClass("image-loaded");
      }

      image.on("load", function () {
        setImageSize(imageContainer, headerImage);
        image.addClass("image-loaded");
      });
    }

    imageIsLoaded(headerImage);

    $(window).on("resize", function () {
      setImageSize(imageContainer, headerImage);
    });

    $(document).ready(function () {
      setTimeout("$('img.header-image').css('opacity', '1 !important');", 800);
    });

  }
 
  pauseOrPlay() {
   // console.log("working");
    $('iframe').attr('src', $('iframe').attr('src'));
  }
}
