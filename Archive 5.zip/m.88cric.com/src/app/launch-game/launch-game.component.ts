import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-launch-game',
  templateUrl: './launch-game.component.html',
  styleUrls: ['./launch-game.component.css']
})
export class LaunchGameComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
