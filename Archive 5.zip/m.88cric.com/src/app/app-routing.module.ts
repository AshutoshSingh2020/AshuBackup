import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { OtploginComponent } from './otplogin/otplogin.component';
import { RegisterComponent } from './register/register.component';
import { DepositComponent } from './deposit/deposit.component';
import { PromotionComponent } from './promotion/promotion.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { SettingsComponent } from './settings/settings.component';
import { SportsComponent } from './sports/sports.component';
import { GamesComponent } from './games/games.component';
import { PrivacypolicyComponent } from './privacypolicy/privacypolicy.component';
import { TermsconditionsComponent } from './termsconditions/termsconditions.component';
import { ResponsiblegamblingComponent } from './responsiblegambling/responsiblegambling.component';
import { ShareandearnComponent } from './shareandearn/shareandearn.component';
import { DisconnectionpolicyComponent } from './disconnectionpolicy/disconnectionpolicy.component';
import { CardinfoComponent } from './cardinfo/cardinfo.component';
import { FAQsComponent } from './faqs/faqs.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { StatementsComponent } from './statements/statements.component';
import { AccountInfoComponent } from './account-info/account-info.component';
import { AllgamesComponent } from './allgames/allgames.component';
import { KYCComponent } from './kyc/kyc.component';
import { TestN0US4bIk64Component } from './test-n0-us4b-ik64/test-n0-us4b-ik64.component';
import { MAINTENANCEComponent } from './maintenance/maintenance.component';
import { BetfairComponent } from './betfair/betfair.component';
import { ReferenceComponent } from './reference/reference.component';
import { TestComponent } from './test/test.component';
import { OldDepositComponent } from './old-deposit/old-deposit.component';
import { HeaderComponent } from './header/header.component';
import { DemoComponent } from './demo/demo.component';
import { DepositBackup2Component } from './deposit-backup2/deposit-backup2.component';
import { CookiePolicyComponent } from './cookie-policy/cookie-policy.component';
import { DisclaimerComponent } from './disclaimer/disclaimer.component';
import { AppPaymentComponent } from './app-payment/app-payment.component';
import { ThankyouComponent } from './thankyou/thankyou.component';



const routes: Routes = [
 // { path: '', redirectTo: '/', pathMatch: 'full', component: DashboardComponent },
  { path: '', redirectTo: '', pathMatch: 'full', component: DashboardComponent },
  { path: 'login', component: LoginComponent },
  { path: 'otplogin', component: OtploginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'deposit', component: DepositComponent },
  { path: 'promotion', component: PromotionComponent },
  { path: 'withdraw', component: WithdrawComponent },
  { path: 'changepassword', component: ChangepasswordComponent },
  { path: 'forgotpassword', component: ForgotpasswordComponent },
  { path: 'settings', component: SettingsComponent },
  { path: 'sports', component: SportsComponent },
  { path: 'games', component: GamesComponent },
  { path: 'privacypolicy', component: PrivacypolicyComponent },
  { path: 'termsconditions', component: TermsconditionsComponent },
  { path: 'responsiblegambling', component: ResponsiblegamblingComponent },
  { path: 'shareandearn', component: ShareandearnComponent },
  { path: 'disconnectionpolicy', component: DisconnectionpolicyComponent },
  { path: 'cardinfo', component: CardinfoComponent },
  { path: 'FAQs', component: FAQsComponent },
  { path: 'about', component: AboutusComponent },
  { path: 'statements', component: StatementsComponent },
  { path: 'account-info', component: AccountInfoComponent },
  { path: 'all-games', component: AllgamesComponent },
  { path: 'kyc', component: KYCComponent },
  { path: 'testn0us4bik64', component: TestN0US4bIk64Component },
  { path: 'maintenance', component: MAINTENANCEComponent },
  { path: 'betfair', component: BetfairComponent },
  { path: 'reference', component: ReferenceComponent },
  { path: 'backup-deposit', component: OldDepositComponent },
  { path: 'demopage', component: DemoComponent },
  { path: 'deposit2', component: DepositBackup2Component },
  { path: 'cookie-policy', component: CookiePolicyComponent },
  { path: 'cookie-policy', component: CookiePolicyComponent },
  { path: 'disclaimer', component: DisclaimerComponent },
  { path: 'AppPayment', component: AppPaymentComponent },
  { path: 'AppPayment', component: AppPaymentComponent },
  { path: 'thankyou', component: ThankyouComponent },

  

  { path: '**', pathMatch: 'full', component: TestComponent },
  
  //{ path: 'backup-deposit', component: OldDepositComponent },
  { path: 'header', component: HeaderComponent }
  
];

@NgModule({
  imports: [ RouterModule.forRoot(routes) ],
  exports: [ RouterModule ]
})
export class AppRoutingModule {}
