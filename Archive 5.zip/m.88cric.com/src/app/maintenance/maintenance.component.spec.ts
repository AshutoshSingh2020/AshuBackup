import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MAINTENANCEComponent } from './maintenance.component';

describe('MAINTENANCEComponent', () => {
  let component: MAINTENANCEComponent;
  let fixture: ComponentFixture<MAINTENANCEComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MAINTENANCEComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MAINTENANCEComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
