import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gamestab',
  templateUrl: './gamestab.component.html',
  styleUrls: ['./gamestab.component.css']
})
export class GamestabComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
