import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GamestabComponent } from './gamestab.component';

describe('GamestabComponent', () => {
  let component: GamestabComponent;
  let fixture: ComponentFixture<GamestabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GamestabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GamestabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
