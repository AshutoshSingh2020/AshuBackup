import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shareandearn',
  templateUrl: './shareandearn.component.html',
  styleUrls: ['./shareandearn.component.css']
})
export class ShareandearnComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
   
  }
  copycode;
  copycode1;
  code = "https://m.betlaga.com/reference?669723";
  copyMessage() {
    const selBox = document.createElement('textarea');
    selBox.style.position = 'fixed';
    selBox.style.left = '0';
    selBox.style.top = '0';
    selBox.style.opacity = '0';
    selBox.value = this.code;
    document.body.appendChild(selBox);
    selBox.focus();
    selBox.select();
    document.execCommand('copy');
    document.body.removeChild(selBox);
  }

}
