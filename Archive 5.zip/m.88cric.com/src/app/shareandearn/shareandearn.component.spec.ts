import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShareandearnComponent } from './shareandearn.component';

describe('ShareandearnComponent', () => {
  let component: ShareandearnComponent;
  let fixture: ComponentFixture<ShareandearnComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShareandearnComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShareandearnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
