const express = require('express');
const { Client } = require('pg');
const { generateServerSeed, sha256, sha512 } = require('./utils');
const dbCreds = require('./dbCreds');

const app = express();
const port = 3000; // Change the port as necessary

app.use(express.json()); // Middleware to parse JSON

// PostgreSQL connection setup
const client = new Client(dbCreds);

client.connect().then(() => {
    console.log('Connected to PostgreSQL');
}).catch(err => {
    console.error('Failed to connect to PostgreSQL', err);
    process.exit(1);
});

app.post('/register-user', async (req, res) => {
    const { sitecode, userid } = req.body;
    
    if (!sitecode || !userid) {
        return res.status(400).send('Missing sitecode or userid');
    }
    
    try {
        const result = await client.query("SELECT register_user($1, $2)", [sitecode, userid]);
        res.send(result.rows[0].register_user);
    } catch (error) {
        console.error('Error during user registration:', error);
        res.status(500).send(`Error: ${error.message}`);
    }
});


// Start round handler
// app.post('/start-round', async (req, res) => {
    //     try {
//         const ongoingRound = await client.query("SELECT * FROM rounds WHERE status = 'ongoing' LIMIT 1");
//         if (ongoingRound.rows.length > 0) {
//             return res.status(400).send('Cannot start a new round until the previous round is closed');
//         }

//         const serverSeed = generateServerSeed();
//         const serverSeedHash = sha256(serverSeed);

//         await client.query("INSERT INTO rounds (server_seed, server_seed_hash) VALUES ($1, $2)", [serverSeed, serverSeedHash]);
//         res.send('New round started successfully');
//     } catch (error) {
//         res.status(500).send(`Error: ${error.message}`);
//     }
// });
// Start round handler
app.post('/start-round', async (req, res) => {
    try {
        const result = await client.query("SELECT start_round()");
        res.send(result.rows[0].start_round);
    } catch (error) {
        console.error('Error during round creation:', error);
        res.status(500).send(`Error: ${error.message}`);
    }
});



app.post('/place-bet', async (req, res) => {
    const { userId, roundId, betAmount, clientSeed } = req.body;
    
    if (!userId || !roundId || !betAmount || !clientSeed) {
        return res.status(400).send('Missing required parameters');
    }
    
    try {
        const result = await client.query("SELECT place_bet($1, $2, $3, $4)", [userId, roundId, betAmount, clientSeed]);
        res.json({ bet_id: result.rows[0].place_bet });
    } catch (error) {
        console.error('Error placing bet:', error);
        res.status(500).send(`Error: ${error.message}`);
    }
});



app.post('/calculate-result', async (req, res) => {
    try {
        const result = await client.query("SELECT * FROM calculate_result()");
        res.json({
            round_id: result.rows[0].round_id,
            result: result.rows[0].result,
            steps: result.rows[0].steps
        });
    } catch (error) {
        console.error('Error calculating result:', error);
        res.status(500).send(`Error: ${error.message}`);
    }
});


app.post('/cash-out', async (req, res) => {
    const { userId, roundId, cashoutMultiplier, betId } = req.body;
    
    if (!userId || !roundId || !cashoutMultiplier || !betId) {
        return res.status(400).send('Missing required parameters');
    }
    
    try {
        const result = await client.query("SELECT cash_out($1, $2, $3, $4)", [userId, roundId, betId, cashoutMultiplier]);
        res.send(result.rows[0].cash_out);
    } catch (error) {
        console.error('Error cashing out:', error);
        res.status(500).send(`Error: ${error.message}`);
    }
});


app.post('/close-round', async (req, res) => {
    try {
        const result = await client.query("SELECT * FROM close_round()");
        
        if (result.rows.length === 0 || !result.rows[0].round_id) {
            return res.status(400).send('No ongoing round found to close');
        }
        
        res.json({
            round_id: result.rows[0].round_id,
            result: result.rows[0].result,
            users: result.rows.map(row => ({
                userid: row.user_id,
                bet_amount: row.bet_amount,
                cashout_multiplier: row.cashout_multiplier,
                final_amount: row.final_amount
            }))
        });
    } catch (error) {
        console.error('Error closing round:', error);
        res.status(500).send(`Error: ${error.message}`);
    }
});



app.get('/verify-round', async (req, res) => {
    const roundId = parseInt(req.query.round_id);  // Ensure round_id is an integer
    
    if (isNaN(roundId)) {
        return res.status(400).send('Invalid round_id');
    }
    
    try {
        const result = await client.query("SELECT * FROM verify_round($1)", [roundId]);
        
        if (result.rows.length === 0 || !result.rows[0].round_id) {
            return res.status(404).send('Round not found or not enough bets placed');
        }
        
        res.json({
            round_id: result.rows[0].round_id,
            original_result: result.rows[0].original_result,
            recalculated_result: result.rows[0].recalculated_result,
            steps: result.rows[0].steps
        });
    } catch (error) {
        console.error('Error verifying round:', error);
        res.status(500).send(`Error: ${error.message}`);
    }
});

app.post('/start-cashout', async (req, res) => {
    const { roundId } = req.body;
    
    if (!roundId) {
        return res.status(400).send('Missing roundId');
    }
    
    try {
        const result = await client.query("SELECT enable_cashout($1)", [roundId]);
        res.send(result.rows[0].enable_cashout);
    } catch (error) {
        console.error('Error enabling cashout:', error);
        res.status(500).send(`Error: ${error.message}`);
    }
});


// Insert data API
app.post('/insert-data', async (req, res) => {
    const { game_code, currency, site, token, player } = req.body;
    try {
        await pool.query(`SELECT insert_into_launchers($1, $2, $3, $4, $5, $6)`,[token,site.id,player,site.lobby,game_code,currency]);
        res.status(200).json({ message: '' });
    } catch (error) {
        console.error('data not inserted:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
});



// Start the server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
