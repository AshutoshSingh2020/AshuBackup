const { Client } = require('pg');
const dbCreds = require('./dbCreds');

const client = new Client(dbCreds);

const connectToDatabase = async () => {
  try {
    await client.connect();
    console.log('Connected to the database');
  } catch (err) {
    console.error('Failed to connect to the database:', err.stack);
    process.exit(1); // Exit the process if connection fails
  }
};

const fetchUsers = async () => {
  try {
    const result = await client.query('SELECT * FROM users');
    return result.rows;
  } catch (err) {
    console.error('Error fetching users:', err.stack);
    throw err;
  }
};

const closeConnection = async () => {
  try {
    await client.end();
    console.log('Database connection closed');
  } catch (err) {
    console.error('Error closing the connection:', err.stack);
  }
};

module.exports = {
  connectToDatabase,
  fetchUsers,
  closeConnection
};
