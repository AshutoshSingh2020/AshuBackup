const fs = require('fs');

const dbCreds = {
  host: 'avixdb.postgres.database.azure.com',
  user: 'postgres',
  password: 'Kitetsu321',
  database: 'postgres',
  port: 5432,
  ssl: {
    // ca: fs.readFileSync('certificate.pem') // Replace with the actual path to your CA certificate
    rejectUnauthorized: false
  }
};

module.exports = dbCreds;
