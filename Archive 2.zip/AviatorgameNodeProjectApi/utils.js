const crypto = require('crypto');

// Function to generate a random server seed using Node.js Crypto API
function generateServerSeed() {
    return crypto.randomBytes(16).toString('hex');
}

// SHA-256 hash function using Node.js Crypto API
function sha256(message) {
    return crypto.createHash('sha256').update(message).digest('hex');
}

// SHA-512 hash function using Node.js Crypto API
function sha512(message) {
    return crypto.createHash('sha512').update(message).digest('hex');
}

// Function to render JSON as a response string
function renderJson(data) {
    return JSON.stringify(data, null, 2);
}

module.exports = {
    generateServerSeed,
    sha256,
    sha512,
    renderJson
};
