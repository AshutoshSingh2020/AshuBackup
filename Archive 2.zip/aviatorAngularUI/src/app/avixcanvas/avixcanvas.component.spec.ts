import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvixcanvasComponent } from './avixcanvas.component';

describe('AvixcanvasComponent', () => {
  let component: AvixcanvasComponent;
  let fixture: ComponentFixture<AvixcanvasComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AvixcanvasComponent]
    });
    fixture = TestBed.createComponent(AvixcanvasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
