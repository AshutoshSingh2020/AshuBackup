import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-avixcanvas',
  templateUrl: './avixcanvas.component.html',
  styleUrls: ['./avixcanvas.component.scss']
})

export class AvixcanvasComponent implements OnInit {
  @ViewChild('canvas', { static: true }) canvas!: ElementRef<HTMLCanvasElement>;
  ctx!: CanvasRenderingContext2D;

  images: HTMLImageElement[] = [];
  currentImageIndex = 0;
  fps: number = 4; // Default FPS (frames per second)

  ngOnInit(): void {
    const canvas = this.canvas.nativeElement;
    this.ctx = canvas.getContext('2d') as CanvasRenderingContext2D;
    canvas.width = 900;
    canvas.height = 500;

    // Load the SVG images
    this.loadImages().then(() => {
      const totalTime = 6000; // Set total time
      this.startAnimation(totalTime);
    });
  }

  loadImages(): Promise<void> {
    const imagePaths = ['assets/anim1.svg', 'assets/anim2.svg', 'assets/anim3.svg', 'assets/anim4.svg'];
    const promises = imagePaths.map(path => {
      return new Promise<void>((resolve) => {
        const img = new Image();
        img.src = path;
        img.onload = () => {
          this.images.push(img);
          resolve();
        };
      });
    });

    return Promise.all(promises).then(() => {});
  }

  startAnimation(totalTime: number): void {
    if (totalTime <= 2000) {
      this.animatePhase1(totalTime, 1, 1);
    } else {
      this.animatePhase1(2000, 0.7, 0.7, () => {
        const swingTime = totalTime - 2300; // Subtract 2 seconds for Phase 1, 1 second for swinging, and 300ms for exit
        this.animateSwing(swingTime, () => {
          this.animateExit(300);
        });
      });
    }
  }

  animatePhase1(duration: number, targetX: number, targetY: number, onComplete?: () => void): void {
    this.animatePath(duration, targetX, targetY, onComplete);
  }

  animateSwing(duration: number, onComplete?: () => void): void {
    const swingCount = Math.floor(duration / 2000); // Calculate how many full swings (2 seconds per swing)
    const swingDuration = duration / (swingCount + 1); // Adjust swing time for smooth transitions

    let swingLeft = swingCount;

    const swing = () => {
      if (swingLeft > 0) {
        this.animatePhase2(swingDuration, () => {
          this.animatePhase3(swingDuration, () => {
            swingLeft--;
            swing();
          });
        });
      } else {
        onComplete?.();
      }
    };

    swing();
  }

  animatePhase2(duration: number, onComplete?: () => void): void {
    const startX = this.canvas.nativeElement.width * 0.7;
    const startY = this.canvas.nativeElement.height * 0.3;

    // Move 5% down and to the right and then back
    this.animatePathSegment(duration / 2, startX, startY, startX + this.canvas.nativeElement.width * 0.05, startY + this.canvas.nativeElement.height * 0.05, () => {
      this.animatePathSegment(duration / 2, startX + this.canvas.nativeElement.width * 0.05, startY + this.canvas.nativeElement.height * 0.05, startX, startY, onComplete);
    });
  }

  animatePhase3(duration: number, onComplete?: () => void): void {
    const startX = this.canvas.nativeElement.width * 0.7;
    const startY = this.canvas.nativeElement.height * 0.3;

    // Move to top left and then back
    this.animatePathSegment(duration / 2, startX, startY, startX - this.canvas.nativeElement.width * 0.05, startY - this.canvas.nativeElement.height * 0.05, () => {
      this.animatePathSegment(duration / 2, startX - this.canvas.nativeElement.width * 0.05, startY - this.canvas.nativeElement.height * 0.05, startX, startY, onComplete);
    });
  }

  animateExit(duration: number): void {
    const startX = this.canvas.nativeElement.width * 0.7;
    const startY = this.canvas.nativeElement.height * 0.3;
    this.animatePathSegment(duration, startX, startY, this.canvas.nativeElement.width, 0);
  }

  animatePath(duration: number, targetX: number, targetY: number, onComplete?: () => void, startX: number = 0, startY: number = this.canvas.nativeElement.height): void {
    const endX = this.canvas.nativeElement.width * targetX;
    const endY = this.canvas.nativeElement.height * (1 - targetY);

    const startTime = Date.now();
    const frameDuration = 1000 / this.fps; // Calculate frame duration based on FPS

    const animate = () => {
      const currentTime = Date.now();
      const elapsedTime = currentTime - startTime;
      const progress = elapsedTime / duration;

      if (progress < 1) {
        this.currentImageIndex = Math.floor((elapsedTime / frameDuration) % this.images.length);

        const x = startX + (endX - startX) * progress;
        const y = startY - (startY - endY) * Math.pow(progress, 2);

        this.drawImage(x, y);

        requestAnimationFrame(animate);
      } else {
        this.drawImage(endX, endY);
        if (onComplete) {
          onComplete();
        }
      }
    };

    animate();
  }

  animatePathSegment(duration: number, startX: number, startY: number, endX: number, endY: number, onComplete?: () => void): void {
    const startTime = Date.now();
    const frameDuration = 1000 / this.fps; // Calculate frame duration based on FPS

    const animate = () => {
      const currentTime = Date.now();
      const elapsedTime = currentTime - startTime;
      const progress = elapsedTime / duration;

      if (progress < 1) {
        this.currentImageIndex = Math.floor((elapsedTime / frameDuration) % this.images.length);

        const x = startX + (endX - startX) * progress;
        const y = startY + (endY - startY) * progress;

        this.drawImage(x, y);

        requestAnimationFrame(animate);
      } else {
        this.drawImage(endX, endY);
        if (onComplete) {
          onComplete();
        }
      }
    };

    animate();
  }

  drawImage(x: number, y: number): void {
    const canvas = this.canvas.nativeElement;
    this.ctx.clearRect(0, 0, canvas.width, canvas.height);
    const img = this.images[this.currentImageIndex];

    const adjustedX = x;
    const adjustedY = y - img.height;

    this.ctx.drawImage(img, adjustedX, adjustedY, img.width, img.height);
  }
}