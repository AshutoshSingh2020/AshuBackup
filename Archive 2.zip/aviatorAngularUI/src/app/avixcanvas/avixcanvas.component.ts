import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-avixcanvas',
  templateUrl: './avixcanvas.component.html',
  styleUrls: ['./avixcanvas.component.scss']
})
export class AvixcanvasComponent implements OnInit {
  @ViewChild('canvas', { static: true }) canvas!: ElementRef<HTMLCanvasElement>;
  ctx!: CanvasRenderingContext2D;
  images: HTMLImageElement[] = [];
  currentImageIndex = 0;
  fps: number = 8;
  isExiting = false;
  hideKite = false;
  finX = 2.5;
  startTime!: number;
  totalTime: number = 14000;
  
  // Timer-specific properties
  timerStartTime: number = 1.00; // Starting value of the timer
  timerEndTime: number = 2.50;   // Ending value of the timer
  
  ngOnInit(): void {
    const canvas = this.canvas.nativeElement;
    this.ctx = canvas.getContext('2d') as CanvasRenderingContext2D;
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    this.startLoop();
  }
  

  
  startLoop() {
    console.log("Ashutosh")
    this.loadImages().then(() => {
      this.startTime = Date.now(); // Start animation
      this.startAnimation(this.totalTime);
  
      // Wait for 10 seconds and then call startLoop again
      setTimeout(() => {
        this.startLoop(); // Recursively call the function after 10s
      }, 10000);
    });
  }
  loadImages(): Promise<void> {
    const imagePaths = ['assets/anim1.svg', 'assets/anim2.svg', 'assets/anim3.svg', 'assets/anim4.svg'];
    const promises = imagePaths.map(path => {
      return new Promise<void>((resolve) => {
        const img = new Image();
        img.src = path;
        // img.height=40;
        // img.width=80;
        img.onload = () => {
          this.images.push(img);
          resolve();
        };
      });
    });
    
    return Promise.all(promises).then(() => {});
  }
  
  startAnimation(totalTime: number): void {
    const exitTime = 300;
    const swingDuration = 2000;
    const initialPhaseTime = totalTime <= 2000 ? totalTime : 2000;
    const remainingTime = totalTime - initialPhaseTime - exitTime;

    if (totalTime <= 2000) {
      this.hideKite = true;
      this.animatePhase1(totalTime, 1, 1);
    } else {
      this.animatePhase1(initialPhaseTime, 0.7, 0.7, () => {
        const adjustedSwingDuration = Math.min(swingDuration, remainingTime);
        const adjustedRemainingTime = remainingTime - adjustedSwingDuration;
        
        this.animateSwing(adjustedRemainingTime, adjustedSwingDuration, () => {
          this.animateExit(exitTime);
        });
      });
    }
  }
  
  animatePhase1(duration: number, targetX: number, targetY: number, onComplete?: () => void): void {
    this.animatePath(duration, targetX, targetY, onComplete);
  }
  
  animateSwing(remainingTime: number, swingDuration: number, onComplete?: () => void): void {
    let timeLeft = remainingTime;
    const swingStep = () => {
      if (timeLeft > swingDuration + 300) {
        this.animateCompleteSwing(swingDuration, () => {
          timeLeft -= swingDuration;
          swingStep();
        });
      } else {
        onComplete?.();
      }
    };
    
    swingStep();
  }
  
  animateCompleteSwing(duration: number, onComplete?: () => void): void {
    const startX = this.canvas.nativeElement.width * 0.7;
    const startY = this.canvas.nativeElement.height * 0.3;
    const midX1 = startX + this.canvas.nativeElement.width * 0.05;
    const midY1 = startY + this.canvas.nativeElement.height * 0.15;
    const midX2 = this.canvas.nativeElement.width * 0.55;
    const midY2 = startY - this.canvas.nativeElement.height * 0.05;
    
    this.animatePathSegmentWithEasing(duration / 1, startX, startY, midX1, midY1, () => {
      this.animatePathSegmentWithEasing(duration / 1, midX1, midY1, midX2, midY2, () => {
        this.animatePathSegmentWithEasing(duration / 1, midX2, midY2, startX, startY, onComplete);
      });
    });
  }
  
  animateExit(duration: number): void {
    this.hideKite = true;
    this.isExiting = true; // Ensure that "FLEW AWAY!" message is shown
    const startX = this.canvas.nativeElement.width * 0.7;
    const startY = this.canvas.nativeElement.height * 0.3;
    this.animatePathSegment(duration, startX, startY, this.canvas.nativeElement.width, 0);
  }
  
  animatePath(duration: number, targetX: number, targetY: number, onComplete?: () => void, startX: number = 0, startY: number = this.canvas.nativeElement.height): void {
    const endX = this.canvas.nativeElement.width * targetX;
    const endY = this.canvas.nativeElement.height * (1 - targetY);
    const startTime = Date.now();
    
    const animate = () => {
      const currentTime = Date.now();
      const elapsedTime = currentTime - startTime;
      const progress = Math.min(elapsedTime / duration, 1);
      
      if (elapsedTime <= duration) {
        this.currentImageIndex = Math.floor((elapsedTime * this.fps / 1000) % this.images.length);
        const x = startX + (endX - startX) * progress;
        const y = startY - (startY - endY) * Math.pow(progress, 2);
        this.drawImage(x, y);
        requestAnimationFrame(animate);
      } else {
        this.drawImage(endX, endY);
        if (onComplete) {
          onComplete();
        }
      }
    };
    
    animate();
  }
  
  animatePathSegment(duration: number, startX: number, startY: number, endX: number, endY: number, onComplete?: () => void): void {
    const startTime = Date.now();
    const frameDuration = 1000 / this.fps;
    const animate = () => {
      const currentTime = Date.now();
      const elapsedTime = currentTime - startTime;
      const progress = elapsedTime / duration;
      
      if (progress < 1) {
        this.currentImageIndex = Math.floor((elapsedTime / frameDuration) % this.images.length);
        const x = startX + (endX - startX) * progress;
        const y = startY + (endY - startY) * progress;
        this.drawImage(x, y);
        requestAnimationFrame(animate);
      } else {
        this.isExiting = true; // Ensure that "FLEW AWAY!" message is shown
        this.drawImage(endX, endY);
        if (onComplete) {
          onComplete();
        }
      }
    };
    animate();
  }
  
  animatePathSegmentWithEasing(duration: number, startX: number, startY: number, endX: number, endY: number, onComplete?: () => void): void {
    const startTime = Date.now();
    const frameDuration = 1000 / this.fps;
    const easeInOutQuad = (t: number) => {
      return t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
    };
    const animate = () => {
      const currentTime = Date.now();
      const elapsedTime = currentTime - startTime;
      const progress = elapsedTime / duration;
      const easedProgress = easeInOutQuad(progress);
      if (progress < 1) {
        this.currentImageIndex = Math.floor((elapsedTime / frameDuration) % this.images.length);
        const x = startX + (endX - startX) * easedProgress;
        const y = startY + (endY - startY) * easedProgress;
        this.drawImage(x, y);
        requestAnimationFrame(animate);
      } else {
        this.drawImage(endX, endY);
        if (onComplete) {
          onComplete();
        }
      }
    };
    
    animate();
  }
  
  drawImage(x: number, y: number): void {
    const canvas = this.canvas.nativeElement;
    this.ctx.clearRect(0, 0, canvas.width, canvas.height);
    const img = this.images[this.currentImageIndex];
    const adjustedX = x;
    const adjustedY = y - img.height;
    
    if (!this.isExiting) {
      this.drawKiteLine(adjustedX, adjustedY);
      // Ensure the text is drawn on top of the object if not exiting
      this.drawElapsedTime(this.startTime, this.totalTime, this.timerStartTime, this.timerEndTime);
    } else {
      this.drawFinalMessage(Date.now() - this.startTime);
    }
    
    this.ctx.drawImage(img, adjustedX, adjustedY, img.width, img.height);
  }

  drawElapsedTime(startTime: number, totalTime: number, startNumber: number, endNumber: number): void {
    if (this.isExiting) return; // Do not display the timer if the kite is exiting

    const canvas = this.canvas.nativeElement;
    this.ctx.font = 'bold 4.2rem Arial';
    this.ctx.fillStyle = 'white';
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    
    const currentTime = Date.now();
    const elapsedTime = currentTime - startTime;
    const progress = elapsedTime / totalTime;
    
    if (elapsedTime <= totalTime) {
      const currentNumber = startNumber + (endNumber - startNumber) * progress;
      const timeText = `${currentNumber.toFixed(2)}x`;
      this.ctx.fillText(timeText, canvas.width / 2, canvas.height / 2);
    }
  }
  
  drawFinalMessage(finalTime: number): void {
    const canvas = this.canvas.nativeElement;
    this.ctx.font = '1.5rem Arial';
    this.ctx.fillStyle = 'white';
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    this.ctx.fillText('FLEW AWAY!', canvas.width / 2, canvas.height / 2 - 25);
    
    if (finalTime !== undefined) {
      this.ctx.font = 'bold 4.2rem Arial';
      this.ctx.fillStyle = 'red';
      const finalTimeText = `${(this.finX).toFixed(2)}x`;
      this.ctx.fillText(finalTimeText, canvas.width / 2, canvas.height / 2 + 30);
    }
  }
  
  drawKiteLine(x: number, y: number): void {
    if (!this.hideKite) {
      const startX = 0;
      const startY = this.canvas.nativeElement.height - 2;
      const controlX = x * 0.55;
      const controlY = startY;
  
      // Begin path for the kite line
      this.ctx.beginPath();
      this.ctx.moveTo(startX, startY);
      this.ctx.quadraticCurveTo(controlX, controlY, x + 20, y + 68);
  
      // Fill the area below the kite line
      this.ctx.lineTo(x+20, this.canvas.nativeElement.height); // Move to bottom-right corner
      this.ctx.lineTo(0, this.canvas.nativeElement.height); // Move to bottom-left corner
      this.ctx.closePath(); // Close the path to the starting point
  
      // Fill with grey and 0.5 opacity red
      this.ctx.fillStyle = 'rgba(255, 0, 0, 0.2)'; // 0.5 opacity red
      this.ctx.fill();
  
      // Draw the kite line on top
      this.ctx.beginPath();
      this.ctx.moveTo(startX, startY);
      this.ctx.quadraticCurveTo(controlX, controlY, x + 20, y + 68);
      this.ctx.strokeStyle = 'red';
      this.ctx.lineWidth = 5;
      this.ctx.stroke();
    }
  }
}
