import { AfterViewInit, Component,OnInit, ViewChild } from '@angular/core';
import { AppService } from '../services/app.service';
import { AvixcanvasmobComponent } from '../avixcanvasmob/avixcanvasmob.component';

@Component({
  selector: 'app-avixmain',
  templateUrl: './avixmain.component.html',
  styleUrls: ['./avixmain.component.scss']
})
export class AvixmainComponent implements OnInit ,AfterViewInit{
  valueb1: number = 10.00;
  min: number = 10.00;
  max: number = 8000.00;
  step: number = 10.00;
  bet:number = 0;
  disable:boolean = false;
  @ViewChild(AvixcanvasmobComponent) canvasCmp!:AvixcanvasmobComponent;
  constructor(private appSer:AppService){
    this.audio = new Audio('assets/audio/bg_music.mp3');
    this.audio.loop = true;
  }

  private audio: HTMLAudioElement;
ngAfterViewInit(): void {
  
  this.disable =this.canvasCmp.disablebtn;
}
  ngOnInit(): void {
    // this.audio.play().catch(error => {
    //   console.error('Error playing the background music:', error);
    // });
    console.log(this.disable)
    this.appSer.betBtnDisable$.subscribe(val => {
      this.disable = val;
      console.log("Bool state updated:", val);
    })
  }
  
  onValueChange(event: string): void {
    // Parse the input value, removing commas
    let parsedValue = parseFloat(event.replace(/,/g, ''));
  
    // Check if the parsed value is a valid number
    if (!isNaN(parsedValue)) {
      // Restrict the value to 2 decimal places
      parsedValue = parseFloat(parsedValue.toFixed(2));
  
      // Check if the parsed value exceeds the max value
      if (parsedValue > 8000) {
        this.valueb1 = 8000.00;
      } else if (parsedValue < 10) {
        this.valueb1 = 10.00;
      } else {
        this.valueb1 = parsedValue;
      }
    } else {
      // Handle invalid input (e.g., if the input is not a number)
      this.valueb1 = 10.00; // or set to a default minimum value
    }
  }
  
  
  inputNumber(type: string, event: Event): void {
    let res = this.valueb1;
    if (type === '-') {
      res -= this.step;
    } else {
      res += this.step;
    }
    if (res < this.min) {
      res = this.min;
    }
    if (res > this.max) {
      res = this.max;
    }
    this.valueb1 = res
  }
  addBet(){
    this.bet += this.valueb1;
    console.log(this.bet)
  }

}
