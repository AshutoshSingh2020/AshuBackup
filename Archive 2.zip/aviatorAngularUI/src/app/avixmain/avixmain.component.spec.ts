import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvixmainComponent } from './avixmain.component';

describe('AvixmainComponent', () => {
  let component: AvixmainComponent;
  let fixture: ComponentFixture<AvixmainComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AvixmainComponent]
    });
    fixture = TestBed.createComponent(AvixmainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
