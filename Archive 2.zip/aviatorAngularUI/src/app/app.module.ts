import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AvixcanvasComponent } from './avixcanvas/avixcanvas.component';
import { AvixmainComponent } from './avixmain/avixmain.component';
import { AvixcanvasmobComponent } from './avixcanvasmob/avixcanvasmob.component';

@NgModule({
  declarations: [
    AppComponent,
    AvixcanvasComponent,
    AvixmainComponent,
    AvixcanvasmobComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
