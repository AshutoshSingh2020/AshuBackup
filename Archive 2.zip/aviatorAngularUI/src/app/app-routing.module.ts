import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AvixmainComponent } from './avixmain/avixmain.component';
import { AvixcanvasComponent } from './avixcanvas/avixcanvas.component';
import { AvixcanvasmobComponent } from './avixcanvasmob/avixcanvasmob.component';


const routes: Routes = [
  { path: '', redirectTo: '/aviator', pathMatch: 'full' },
  { path: 'aviator', component: AvixmainComponent },
  { path: 'aviatorcan', component: AvixcanvasComponent },
  { path: 'aviatorcanmob', component: AvixcanvasmobComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
