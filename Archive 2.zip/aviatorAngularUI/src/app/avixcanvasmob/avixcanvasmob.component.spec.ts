import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AvixcanvasmobComponent } from './avixcanvasmob.component';

describe('AvixcanvasmobComponent', () => {
  let component: AvixcanvasmobComponent;
  let fixture: ComponentFixture<AvixcanvasmobComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AvixcanvasmobComponent]
    });
    fixture = TestBed.createComponent(AvixcanvasmobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
