import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  private boolSubject = new BehaviorSubject<boolean>(false); 
  betBtnDisable$ = this.boolSubject.asObservable();
  constructor() { }

  updateBoolState(value: boolean): void {
    this.boolSubject.next(value);
  }

  getCurrentValue(): boolean {
    return this.boolSubject.value;
  }
}
