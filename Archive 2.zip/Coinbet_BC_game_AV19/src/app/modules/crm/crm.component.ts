import { Component } from '@angular/core';

@Component({
  selector: 'app-crm',
  imports: [],
  templateUrl: './crm.component.html',
  styleUrl: './crm.component.scss'
})
export class CrmComponent {

}
