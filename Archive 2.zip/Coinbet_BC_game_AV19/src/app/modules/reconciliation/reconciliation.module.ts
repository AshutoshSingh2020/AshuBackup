import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ReconciliationRoutingModule } from './reconciliation-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ReconciliationRoutingModule
  ]
})
export class ReconciliationModule { }
