import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WithdrawRoutingModule } from './withdraw-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    WithdrawRoutingModule
  ]
})
export class WithdrawModule { }
