import { Component } from '@angular/core';

@Component({
  selector: 'app-approve-reel',
  imports: [],
  templateUrl: './approve-reel.component.html',
  styleUrl: './approve-reel.component.scss'
})
export class ApproveReelComponent {

}
