export const environment = {
	production: true,
	// apiUrl: 'https://adminuat.coinbet91.com/',
	apiUrl: 'https://adminuat.coinbet91.com/api/',
	crmapiUrl: 'https://crmapi.fairbet91.com/'
};


