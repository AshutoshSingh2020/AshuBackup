export const environment = {
    production: false,
    // apiUrl: 'https://adminuat.coinbet91.com/',
    apiUrl: 'https://adminuat.coinbet91.com/api/',
    // crmapiUrl: 'https://crmapi.fairbet91.com/',
    crmapiUrl: 'https://crmapi.fairbet91.com/'
    //checking
  };