import { Component, HostBinding, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ToastrService} from 'ngx-toastr';
import { ApiService } from '@services/api.service';
import { config } from '../../services/config';
import { Router } from '@angular/router';


@Component({
    selector: 'app-recover-password',
    templateUrl: './recover-password.component.html',
    styleUrls: ['./recover-password.component.scss']
})

export class RecoverPasswordComponent implements OnInit, OnDestroy {
    @HostBinding('class') class = 'login-box';
    
    public recoverPasswordForm: FormGroup;
    public isAuthLoading = false;
    
    constructor( private renderer: Renderer2, private toastr: ToastrService, private apiservice: ApiService, private formBuilder: FormBuilder, private router: Router) {}
    
    ngOnInit(): void {
        this.renderer.addClass(document.querySelector('app-root'),'login-page');
        this.recoverPasswordForm = this.formBuilder.group({
            password: ['', (Validators.required)],
            confirmPassword: ['', (Validators.required)]
        });
        
    }
    
    recoverPassword() {
        if (this.recoverPasswordForm.invalid) {
            this.toastr.warning('Please fill all fields properly', 'Error!',{positionClass: 'toast-top-center'});
        } else {
            let request = "?ConfrimPassword="+this.recoverPasswordForm.get('confirmPassword').getRawValue()+"&NewPassword="+this.recoverPasswordForm.get('password').getRawValue();
            this.isAuthLoading = true;
            this.apiservice.getRequest(config['ChangePassword'] + request).subscribe((data: any={}) => {
                this.isAuthLoading = false;   
                if('RStatus' in data && data.RStatus=='Failed'){
                    this.toastr.warning(data.Msg, data.RStatus,{positionClass: 'toast-top-center'});
                }
                else{
                    this.toastr.success('Password Changed!', 'Success!',{positionClass: 'toast-top-center'});
                this.router.navigate(['/']);
                }         
                
            }, (error) => {
                this.isAuthLoading = false;
                console.log(error);
                this.toastr.warning('Please try again', 'Error!',{positionClass: 'toast-top-center'});
            });
            
        }
    }
    
    ngOnDestroy(): void {
        this.renderer.removeClass(document.querySelector('app-root'),'login-page');
    }
}
