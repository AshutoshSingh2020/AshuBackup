import {Component, OnInit} from '@angular/core';
import moment from 'moment';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { CommonFunctionService } from '@services/common-function.service'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit{
  todayDate = new Date();
  dateDashValue: Date[]=[new Date,new Date];
  dashboardCount=[];
  dashboardCountLoading = false;

  constructor(private apiservice :ApiService, private utilities:CommonFunctionService) {}

  ngOnInit(): void {
    this.GetDashboardCount(this.dateDashValue);
  }

  GetDashboardCount(DateValues:Date[]) {
    let request = {
      "StartDateTime": moment(DateValues[0]).format("MM-DD-yyyy"),
      "EndDateTime": moment(DateValues[1]).format("MM-DD-yyyy")
    };
    this.dashboardCount=[];
    this.dashboardCountLoading = true;
    this.apiservice.sendRequest(config['GetDashBoardCount'], request).subscribe((data: any) => {
      this.dashboardCountLoading = false;
      this.dashboardCount = [
        { "name": "Payment Volume", "value":'₹ '+this.utilities.roundOffNum(data.TotalValume), "icon": "ion-person-add", "feather": "user-plus", "color": "#33c38e"},
        { "name": "Transaction Charges", "value":'₹ '+ this.utilities.roundOffNum(data.Charges), "icon": "ion-paper-airplane", "feather": "send", "color": "#ef6767"},
        { "name": "Number of Payment", "value": this.utilities.roundOffNum(data.TotatPaymentCount), "icon": "ion-pie-graph", "feather": "pie-chart", "color": "#1c84ee"},
        { "name": "Number of Request", "value": this.utilities.roundOffNum(data.NumberOfRequest), "icon": "ion-stats-bars", "feather": "bar-chart", "color": "#ffcc5a"},
        { "name": "Withdrawal Balance", "value":'₹ '+ this.utilities.roundOffNum(data.NetBalance), "icon": "ion-pie-graph", "feather": "book", "color": "#1c84ee"},
      ];
    }, (error) => {
      this.dashboardCountLoading = false;
      console.log(error);
    });
  }
}

