import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';

@Component({
  selector: 'app-advance-table',
  templateUrl: './advance-table.component.html',
  styleUrls: ['./advance-table.component.scss']
})

export class AdvanceTableComponent implements OnInit {
  @Input() TableCollumnData:any[]=[];
  @Input() DataLoader:boolean=false;
  // @Input() DataBlank:boolean=false; use for blank data purpose
  @Input() TableData:any[]=[];
  @Input() rowCount:number=0;
  @Output() onInputChange = new EventEmitter<any>();
  @Output() onRowInputChange = new EventEmitter<any>();
  
  dateValues: Date[] = [];
  
  constructor() { }
  
  ngOnInit(): void {
  }
  
  setToggleChange(row:number,cell:number,event:MatSlideToggleChange){
    let inputValue = {'row':row,'col':cell,'value':event.checked,'type':'Toggle'};
    this.onInputChange.emit(inputValue);
  }
  
  buttonPressed(row:number,cell:number,type:string){
    let inputValue = {'row':row,'col':cell,'type':type};
    this.onInputChange.emit(inputValue);
  }

  buttonRowPressed(row:number,cell:number,type:string){
    let inputValue = {'row':row,'col':cell,'type':type};
    this.onRowInputChange.emit(inputValue);
  }
  
}