module.exports = {
    trailingComma: 'none',
    tabWidth: 4,
    singleQuote: true,
    printWidth: 80,
    semi: true,
    bracketSpacing: false
};
