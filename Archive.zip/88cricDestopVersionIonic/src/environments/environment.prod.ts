export const environment = {
  production: true,
  apiUrl: 'https://api.betlaga.com/api/'
};
