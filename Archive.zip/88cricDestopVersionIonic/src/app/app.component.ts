import { Component } from '@angular/core';
import { register } from 'swiper/element/bundle';
import { NavigationEnd, Router } from '@angular/router';
import { CommonService } from './service/common.service';
register();
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(private router:Router,private userauth:CommonService){}
  ngOnInit(): void {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.refreshHeader(); 
      }
    });
  }

  refreshHeader(){
    let LoginToken = localStorage.getItem('LoginToken');
    if (LoginToken != '' && LoginToken != null) {
      this.userauth?.startloging('login');
    } else {
      this.userauth?.stoploging('login');
    }
  }
}
