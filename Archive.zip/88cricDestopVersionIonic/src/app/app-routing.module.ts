import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { MainComponent } from './main/main.component';

const routes: Routes = [
  {
    path: '',
    component:MainComponent,
    children:[
      {
        path: 'home',
        loadChildren: () => import('./module/home/home.module').then( m => m.HomeModule)
      },
      {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
      },
      {
        path:'tabs',
        loadChildren: () => import('./tabs/tabs.module').then(m => m.TabsPageModule)
        
      },
      {
        path: 'promotion',
        loadChildren: () => import('./module/promotion/promotion.module').then( m => m.PromotionPageModule)
      },
      {
        path: 'deposit',
        loadChildren: () => import('./module/deposit/deposit.module').then( m => m.DepositPageModule)
      },
      {
        path: 'withdraw',
        loadChildren: () => import('./module/withdraw/withdraw.module').then( m => m.WithdrawPageModule)
      },
      {
        path: 'game-statement',
        loadChildren: () => import('./module/game-statement/game-statement.module').then( m => m.GameStatementPageModule)
      },
      {
        path: 'profile-setting',
        loadChildren: () => import('./module/profile-setting/profile-setting.module').then( m => m.ProfileSettingPageModule)
      },
      {
        path: 'account-info',
        loadChildren: () => import('./module/account-info/account-info.module').then( m => m.AccountInfoPageModule)
      },
      {
        path: 'game-platforms/:id',
        loadChildren: () => import('./module/game-platforms/game-platforms.module').then( m => m.GamePlatformsPageModule)
      },
    ]
  },
  {
    path: 'login',
    loadChildren: () => import('./auth/login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'register',
    loadChildren: () => import('./auth/register/register.module').then( m => m.RegisterPageModule)
  },
  {
    path: 'forgot-password',
    loadChildren: () => import('./auth/forgot-password/forgot-password.module').then( m => m.ForgotPasswordPageModule)
  },
 
 
 
];
@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule {}
