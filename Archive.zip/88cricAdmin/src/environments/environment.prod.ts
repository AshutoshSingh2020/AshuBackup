export const environment = {
    production: true,
    apiUrl: 'https://88.playludo.app/api/'
    // apiUrl: 'https://88uat.playludo.app/api/'
};
