import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormArray,FormControl } from '@angular/forms';
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
// import _moment , {default as _rollupMoment , Moment} from 'moment';

import {MatDatepicker} from '@angular/material/datepicker';

// import moment from 'moment'

import _moment , {default as _rollupMoment,Moment} from 'moment';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'DD MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'DD MMMM YYYY',
  },
};

@Component({
  selector: 'app-advance-inputs-new',
  templateUrl: './advance-inputs-new.component.html',
  styleUrls: ['./advance-inputs-new.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ]
})

export class AdvanceInputsNewComponent {
  @Input() question: any;
  @Input() formGroup: FormGroup;
  // @Input() DateObj:any={};
  @Output() submitTrigger = new EventEmitter<any>();
  newMonthSelected = new FormControl(moment().startOf('month'));
  newYearSelected = new FormControl(moment().startOf('year'));
  constructor() { }

  ngOnInit(): void {
    // console.log("Ahus"+this.formGroup);
      if(this.question.changeAction && this.question.changeAction=='submit'){
        if(this.question.type!='daterange' ){
          // console.log(this.question);
          this.formGroup.get('value').valueChanges.subscribe((val) => {
            this.submitTrigger.emit();
          })
        }
        else if(this.question.type=='daterange'){
          this.formGroup.get('value1').valueChanges.subscribe((val) => {
            this.submitTrigger.emit();
          })
          this.formGroup.get('value2').valueChanges.subscribe((val) => {
            this.submitTrigger.emit();
          })
        }
      }
    }
    
    get subqueArray(): FormArray {
      return this.formGroup.get('subque') as FormArray;
    }
    
    setMonthAndYear(normalizedMonthAndYear: Moment, datepicker: MatDatepicker<Moment>) {
      const ctrlValue = this.newMonthSelected.value!;
      ctrlValue.month(normalizedMonthAndYear.month());
      ctrlValue.year(normalizedMonthAndYear.year());
      this.formGroup.controls.value.setValue(ctrlValue);
      datepicker.close();
    }
    
    setYear(normalizedYear: Moment, datepicker: MatDatepicker<Moment>) {
      const ctrlValue = this.newYearSelected.value!;
      ctrlValue.year(normalizedYear.year());
      this.formGroup.controls.value.setValue(ctrlValue);
    datepicker.close();
  }
  searchSelOps(val:string){
    let newVal=val.toLocaleLowerCase();
    let foundObj = this.question.options.filter(({ name }) => (name.toLocaleLowerCase()).includes(newVal));
    this.question.filteredOptions = foundObj;
  }
}
