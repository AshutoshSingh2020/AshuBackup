import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormArray } from '@angular/forms';
import { MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
// import _moment , {default as _rollupMoment , Moment} from 'moment';

import { MatDatepicker } from '@angular/material/datepicker';

// import moment from 'moment'

import _moment, { default as _rollupMoment, Moment } from 'moment';

const moment = _rollupMoment || _moment;
export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'DD MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'DD MMMM YYYY',
  },
};
@Component({
  selector: 'app-advance-title-head-new',
  templateUrl: './advance-title-head-new.component.html',
  styleUrls: ['./advance-title-head-new.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ]
})

export class AdvanceTitleHeadNewComponent implements OnInit {
  @Input() subText: boolean = false;
  @Input() titleText: string = '';
  @Input() btnVal: string = '';
  @Input() classes: string = '';
  @Input() dynamicForm: any = [];
  @Input() showForm: any = false;
  @Output() onSubmitForm = new EventEmitter<any>();
  generatedForm!: FormGroup;
  constructor(private formBuilder: FormBuilder) { }

  ngOnInit(): void {
    this.generatedForm = this.toFormGroup(this.dynamicForm);
  }

  toFormGroup(questions: any[]): FormGroup {
    const group: any = {};
    questions.forEach(question => {
      if (question.subque.length > 0) {
        if (question.type == 'input') {
          group[question.que] = this.formBuilder.group({
            value: [null],
            subque: this.toFormArray(question.subque)
          });
        }
        else if (question.type == 'dropdown') {
          group[question.que] = this.formBuilder.group({
            value: [question.options[0]],
            subque: this.toFormArray(question.subque)
          });
        }
        else if (question.type == 'daterange') {
          group[question.que] = this.formBuilder.group({
            value1: [question.startDate],
            value2: [question.endDate],
            subque: this.toFormArray(question.subque)
          });
        }
        else if (question.type == 'date') {
          group[question.que] = this.formBuilder.group({
            value: [question.defaultDate],
            subque: this.toFormArray(question.subque)
          });
        }
        else if (question.type == 'Daily') {
          group[question.que] = this.formBuilder.group({
            value: [question.startDate],
            subque: this.toFormArray(question.subque)
          });
        }
        else if (question.type == 'Monthly') {

          group[question.que] = this.formBuilder.group({
            value: [question.startMonth],
            subque: this.toFormArray(question.subque)
          });
        }
        else if (question.type == 'Yearly') {
          group[question.que] = this.formBuilder.group({
            value: [question.startYear],
            subque: this.toFormArray(question.subque)
          });
        }
        else if (question.type == 'select') {
          group[question.que] = this.formBuilder.group({
            value: [question.default.value]
          });
        }
        else if (question.type == 'search-select') {
          group[question.que] = this.formBuilder.group({
            value: [question.default.value]
          });
        }
      } else {
        if (question.type == 'input') {
          group[question.que] = this.formBuilder.group({
            value: [null]
          });
        }
        else if (question.type == 'dropdown') {
          group[question.que] = this.formBuilder.group({
            value: [question.options[0]]
          });
        }
        else if (question.type == 'daterange') {
          group[question.que] = this.formBuilder.group({
            value1: [question.startDate],
            value2: [question.endDate],
          });
        }
        else if (question.type == 'date') {
          group[question.que] = this.formBuilder.group({
            value: [question.defaultDate]
          });
        } else if (question.type == 'Daily') {
          group[question.que] = this.formBuilder.group({
            value: [question.startDate],
            subque: this.toFormArray(question.subque)
          });
        }
        else if (question.type == 'Monthly') {
          group[question.que] = this.formBuilder.group({
            value: [question.startMonth],
            subque: this.toFormArray(question.subque)
          });
        }
        else if (question.type == 'Yearly') {
          group[question.que] = this.formBuilder.group({
            value: [question.startYear],
            subque: this.toFormArray(question.subque)
          });
        }
        else if (question.type == 'select') {
          group[question.que] = this.formBuilder.group({
            value: [question.default.value]
          });
        }
        else if (question.type == 'search-select') {
          group[question.que] = this.formBuilder.group({
            value: [question.default.value]
          });
        }
      }
    });
    return this.formBuilder.group(group);
  }

  toFormArray(subQuestions: any[]): FormArray {
    const arr: FormGroup[] = [];
    subQuestions.forEach(subQuestion => {
      let group: FormGroup;
      if (subQuestion.subque.length > 0) {
        if (subQuestion.type == 'input') {
          group = this.formBuilder.group({
            value: [null],
            subque: this.toFormArray(subQuestion.subque)
          });
        }
        else if (subQuestion.type == 'dropdown') {
          group = this.formBuilder.group({
            value: [subQuestion.options[0]],
            subque: this.toFormArray(subQuestion.subque)
          });
        }
        else if (subQuestion.type == 'daterange') {
          group = this.formBuilder.group({
            value1: [subQuestion.startDate],
            value2: [subQuestion.endDate],
            subque: this.toFormArray(subQuestion.subque)
          });
        }
        else if (subQuestion.type == 'Daily') {
          group = this.formBuilder.group({
            value: [subQuestion.startDate],
            subque: this.toFormArray(subQuestion.subque)
          });
        }
        else if (subQuestion.type == 'Monthly') {
          group = this.formBuilder.group({
            value: [subQuestion.startMonth],
            subque: this.toFormArray(subQuestion.subque)
          });
        }
        else if (subQuestion.type == 'Yearly') {
          group = this.formBuilder.group({
            value: [subQuestion.startYear],
            subque: this.toFormArray(subQuestion.subque)
          });
        }
        else if (subQuestion.type == 'select') {
          group = this.formBuilder.group({
            value: [subQuestion.default.value],
            subque: this.toFormArray(subQuestion.subque)
          });
        }
        else if (subQuestion.type == 'search-select') {
          group = this.formBuilder.group({
            value: [subQuestion.default.value],
            subque: this.toFormArray(subQuestion.subque)
          });
        }


      } else {
        if (subQuestion.type == 'input') {
          group = this.formBuilder.group({
            value: [null]
          });
        }
        else if (subQuestion.type == 'dropdown') {
          group = this.formBuilder.group({
            value: [subQuestion.options[0]]
          });
        }
        else if (subQuestion.type == 'daterange') {
          group = this.formBuilder.group({
            value1: [subQuestion.startDate],
            value2: [subQuestion.endDate]
          });
        }
        else if (subQuestion.type == 'date') {
          group = this.formBuilder.group({
            value: [subQuestion.defaultDate]
          });
        }
        else if (subQuestion.type == 'Daily') {
          group = this.formBuilder.group({
            value: [subQuestion.startDate]
          });
        }
        else if (subQuestion.type == 'Monthly') {
          group = this.formBuilder.group({
            value: [subQuestion.startMonth]
          });
        }
        else if (subQuestion.type == 'Yearly') {
          group = this.formBuilder.group({
            value: [subQuestion.startYear]
          });
        }
        else if (subQuestion.type == 'select') {
          group = this.formBuilder.group({
            value: [subQuestion.default.value]
          });
        }
        else if (subQuestion.type == 'search-select') {
          group = this.formBuilder.group({
            value: [subQuestion.default.value]
          });
        }

      }
      arr.push(group);
    });
    return this.formBuilder.array(arr);
  }

  submitFunction() {
    this.onSubmitForm.emit(this.generatedForm.getRawValue());
  }
}