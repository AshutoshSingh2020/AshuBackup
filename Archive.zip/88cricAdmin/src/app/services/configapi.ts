export const apiData: any = {
  "GetDashBoardCount":{endURL:"DashboardApi/GetDashboardCount",type:"POST",keyL:"GetDashBoardCount"}, //dashboard/my-dashboard
  "GetDashboardChart":{endURL:"DashboardApi/GetDashBoardCount",type:"POST",keyL:"GetDashboardChart"}, //dashboard/my-dashboard
  "GetDashboardChart1": {endURL:"DashboardApi/GetDashboardDepositChart",type:"POST",keyL:"GetDashboardChart1"},
  "GetTopDepositors": {endURL:"DashboardApi/GetTopDepositors",type:"POST",keyL:"GetTopDepositors"},
  "getWD": {endURL:"UsersApi/GetWithdraw",type:"POST",keyL:"getWD"},
  "getClients": {endURL:"UsersApi/GetClientList",type:"GET",keyL:"getClients"},
  "submitWdReq": {endURL:"UsersApi/SubmitWithdrawalRequest",type:"POST",keyL:"submitWdReq"},
  "getClientCb": {endURL:"UsersApi/GetClientChargeback",type:"POST",keyL:"getClientCb"},
  "makeCBReq": {endURL:"UsersApi/MakeChargebackRequest",type:"POST",keyL:"makeCBReq"},
  "GetPGClientIPList": {endURL:"UsersApi/GetPGClientIPList",type:"GET",keyL:"GetPGClientIPList"},
  "SavePaymentGetwayIPAddress": {endURL:"UsersApi/SavePaymentGetwayIPAddress",type:"POST",keyL:"SavePaymentGetwayIPAddress"},
  "DeleteClientPGIPStatus": {endURL:"UsersApi/DeleteClientPGIPStatus",type:"GET",keyL:"DeleteClientPGIPStatus"},
  "SavePaymentGetway": {endURL:"DashboardApi/SavePaymentGetway",type:"POST",keyL:"SavePaymentGetway"},
  
  "GetClientGatewayData": {endURL:"DashboardApi/GetClientGatewayData",type:"POST",keyL:"GetClientGatewayData"},
  "GetLeadClients": {endURL:"LeadApi/GetLeadClientData",type:"GET",keyL:"GetLeadClients"},//Lead
  "GetAllLeads": {endURL:"LeadApi/GetAllLeads",type:"POST",keyL:"GetAllLeads"},
  "AssignLeadToAdmin": {endURL:"LeadApi/AssignLeadToAdmin",type:"POST",keyL:"AssignLeadToAdmin"},
  "UploadBulkLead": {endURL:"LeadApi/UploadBulkLead",type:"POST",keyL:"UploadBulkLead"},
  "GetAgentTiming": {endURL:"LeadApi/GetAgentTiming",type:"POST",keyL:"GetAgentTiming"},
  "GetLeadPerformer": {endURL:"LeadApi/GetLeadPerformer",type:"POST",keyL:"GetLeadPerformer"},
  "GetMyLeads": {endURL:"LeadApi/GetMyLeads",type:"POST",keyL:"GetMyLeads"},
  "GetLeadLog": {endURL:"LeadApi/GetLeadLog",type:"POST",keyL:"GetLeadLog"},
  "GetRegisterLead": {endURL:"LeadApi/GetRegisterLead",type:"POST",keyL:"GetRegisterLead"},
  "GetLeadDashhboard": {endURL:"LeadApi/GetLeadDashhboard",type:"POST",keyL:"GetLeadDashhboard"},
  "SaveLead": {endURL:"LeadApi/SaveLead",type:"POST",keyL:"SaveLead"},
  "GetRefCode": {endURL:"LeadApi/GetRefCode",type:"POST",keyL:"GetRefCode"},
  "SaveLeadLog": {endURL:"LeadApi/SaveLeadLog",type:"POST",keyL:"SaveLeadLog"},
  
  "getCallLog": {endURL:"UsersApi/GetCallBackRequestList",type:"GET",keyL:"getCallLog"}, //call request
  "saveCallRequest": {endURL:"UsersApi/SaveCallRequest",type:"POST",keyL:"saveCallRequest"},
  
  "getAllPlayer": {endURL:"UsersApi/GetAllPlayer",type:"POST",keyL:"getAllPlayer"}, //admin
  
  "getAllAdmins": {endURL:"UsersApi/GetAllAdmins",type:"POST",keyL:"getAllAdmins"},//all admin
  "saveRoleChange": {endURL:"UsersApi/SaveRoleChange",type:"GET",keyL:"saveRoleChange"},
  "saveBlockAdmin": {endURL:"UsersApi/SaveBlockAdmin",type:"GET",keyL:"saveBlockAdmin"},
  "saveDepositAccess": {endURL:"UsersApi/SaveDepositAccess",type:"GET",keyL:"saveDepositAccess"},
  "saveIMPSAccess": {endURL:"UsersApi/SaveIMPSAccess",type:"GET",keyL:"saveIMPSAccess"},
  
  "getUserStatement": {endURL:"UsersApi/GetUserStatement",type:"GET",keyL:"getUserStatement"}, // user-deails
  "getOnlineDepositList": {endURL:"UsersApi/GetOnlineDepositList",type:"GET",keyL:"getOnlineDepositList"},
  "getUserWithdrawal": {endURL:"UsersApi/GetUserWithdrawData",type:"GET",keyL:"getUserWithdrawal"},
  "getGamePlayed": {endURL:"UsersApi/getGamePlayed",type:"GET",keyL:"getGamePlayed"},
  "hasDepositAccess": {endURL:"UsersApi/HasDepositAccess",type:"GET",keyL:"hasDepositAccess"},
  "getUserDepositeData": {endURL:"UsersApi/GetUserDepositeData",type:"GET",keyL:"getUserDepositeData"},
  "updateUserAccount": {endURL:"UsersApi/UpdateUserAccount",type:"POST",keyL:"updateUserAccount"},
  "saveUserProfile": {endURL:"UsersApi/SaveUserProfile",type:"POST",keyL:"saveUserProfile"},
  
  "otpnotregister": {endURL:"LeadApi/OTPNotRegister",type:"POST",keyL:"otpnotregister"},//missed player
  
  "getCallBackRequest": {endURL:"UsersApi/GetCallBackRequest",type:"GET",keyL:"getCallBackRequest"},//call-request
  
  "saveTally": {endURL:"UsersApi/SaveTally",type:"POST",keyL:"saveTally"},
  "getTally": {endURL:"UsersApi/GetTallyRecords",type:"POST",keyL:"getTally"},
  "getClientRecon": {endURL:"UsersApi/GetClientReconciliation",type:"POST",keyL:"getClientRecon"}, // reconcilation
  
  "getRegisterUser": {endURL:"UsersApi/GetRegisterUser",type:"POST",keyL:"getRegisterUser"},//report
  
  
  "getBankTransaction": {endURL:"UsersApi/GetBankTransaction",type:"POST",keyL:"getBankTransaction"}, //Bank
  "setBTrxDesc": {endURL:"UsersApi/UpdateBankTransactionDescription",type:"POST",keyL:"setBTrxDesc"},
  
  
  "getPayClicks": {endURL:"UsersApi/GetPaymenntClickData",type:"POST",keyL:"getPayClicks"}, //payment
  
   "getSafeXPayBal": {endURL:"UsersApi/GetSafeXPayBalance",type:"GET",keyL:"getSafeXPayBal"},
   "getPayoutList": {endURL:"UsersApi/GetClientPayoutWithoutBalanceList",type:"GET",keyL:"getPayoutList"},//client
   "getWithdrawBank": {endURL:"UsersApi/GetActiveWithdrawBankDetails",type:"GET",keyL:"getWithdrawBank"},
   "getPayoutData": {endURL:"UsersApi/GetClientPayout",type:"POST",keyL:"getPayoutData"},
   "transferFundsUsingPayMyRecharge": {endURL:"payout/TransferFundsPlayerViaPayMyRecharge",type:"POST",keyL:"transferFundsUsingPayMyRecharge"},//client
   
   "getUsersListBlock": {endURL:"UsersApi/GetUsersListBlock",type:"POST",keyL:"getUsersListBlock"},
   "changeUserStatus": {endURL:"UsersApi/ChangeUserStatus",type:"POST",keyL:"changeUserStatus"}, //add-fund
   
   "getdepositddata": {endURL:"UsersApi/GetDepositeData",type:"POST",keyL:"getdepositddata"},//deposit
   
   "transferFundViaPayconnect": {endURL:"UsersApi/TransferUsingPayConnect",type:"POST",keyL:"transferFundViaPayconnect"},
   "trxFundsViaPMR": {endURL:"withdrawal/TransferFundsPlayerViaPayMyRecharge",type:"POST",keyL:"trxFundsViaPMR"},
   "transferFundsWithOtpPlayerV1": {endURL:"UsersApi/TransferFundsWithOtpPlayerV1",type:"POST",keyL:"transferFundsWithOtpPlayerV1"},
   "transferUserFundsUsingVaderPay": {endURL:"UserWithdrawal/TransferUserFundsUsingVaderPay",type:"POST",keyL:"transferUserFundsUsingVaderPay"},
   "okWithdrawalmain": {endURL:"UsersApi/ApproveWithdrawal",type:"POST",keyL:"okWithdrawalmain"},
   "initiateOtpV1": {endURL:"UsersApi/InitiateOtpV1",type:"GET",keyL:"initiateOtpV1"},
   "initiateOtp": {endURL:"UsersApi/InitiateOtp",type:"GET",keyL:"initiateOtp"},
   "getPGPayoutProvider": {endURL:"UsersApi/GetPGPayoutProviderData",type:"GET",keyL:"getPGPayoutProvider"},
   "withdrawalData": {endURL:"UsersApi/WithdrawalData",type:"POST",keyL:"withdrawalData"},
   "processWithdrawal": {endURL:"UsersApi/ProcessWithdrawal",type:"POST",keyL:"processWithdrawal"},
   "clientWithdrawalProviderReset": {endURL:"withdrawal/ClientWithdrawalProviderReset",type:"GET",keyL:"clientWithdrawalProviderReset"},
   "getSafeXPayBalance": {endURL:"UsersApi/GetSafeXPayBalance",type:"GET",keyL:"getSafeXPayBalance"},
   "getMyPayBalance": {endURL:"UsersApi/GetMyPayBalance",type:"GET",keyL:"getMyPayBalance"},
   "getwithdrawddata": {endURL:"UsersApi/GetWithdrawData",type:"POST",keyL:"getwithdrawddata"},//withdraw
   
   "getwinlose": {endURL:"UsersApi/GetWinAndLose",type:"POST",keyL:"getwinlose"}, //win-lose
   
   "getIPData": {endURL:"UsersApi/GetAdminIPAddress",type:"POST",keyL:"getIPData"},//security
   "saveIP": {endURL:"Usersapi/SaveAdminIPAddress",type:"POST",keyL:"saveIP"},
   "updateIPData": {endURL:"Usersapi/UpdateAdminIPAddress",type:"POST",keyL:"updateIPData"},
   "removeIP": {endURL:"Usersapi/RemoveAdminIPAddress",type:"GET",keyL:"removeIP"},
   
   "getAllPlayerForEdit": {endURL:"UsersApi/GetAllPlayerForEdit",type:"POST",keyL:"getAllPlayerForEdit"},
   "editPlayerDetails": {endURL:"UsersApi/EditPlayerDetails",type:"POST",keyL:"editPlayerDetails"},
   "resetPassword": {endURL:"UsersApi/ResetPassword",type:"POST",keyL:"resetPassword"},
   "resetStatus": {endURL:"Usersapi/ResetClientDepositStatus",type:"POST",keyL:"resetStatus"},
   
   'getGameList':{endURL:'UsersApi/GetGameList',type:"POST",keyL:"getGameList"}, //modules/ game-list
   "editGameDetails": {endURL:"UsersApi/EditGameDetails",type:"POST",keyL:"editGameDetails"},
   "updateGameDetail": {endURL:"UsersApi/UpdateGameDetail",type:"POST",keyL:"updateGameDetail"},


      //  "loginApi": {endURL:"HomeApi/UserLogin",type:"",keyL:""},
      //  "ChangePassword": {endURL:"UsersApi/ChangePassword",type:"",keyL:""},
       //  "GetTopWithdraw": {endURL:"DashboardApi/GetTopWithdraw",type:"",keyL:"GetTopWithdraw"},
       //  "getpgGraphData": {endURL:"DashboardApi/BindGraphDateWiseClientGateway",type:"",keyL:"getpgGraphData"},
       //  "exportDepositAndWithdrawal": {endURL:"UsersApi/ExportDepositAndWithdrawal",type:"",keyL:"exportDepositAndWithdrawal"},
       //  "exportStatement": {endURL:"UsersApi/ExportStatement",type:"",keyL:"exportStatement"},
       //  "exportWithdrawalData": {endURL:"withdrawal/ExportWithdrawalData",type:"",keyL:"exportWithdrawalData"},
       //  "dlCPayout": {endURL:"UsersApi/ExportClientPayout",type:"",keyL:"dlCPayout"},
       //  "expCDeposit": {endURL:"UsersApi/ExportClientDeposit",type:"",keyL:"expCDeposit"},
       //  "changeAdminStatus": {endURL:"UsersApi/ChangeAdminStatus",type:"",keyL:"changeAdminStatus"},
       //  "downLoadWithdraw": {endURL:"UsersApi/DownLoadExcelWithdrawal",type:"",keyL:"downLoadWithdraw"},
       //  "dlPaykunPmt": {endURL:"UsersApi/DownloadPaymentPaykun",type:"",keyL:"dlPaykunPmt"},
       //  "dlDailyUserActWGame": {endURL:"UsersApi/DownLoadADailyUserAcivityWithGame",type:"",keyL:"dlDailyUserActWGame"},
       //  "dlGamesAct": {endURL:"UsersApi/DownloadGameAcivity",type:"",keyL:"dlGamesAct"},
       //  "dlAllPGdata": {endURL:"UsersApi/DownLoadAllPaymentGatewayExcell",type:"",keyL:"dlAllPGdata"},
       //  "dlAllPOdata": {endURL:"UsersApi/DownLoadAllPayoutExcell",type:"",keyL:"dlAllPOdata"},
       //  "dlClientCb": {endURL:"UsersApi/ExportClientChargeback",type:"",keyL:"dlClientCb"},
       //  "getRefCodelead": {endURL:"LeadApi/GetRefCode",type:"",keyL:"getRefCodelead"},
       //  "dlUserDeposits": {endURL:"UsersApi/DownloadUserDepositData",type:"",keyL:"dlUserDeposits"},
       //  "dlUserWithdraws": {endURL:"UsersApi/DownloadUserWithdrawData",type:"",keyL:"dlUserWithdraws"},
       //  "dlUserBnusDeposits": {endURL:"UsersApi/DownloadUserBonusDepositData",type:"",keyL:"dlUserBnusDeposits"},
       //  "downLoadAllPaymentGatewayExcell": {endURL:"UsersApi/DownLoadAllPaymentGatewayExcell",type:"",keyL:"downLoadAllPaymentGatewayExcell"},
       //  "downLoadAllPayoutExcell": {endURL:"UsersApi/DownLoadAllPayoutExcell",type:"",keyL:"downLoadAllPayoutExcell"},
       //  "downloadAllReportData": {endURL:"UsersApi/DownloadAllReportData",type:"",keyL:"downloadAllReportData"},
       //  "exportBankTransaction": {endURL:"UsersApi/ExportBankTransaction",type:"",keyL:"exportBankTransaction"},
       

   "emailAuthApi": {endURL:"HomeApi/LoginAuth",type:"GET",keyL:"emailAuthApi"},
   "okWithdrawal": {endURL:"withdrawal/ApproveWithdrawal",type:"",keyL:"okWithdrawal"},
   "getAdminMenuMappingsData": {endURL:"UsersApi/GetAdminMenu",type:"GET",keyL:""},
   "SaveBankTransaction": {endURL:"UsersApi/SaveBankTransaction",type:"POST",keyL:"SaveBankTransaction"},
   "GetAdminDetails": {endURL:"LeadApi/GetAdminDetail",type:"GET",keyL:"GetAdminDetails"},
   "getUserData": {endURL:"UsersApi/GetUserData",type:"GET",keyL:"getUserData"},
   "otpOpenMoney": {endURL:"withdrawal/InitiateOtpViaOpenMoney",type:"",keyL:"otpOpenMoney"},
   "trxOpenMoney": {endURL:"withdrawal/TransferFundsPlayerViaOpenMoney",type:"",keyL:"trxOpenMoney"},
   "otpOpenMoneyRoyal": {endURL:"withdrawal/InitiateOtpViaOpenMoneyRoyal",type:"",keyL:"otpOpenMoneyRoyal"},
   "trxOpenMoneyRoyal": {endURL:"withdrawal/TransferFundsPlayerViaOpenMoneyRolyal",type:"",keyL:"trxOpenMoneyRoyal"},
   "trxVader": {endURL:"withdrawal/TransferFundsPlayerViaVaderPay",type:"",keyL:"trxVader"},
   
   "getAdminRoles": {endURL:"UsersApi/GetAdminRolesData",type:"GET",keyL:"getAdminRoles"},
   "saveAdminProfile": {endURL:"UsersApi/SaveAdminProfile",type:"POST",keyL:"saveAdminProfile"},
   "getAllBanks": {endURL:"UsersApi/GetAllBankDetails",type:"GET",keyL:"getAllBanks"},
   "changeUpiStat": {endURL:"UsersApi/ChangeBankUpiStatus",type:"GET",keyL:"changeUpiStat"},
   "changeUpiVisibility": {endURL:"UsersApi/ChangeBankUpiIsVisible",type:"GET",keyL:"changeUpiVisibility"},
   "getBankSummary": {endURL:"UsersApi/GetBankUPIPercentageSummaryViaUPI",type:"GET",keyL:"getBankSummary"},
   "getBClientList": {endURL:"UsersApi/GetBankClientList",type:"GET",keyL:"getBClientList"},
   "addToBClient": {endURL:"UsersApi/AddBankClientMapping",type:"POST",keyL:"addToBClient"},
   "delFromBClient": {endURL:"UsersApi/RemoveBankClientMapping",type:"POST",keyL:"delFromBClient"},
   "getBClientStat": {endURL:"UsersApi/GetBankClientStatus",type:"GET",keyL:"getBClientStat"},
   "setPGStat": {endURL:"UsersApi/ChangePaymentGatewayStatus",type:"POST",keyL:"setPGStat"},
   "getPGMaster": {endURL:"UsersApi/GetPaymentGatewayMasterDetails",type:"GET",keyL:"getPGMaster"},
   "doCallback": {endURL:"UsersApi/CallbackClientTransaction",type:"POST",keyL:"doCallback"},
   "getClientDeposit": {endURL:"UsersApi/GetClientDeposit",type:"POST",keyL:"getClientDeposit"},
   "editCbackTrx": {endURL:"UsersApi/EditCallbackClientTransaction",type:"POST",keyL:"editCbackTrx"},
   "blockUserUPI": {endURL:"UsersApi/BlockUPI",type:"POST",keyL:"blockUserUPI"},
   "userVerifications": {endURL:"UsersApi/GetUserVarificationData",type:"POST",keyL:"userVerifications"},
   "clientPayoutProviderReset": {endURL:"payout/",type:"GET",keyL:"ClientPayoutProviderReset"},
   "getClientPayoutList": {endURL:"UsersApi/GetClientPayoutList",type:"GET",keyL:"getClientPayoutList"},
   "getPayoutBal": {endURL:"UsersApi/GetPayoutBalance",type:"POST",keyL:"getPayoutBal"},
   "savePayoutBal": {endURL:"UsersApi/SavePayoutBalance",type:"POST",keyL:"savePayoutBal"},
   "blockUserPayment": {endURL:"UsersApi/BlockUserTrypayment",type:"POST",keyL:"blockUserPayment"},
   "setCPayout": {endURL:"payout/ApproveClientPayout",type:"",keyL:"setCPayout"},
   "approveClientPayout": {endURL:"UsersApi/ApproveClientPayout",type:"",keyL:"approveClientPayout"},
   "approveClientPayoutV1": {endURL:"UsersApi/ApproveClientPayoutV1",type:"",keyL:"approveClientPayoutV1"},
   "transferClientFundsUsingVaderPay": {endURL:"UserWithdrawal/TransferClientFundsUsingVaderPay",type:"",keyL:"transferClientFundsUsingVaderPay"},
   "getPayoutProviders": {endURL:"withdrawal/GetPGPayoutProviderData",type:"",keyL:"getPayoutProviders"},
   "updateBankUPIDescription": {endURL:"UsersApi/UpdateBankUPIDescription",type:"",keyL:"updateBankUPIDescription"},

  }