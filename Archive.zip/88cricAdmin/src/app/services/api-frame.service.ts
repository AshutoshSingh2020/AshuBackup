import { Injectable } from '@angular/core';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

export class ApiFrameService {
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService) { }
  // GenTable(rowRef:any,apiData:any,currentQuery?:any) {
  //   this.apiservice.apiRequest(apiData, currentQuery).subscribe({
  //     next: (data: any) => {
  //       if(data[0]){
  //         return this.utilities.mapDataToTableRow(rowRef,data);
  //       }
  //       return [];
  //     },
  //     error: (error) => {
  //       console.log(error);
  //     }
  //   });
  // }

  GenTable(rowRef: any, apiData: any, currentQuery?: any): Observable<any> {
    return this.apiservice.apiRequest(apiData, currentQuery).pipe(
      map((data: any) => {
        if (data && data[0]) {
          return this.utilities.mapDataToTableRow(rowRef, data);
        }
        return [];
      }),
      catchError((error) => {
        console.error(error);
        return of([]);
      })
    );
  }
}
