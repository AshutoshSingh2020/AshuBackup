export const config: any = {
  "emailAuthApi": "HomeApi/LoginAuth",
  "loginApi": "HomeApi/UserLogin",
  'ChangePassword': 'UsersApi/ChangePassword',
  "GetDashBoardCount":"DashboardApi/GetDashBoardCount ",
  "getAdminMenuMappingsData": "UsersApi/GetAdminMenu",
  'GetTopDepositors': 'DashboardApi/GetTopDepositors',
  'GetTopWithdraw': 'DashboardApi/GetTopWithdraw',
  'GetClientGatewayData': 'DashboardApi/GetClientGatewayData',
  "otpnotregister": "LeadApi/OTPNotRegister",
  'getUsersListBlock':'UsersApi/GetUsersListBlock', //modules/ users/ blocked-users
  "okWithdrawal":"withdrawal/ApproveWithdrawal",//withdraw/withdrawal-request
  "okWithdrawalmain":"UsersApi/ApproveWithdrawal",//withdraw/withdrawal-request
  "GetDashboardChart":"DashboardApi/GetDashBoardCount",
  "GetDashboardChart1":"DashboardApi/GetDashboardDepositChart",
  'transferFundViaPayconnect':'UsersApi/TransferUsingPayConnect',
  "SaveBankTransaction": "UsersApi/SaveBankTransaction",//banktransaction
  "getwinlose": "UsersApi/GetWinAndLose",//banktransaction
  "getwithdrawddata": "UsersApi/GetWithdrawData",//banktransaction
  "getdepositddata": "UsersApi/GetDepositeData",//banktransaction
  "getpgGraphData":"DashboardApi/BindGraphDateWiseClientGateway",
  'SavePaymentGetway': 'DashboardApi/SavePaymentGetway',
  "GetPGClientIPList":"UsersApi/GetPGClientIPList",
  "SavePaymentGetwayIPAddress":"UsersApi/SavePaymentGetwayIPAddress",
  "DeleteClientPGIPStatus":"UsersApi/DeleteClientPGIPStatus",
  
  "GetAdminDetails": "LeadApi/GetAdminDetail",
  "GetLeadClients": "LeadApi/GetLeadClientData",
  "SaveLead": "LeadApi/SaveLead",
  "GetAllLeads": "LeadApi/GetAllLeads",
  "AssignLeadToAdmin": "LeadApi/AssignLeadToAdmin",
  "GetLeadLog": "LeadApi/GetLeadLog",
  "UploadBulkLead": "LeadApi/UploadBulkLead",
  "GetLeadPerformer": "LeadApi/GetLeadPerformer",
  "GetAgentTiming": "LeadApi/GetAgentTiming",
  "GetMyLeads": "LeadApi/GetMyLeads",
  "GetRefCode": "LeadApi/GetRefCode",
  "SaveLeadLog": "LeadApi/SaveLeadLog",
  "GetLeadDashhboard": "LeadApi/GetLeadDashhboard",
  "GetRegisterLead": "LeadApi/GetRegisterLead",
  
  "getAllPlayer" : "UsersApi/GetAllPlayer",
  "getUserData" : "UsersApi/GetUserData",
  "hasDepositAccess" : "UsersApi/HasDepositAccess",
  "getUserDepositeData" : "UsersApi/GetUserDepositeData",
  "getUserStatement": "UsersApi/GetUserStatement",
  "getUserWithdrawal" : "UsersApi/GetUserWithdrawData",
  "getGamePlayed" : "UsersApi/getGamePlayed",
  "getCallLog" : "UsersApi/GetCallBackRequestList",
  "getOnlineDepositList" : "UsersApi/GetOnlineDepositList",
  "changeUserStatus" : "UsersApi/ChangeUserStatus",
  "updateUserAccount" : "UsersApi/UpdateUserAccount",
  "exportDepositAndWithdrawal": "UsersApi/ExportDepositAndWithdrawal",
  "exportStatement": "UsersApi/ExportStatement",
  "getAdminRoles": "UsersApi/GetAdminRolesData",
  "getAllAdmins": "UsersApi/GetAllAdmins",
  "saveRoleChange": "UsersApi/SaveRoleChange",
  "saveBlockAdmin": "UsersApi/SaveBlockAdmin",
  "saveIMPSAccess": "UsersApi/SaveIMPSAccess",
  'saveDepositAccess': 'UsersApi/SaveDepositAccess',
  "getCallBackRequest": "UsersApi/GetCallBackRequest",
  "saveCallRequest": "UsersApi/SaveCallRequest",
  "saveUserProfile": "UsersApi/SaveUserProfile",
  "withdrawalData": "UsersApi/WithdrawalData",
  "saveAdminProfile":"UsersApi/SaveAdminProfile",
  "getPayoutProviders":"withdrawal/GetPGPayoutProviderData",// withdrawal Page
  "getSafeXPayBalance":"UsersApi/GetSafeXPayBalance",// withdrawal Page
  "otpOpenMoney":"withdrawal/InitiateOtpViaOpenMoney",// withdrawal Page
  "trxOpenMoney":"withdrawal/TransferFundsPlayerViaOpenMoney",// withdrawal Page
  "otpOpenMoneyRoyal":"withdrawal/InitiateOtpViaOpenMoneyRoyal",// withdrawal Page
  "trxOpenMoneyRoyal":"withdrawal/TransferFundsPlayerViaOpenMoneyRolyal", // withdrawal Page
  "trxVader":"withdrawal/TransferFundsPlayerViaVaderPay",// withdrawal Page
  "exportWithdrawalData":"UsersApi/ExportWithdrawalData",// withdrawal Page
  "getIPData":"UsersApi/GetAdminIPAddress",//ip listing
  "updateIPData":"Usersapi/UpdateAdminIPAddress",//ip listing
  "removeIP":"Usersapi/RemoveAdminIPAddress",//ip listing
  "saveIP":"Usersapi/SaveAdminIPAddress",//ip listing
  
  "GetBankTransaction": "UsersApi/GetBankTransaction",//banktransaction
  "setBTrxDesc":"UsersApi/UpdateBankTransactionDescription",//banktransaction
  
  "getAllBanks":"UsersApi/GetAllBankDetails",//allbank
  "changeUpiStat":"UsersApi/ChangeBankUpiStatus",//allbank
  "changeUpiVisibility":"UsersApi/ChangeBankUpiIsVisible",//allbank
  "getBankSummary":"UsersApi/GetBankUPIPercentageSummaryViaUPI",//allbank
  "getBClientList":"UsersApi/GetBankClientList",//allbank
  "addToBClient":"UsersApi/AddBankClientMapping",//allbank
  "delFromBClient":"UsersApi/RemoveBankClientMapping",//allbank
  "getBClientStat":"UsersApi/GetBankClientStatus",//allbank
  
  "getPGMaster":"UsersApi/GetPaymentGatewayMasterDetails",//pgmaster
  "setPGStat":"UsersApi/ChangePaymentGatewayStatus",//pgmaster
  "saveNewPGMaster":"UsersApi/SavePaymentGatewayMasterDetails",//pgmaster
  
  "getPayoutList":"UsersApi/GetClientPayoutWithoutBalanceList",//client-payout
  "getPayoutData":"UsersApi/GetClientPayout",//client-payout
  "getWithdrawBank":"UsersApi/GetActiveWithdrawBankDetails",//client-payout
  "getPGPayoutProvider":"UsersApi/GetPGPayoutProviderData",//client-payout
  "getSafeXPayBal":"UsersApi/GetSafeXPayBalance",//client-payout
  "dlCPayout":"UsersApi/ExportClientPayout",//client/client-payout
  
  "doCallback":"UsersApi/CallbackClientTransaction",//client-deposit
  "expCDeposit":"UsersApi/ExportClientDeposit",//client-deposit
  
  "getClientDeposit":"UsersApi/GetClientDeposit",//client-deposit client-add-deposit
  "editCbackTrx":"UsersApi/EditCallbackClientTransaction",//client-add-deposit
  
  "userVerifications":"UsersApi/GetUserVarificationData",//uservarification
  "blockUserUPI": "UsersApi/BlockUPI",//uservarification
  
  "getClients":"UsersApi/GetClientList",//client/client-pg-user
  "changeAdminStatus":"UsersApi/ChangeAdminStatus",//client/client-pg-user
  "clientPayoutProviderReset":"payout/ClientPayoutProviderReset",//client/client-pg-user
  
  "getPayoutBal":"UsersApi/GetPayoutBalance",//client/payout-balance
  "getClientPayoutList":"UsersApi/GetClientPayoutList",//client/payout-balance
  "savePayoutBal":"UsersApi/SavePayoutBalance",//client/payout-balance
  
  "getClientRecon":"UsersApi/GetClientReconciliation",//reconciliation/recon
  "downLoadWithdraw":"UsersApi/DownLoadExcelWithdrawal",//reconciliation/recon
  
  "getTally":"UsersApi/GetTallyRecords",//reconciliation/tally
  "saveTally":"UsersApi/SaveTally",//reconciliation/tally
  
  "dlPaykunPmt":"UsersApi/DownloadPaymentPaykun",//reconciliation/pay-gate
  
  "dlDailyUserActWGame":"UsersApi/DownLoadADailyUserAcivityWithGame",//reconciliation/download
  "dlGamesAct":"UsersApi/DownloadGameAcivity",//reconciliation/download
  "dlAllPGdata":"UsersApi/DownLoadAllPaymentGatewayExcell",//reconciliation/download
  "dlAllPOdata":"UsersApi/DownLoadAllPayoutExcell",//reconciliation/download
  
  "getClientCb":"UsersApi/GetClientChargeback",//dashboard/chargeback
  "dlClientCb":"UsersApi/ExportClientChargeback",//dashboard/chargeback
  "makeCBReq":"UsersApi/MakeChargebackRequest",//dashboard/chargeback
  
  "getWD":"UsersApi/GetWithdraw",//dashboard/addclientpayout
  "submitWdReq":"UsersApi/SubmitWithdrawalRequest",//dashboard/addclientpayout
  
  "getRefCodelead":"LeadApi/GetRefCode",//dashboard/bdpginfo
  "getPayClicks":"UsersApi/GetPaymenntClickData",//users/payment-click
  "blockUserPayment":"UsersApi/BlockUserTrypayment",//users/payment-click
  
  
  "dlUserDeposits":"UsersApi/DownloadUserDepositData",//dashboard/index
  "dlUserWithdraws":"UsersApi/DownloadUserWithdrawData",//dashboard/index
  "dlUserBnusDeposits":"UsersApi/DownloadUserBonusDepositData",//dashboard/index

  'initiateOtp':'UsersApi/InitiateOtp', //users/approval-BankDetailsComponent
  'trxFundsViaPMR':'withdrawal/TransferFundsPlayerViaPayMyRecharge', //users/approval-BankDetailsComponent
  'transferFundsWithOtpPlayerV1':'UsersApi/TransferFundsWithOtpPlayerV1', //users/approval-BankDetailsComponent
  'transferUserFundsUsingVaderPay':'UserWithdrawal/TransferUserFundsUsingVaderPay', //users/approval-BankDetailsComponent
  'setCPayout':'payout/ApproveClientPayout', //client/payout
  
  'initiateOtpV1':'UsersApi/InitiateOtpV1', //users/approval-BankDetailsComponent
  
  'approveClientPayout':'UsersApi/ApproveClientPayout', //client/approval-BankDetailsComponent
  
  'transferFundsUsingPayMyRecharge':"payout/TransferFundsPlayerViaPayMyRecharge", //client/approval-PMR
  'approveClientPayoutV1':'UsersApi/ApproveClientPayoutV1', //client/approval-BankDetailsComponent
  'transferClientFundsUsingVaderPay':'UserWithdrawal/TransferClientFundsUsingVaderPay', //client/approval-BankDetailsComponent
  
  'downLoadAllPaymentGatewayExcell':'UsersApi/DownLoadAllPaymentGatewayExcell', //dashboard/payment-gateway /pg-data
  'downLoadAllPayoutExcell':'UsersApi/DownLoadAllPayoutExcell', //dashboard/payment-gateway /pg-data
  
  'processWithdrawal':'UsersApi/ProcessWithdrawal', //user/withdrawal-request
  'clientWithdrawalProviderReset':'withdrawal/ClientWithdrawalProviderReset', //user/ negative-withdrawal-request
  
  'updateBankUPIDescription':'UsersApi/UpdateBankUPIDescription', //user/ negative-withdrawal-request
  
  'getRegisterUser':'UsersApi/GetRegisterUser', //modules/ report/ register-users
  'downloadAllReportData':'UsersApi/DownloadAllReportData', //modules/ report/ register-users
  'exportBankTransaction':'UsersApi/ExportBankTransaction', //modules/ report/ register-users
  'getGameList':'UsersApi/GetGameList', //modules/ game-list
  'updateGameDetail':'UsersApi/UpdateGameDetail', //modules/ game-list
  'getAllPlayerForEdit':'UsersApi/GetAllPlayerForEdit', //modules/ game-list
  'editPlayerDetails':'UsersApi/EditPlayerDetails', //modules/ game-list
  'resetPassword':'UsersApi/ResetPassword', //modules/ game-list
  'editGameDetails':'UsersApi/EditGameDetails', //modules/ game-list
  'resetStatus':'Usersapi/ResetClientDepositStatus' //client/add-deposits
}
