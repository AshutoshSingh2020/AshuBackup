import { TestBed } from '@angular/core/testing';

import { ApiFrameService } from './api-frame.service';

describe('ApiFrameService', () => {
  let service: ApiFrameService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApiFrameService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
