import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EditErrorListComponent } from './edit-error-list/edit-error-list.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'edit-error',
    pathMatch: 'full'
  },
  {
    path: 'edit-error',
    component: EditErrorListComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EditErrorRoutingModule { }
