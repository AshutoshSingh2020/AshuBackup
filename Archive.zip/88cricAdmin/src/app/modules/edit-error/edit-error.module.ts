import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { EditErrorRoutingModule } from './edit-error-routing.module';
import { EditErrorListComponent } from './edit-error-list/edit-error-list.component';
import { PlayerDetailsComponent } from './player-details/player-details.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';


@NgModule({
  declarations: [
    EditErrorListComponent,
    PlayerDetailsComponent,
    ResetPasswordComponent
  ],
  imports: [
    EditErrorRoutingModule,
    SharedModule,
  
  ]
})
export class EditErrorModule { }
