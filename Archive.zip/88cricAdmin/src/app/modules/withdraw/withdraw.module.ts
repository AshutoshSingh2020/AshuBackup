import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { WithdrawRoutingModule } from './withdraw-routing.module';
import { WithdrawRequestComponent } from './withdraw-request/withdraw-request.component';
import { BankDetailsComponent } from './bank-details/bank-details.component';
import { ApproveDetailsComponent } from './approve-details/approve-details.component';
import { WithdrawViewComponent } from './withdraw-view/withdraw-view.component';


@NgModule({
  declarations: [
    WithdrawRequestComponent,
    BankDetailsComponent,
    ApproveDetailsComponent,
    WithdrawViewComponent
  ],
  imports: [
    SharedModule,
    WithdrawRoutingModule,
  ]
})
export class WithdrawModule { }
