import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { apiData } from '@services/configapi';
import { Subscription } from 'rxjs';
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

import _moment , {default as _rollupMoment} from 'moment';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'DD MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'DD MMMM YYYY',
  },
};

@Component({
  selector: 'app-withdraw-request',
  templateUrl: './withdraw-request.component.html',
  styleUrls: ['./withdraw-request.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ]
})

export class WithdrawRequestComponent implements OnInit, OnDestroy {
  @ViewChild('UDataDialogOpen') UDataDialogOpen!: TemplateRef<any>;
  @ViewChild('ApproveDialogOpen') ApproveDialogOpen!: TemplateRef<any>;
  allData:any=[];
  tableInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  udataToView={};
  AcceptRejectVar="A";
  paginatorBlock:any=[];
  dynamicControls = [
    {que:'select' ,changeAction:'submit',type:'select',default:{value:"",name:'All'},options:[{value:"P",name:'Pending'},{value:"PR",name:'Processing'},{value:"A",name:'Approved'},{value:"R",name:'Rejected'},{value:"NP",name:'Not Processed'}],subque:[]},
    {que:'Search',type:'input',subque:[]}
  ];
  UserCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Id',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},{value:'Mobile',bg:'white-drop'},{value:'Amount',bg:'white-drop'},
    {value:'Difference (D-W)',bg:'white-drop'},{value:'Date',bg:'white-drop'},{value:'Updated',bg:'white-drop'},{value:'Status',bg:'white-drop'},{value:'Bank',bg:'white-drop'},{value:'Profile',bg:'white-drop'},
    {value:'Action',bg:'white-drop'}]
  ];
  UserDataCollumns=this.UserCollumnHeaders;
  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[2],"Status":""};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={wrc_list:false,wrc_export:false};
  dateValue: any=[new Date(),new Date()];
  maxDate=new Date();
  showExportDates=false;
  ExportClicked=false;
  allProviderBalance:string = '';
  personRole=JSON.parse(localStorage.getItem('personalDetails')).RoleCode;
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private dialog: MatDialog) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.wrc_list=('withdrawalData' in loading);
      if('exportWithdrawalData' in loading){
        this.apiLoader.wrc_export=this.ExportClicked=true;
      }
      else{
        this.apiLoader.wrc_export=false;
        if(this.ExportClicked){
          this.showExportDates=false;
        }
      }
    });
    this.getAllData();
  }
  
  getAllData(){
    this.GetMasterData();
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['getMyPayBalance']).subscribe({
      next: (data:any) => {
        if(data.ErrorCode =='1'){
          let balance = data.ErrorMessage;
          this.allProviderBalance=balance.split(',')[0];
          console.log(this.allProviderBalance);
        }
      },
      error: (error)=> {
        console.error(error);
      }
    });
  }
  
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetMasterData();
  }
  
  GetMasterData() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['withdrawalData'], this.currentQuery).subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.UserDataCollumns=this.UserCollumnHeaders;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
        let bg_cell = ''
        this.allData.forEach((element:any,index:any) => {
          bg_cell = element.FirstDeposit && (element.StatusCode == 'PR' || element.StatusCode == 'P')?'blue-blink-cell':'white-cell';
          let difvalue:any;
          if (element.DifferenceAmount || element.DifferenceAmount == 0) {
            difvalue = element.DifferenceAmount;
          } else {
            difvalue = 'Invalid';
          }
          this.tableInfoData.push([
            {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:bg_cell},
            {value:element.UserId,bg:bg_cell,...(element.UniqueId!="00000000-0000-0000-0000-000000000000"?{sufText:'Request Id : '+element.UniqueId}:{})},
            {value:element.FName,bg:bg_cell,sufText:'AC : '+element.AccountNumber},
            {value:element.UserName,bg:bg_cell},
            {value:element.Mobile,bg:bg_cell},
            {value:element.AccountBalance,bg:bg_cell},
            {value:difvalue,bg:bg_cell},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A DD MMM yyyy"):'',bg:bg_cell,sufText:element.TimeAgo},
            {value:element.UpdatedDate?moment(element.UpdatedDate).format("h:mm:ss A DD MMM yyyy"):'',bg:bg_cell,sufText:element.UTRNumber!='\r'?("UTR : "+element.UTRNumber):'',span_values:[element.PayoutVia],span_classes:["badge light badge-primary"]},
            {value:element.StatusName,bg:bg_cell},
            {value:'',bg:bg_cell,icon:'View'},
            {value:'',bg:bg_cell,icon:'feather',iconvalue:'Users'},
            {bg:bg_cell,icon:'Multi',value:[
              ...(element.StatusCode=='PR'?[{value:'Approve',bg:bg_cell,icon:'None',hrefvalue:element.FileNameServer}]:[]),
              ...(element.StatusCode=='P'?[{value:'Process',bg:bg_cell,icon:'None'}]:[]),
              ...((element.StatusCode=='P' || element.StatusCode=='PR')?[{value:'Reject',bg:bg_cell,icon:'None'}]:[]),
              ...((this.personRole=='SA' && ((element.StatusCode=='P' || element.StatusCode=='PR') && element.PayoutVia))?[{value:'Reset Provider',bg:bg_cell,icon:'None'}]:[]),
              ...((element.StatusCode!='P' && element.StatusCode!='PR')?[{value:element.StatusName,bg:bg_cell}]:[])]
            }
          ])
        });
        this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.UserDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.error(error);
    });
  }
  
  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  onValueChange(formVal:any){
    if(formVal.col==11 && formVal.type=='Users'){
      window.open('/users/playerdetailview/'+this.allData[formVal.row].UserId, '_blank');
    }
    if(formVal.col==10 && formVal.type=='View'){
      this.udataToView=this.allData[formVal.row];
      this.BDataOpenPopup()
    }
    if(formVal.col==12 && formVal.type=='Process'){
      this.udataToView=this.allData[formVal.row];
      this.ProcessWithdrawal();
    }
    if(formVal.col==12 && formVal.type=='Approve'){
      this.AcceptRejectVar="A";
      this.udataToView=this.allData[formVal.row];
      this.ApproveOpenPopup();
    }
    if(formVal.col==12 && formVal.type=='Reject'){
      this.AcceptRejectVar="R";
      this.udataToView=this.allData[formVal.row];
      this.ApproveOpenPopup();
    }
    if(formVal.col==12 && formVal.type=='Reset Provider'){
      this.udataToView=this.allData[formVal.row];
      this.resetdata(this.allData[formVal.row].UserId);
    }
  }
  
  resetdata(data:any){
    let param = {id:data};
    this.apiservice.apiRequest(apiData['clientWithdrawalProviderReset'] , param).subscribe((data: any) => {
      if(data.ErrorCode=='1'){
        this.utilities.toastMsg("success", "Success", data.ErrorMessage);
        this.GetMasterData();
      }
      else{
        this.utilities.toastMsg("error", "Error", data.ErrorMessage);
      }
    }, (error) => {
      this.utilities.toastMsg("error", "Can not process", '');
      console.error(error);
    });
  }
  BDataOpenPopup() {
    let dialogRef = this.dialog.open(this.UDataDialogOpen, {
      width: '600px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  closePopup(){
    this.GetMasterData();
    this.dialog.closeAll();
  }
  
  ApproveOpenPopup() {
    let dialogRef = this.dialog.open(this.ApproveDialogOpen, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  ProcessWithdrawal(){
    this.apiservice.apiRequest(apiData['processWithdrawal'], this.udataToView).subscribe((data: any) => {
      if(data.ErrorCode=='1'){
        this.utilities.toastMsg("success", "Success", data.ErrorMessage);
        this.GetMasterData();
      }
      else{
        this.utilities.toastMsg("error", "Error", data.ErrorMessage);
      }
    }, (error) => {
      this.utilities.toastMsg("error", "Can not process", '');
      console.error(error);
    });
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Status=formVal.select.value;
    this.currentQuery.Search=formVal.Search.value;
    this.currentQuery.PageNo = 1;
    this.GetMasterData();
  }
  
  DownloadWithdrawalRequestData() {
    let d1 = encodeURIComponent(moment(this.dateValue[0]).format("DD/MM/yyyy HH:mm"));
    let d2 = encodeURIComponent(moment(this.dateValue[1]).format("DD/MM/yyyy HH:mm"));
    let request = "?Status="+this.currentQuery.Status+"&StartDateTime="+d1+"&EndDateTime="+d2;
    let docname = 'WithdrawalRequest_Download';
    this.apiservice.exportExcel(config['exportWithdrawalData'] + request,docname,'exportWithdrawalData');
  }
  
  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
}