import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WithdrawRequestComponent } from './withdraw-request/withdraw-request.component';
import { WithdrawViewComponent } from './withdraw-view/withdraw-view.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'withdraw-request',
    pathMatch: 'full'
  },
  {
    path: 'withdraw-request',
    component: WithdrawRequestComponent
  },
  {
    path: 'withdraw-view',
    component: WithdrawViewComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WithdrawRoutingModule { }
