import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.scss']
})

export class ViewDetailsComponent implements OnInit {
  @Input() detailData:any;
  @Output() onCancel = new EventEmitter<any>();
  
  DataLoader=false;
  BankDataCollumns=[]
  BankDataRows:any=[];
  
  constructor() { }
  
  ngOnInit(){
    this.BankDataRows=[
    [{value:'Account Number',bg:'white-cell'},{value:this.detailData.AccountNumber,bg:'white-cell'}],
    [{value:'Bank Name	',bg:'white-cell'},{value:this.detailData.BankName,bg:'white-cell'}],
    [{value:'Branch Name	',bg:'white-cell'},{value:this.detailData.BranchName,bg:'white-cell'}],
    [{value:'Holder Name	',bg:'white-cell'},{value:this.detailData.AccountHolderName,bg:'white-cell'}],
    [{value:'IFSC Code	',bg:'white-cell'},{value:this.detailData.IfscCode,bg:'white-cell'}]
    ]
  }
  
  onBack(){
    this.onCancel.emit();
  }
}