import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
@Component({
  selector: 'app-approve-details',
  templateUrl: './approve-details.component.html',
  styleUrls: ['./approve-details.component.scss']
})
export class ApproveDetailsComponent implements OnInit {

  @Input() userData:any;
  @Input() AcceptRejectVar='A';
  @Output() onCancel = new EventEmitter<any>();
  
  DataLoader=false;
  trxdisabled1=false;
  BankDataCollumns=[]
  BankDataRows:any=[];
  UTRinput=new FormControl('',Validators.required);
  activeTabIndex=[0,'Open Money'];
  tabConfigs=[
    {otp:'otpOpenMoney',trx:'trxOpenMoney'},
    {trx:'trxOpenMoney'},
    {otp:'otpOpenMoneyRoyal',trx:'trxOpenMoneyRoyal'},
    {trx:'trxVader'},
    {checkstat:'otpOpenMoney',trx:'trxOpenMoney'}
  ]
  
  approveDisabled=false;
  trxdisabled=false;
  assignWBank="0";
  bankList=[
    {val:"ALHB",Name:"Allahabad Bank"},
    {val:"ADRB",Name:"Andhra Bank"},
    {val:"AXSB",Name:"Axis Bank"},
    {val:"BDHN",Name:"Bandhan Bank"},
    {val:"BOBB",Name:"Bank Of Baroda"},
    {val:"BOIB",Name:"Bank of India"},
    {val:"CNRB",Name:"Canara Bank"},
    {val:"HDFC",Name:"HDFC Bank"},
    {val:"FEDB",Name:"Federal Bank LTD"},
    {val:"ICBB",Name:"ICICI Bank"},
    {val:"IDBI",Name:"IDBI Bank"},
    {val:"IDFC",Name:"IDFC Bank"},
    {val:"INDB",Name:"Indian Bank"},
    {val:"IDSB",Name:"IndusInd Bank"},
    {val:"IPPB",Name:"India Post Payment Bank"},
    {val:"JAKB",Name:"Jammu and Kashmir Bank Limited"},
    {val:"KBLB",Name:"Karnataka Bank Limited"},
    {val:"KTKB",Name:"Kotak Mahindra Bank"},
    {val:"LXVB",Name:"Lakshmi Vilas Bank"},
    {val:"PNBB",Name:"Punjab National Bank"},
    {val:"PTMB",Name:"PAYTM Payments Bank LTD"},
    {val:"SINB",Name:"South Indian Bank"},
    {val:"SBOI",Name:"State Bank of India"},
    {val:"UJVB",Name:"Ujjivan Small Finance Bank"},
    {val:"UBOI",Name:"Union Bank of India"},
  ]
  ProviderList=[];
  
  constructor(private apiservice: ApiService, private utilities : CommonFunctionService) { }
  
  ngOnInit(){
    this.getAllData();
    this.BankDataRows=[
      [{value:'Account Number',bg:'white-cell'},{value:this.userData.AccountNumber,bg:'white-cell'}],
      [{value:'Bank Name',bg:'white-cell'},{value:this.userData.BankName,bg:'white-cell'}],
      [{value:'Branch Name',bg:'white-cell'},{value:this.userData.BranchName,bg:'white-cell'}],
      [{value:'Holder Name',bg:'white-cell'},{value:this.userData.AccountHolderName,bg:'white-cell'}],
      [{value:'IFSC Code',bg:'white-cell'},{value:this.userData.IfscCode,bg:'white-cell'}]
    ]
  }

  getAllData(){
    this.apiservice.getRequest(config['getPayoutProviders'],'getPayoutProviders').subscribe((data: any) => {
      this.ProviderList = data;
    }, (error) => {
      console.log(error);
    });
  }
  
  onTabChange(event: any) {
    this.activeTabIndex[0] = event;
    if (this.activeTabIndex[0] == 0) {
      this.activeTabIndex[1]='Open Money';
    } else if (this.activeTabIndex[0] == 1) {
      this.activeTabIndex[1]='Pay My Recharge';
    } else if (this.activeTabIndex[0] == 2) {
      this.activeTabIndex[1]='Open Money - Royal';
    } else if (this.activeTabIndex[0] == 3) {
      this.activeTabIndex[1]='Vader Pay';
    } else if (this.activeTabIndex[0] == 4) {
      this.activeTabIndex[1]='Safex Pay';
    }
  }
  
  onBack(){
    this.onCancel.emit();
  }




  getOtp(data:any){
    if(data == '1'){
      let endsPnt = 'initiateOtp';
      this.onOTP(endsPnt);
    }else if(data == '2'){
      let endsPnt = 'initiateOtpV1';
       this.onOTP(endsPnt);
    }
  }

  onOTP(endsPoint:any){
    let apiEndPoint=this.tabConfigs[this.activeTabIndex[0]].otp;
   
    this.trxdisabled1=true;
    this.apiservice.getRequest(config[endsPoint],endsPoint).subscribe((data: any) => {
      this.trxdisabled1=false;
      if (data.ErrorCode == "1") {
        this.utilities.toastMsg('success',data.Result, data.ErrorMessage);
      }
      else {
        this.utilities.toastMsg('warning',data.Result,data.ErrorMessage);
      }
    }, (error) => {
      this.trxdisabled=false;
      console.error(error);
    }); 

  }



  getTransfer(data:any){
    let param = this.userData;
    if(data == '1'){
      let endpoint = 'approveClientPayout';
      this.onTransfer(endpoint,param);
    }else if(data == '2'){
      let endpoint = 'transferFundsUsingPayMyRecharge';
      this.onTransfer(endpoint,param);
    }else if(data == '3'){
      let endpoint = 'approveClientPayoutV1';
      this.onTransfer(endpoint,param);
    }else if(data == '4'){
      let endpoint = 'transferClientFundsUsingVaderPay';
      this.onTransfer(endpoint,param);
    }else if(data == '5'){
      let endpoint = 'transferFundViaPayconnect'; //need to check provider not coming
      this.onTransfer(endpoint,param);
    }
  }

  checkStatus(){
    this.utilities.toastMsg('warning','', 'Please');
  }
  
  onTransfer(endsPoint:any,param:any){
    this.trxdisabled=true;
    this.apiservice.sendRequest(config[endsPoint],param,endsPoint).subscribe((data: any) => {
      this.trxdisabled=false;
      if (data.ErrorCode == "1") {
        this.utilities.toastMsg('success',data.Result, data.ErrorMessage);
        this.UTRinput.setValue(data.Result);
      }
      else {
        this.utilities.toastMsg('warning',data.Result,data.ErrorMessage);
      }
    }, (error) => {
      this.trxdisabled=false;
      console.error(error);
    });
  }
  
  onApprove(){
    if(this.UTRinput.value){
      this.userData.StatusCode = this.AcceptRejectVar=='A'?"AP":"R";
      this.userData.UTRNumber = this.UTRinput.value;
      let param =  this.userData;
      this.approveDisabled=true;
      this.apiservice.sendRequest(config['setCPayout'],param).subscribe((data: any) => {
        this.approveDisabled=false;
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',data.Result, data.ErrorMessage);
          this.onBack();
        }
        else {
          this.utilities.toastMsg('warning',data.Result,data.ErrorMessage);
          
        }
      }, (error) => {
        this.approveDisabled=false;
        console.error(error);
      });
    }
    else{
      this.utilities.toastMsg('error',(this.AcceptRejectVar=='A'?"Fill UTR to Approve":"Fill Description to Reject"),"");
    }
  }
}