import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ResetProviderComponent } from './reset-provider.component';

describe('ResetProviderComponent', () => {
  let component: ResetProviderComponent;
  let fixture: ComponentFixture<ResetProviderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ResetProviderComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ResetProviderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
