import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

import _moment , {default as _rollupMoment} from 'moment';
import { apiData } from '@services/configapi';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'DD MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'DD MMMM YYYY',
  },
};

@Component({
  selector: 'app-client-payout',
  templateUrl: './client-payout.component.html',
  styleUrls: ['./client-payout.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },
    
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ]
})
export class ClientPayoutComponent implements OnInit, OnDestroy {
  @ViewChild('VewDetailsOpen') VewDetailsOpen!: TemplateRef<any>;
  @ViewChild('ApproveDialogOpen') ApproveDialogOpen!: TemplateRef<any>;
  @ViewChild('ResetDialogOpen') ResetDialogOpen!: TemplateRef<any>;
  allData:any=[];
  tableInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  detailsToView={};
  AcceptRejectVar="A";
  paginatorBlock:any=[];
  bulkPayouts=[];
  dynamicControls = [
    {que:'select',changeAction:'submit',type:'select',default:{value:"",name:'All'},options:[{value:"PD",name:'Pending'},{value:"PR",name:'In Process'},{value:"AP",name:'Approved'},{value:"RJ",name:'Rejected'},{value:"NP",name:'Not Processed'}],subque:[]},
    {que:'select1',changeAction:'submit',type:'search-select',default:{value:"",name:'All'},options:[],filteredOptions:[],subque:[]},
    {que:'Search',type:'input',subque:[]}
  ];
  collumnHeads:any = [
    [{value:'',bg:'white-drop'},{value:'Sr. No.',bg:'white-drop'},{value:'Client',bg:'white-drop'},{value:'Request Id',bg:'white-drop'},
    {value:'Amount',bg:'white-drop'},{value:'AccountHolderName',bg:'white-drop'},{value:'Account',bg:'white-drop'},
    {value:'Status',bg:'white-drop'},{value:'UTR',bg:'white-drop'},{value:'Description',bg:'white-drop'},
    {value:'Date',bg:'white-drop'},{value:'Updated',bg:'white-drop'},{value:'View',bg:'white-drop'},
    {value:'Action',bg:'white-drop'}]
  ];
  tableCollumns=this.collumnHeads;
  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[2],"ClientId":"0","Status":""};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={cpc_list:false,cpc_export:false,cpc_apmr:false};
  dateValue: any=[new Date(),new Date()];
  maxDate=new Date();
  showExportDates=false;
  ExportClicked=false;
  payoutList=[];
  WithdrawBankList=[];
  PGPayoutProviderList=[];
  safeXPayBal=[];
  personRole=JSON.parse(localStorage.getItem('personalDetails')).RoleCode;
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private dialog: MatDialog) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.cpc_list=('getPayoutData' in loading)?true:false;
      this.apiLoader.cpc_apmr=('transferFundsUsingPayMyRecharge' in loading)?true:false;
      if('dlCPayout' in loading){
        this.apiLoader.cpc_export=this.ExportClicked=true;
      }
      else{
        this.apiLoader.cpc_export=false;
        if(this.ExportClicked){
          this.showExportDates=false;
        }
      }
    });
    this.getAllData();
  }
  
  getAllData(){
    this.GetMasterData();
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['getPayoutList']).subscribe({
      next: (data:any) => {
        this.payoutList=data;
        this.dynamicControls[1].options = this.dynamicControls[1].filteredOptions = this.payoutList.map(({ Id, CompanyName }) => ({
          value: Id,
          name: CompanyName
        }));
      },
      error: (error)=> {
        console.error(error);
      }
    });
    this.apiSubscriber[1] = this.apiservice.apiRequest(apiData['getWithdrawBank']).subscribe({
      next: (data:any) => {
        this.WithdrawBankList=data;
      },
      error: (error)=> {
        console.error(error);
      }
    });
    this.apiSubscriber[2] = this.apiservice.apiRequest(apiData['getPGPayoutProvider']).subscribe({
      next: (data:any) => {
        this.PGPayoutProviderList=data;
      },
      error: (error)=> {
        console.error(error);
      }
    });
    this.apiSubscriber[3] = this.apiservice.apiRequest(apiData['getSafeXPayBal']).subscribe({
      next: (data:any) => {
        this.safeXPayBal=data;
      },
      error: (error)=> {
        console.error(error);
      }
    });
  }
  
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetMasterData();
  }
  
  GetMasterData() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['getPayoutData'],this.currentQuery).subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.tableCollumns=this.collumnHeads;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
        let bg_cell = '';
        this.allData.forEach((element:any,index:any) => {
          bg_cell = element.FirstDeposit && (element.StatusCode == 'PR' || element.StatusCode == 'P')?'blue-blink-cell':'white-cell';
          this.tableInfoData.push([
            ...((!element.PayoutVia && element.StatusCode=='PD')?[{value:false,bg:'white-cell',icon:'Checkbox'}]:[{value:'',bg:bg_cell}]),
            {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:bg_cell},
            {value:element.CompanyName,bg:bg_cell},
            {value:element.RequestId,bg:bg_cell,sufText:element.PaymentRequestId},
            {value:element.Amount,bg:bg_cell},
            {value:element.AccountHolderName,bg:bg_cell},
            {value:element.AccountNumber,bg:bg_cell},
            {value:element.StatusName,bg:bg_cell},
            {value:element.UTRNumber,bg:bg_cell,sufText:element.RefTransactionId?element.RefTransactionId:'',span_values:[element.PayoutVia],span_classes:["badge light badge-primary"]},
            {value:element.Description,bg:bg_cell},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:bg_cell,sufText:element.TimeAgo},
            {value:element.UpdatedDate?moment(element.UpdatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:bg_cell},
            {value:'',bg:bg_cell,icon:'View'},
            {bg:bg_cell,icon:'Multi',value:[
              ...((element.StatusCode=='PD' || element.StatusCode=='PR')?[{value:'Approve',bg:bg_cell,icon:'None',hrefvalue:element.FileNameServer}]:[]),
              ...((this.personRole=='SA' && element.StatusCode=='AP')?[{value:'Processing',bg:bg_cell,icon:'None'}]:[]),
              ...((element.StatusCode=='PD' || element.StatusCode=='PR')?[{value:'Reject',bg:bg_cell,icon:'None'}]:[]),
              ...((this.personRole=='SA' &&((element.StatusCode=='PD' || element.StatusCode=='PR') && element.PayoutVia))?[{value:'Reset Provider',bg:bg_cell,icon:'None'}]:[])]
            }
          ])
        });
        this.rowCount={f:this.tableInfoData[0][1].value,l:this.tableInfoData[this.tableInfoData.length-1][1].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.tableCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.error(error);
    });
  }
  
  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  onValueChange(formVal:any){
    if(formVal.col==0&&formVal.type==true){
      if (!this.bulkPayouts.includes(formVal.row)) {
        this.bulkPayouts.push(formVal.row);
      }
    }
    if(formVal.col==0&&formVal.type==false){
      const index = this.bulkPayouts.indexOf(formVal.row);
      if (index !== -1) {
        this.bulkPayouts.splice(index, 1);
      }
    }
    if(formVal.col==11 && formVal.type=='Users'){
      window.open('/users/playerdetailview/'+this.allData[formVal.row].UserId, '_blank');
    }
    if(formVal.col==12 && formVal.type=='View'){
      this.detailsToView=this.allData[formVal.row];
      this.BDataOpenPopup()
    }
    if(formVal.col==13 && formVal.type=='Process'){
      this.detailsToView=this.allData[formVal.row];
      this.ProcessWithdrawal();
    }
    if(formVal.col==13 && formVal.type=='Approve'){
      this.AcceptRejectVar="A";
      this.detailsToView=this.allData[formVal.row];
      this.ApproveOpenPopup();
    }
    if(formVal.col==13 && formVal.type=='Reject'){
      this.AcceptRejectVar="R";
      this.detailsToView=this.allData[formVal.row];
      this.ApproveOpenPopup();
    }
    if(formVal.col==13 && formVal.type=='Reset Provider'){
      this.AcceptRejectVar="Reset";
      this.detailsToView=this.allData[formVal.row];
      this.ResetOpenPopup();
      // this.tableInfoData[formVal.row][13].value = '';
    }
  }
  
  BDataOpenPopup() {
    let dialogRef = this.dialog.open(this.VewDetailsOpen, {
      width: '600px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  closePopup(){
    this.GetMasterData();
    this.dialog.closeAll();
  }
  
  ApproveOpenPopup() {
    let dialogRef = this.dialog.open(this.ApproveDialogOpen, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  ResetOpenPopup() {
    let dialogRef = this.dialog.open(this.ResetDialogOpen, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  doBulkPMR(){
    this.bulkPayouts.forEach((element) => {
      let param = {Id:this.allData[element].Id+''};
      let endpoint = 'transferFundsUsingPayMyRecharge';
      this.onTransferBulk(endpoint,param,element);
    });
  }
  
  onTransferBulk(endPoint:any,param:any,tIndex:number){
    this.apiservice.apiRequest(apiData[endPoint],param).subscribe((data: any) => {
      this.tableInfoData[tIndex][8].value=data.Result;
    }, (error) => {
      console.error(error);
    });
  }
  
  ProcessWithdrawal(){
    this.apiservice.apiRequest(apiData['processWithdrawal'], this.detailsToView).subscribe((data: any) => {
      if(data.ErrorCode=='1'){
        this.utilities.toastMsg("success", "Success", data.ErrorMessage);
        this.GetMasterData();
      }
      else{
        this.utilities.toastMsg("error", "Error", data.ErrorMessage);
      }
    }, (error) => {
      this.utilities.toastMsg("error", "Can not process", '');
      console.error(error);
    });
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Status=formVal.select.value;
    this.currentQuery.ClientId=formVal.select1.value;
    this.currentQuery.Search=formVal.Search.value;
    this.currentQuery.PageNo = 1;
    this.GetMasterData();
  }
  
  
  DownloadWithdrawalRequestData() {
    let d1 = (moment(this.dateValue[0]).format("DD/MM/yyyy HH:mm"));
    let d2 = (moment(this.dateValue[1]).format("DD/MM/yyyy HH:mm"));
    let request = "?ClientId="+this.currentQuery.ClientId+"&status="+this.currentQuery.Status+"&StartDateTime="+d1+"&EndDateTime="+d2;
    let docname = 'ClientPayout_Download'+d1+'_'+d2;
    this.apiservice.exportExcel(config['dlCPayout'] + request,docname,'dlCPayout');
  }
  
  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    this.apiSubscriber.forEach(subscription => {
      subscription.unsubscribe();
    });
  }
}
