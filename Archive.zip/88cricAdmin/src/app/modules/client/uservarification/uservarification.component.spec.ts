import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UservarificationComponent } from './uservarification.component';

describe('UservarificationComponent', () => {
  let component: UservarificationComponent;
  let fixture: ComponentFixture<UservarificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UservarificationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UservarificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
