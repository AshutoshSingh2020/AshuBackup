import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-block-upi',
  templateUrl: './block-upi.component.html',
  styleUrls: ['./block-upi.component.scss']
})

export class BlockUpiComponent implements OnInit {
	@Input() upiData:any;
	@Output() onSave = new EventEmitter<any>();
	@Output() onCancel = new EventEmitter<any>();
	
	submitDisabled=false;
	
	constructor(private apiservice: ApiService, private utilities : CommonFunctionService) { }
	
	ngOnInit(){
	}
	
	onBack(){
		this.onCancel.emit();
	}
	
	onSubmit(){
		this.submitDisabled=true;
		this.apiservice.apiRequest(apiData['blockUserUPI'],this.upiData).subscribe((data: any) => {
			if (data.ErrorCode === "1") {
				this.utilities.toastMsg('success',"Success", data.ErrorMessage);
				setTimeout(()=>{
					this.onCancel.emit();
					this.onSave.emit();
				}, 1000);
			}
			else {
				this.utilities.toastMsg('warning',"Failed",data.Result + " : " + data.ErrorMessage);
				this.onSave.emit();
			}
		}, (error) => {
			this.submitDisabled=false;
			console.log(error);
		});
	}
}