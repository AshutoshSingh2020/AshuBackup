import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockUpiComponent } from './block-upi.component';

describe('BlockUpiComponent', () => {
  let component: BlockUpiComponent;
  let fixture: ComponentFixture<BlockUpiComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BlockUpiComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BlockUpiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
