import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup } from "@angular/forms";

import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-add-payout-balance',
  templateUrl: './add-payout-balance.component.html',
  styleUrls: ['./add-payout-balance.component.scss']
})

export class AddPayoutBalanceComponent implements OnInit {
  @Input() submitBtn!:boolean;
  @Input() clientList=[];
  @Output() onSave = new EventEmitter<any>();
  @Output() onCancel = new EventEmitter<any>();
  
  submitDisabled=false;
  
  pbUserForm!: FormGroup;
  clientBalance:'';
  balanceRegex = /(?<=Bal-)\d+(\.\d{2})?/;
  
  constructor(private formBuilder: FormBuilder, private apiservice: ApiService, private utilities : CommonFunctionService) { }
  
  ngOnInit(){
    this.initializeForm();
    this.pbUserForm.get('ClientId').valueChanges.subscribe((val) => {
      let cbal = this.clientList.find(obj => obj.Id == val)?.CompanyName;
      const match = cbal.match(this.balanceRegex);
      this.clientBalance = match ? match[0] : null;
    })
  }
  
  initializeForm(){
    this.pbUserForm = this.formBuilder.group({
      ClientId: [""],
      CreditAmount: [""],
      Description: [""]
    });
  }
  
  onBack(){
    this.onCancel.emit();
  }
  
  onSubmit(){
    if(this.pbUserForm.invalid){
      this.utilities.toastMsg('warning','Please enter valid Data!','');
      return;
    }
    else{
      this.submitDisabled=true;
      let FormValue = this.pbUserForm.getRawValue();
      if(!FormValue.ClientId){
        this.utilities.toastMsg('warning',"Please provide Company Name!",'');
        this.submitDisabled=false;
        return;
      }
      else if(!FormValue.CreditAmount){
        this.utilities.toastMsg('warning',"Please provide Credit Amount!",'');
        this.submitDisabled=false;
        return;
      }
      else if(!FormValue.Description){
        this.utilities.toastMsg('warning',"Please provide Description!",'');
        this.submitDisabled=false;
        return;
      }
      this.apiservice.apiRequest(apiData['savePayoutBal'],FormValue).subscribe((data: any) => {
        this.submitDisabled=false;
        if (data.ErrorCode === "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.onCancel.emit();
          this.onSave.emit();
        }
        else {
          this.utilities.toastMsg('warning',"Failed",data.Result + " : " + data.ErrorMessage);
          this.submitDisabled=false;
        }
      }, (error) => {
        console.log(error);
        this.submitDisabled=false;
      });
    }
  }
}
