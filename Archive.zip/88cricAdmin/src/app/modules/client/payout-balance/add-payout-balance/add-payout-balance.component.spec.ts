import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPayoutBalanceComponent } from './add-payout-balance.component';

describe('AddPayoutBalanceComponent', () => {
  let component: AddPayoutBalanceComponent;
  let fixture: ComponentFixture<AddPayoutBalanceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddPayoutBalanceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddPayoutBalanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
