import { Component, OnDestroy, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { DatePipe } from '@angular/common';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import moment from 'moment';
import { MatDialog } from '@angular/material/dialog';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-payout-balance',
  templateUrl: './payout-balance.component.html',
  styleUrls: ['./payout-balance.component.scss'],
  providers: [DatePipe]
})

export class PayoutBalanceComponent implements OnInit, OnDestroy {
  @ViewChild('AddPBPopUp') AddPBPopUp!: TemplateRef<any>;
  assignList: any = [];
  allData:any=[];
  tableInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,200,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  companyList=[];
  maxDate=new Date();
  maxDF=this.datePipe.transform(this.maxDate, 'yyyy-MM-dd');
  
  dynamicControls = [
    {que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]},
    {que:'Search',type:'input',subque:[]}
  ];
  
  collumnHeads:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'Amount',bg:'white-drop'},
    {value:'Description',bg:'white-drop'},{value:'Added By',bg:'white-drop'},{value:'Date',bg:'white-drop'}]
  ];
  tableCollumns=this.collumnHeads;
  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[0],"StartDateTime": this.maxDF,"EndDateTime": this.maxDF};

  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={cdc_list:false};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private datePipe: DatePipe, private dialog: MatDialog) { }
  
  ngOnInit(): void
  {
    this.initSubscribe();
    this.getAllData();
  }
  
  getAllData()
  {
    this.apiservice.apiRequest(apiData['getClientPayoutList']).subscribe((data: any) => {
      this.companyList = data;
    }, (error) => {
      console.error(error);
    });
    this.GetAllTrx();
  }

  initSubscribe()
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.cdc_list=('getPayoutBal' in loading);
    });
  }

  resetSubscribe()
  {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
  
  initializeData()
  {
    this.resetSubscribe();
    this.allData = [];
    this.tableInfoData = [];
    this.initSubscribe();
  }
  
  onPaginatorChange(paginatorQuery:any)
  {
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllTrx();
  }
  
  GetAllTrx()
  {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['getPayoutBal'], this.currentQuery).subscribe({
      next: (data:any) => {
        this.allData=data;
      if(this.allData[0]){
        this.tableCollumns=this.collumnHeads;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
            {value:element.ClientName,bg:'white-cell'},
            {value:element.CreditAmount,bg:'white-cell'},
            {value:element.Description,bg:'white-cell'},
            {value:element.UserName,bg:'white-cell'},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'}
          ])
        });
        this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.tableCollumns=this.utilities.TableDataNone;
      }
      },
      error: (error)=> {
        console.log(error);
      }
    });
  }
  
  setPaginator()
  {
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.Search.value;
    this.currentQuery.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'yyyy-MM-dd');
    this.currentQuery.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'yyyy-MM-dd');
    this.currentQuery.PageNo = 1;
    this.GetAllTrx();
  }

  AddPBOpenPopUp() {
    let dialogRef = this.dialog.open(this.AddPBPopUp, {
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
    })
  }
  
  closePopup(){
    this.dialog.closeAll();
  }

  ngOnDestroy()
  {
    this.resetSubscribe();
  }
}