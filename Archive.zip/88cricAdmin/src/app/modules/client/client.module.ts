import { NgModule } from '@angular/core';
import { ClientRoutingModule } from './client-routing.module';
import { SharedModule } from '@shared/shared.module';
import { ClientPayoutComponent } from './client-payout/client-payout.component';
import { ViewDetailsComponent } from './client-payout/view-details/view-details.component';
import { ApproveDetailsComponent } from './client-payout/approve-details/approve-details.component';
import { ClientDepositComponent } from './client-deposit/client-deposit.component';
import { UservarificationComponent } from './uservarification/uservarification.component';
import { BlockUpiComponent } from './uservarification/block-upi/block-upi.component';
import { ClientAddDepositComponent } from './client-add-deposit/client-add-deposit.component';

import { PayoutBalanceComponent } from './payout-balance/payout-balance.component';
import { AddPayoutBalanceComponent } from './payout-balance/add-payout-balance/add-payout-balance.component';

import { ResetProviderComponent } from './client-payout/reset-provider/reset-provider.component';

@NgModule({
  declarations: [
    ClientPayoutComponent,
    ViewDetailsComponent,
    ApproveDetailsComponent,
    ClientDepositComponent,
    UservarificationComponent,
    BlockUpiComponent,
    ClientAddDepositComponent,
    PayoutBalanceComponent,
    AddPayoutBalanceComponent,
    ResetProviderComponent
  ],
  imports: [
    ClientRoutingModule,
    SharedModule,
  ]
})
export class ClientModule { }
