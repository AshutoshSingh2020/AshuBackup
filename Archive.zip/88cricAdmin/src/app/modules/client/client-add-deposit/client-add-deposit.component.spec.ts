import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ClientAddDepositComponent } from './client-add-deposit.component';

describe('ClientAddDepositComponent', () => {
  let component: ClientAddDepositComponent;
  let fixture: ComponentFixture<ClientAddDepositComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ClientAddDepositComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ClientAddDepositComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
