import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { CreateUserComponent } from './create-user/create-user.component';
import { PlayerListComponent } from './player-list/player-list.component';
import { PlayerDetailsComponent } from './player-details/player-details.component';

import { PaymentClickComponent } from './payment-click/payment-click.component';

import { BlockedUsersComponent } from './blocked-users/blocked-users.component';
const routes: Routes = [
  {
    path: '',
    redirectTo: 'createuser',
    pathMatch: 'full'
  },
  {
    path: 'createuser',
    component: CreateUserComponent
  },
  {
    path: 'blockuser',
    component: BlockedUsersComponent
  },
  {
    path: 'searchplayer',
    component: PlayerListComponent
  },
  {
    path: 'playerdetailview/:id',
    component: PlayerDetailsComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRoutingModule { }