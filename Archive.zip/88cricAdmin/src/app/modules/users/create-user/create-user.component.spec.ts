import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateUserComponent } from './create-user.component';
import { BrowserModule,By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DebugElement } from '@angular/core';
import { ApiService } from '@services/api.service';
 import { HttpClientTestingModule } from  '@angular/common/http/testing'
 import { Observable, of } from 'rxjs';
 import { CommonFunctionService } from '@services/common-function.service';
 import { ToastrModule, ToastrService } from 'ngx-toastr';
 import { UsersModule } from '../users.module';
 class MockApiService {
  sendRequest() {
    // Mock implementation for sendRequest method
    return new Observable((observer) => {
      // Simulate a successful response
      observer.next(/* mock response here */);

      // Complete the observable
      observer.complete();
    });
  }
}
describe('CreateUserComponent', () => {
  let component: CreateUserComponent;
  let fixture: ComponentFixture<CreateUserComponent>;
  let de : DebugElement;
  let el : HTMLElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateUserComponent ],
      imports:[
        BrowserModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientTestingModule,
        ToastrModule.forRoot(),
        UsersModule

      ],
      providers: [  { provide: ApiService, useClass: MockApiService },
        CommonFunctionService,
        ToastrService
      ]
    })
    .compileComponents();
    fixture = TestBed.createComponent(CreateUserComponent);
    component = fixture.componentInstance;
    de = fixture.debugElement.query(By.css('form'));
    component.ngOnInit();
    el = de.nativeElement;
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should submit to true ', () => {
    component.onSubmit();
    expect(component.submitDisabled).toBeTruthy;
  });
  it('form should submit to invalid ', () => {
    component.adduser.controls['UserName'].setValue('');
    component.adduser.controls['FName'].setValue('');
    component.adduser.controls['LName'].setValue('');
    component.adduser.controls['Mobile'].setValue('');
    component.adduser.controls['DOB'].setValue('');
    component.adduser.controls['CurrencyType'].setValue('');
    expect(component.adduser.valid).toBeFalsy;
  });
  it('form should submit to valid ', () => {
    component.adduser.controls['UserName'].setValue('ashu');
    component.adduser.controls['FName'].setValue('Ashutosh');
    component.adduser.controls['LName'].setValue('Kumar');
    component.adduser.controls['Mobile'].setValue('8899776655');
    component.adduser.controls['DOB'].setValue('2023/04/05');
    component.adduser.controls['CurrencyType'].setValue('KZT');
    expect(component.adduser.valid).toBeTruthy;
  });
});
