import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { apiData } from '@services/configapi';

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'DD MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'DD MMMM YYYY',
  },
};

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ]
})

export class CreateUserComponent implements OnInit {
  todayDate = new Date();
  submitDisabled=false;
  disable = false
  resetDisable = true;
  adduser!: FormGroup;
  TransactionTypeList = [
    {cc:'INR',cn:'INR'},
    {cc:'MYR',cn:'MYR'},
    {cc:'KZT',cn:'KZT'},
    {cc:'NPR',cn:'NPR'},
    {cc:'USD',cn:'USD'},
    {cc:'GBP',cn:'GBP (Pound)'},
    {cc:'IDR',cn:'IDR'},
    {cc:'SGD',cn:'SGD'}
  ];
  userPass='';
  constructor(private formBuilder: FormBuilder, private apiservice: ApiService, private utilities : CommonFunctionService) { }
  
  ngOnInit(){
    this.initializeForm();
  }
  
  initializeForm(){
    this.adduser = this.formBuilder.group({
      UserName: ["", [Validators.required]],
      FName: ["", [Validators.required]],
      LName: ["", [Validators.required]],
      Mobile: ["", [Validators.required,Validators.pattern('[6-9]\\d{9}')]],
      DOB: ["", [Validators.required]],
      CurrencyType: ["", [Validators.required]]
    });
  }
  resetAll(){
    window.location.reload();
    // this.adduser.reset();
    // this.adduser.markAsPristine(); //
    // this.adduser.markAsUntouched();
    // this.initializeForm();
    // this.submitDisabled=false;
    // this.disable = false;
    // this.userPass='';
    // this.resetDisable = true;
  }
  onSubmit(){
    if(this.adduser.invalid){
      this.utilities.toastMsg('warning','Please enter Required Data!','');
    }
    else{
      this.submitDisabled=true;
      let FormValue = this.adduser.getRawValue();
      this.apiservice.apiRequest(apiData['saveUserProfile'], FormValue).subscribe((data: any) => {
        this.submitDisabled = false;
        if (data) {
          if (data.n == 1) {
            this.resetDisable = false;
            this.disable=true;
            this.utilities.toastMsg('success',"Success", data.Msg);
            this.userPass = data.Msg;
            this.adduser.disable();
          } else {
            this.utilities.toastMsg('error',"Failed",data.Msg);
          }
        }
      }, (error) => {
        console.log(error);
        this.submitDisabled = false;
      });
    }
  }
}