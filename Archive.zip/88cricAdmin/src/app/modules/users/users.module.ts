import { NgModule } from '@angular/core';
import { UsersRoutingModule } from './users-routing.module';
import { SharedModule } from '@shared/shared.module';
import { CreateUserComponent } from './create-user/create-user.component';
import { PlayerListComponent } from './player-list/player-list.component';
import { PlayerDetailsComponent } from './player-details/player-details.component';
import { PlayerStatementComponent } from './player-statement/player-statement.component';
import { PlayerDepositComponent } from './player-deposit/player-deposit.component';
import { PlayerWithdrawComponent } from './player-withdraw/player-withdraw.component';
import { BankDetailsComponent } from './bank-details/bank-details.component';
import { OnlineDepositWithdrawComponent } from './online-deposit-withdraw/online-deposit-withdraw.component';
import { BlockUserComponent } from './block-user/block-user.component';
import { PlayerCallLogComponent } from './player-call-log/player-call-log.component';
import { PlayerGamePlayedComponent } from './player-game-played/player-game-played.component';
import { PlayerOnlineDepositComponent } from './player-online-deposit/player-online-deposit.component';
import { PaymentClickComponent } from './payment-click/payment-click.component';
import { BlockPayComponent } from './payment-click/block-pay/block-pay.component';
import { BlockedUsersComponent } from './blocked-users/blocked-users.component';


@NgModule({
  declarations: [
    CreateUserComponent,
    PlayerListComponent,
    PlayerDetailsComponent,
    PlayerStatementComponent,
    PlayerDepositComponent,
    PlayerWithdrawComponent,
    BankDetailsComponent,
    OnlineDepositWithdrawComponent,
    BlockUserComponent,
    PlayerCallLogComponent,
    PlayerGamePlayedComponent,
    PlayerOnlineDepositComponent,
    PaymentClickComponent,
    BlockPayComponent,
    BlockedUsersComponent,
  
  ],
  imports: [
    UsersRoutingModule,
    SharedModule,
  ]
})
export class UsersModule { }
