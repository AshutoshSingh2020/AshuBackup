import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';

import _moment , {default as _rollupMoment} from 'moment';
import { apiData } from '@services/configapi';

const moment = _rollupMoment || _moment;

@Component({
  selector: 'app-blocked-users',
  templateUrl: './blocked-users.component.html',
  styleUrls: ['./blocked-users.component.scss']
})
export class BlockedUsersComponent implements OnInit {

  @ViewChild('BlockUpiPopUp') BlockUpiPopUp!: TemplateRef<any>;
  allData:any=[];
  currenUPIData={};
  tableInfoData:any=[];
  dynamicControls = [
    {que:'Search',type:'input',subque:[]}
  ];
  UPIColHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},
    {value:'Mobile',bg:'white-drop'},{value:'Balance',bg:'white-drop'},{value:'Action',bg:'white-drop'}]
  ]
  UPIDataCollumns=[];
  currentQuery={ "Search": "", "PageSize": 10, "PageNo": 1 };
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  apiLoader={uvc_list:false};
  dIndex={status:{row:0,col:0,use:false},depositAccess:{row:0,col:0,use:false},IMPSAccess:{row:0,col:0,use:false},roleChange:{row:0,col:0,use:false}};

  paginatorBlock:any=[];
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];

  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }

  ngOnInit(): void
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.uvc_list=('getUsersListBlock' in loading)?true:false;
      if(this.dIndex.status.use){
        this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon = ('changeUserStatus' in loading)?'Loading':'Toggle';
       }
    });
    this.getAllData();
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }

  initializeData(){
    this.allData=[];
    this.tableInfoData=[];
    this.dIndex={status:{row:0,col:0,use:false},depositAccess:{row:0,col:0,use:false},IMPSAccess:{row:0,col:0,use:false},roleChange:{row:0,col:0,use:false}};
  }

  getAllData()
  {
    this.initializeData();
    this.apiservice.apiRequest(apiData['getUsersListBlock'], this.currentQuery).subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.UPIDataCollumns=this.UPIColHeaders;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
            {value:element.FName + element.LName,bg:'white-cell'},
            {value:element.UserName,bg:'white-cell'},
            {value:element.Mobile,bg:'white-cell'},
            {value:element.CurrencyType +" "+element.AccountBalance ,bg:'white-cell'},
            {value:element.StatusId,bg:'white-cell',icon:'Toggle'},
          ])
        });
        this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.UPIDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }


  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.Search.value;
    this.getAllData();
  }
  onValueChange(formVal:any)
  {
    if(formVal.col==5){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      this.currenUPIData=this.allData[formVal.row];
      this.saveStatusBlock(this.currenUPIData);
    }
  }

  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.getAllData();
  }
  
  saveStatusBlock(param:any){
    this.apiservice.apiRequest(apiData['changeUserStatus'],param).subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value=!this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value;
          this.getAllData();
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }

}
