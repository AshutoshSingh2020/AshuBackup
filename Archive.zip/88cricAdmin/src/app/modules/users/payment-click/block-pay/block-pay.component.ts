import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';

@Component({
  selector: 'app-block-pay',
  templateUrl: './block-pay.component.html',
  styleUrls: ['./block-pay.component.scss']
})

export class BlockPayComponent implements OnInit {
	@Input() preData:any;
	@Output() onSave = new EventEmitter<any>();
	@Output() onCancel = new EventEmitter<any>();
	
	submitDisabled=false;
	
	constructor(private apiservice: ApiService, private utilities : CommonFunctionService) { }
	
	ngOnInit(){
	}
	
	onBack(){
		this.onCancel.emit();
	}
	
	onSubmit(){
		this.submitDisabled=true;
		this.apiservice.sendRequest(config['blockUserPayment'],this.preData).subscribe((data: any) => {
			if (data.ErrorCode === "1") {
				this.utilities.toastMsg('success',"Success", data.ErrorMessage);
				setTimeout(()=>{
					this.onCancel.emit();
					this.onSave.emit();
				}, 1000);
			}
			else {
				this.utilities.toastMsg('warning',"Failed",data.Result + " : " + data.ErrorMessage);
				this.onSave.emit();
			}
		}, (error) => {
			this.submitDisabled=false;
			console.log(error);
		});
	}
}