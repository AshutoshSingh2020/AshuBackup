import { Component, OnInit } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-player-list',
  templateUrl: './player-list.component.html',
  styleUrls: ['./player-list.component.scss']
})
export class PlayerListComponent implements OnInit {
  AllUserinfo:any=[];
  UserinfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  dynamicControls = [{que:'Search',type:'input',subque:[]}];
  UserCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Id',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},{value:'Mobile',bg:'white-drop'},{value:'Amount',bg:'white-drop'},{value:'Date',bg:'white-drop'},{value:'View',bg:'white-drop'}]
  ]
  UserDataCollumns=this.UserCollumnHeaders;
  UserCollumnLoading = false;
  currentQuery={"Search": "","Pagination": 1,"PageSize": this.pageCount[0]};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService) { }
  
  ngOnInit(): void {
    this.GetAllUsers();
  }
  
  initializeData()
  {
    this.UserCollumnLoading = true;
    this.AllUserinfo = [];
    this.UserinfoData = [];
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.Pagination = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.Pagination = paginatorQuery.pageNo;
    }
    this.GetAllUsers();
  }
  
  GetAllUsers() {
    this.initializeData();
    this.apiservice.apiRequest(apiData['getAllPlayer'], this.currentQuery).subscribe((data: any) => {
      this.UserCollumnLoading = false;
      this.AllUserinfo=data;
      if(this.AllUserinfo[0]){
        this.UserDataCollumns=this.UserCollumnHeaders;
        this.pagesTotal=Math.ceil(this.AllUserinfo[0].TotalCount/this.currentQuery.PageSize);
        this.AllUserinfo.forEach((element:any,index:any) => {
          this.UserinfoData.push([
          {value:((this.currentQuery.Pagination-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
          {value:element.UserId,bg:'white-cell'},
          {value:element.FName,bg:'white-cell'},
          {value:element.UserName,bg:'white-cell'},
          {value:element.Mobile,bg:'white-cell'},
          {value:element.CurrencyType+' '+this.utilities.roundOffNum(element.AccountBalance),bg:'white-cell'},
          {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
          {value:'',bg:'white-cell',icon:'View'}
          ])
        });
        this.rowCount={f:this.UserinfoData[0][0].value,l:this.UserinfoData[this.UserinfoData.length-1][0].value,t:this.AllUserinfo[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.UserDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      this.UserCollumnLoading = false;
      console.log(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.Pagination <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.Pagination - 3; i <= this.currentQuery.Pagination + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  onValueChange(formVal:any){
    if(formVal.col==7 && formVal.type=='View'){
      window.open('/users/playerdetailview/'+this.AllUserinfo[formVal.row].UserId, '_blank');
    }
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.Search.value;
    this.currentQuery.Pagination = 1;
    this.GetAllUsers();
  }
}