import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deposit-withdraw',
  templateUrl: './deposit-withdraw.component.html',
  styleUrls: ['./deposit-withdraw.component.scss']
})
export class DepositWithdrawComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
