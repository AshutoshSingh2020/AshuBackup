import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { DepositWithdrawRoutingModule } from './deposit-withdraw-routing.module';
import { DepositWithdrawComponent } from './deposit-withdraw/deposit-withdraw.component';


@NgModule({
  declarations: [
    DepositWithdrawComponent
  ],
  imports: [
    DepositWithdrawRoutingModule,
    SharedModule,
  
  ]
})
export class DepositWithdrawModule { }
