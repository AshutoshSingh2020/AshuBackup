import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WinLoseComponent } from './win-lose/win-lose.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'win-lose',
    pathMatch: 'full'
  },
  {
    path: 'win-lose',
    component: WinLoseComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class WinLoseRoutingModule { }
