import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { WinLoseRoutingModule } from './win-lose-routing.module';
import { WinLoseComponent } from './win-lose/win-lose.component';


@NgModule({
  declarations: [
    WinLoseComponent
  ],
  imports: [
    WinLoseRoutingModule,
    SharedModule,
  ]
})
export class WinLoseModule { }
