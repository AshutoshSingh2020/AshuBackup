import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { DepositRoutingModule } from './deposit-routing.module';
import { DepositViewComponent } from './deposit-view/deposit-view.component';


@NgModule({
  declarations: [
    DepositViewComponent
  ],
  imports: [
    DepositRoutingModule,
    SharedModule,
    
  ]
})
export class DepositModule { }
