import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DepositViewComponent } from './deposit-view/deposit-view.component';

const routes: Routes = [
  {
    path:'',
    redirectTo:'deposit-view',
    pathMatch:'full'
    },
    {
      path:'deposit-view',
      component:DepositViewComponent
    }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DepositRoutingModule { }
