import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { apiData } from '@services/configapi';
import { Subscription } from 'rxjs';
import {MomentDateAdapter, MAT_MOMENT_DATE_ADAPTER_OPTIONS} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

import _moment , {default as _rollupMoment} from 'moment';

const moment = _rollupMoment || _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY',
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'DD MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'DD MMMM YYYY',
  },
};

@Component({
  selector: 'app-deposit-view',
  templateUrl: './deposit-view.component.html',
  styleUrls: ['./deposit-view.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ]
})
export class DepositViewComponent implements OnInit {
  allData:any=[];
  tableInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  udataToView={};
  AcceptRejectVar="A";
  paginatorBlock:any=[];
  dynamicControls = [
    {que:'Search',type:'input',subque:[]}
  ];
  UserCollumnHeaders:any = [
    [
      {value:'Sr. No.',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},{value:'Mobile',bg:'white-drop'},{value:'Amount',bg:'white-drop'}, {value:'Description',bg:'white-drop'},{value:'Date',bg:'white-drop'}
  ]
  ];
  UserDataCollumns=this.UserCollumnHeaders;
  currentQuery={"Search": "","Pagination": 1,"PageSize": this.pageCount[2]};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={wrc_list:false,wrc_export:false};
  dateValue: any=[new Date(),new Date()];
  maxDate=new Date();
  showExportDates=false;
  ExportClicked=false;
  allProviderBalance=[];
  personRole=JSON.parse(localStorage.getItem('personalDetails')).RoleCode;
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private dialog: MatDialog) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.wrc_list=('getdepositddata' in loading)?true:false;
    });
    this.GetMasterData();
  }

  
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.Pagination = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.Pagination = paginatorQuery.pageNo;
    }
    this.GetMasterData();
  }
  
  GetMasterData() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['getdepositddata'], this.currentQuery).subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.UserDataCollumns=this.UserCollumnHeaders;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
        let bg_cell = ''
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:((this.currentQuery.Pagination-1)*this.currentQuery.PageSize)+(index+1),bg:bg_cell},
            {value:element.FName,bg:bg_cell},
            {value:element.UserName,bg:bg_cell},
            {value:element.Mobile,bg:bg_cell},
            {value:element.AccountBalance,bg:bg_cell},
            {value:element.Description,bg:bg_cell},
            {value:element.CreatedDate?moment(element.CreatedDate).format("  h:mm:ss A, DD-MMM-yyyy"):'',bg:bg_cell,sufText:element.TimeAgo},
          ])
        });
        this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.UserDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.error(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.Pagination <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.Pagination - 3; i <= this.currentQuery.Pagination + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.Search.value;
    this.currentQuery.Pagination = 1;
    this.GetMasterData();
  }


  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
}
