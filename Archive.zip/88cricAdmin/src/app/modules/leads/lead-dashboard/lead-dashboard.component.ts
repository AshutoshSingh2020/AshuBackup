import { Component, OnInit } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { Chart } from 'chart.js';
import { DatePipe } from '@angular/common';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-lead-dashboard',
  templateUrl: './lead-dashboard.component.html',
  styleUrls: ['./lead-dashboard.component.scss'],
  providers:[DatePipe]
})

export class LeadDashboardComponent implements OnInit {
  dkCols=localStorage.getItem('dkMode')=='sd-dark'?true:false;
  dateValue1:any;
  dateValue2:any;
  DataLoader1 = false;
  DataLoader2 = false;
  todayDate = new Date();
  maxDate=new Date();
  maxDate1=new Date();

  maxDF=this.datePipe.transform(this.maxDate, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
  maxDF1=this.datePipe.transform(this.maxDate1, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
  dIndex={status:{row:0,col:0,use:false}};
  TPCollumns  = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'Registered',bg:'white-drop'},
    {value:'Deposit',bg:'white-drop'},{value:'Played',bg:'white-drop'},{value:'Dialled',bg:'white-drop'},
    {value:'Connected',bg:'white-drop'},{value:'Follow Up',bg:'white-drop'}]
  ]

  dynamicControls = [
    {que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]},
  ];
  dynamicControls1= [
    {que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate1,startDate:this.maxDate1,endDate:this.maxDate1,subque:[]},
  ];
  currentQuery={"StartDateTime": this.maxDF,"EndDateTime": this.maxDF};
  currentQuery1 = {"StartDateTime": this.maxDF1,"EndDateTime": this.maxDF1};
  TPDataCollumns = this.TPCollumns;
  allTopPerData:any=[];
  TopPerData:any=[];
  ChartDataMsg=false;

  AgentTimeList: any = [];
  
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private datePipe:DatePipe) { }

  ngOnInit(): void {
    this.getAllData();
  }

  getAllData(){
    let currentday = new Date;
    this.dateValue1 = [currentday, currentday];
    this.GetLeadPerformerData(this.dateValue1);
    this.dateValue2 = [currentday, currentday];
    this.GetAgentTiming(this.dateValue2);
  }

  searchdata1(dataVal:any) {
    this.GetLeadPerformerData(dataVal);
  }
  
  searchdata2(dataVal:any) {
    this.GetAgentTiming(dataVal);
  }

  GetLeadPerformerData(dateValue:any) {
    let request = {"StartDateTime": moment(dateValue[0]).format("MM-DD-yyyy hh:mm a"), "EndDateTime": moment(dateValue[1]).format("MM-DD-yyyy 23:59:59")};
    this.DataLoader1=true;
    this.apiservice.apiRequest(apiData['GetLeadPerformer'], request).subscribe((data: any) => {
      this.DataLoader1=false;
      this.allTopPerData=data;
      this.TopPerData=[];
      if(this.allTopPerData[0]){
        this.TPDataCollumns = this.TPCollumns;
        this.allTopPerData.forEach((element:any,index:any) => {
          this.TopPerData.push([
            {value:(index+1),bg:'white-cell'},
            {value:element.UserName,bg:'white-cell'},
            {value:element.RegisterCount,bg:'white-cell'},
            {value:element.DepositCount,bg:'white-cell'},
            {value:element.GamePlayed,bg:'white-cell'},
            {value:element.TotalDial,bg:'white-cell'},
            {value:element.TotalPick,bg:'white-cell'},
            {value:element.FollowUpCount,bg:'white-cell'}
          ])
        });
      }
      else{
        this.TPDataCollumns = this.utilities.TableDataNone;
      }

    }, (error) => {
      this.DataLoader1=false;
      console.error(error);
    });
  }
  getSearchQuery(formVal:any){
    this.currentQuery.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
    this.currentQuery.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
    this.dateValue1 = [this.currentQuery.StartDateTime, this.currentQuery.EndDateTime];
    this.GetLeadPerformerData(this.dateValue1);
  }
  getSearchQuery1(formVal:any){
    this.currentQuery1.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
    this.currentQuery1.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'yyyy-MM-ddTHH:mm:ss.SSS') + 'Z';
    this.dateValue1 = [this.currentQuery1.StartDateTime, this.currentQuery1.EndDateTime];
    this.GetAgentTiming(this.dateValue1);

  }
  GetAgentTiming(dateValue:any) {
    let request = {"StartDateTime": moment(dateValue[0]).format("MM-DD-yyyy hh:mm a"), "EndDateTime": moment(dateValue[1]).format("MM-DD-yyyy 23:59:59")};
    this.DataLoader2=true;
    this.ChartDataMsg=true;
    this.apiservice.apiRequest(apiData['GetAgentTiming'], request).subscribe((data: any) => {
      this.DataLoader2=false;
      this.AgentTimeList = data;
      if(this.AgentTimeList[0]){
        this.drawlinecahrt(this.AgentTimeList);
      }
      else{
        this.ChartDataMsg=false;
      }
    }, (error) => {
      this.DataLoader2=false;
      this.ChartDataMsg=false;
      console.error(error);
    });
  }

  drawlinecahrt(datalist: any) {
    let labeldataset: any = [];
    let result: any = [];
    datalist.forEach((depositElement: any, index: any) => {
      if (!labeldataset.includes(depositElement.strDate)) {
        labeldataset.push(depositElement.strDate);
        result[depositElement.UserName] = result[depositElement.UserName] || [];
        result[depositElement.UserName].push(depositElement);
        return result;
      }
    });
    let DatasetList = [];
    for (let i = 0; i < Object.keys(result).length; i++) {
      DatasetList.push({ label: Object.keys(result)[i], borderColor: this.get_random_color(), data: this.MakeCallCount(labeldataset, Object.values(result)[i]), fill: false, lineTension: 0.4 });
    }
    let tCol=this.dkCols?'#ddd':'#666';
    let gCol=this.dkCols?'#888':'#e5e5e5';
    let chartStatus = Chart.getChart("line_chart");
    if (chartStatus != undefined) {
      chartStatus.destroy();
    }
    const lineCanvasEle: any = document.getElementById('line_chart');
    new Chart(lineCanvasEle.getContext('2d'), {
      type: 'line',
      data: {
        labels: labeldataset,
        datasets: DatasetList
      },
      options: {
        responsive: true,
        plugins:{
          legend: { labels: { font:{ family:'BeVietnamPro' } } }
        },
        scales:{
          x: { ticks:{ font:{ family:'BeVietnamPro' } ,color:tCol},grid: { color:gCol} },
          y: { grid: { color: gCol},ticks:{ font:{ family:'BeVietnamPro' },color:tCol, callback(index) {
            let numData:any = index;
            let signage = '';
            if(numData && numData<0){
              signage='-';
              numData=Math.abs(numData);
            }
            if(numData && ((numData%1)!=0)){
              let x=numData.toFixed(2);
              x=x.toString();
              let afterPoint = '';
              if(x.indexOf('.') > 0){
                afterPoint = x.substring(x.indexOf('.'),x.length);
              }
              x = Math.floor(x);
              x=x.toString();
              let lastThree = x.substring(x.length-3);
              let otherNumbers = x.substring(0,x.length-3);
              if(otherNumbers != ''){
                lastThree = ',' + lastThree;
              }
              let res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree + afterPoint;
              return(signage+res);
            }
            else if(numData){
              let x=numData;
              x=x.toString();
              let lastThree = x.substring(x.length-3);
              let otherNumbers = x.substring(0,x.length-3);
              if(otherNumbers != ''){
                lastThree = ',' + lastThree;
              }
              let res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
              return(signage+res);
            }
            else{
              return('0.00');
            }
          }, } }
        }
      }
    });
  }

  MakeCallCount(Labeldataset:any, CommonDataset:any) {
    return Labeldataset.map((date:any) => {
      const match = CommonDataset.find((item:any) => item.strDate === date);
      return match ? match.TotalCount : 0;
    });
  }

  get_random_color() {
    function c() {
      let hex = Math.floor(Math.random() * 256).toString(16);
      return ("0" + String(hex)).substr(-2);
    }
    return "#" + c() + c() + c();
  }
}