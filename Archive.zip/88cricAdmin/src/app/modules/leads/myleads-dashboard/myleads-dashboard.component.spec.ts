import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyleadsDashboardComponent } from './myleads-dashboard.component';

describe('MyleadsDashboardComponent', () => {
  let component: MyleadsDashboardComponent;
  let fixture: ComponentFixture<MyleadsDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyleadsDashboardComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyleadsDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
