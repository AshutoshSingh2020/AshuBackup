import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MyleadsDetailsComponent } from './myleads-details.component';

describe('MyleadsDetailsComponent', () => {
  let component: MyleadsDetailsComponent;
  let fixture: ComponentFixture<MyleadsDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MyleadsDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MyleadsDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
