import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import moment from 'moment';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-myleads-details',
  templateUrl: './myleads-details.component.html',
  styleUrls: ['./myleads-details.component.scss']
})

export class MyleadsDetailsComponent implements OnInit {

  @Input() submitBtn!:boolean;
  @Input() leadData:any;
  @Output() onSave = new EventEmitter<any>();
  @Output() onCancel = new EventEmitter<any>();
  
  submitDisabled=false;
  CallStatusCode:any=[];
  leadControls = [
    {type:'cell',label:'0'},{type:'textarea',placeholder:'Enter ...'},{type:'date',dependent:'Status'},
    {type:'select',placeholder:'Select',options:[{value:1,name:'Closed'},{value:2,name:'Follow Up'}]},
    {type:'select',placeholder:'Select',options:[]},{type:'button',label:'Submit',icon:''}
  ];

  dynamicControls = this.leadControls;

  staticCollumns = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Remark',bg:'white-drop'},{value:'Follow Up Date',bg:'white-drop'},{value:'Status',bg:'white-drop'},
    {value:'Call Status',bg:'white-drop'},{value:'Action',bg:'white-drop'}]
  ];

  infoData:any=[];
  dataLoading = false;
  staticRows :any = [];
  
  constructor(private apiservice:ApiService, private utilities : CommonFunctionService) { }

  ngOnInit(){
    if(this.leadData){
      this.getLeadDetails();
    }
    this.getAllData();
  }

  getAllData(){
    let request = {"RCType": "CallStatus"};
    this.leadControls[4].options=[];
    this.apiservice.apiRequest(apiData['GetRefCode'], request).subscribe((data: any) => {
      this.CallStatusCode = data;
      this.CallStatusCode.forEach((element:any) => {
        this.leadControls[4].options?.push({
          value:element.RCCode,
          name:element.RCName
        })
      });
    }, (error) => {
      console.error(error);
    });
  }

  getLeadDetails(){
    this.dataLoading = true;
    this.dynamicControls=[];
    this.apiservice.apiRequest(apiData['GetLeadLog'], this.leadData).subscribe((data: any) => {
      this.dataLoading = false;
      this.infoData = data;
      this.staticRows = [];
      this.dynamicControls = this.leadControls;
      if(this.infoData[0]){
        this.infoData.forEach((element:any,index:any) => {
          this.staticRows.push([
            {value:index+1,bg:'white-cell'},
            {value:element.Remark,bg:'white-cell'},
            {value:element.FollowUpDate?moment(element.FollowUpDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
            {value:element.StatusName,bg:'white-cell'},
            {value:element.CallStatusName,bg:'white-cell'},
            {value:'',bg:'white-cell'}
          ]);
        });
      }
    }, (error) => {
      this.dataLoading = false;
      console.log(error);
    });
  }
  
  onBack(){
    this.onCancel.emit();
  }

  AddStatus(dataVal:any){
    if(dataVal.col==5){
      let submitVal={
        "LeadUserDetailId": this.leadData.Id,
        "Remark": dataVal.formVal.C1,
        "FollowUpDate": dataVal.formVal.C2,
        "StatusId": dataVal.formVal.C3,
        "CallStatusCode": dataVal.formVal.C4
      }
      this.LeadDataSubmit(submitVal);
    }
  }

  LeadDataSubmit(submitVal:any) {
    let ErrorMsg:any = [];
    if (!submitVal.Remark) {
      ErrorMsg.push("Please enter Remark\n");
    }
    if (submitVal.StatusId == "") {
      ErrorMsg.push("Please select Status\n");
    }
    if (submitVal.CallStatusCode == "") {
      ErrorMsg.push("Please select Call Status\n");
    }
    if (submitVal.StatusId == "2") {
      if (!(submitVal.FollowUpDate instanceof Date && !isNaN(Date.parse(submitVal.FollowUpDate.toString())))) {
        ErrorMsg.push("Please select Date\n");
      }
    }
    if (ErrorMsg != "") {
      this.utilities.toastMsg("warning", "Failed", ErrorMsg[0]);
      return;
    }
    this.leadControls[5].icon='Loading';
    this.apiservice.apiRequest(apiData['SaveLeadLog'], submitVal).subscribe((response: any) => {
      this.leadControls[5].icon='';
      this.getLeadDetails();
      if (response.ErrorCode === "1") {
        this.utilities.toastMsg("success", "Success", response.ErrorMessage);
      } else {
        this.utilities.toastMsg("error", "Failed", response.Result + " : " + response.ErrorMessage);
      }
    }, (error) => {
      this.leadControls[5].icon='';
      console.error(error);
    });
  }
}