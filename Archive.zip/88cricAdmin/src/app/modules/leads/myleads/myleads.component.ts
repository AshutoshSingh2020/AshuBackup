import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-myleads',
  templateUrl: './myleads.component.html',
  styleUrls: ['./myleads.component.scss']
})

export class MyleadsComponent implements OnInit {
  @ViewChild('LeadDialogOpen') LeadDialogOpen!: TemplateRef<any>;

  showForm = '';
  selectedLead= {};
  
  dynamicControls = [
    {que:'select',type:'select',default:{value:'-1',name:'All Status'},options:[{value:'0',name:'Open'},{value:'1',name:'Closed'},{value:'2',name:'Follow Up'}],subque:[]},
    {que:'Search',type:'input',subque:[]}
  ];

  MyLeadCollumns = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Id',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'Mobile',bg:'white-drop'},
    {value:'Date',bg:'white-drop'},{value:'Status',bg:'white-drop'},{value:'Follow Up',bg:'white-drop'},{value:'Action',bg:'white-drop'}]
  ]
  
  MyLeadDataCollumns=this.MyLeadCollumns;
  
  MyLeadData:any=[];
  rowCount={f:0,l:0,t:0};
  paginatorBlock:any=[];
  pageCount=[10,50,100,500,1000];
  pagesTotal=1;
  currentQuery={"Search":'',"PageNo":1,"PageSize":this.pageCount[0],"intParam1":'-1'};
  MyLeadCollumnLoading=false;
  
  DataMyLeadinfo: any = [];
  CallStatusCode: any = [];
  Leadlogs: any = [];
  TempUser: any = [];
  StatusId: string = '0';
  CallStatus: string = '0';
  pageIndex: number = 0;
  FollowUpDate: any;
  Remark: string = '';
  ShowDate: any;
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }
  
  ngOnInit(): void {
    this.GetMyLeads();
  }
  
  getSearchQuery(formVal:any){
    this.currentQuery.Search=formVal.Search.value;
    this.currentQuery.intParam1=formVal.select.value;
    this.currentQuery.PageNo = 1;
    this.GetMyLeads();
  }
  
  initializeData(){
    this.MyLeadCollumnLoading = true;
    this.DataMyLeadinfo = [];
    this.MyLeadData = [];
  }
  
  GetMyLeads() {
    this.initializeData();
    this.apiservice.apiRequest(apiData['GetMyLeads'], this.currentQuery).subscribe((data: any) => {
      this.MyLeadCollumnLoading = false;
      this.DataMyLeadinfo = data;
      if(this.DataMyLeadinfo[0]){
        this.MyLeadDataCollumns=this.MyLeadCollumns;
        this.pagesTotal=Math.ceil(this.DataMyLeadinfo[0].TotalCount/this.currentQuery.PageSize);
        this.DataMyLeadinfo.forEach((element:any,index:any) => {
          this.MyLeadData.push([
            {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
            ... (element.Register ? [{value:element.Id,bg:'white-cell',faicon:'fa fa-check-circle',fabefore:true}]:[{value:element.Id,bg:'white-cell'}]),
            {value:element.FName?(element.FName+' '+(element.LName?element.LName:'')):'',bg:'white-cell'},
            {value:element.Mobile,bg:'white-cell'},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
            {value:element.LeadStatusName,bg:'white-cell'},
            {value:element.FollowUpDate?moment(element.FollowUpDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
            {value:'',bg:'white-cell',icon:'View'}
          ])
        });
        this.rowCount={f:this.MyLeadData[0][0].value,l:this.MyLeadData[this.MyLeadData.length-1][0].value,t:this.DataMyLeadinfo[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.MyLeadDataCollumns = this.utilities.TableDataNone;
        this.rowCount={f:0,l:0,t:0};
      }      
    }, (error) => {
      this.MyLeadCollumnLoading = false;
      console.log(error);
    });
  }
  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  onValueChange(btnValue:any){
    if(btnValue.col==7){
      this.selectedLead = this.DataMyLeadinfo[btnValue.row];
      this.viewLeadForm();
    }
  }

  viewLeadForm(){
    this.showForm = 'EditLead';
    this.LeadOpenPopup();
  }

  LeadOpenPopup() {
    let dialogRef = this.dialog.open(this.LeadDialogOpen, {
      height: '800x',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.onCancel();
    })
  }
  
  onCancel() {
    this.selectedLead = {};
    this.showForm = '';
  }
  
  GetLeadLog(param: any) {
    this.apiservice.apiRequest(apiData['GetLeadLog'], param).subscribe((data: any) => {
      this.Leadlogs = data;
    }, (error) => {
      console.error(error);
    });
  }
   
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetMyLeads();
  }
  
}