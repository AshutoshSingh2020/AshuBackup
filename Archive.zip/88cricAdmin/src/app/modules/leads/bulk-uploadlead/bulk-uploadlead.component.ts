import { Component, OnInit } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-bulk-uploadlead',
  templateUrl: './bulk-uploadlead.component.html',
  styleUrls: ['./bulk-uploadlead.component.scss']
})

export class BulkUploadleadComponent implements OnInit {
  uploadLoader = false;
  constructor(private apiservice: ApiService, private commonFunctionService: CommonFunctionService) { }

  ngOnInit(): void {
  }

  clearFileInput(){
    (document.getElementById("ExcelUpload") as HTMLInputElement).value = "";
  }

  UploadFile() {
    var formData = new FormData();
    const input = document.getElementById("ExcelUpload") as HTMLInputElement;
    if (!input.files?.length) {
      this.commonFunctionService.toastMsg("warning", "Failed", "Plaese select file");
      return;
    }
    const file = input.files[0];
    var ext = file.name.split('.').pop();
    if (ext != "xlsx" && ext != "xls") {
      this.commonFunctionService.toastMsg("error", "Failed", "Please Upload Only Excel File");
      return;
    }
    formData.append("ExcelUpload", file);
    this.uploadLoader = true;
    this.apiservice.apiRequest(apiData['UploadBulkLead'], formData).subscribe((response: any) => {
      this.clearFileInput();    
      this.uploadLoader = false;
      if (response != null) {
        if (response.ErrorCode === "1") {
          this.commonFunctionService.toastMsg("success", "Success", response.ErrorMessage);
        } else {
          this.commonFunctionService.toastMsg("error", "Failed", response.ErrorMessage);
        }
      }
    }, (error) => {
      this.clearFileInput();
      this.uploadLoader = false;
    });
  }
}