import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkUploadleadComponent } from './bulk-uploadlead.component';

describe('BulkUploadleadComponent', () => {
  let component: BulkUploadleadComponent;
  let fixture: ComponentFixture<BulkUploadleadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BulkUploadleadComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BulkUploadleadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
