import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddleadDetailsComponent } from './addlead-details.component';

describe('AddleadDetailsComponent', () => {
  let component: AddleadDetailsComponent;
  let fixture: ComponentFixture<AddleadDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddleadDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddleadDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
