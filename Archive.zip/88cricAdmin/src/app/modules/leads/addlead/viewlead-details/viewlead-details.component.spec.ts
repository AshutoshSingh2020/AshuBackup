import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewleadDetailsComponent } from './viewlead-details.component';

describe('ViewleadDetailsComponent', () => {
  let component: ViewleadDetailsComponent;
  let fixture: ComponentFixture<ViewleadDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewleadDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewleadDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
