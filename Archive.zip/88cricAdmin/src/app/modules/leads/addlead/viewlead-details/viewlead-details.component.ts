import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import moment from 'moment';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { config } from '@services/config';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-viewlead-details',
  templateUrl: './viewlead-details.component.html',
  styleUrls: ['./viewlead-details.component.scss']
})

export class ViewleadDetailsComponent implements OnInit {
  
  @Input() leadData:any;
  @Output() onCancel = new EventEmitter<any>();
  
  DataLoader=false;
  LogCollumns=[
    [{value:'Sr. No',bg:'white-drop'},{value:'Remark',bg:'white-drop'},{value:'Follow Up Date',bg:'white-drop'},
    {value:'Status',bg:'white-drop'},{value:'Call Status',bg:'white-drop'}]
  ]
  LogRows:any=[];
  
  constructor(private apiservice: ApiService,private utilities: CommonFunctionService) { }
  
  ngOnInit(){
    this.GetLeadLog(this.leadData);
  }

  GetLeadLog(request: any) {
    this.DataLoader=true;
    this.apiservice.apiRequest(apiData['GetLeadLog'], request).subscribe((data: any) => {
      this.DataLoader=false;
      if(data[0]){
        let leadLogs=data;
        leadLogs.forEach((element:any,index:number) => {          
            this.LogRows.push([
              {value:index+1,bg:'white-cell'},{value:element.Remark,bg:'white-cell'},
              {value:element.FollowUpDate?moment(element.FollowUpDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
              {value:element.StatusName,bg:'white-cell'},{value:element.CallStatusName,bg:'white-cell'}
            ])
        });
      }
      else{
        this.LogCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      this.DataLoader=false;
      this.utilities.toastMsg("error", "Failed", error);
      this.onBack()
      console.error(error);
    });
  }
  
  onBack(){
    this.onCancel.emit();
  }
}