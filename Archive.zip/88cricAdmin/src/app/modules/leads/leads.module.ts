import { NgModule } from '@angular/core';
import { LeadsRoutingModule } from './leads-routing.module';
import { SharedModule } from '@shared/shared.module';

import { AddleadComponent } from './addlead/addlead.component';
import { AddleadDetailsComponent } from './addlead/addlead-details/addlead-details.component';
import { ViewleadDetailsComponent } from './addlead/viewlead-details/viewlead-details.component';
import { BulkUploadleadComponent } from './bulk-uploadlead/bulk-uploadlead.component';
import { LeadDashboardComponent } from './lead-dashboard/lead-dashboard.component';
import { MyleadsComponent } from './myleads/myleads.component';
import { MyleadsDetailsComponent } from './myleads/myleads-details/myleads-details.component';
import { MyleadsDashboardComponent } from './myleads-dashboard/myleads-dashboard.component';

@NgModule({
  declarations: [
    AddleadComponent,
    AddleadDetailsComponent,
    ViewleadDetailsComponent,
    BulkUploadleadComponent,
    LeadDashboardComponent,
    MyleadsComponent,
    MyleadsDetailsComponent,
    MyleadsDashboardComponent
  ],
  imports: [
    SharedModule,
    LeadsRoutingModule,
 
  ]
})
export class LeadsModule { }