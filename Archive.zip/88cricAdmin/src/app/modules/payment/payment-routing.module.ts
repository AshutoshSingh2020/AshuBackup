import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PaymentClickComponent } from './payment-click/payment-click.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'payment-click',
    pathMatch: 'full'
  },
  {
    path: 'payment-click',
    component: PaymentClickComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PaymentRoutingModule { }
