import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { PaymentRoutingModule } from './payment-routing.module';
import { PaymentClickComponent } from './payment-click/payment-click.component';
import { BlockPayComponent } from './block-pay/block-pay.component';


@NgModule({
  declarations: [
    PaymentClickComponent,
    BlockPayComponent
  ],
  imports: [
    PaymentRoutingModule,
    SharedModule,
  ]
})
export class PaymentModule { }
