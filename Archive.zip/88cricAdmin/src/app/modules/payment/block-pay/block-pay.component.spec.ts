import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BlockPayComponent } from './block-pay.component';

describe('BlockPayComponent', () => {
  let component: BlockPayComponent;
  let fixture: ComponentFixture<BlockPayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BlockPayComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BlockPayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
