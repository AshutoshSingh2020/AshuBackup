import { NgModule } from '@angular/core';

import { ReportRoutingModule } from './report-routing.module';
import { RegisteredUserComponent } from './registered-user/registered-user.component';

import { SharedModule } from '@shared/shared.module';


@NgModule({
  declarations: [
    RegisteredUserComponent
  ],
  imports: [
    ReportRoutingModule,
    SharedModule,
  ]
})
export class ReportModule { }
