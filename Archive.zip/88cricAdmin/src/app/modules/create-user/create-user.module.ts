import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CreateUserRoutingModule } from './create-user-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    CreateUserRoutingModule
  ]
})
export class CreateUserModule { }
