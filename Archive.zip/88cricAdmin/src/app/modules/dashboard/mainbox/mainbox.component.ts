import { Component, OnInit, Input, Output, EventEmitter, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { ApiService } from '@services/api.service';

@Component({
  selector: 'app-mainbox',
  templateUrl: './mainbox.component.html',
  styleUrls: ['./mainbox.component.scss']
})

export class MainboxComponent implements OnInit, OnDestroy {
  @Input() compData: any[]=[];
  @Output() onSubmitComp = new EventEmitter<any>();
  private loaderSubscriber: Subscription;
  constructor(private apiservice :ApiService) { }
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      for(let element of this.compData){
        if(element.hasOwnProperty('loader') && element.hasOwnProperty('loaderkey')) {
          element.loader = element.loaderkey in loading;
        }
        if(element.type=='table'){
          for(let rowElement of element.rowdata){
            for(let subElement of rowElement){
              if(subElement.hasOwnProperty('cellLoaderKey')) {
                if(subElement.cellLoaderKey in loading){
                  subElement.icon=subElement.loadingIcon;
                }
                else{
                  subElement.cellLoader = false;
                  subElement.icon=subElement.defaultIcon;
                }
              }
            }
          }
        }
        if(element.type=='cardList'){
          for(let subElement of element.data){
            if(subElement.hasOwnProperty('btnLoader') && subElement.hasOwnProperty('btnLoaderKey')) {
              subElement.btnLoader = subElement.btnLoaderKey in loading;
            }
          }
        }
      }
    });
  }
  
  submitFunction(event,id) {
    this.onSubmitComp.emit({id:id,info:event});
  }
  
  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
  }
}