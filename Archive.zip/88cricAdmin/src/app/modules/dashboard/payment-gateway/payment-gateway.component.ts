import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import moment from 'moment';
import { DatePipe } from '@angular/common';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-payment-gateway',
  templateUrl: './payment-gateway.component.html',
  styleUrls: ['./payment-gateway.component.scss'],
  providers: [DatePipe]
})

export class PaymentGatewayComponent implements OnInit, OnDestroy {
  PGinfoData: any = [];
  AllPGinfo: any = [];
  todayDate = new Date();
  dynamicControls = [{que: 'Date',type: 'daterange',minDate: null,maxDate: this.todayDate,startDate: this.todayDate,endDate: this.todayDate,subque: []}];
  currentQuery = {"StartDateTime":this.datePipe.transform(this.todayDate,'MM-dd-yyyy'),"EndDateTime":this.datePipe.transform(this.todayDate,'MM-dd-yyyy')};
  PGDataCollumns: any = [[{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'PG On Date',bg:'blue-drop'},{value:'Payout On Date',bg:'red-drop'}]]
  private apiSubscriber:Subscription[]=[];
  pginfo=[
    {
      type:'header',id:'header1',static:{showForm:true,btnVal:"Search",titleText:"Payment Gateway"},dynamicControls:this.dynamicControls,
      trigger: (formVal: any) => {
        this.getSearchQuery(formVal);
      }
    },
    {
      type:'table',id:'table1',loader:false,rowdata:this.PGinfoData,coldata:this.PGDataCollumns,
      loaderkey:apiData['GetClientGatewayData'].keyL,
      trigger: (formVal: any) => {
        this.onValueChange(formVal);
      }
    }
  ];
  
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private datePipe: DatePipe) { }
  
  ngOnInit(): void {
    this.getAllData();
  }
  
  getAllData() {
    this.GetClientGatewayData();
  }
  
  GetClientGatewayData() {
    this.PGinfoData = [];
    this.AllPGinfo=[];
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['GetClientGatewayData'], this.currentQuery).subscribe({
      next: (data:any) => {
        let allData = data;
        if(allData[0]){
          this.AllPGinfo=allData;
          allData.forEach((element:any,index:any) => {
            this.PGinfoData.push([
            { value: index + 1, bg: 'white-cell' },
            { value: element.ClientName, bg: 'white-cell' },
            { value: '₹ ' + this.utilities.roundOffNum(element.TotalTransactionOnDate), bg: 'blue-cell' },
            (element.TotalPayoutTransactionOnDate?
              {value:'₹ '+this.utilities.roundOffNum(element.TotalPayoutTransactionOnDate),bg:'red-cell',icon:'Download',defaultIcon:'Download',loadingIcon:'Loading',cellLoader:false,cellLoaderKey:'downLoadAllPayoutExcell',downloadvalue:'ClientRData'}:
              {value:'₹ '+this.utilities.roundOffNum(element.TotalPayoutTransactionOnDate),bg:'red-cell'})
            ])
          });
          this.pginfo[1].rowdata=this.PGinfoData;
        }
        else{
          this.pginfo[1].rowdata=this.utilities.TableDataNone;
        }
      },
      error: (error) => {
        console.log(error);
      }
    });
  }
  
  getSearchQuery(formVal: any) {
    this.currentQuery.StartDateTime = this.datePipe.transform(formVal.Date.value1, 'MM-dd-yyyy');
    this.currentQuery.EndDateTime = this.datePipe.transform(formVal.Date.value2, 'MM-dd-yyyy');
    this.GetClientGatewayData();
  }
  
  DownLoadAllReconciliationData(ClientId: any) {
    let d1 = moment(this.currentQuery.StartDateTime).format("DD/MM/yyyy HH:MM");
    let d2 = moment(this.currentQuery.EndDateTime).format("DD/MM/yyyy HH:MM");
    let param = "?ClientId=" + ClientId + "&StartDateTime=" + d1 + "&EndDateTime=" + d2;
    let docname = 'Payout_Record_'+d1+'_'+d2;
    this.apiservice.exportExcel(config['downLoadAllPayoutExcell'] + param, docname, 'downLoadAllPayoutExcell');
  }
  
  onValueChange(formVal: any) {
    if (formVal.type == 'ClientRData') {
      this.DownLoadAllReconciliationData(0);
    }
  }
  
  ngOnDestroy() {
    for (const element of this.apiSubscriber) {
      if (element) {
        element.unsubscribe();
      }
    }
  }
}