import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { MyDashboardComponent } from './my-dashboard/my-dashboard.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { PaymentGatewayComponent } from './payment-gateway/payment-gateway.component';
import { MainboxComponent } from './mainbox/mainbox.component';

@NgModule({
  declarations: [
    MyDashboardComponent,
    AnalyticsComponent,
    PaymentGatewayComponent,
    MainboxComponent
  ],
  imports: [
    SharedModule,
    DashboardRoutingModule,
  ]
})
export class DashboardModule { }
