import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import Chart from 'chart.js/auto';
import { DatePipe } from '@angular/common';
import { apiData } from '@services/configapi';
@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.scss'],
  providers: [DatePipe]
})

export class AnalyticsComponent implements OnInit, OnDestroy {
  todayDate = new Date();
  depositData: any = [];
  pieChart: any={};
  isPieChartEmpty=true;
  dynamicControls = [
    {que:'Date',type:'daterange',minDate:null,maxDate:this.todayDate,startDate:this.todayDate,endDate:this.todayDate,subque:[]},
  ];
  dynamicControls1= [
    {que:'Date',type:'daterange',minDate:null,maxDate:this.todayDate,startDate:this.todayDate,endDate:this.todayDate,subque:[]},
  ];
  currentQuery={"StartDateTime": this.datePipe.transform(this.todayDate, 'MM-dd-yyyy'),"EndDateTime": this.datePipe.transform(this.todayDate, 'MM-dd-yyyy')};
  currentQuery1 = {"StartDateTime": this.datePipe.transform(this.todayDate, 'MM-dd-yyyy'),"EndDateTime": this.datePipe.transform(this.todayDate, 'MM-dd-yyyy')};
  depositDataCollumns=[
    [{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},
    {value:'Percentage',bg:'white-drop'},{value:'Amount',bg:'white-drop'},{value:'Withdraw',bg:'white-drop'}]
  ];
  chartLoading=false;
  
  analyticsData=[
    {
      type:'header',id:'header1',static:{showForm:true,btnVal:"Search",titleText:"Deposit Percentage"},dynamicControls:this.dynamicControls,
      trigger: (formVal: any) => {
        this.getSearchQuery(formVal);
      }
    },
    {
      type:'table',id:'table1',loader:false,rowdata:this.depositData,coldata:this.depositDataCollumns,
      loaderkey:apiData['GetTopDepositors'].keyL,
      trigger: (formVal: any) => {}
    },
    {
      type:'header',id:'header2',static:{showForm:true,btnVal:"Search",titleText:"Deposit"},dynamicControls:this.dynamicControls1,
      trigger: (formVal: any) => {
        this.getSearchQuery1(formVal);
      }
    }
  ];
  
  private apiSubscriber: Subscription[]=[];
  constructor(private apiservice: ApiService,private utilities: CommonFunctionService ,private datePipe:DatePipe) { }
  
  ngOnInit(): void {
    this.GetTopDepositors();
    this.GetDashboardChart();
  }
  
  GetTopDepositors() {
    this.depositData=[];
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['GetTopDepositors'], this.currentQuery).subscribe({
      next: (data:any) => {
        let DataDeposit = data;
        if(DataDeposit[0]){
          DataDeposit.forEach((element:any,index:any) => {
            this.depositData.push([
              {value:index+1,bg:'white-drop'},
              {value:element.FName,bg:'white-drop'},
              {value:element.UserName,bg:'white-drop'},
              {value:element.DepositPercentage+' %',bg:'white-drop'},
              {value:'₹ '+this.utilities.roundOffNum(element.DepositAmount),bg:'white-drop'},
              {value:'₹ '+this.utilities.roundOffNum(element.WithdrawAmount),bg:'white-drop'}
            ])
          });
          this.analyticsData[1].rowdata=this.depositData;
        }
        else{
          this.analyticsData[1].rowdata=this.utilities.TableDataNone;
        }
      },
      error: (error) => {
        console.log(error);
      }
    });
  }
  
  getSearchQuery(formVal:any){
    this.datePipe.transform(this.todayDate, 'MM-dd-yyyy')
    this.currentQuery.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'MM-dd-yyyy');
    this.currentQuery.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'MM-dd-yyyy');
    this.GetTopDepositors();
  }
  
  getSearchQuery1(formVal:any){
    this.currentQuery1.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'MM-dd-yyyy');
    this.currentQuery1.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'MM-dd-yyyy');
    this.GetDashboardChart();
  }

  GetDashboardChart() {
    this.chartLoading=true;
    this.pieChart={};
    this.isPieChartEmpty=true;
    this.apiSubscriber[1] = this.apiservice.apiRequest(apiData['GetDashBoardCount'], this.currentQuery1).subscribe((data: any) => {
      this.chartLoading=false;
      if(data.TotalDepositAmount && data.TotalWithdrawAmount){
        this.isPieChartEmpty=false;
      }
      let chartStatus = Chart.getChart("pie_chart");
      if (chartStatus != undefined) {
        chartStatus.destroy();
      }
      this.pieChart = new Chart('pie_chart', {
        type: 'doughnut',
        data: {
          labels: [  'Deposit','Withdraw'],
          datasets: [
            {
              data: [data.TotalDepositAmount,data.TotalWithdrawAmount], 
              backgroundColor: [  '#5fb331','#66cced',], 
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: true,
          aspectRatio:4
        },
      });
      
    }, (error) => {
      console.error(error)
    });
  }
  
  ngOnDestroy() {
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
    if(this.apiSubscriber[1]) {
      this.apiSubscriber[1].unsubscribe();
    }
  }
}