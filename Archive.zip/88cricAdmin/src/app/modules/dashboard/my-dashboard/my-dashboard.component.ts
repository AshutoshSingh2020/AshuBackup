import {Component, OnInit, OnDestroy} from '@angular/core';
import { Subscription } from 'rxjs';
import moment from 'moment';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { CommonFunctionService } from '@services/common-function.service';
import Chart from 'chart.js/auto';
import { DatePipe } from '@angular/common';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-my-dashboard',
  templateUrl: './my-dashboard.component.html',
  styleUrls: ['./my-dashboard.component.scss'],
  providers:[DatePipe]
})

export class MyDashboardComponent implements OnInit, OnDestroy {
  todayDate = new Date();
  dkCols=localStorage.getItem('dkMode')=='sd-dark'?true:false;
  chartStart = new Date((new Date()).setMonth(this.todayDate.getMonth()-1));
  dynamicControls = [{que:'Date',type:'daterange',minDate:null,maxDate:this.todayDate,startDate:this.todayDate,endDate:this.todayDate,subque:[]}];
  dynamicControls1= [{que:'Date',type:'daterange',minDate:null,maxDateb1:this.todayDate,startDate:this.chartStart,endDate:this.todayDate,subque:[]}];
  currentQuery={"StartDateTime": this.datePipe.transform(this.todayDate, 'MM-dd-yyyy'),"EndDateTime":  this.datePipe.transform(this.todayDate, 'MM-dd-yyyy')};
  currentQuery1={"StartDateTime": this.datePipe.transform(this.chartStart, 'MM-dd-yyyy'),"EndDateTime": this.datePipe.transform(this.todayDate, 'MM-dd-yyyy')};
  dashboardCount = [
    { name: "New User", value: '0', feather: "user-plus", "color": this.dkCols?"#86afd9":"#1c84ee", isDownload: "N" },
    { name: "New Depositor", value: '0', feather: "pie-chart", "color": this.dkCols?"#7db39f":"#33c38e", isDownload: "N" },
    { name: "All Depositor", value: '0', feather: "bar-chart", "color": this.dkCols?"#86afd9":"#ffcc5a", isDownload: "N" },
    { name: "Total TRX", value: '0', feather: "send", "color": this.dkCols?"#86afd9":"#1c84ee", isDownload: "N" },
    { name: "Deposit", btnDownload: false, btnLoader: false, btnLoaderKey:"dlUserDeposits", value: '0.00', feather: "lock", "color": this.dkCols?"#7db39f":"#33c38e", isDownload: "Y" },
    { name: "Deposit Average", value: '0.00', feather: "trending-up", "color": this.dkCols?"#86afd9":"#ffcc5a", isDownload: "N" },
    { name: "Withdraw", btnDownload: false, btnLoader: false, btnLoaderKey:"dlUserWithdraws", value: '0.00', feather: "credit-card", "color": this.dkCols?"#be9090":"#ef6767", isDownload: "Y" },
    { name: "Difference", value: '0.00', feather: "flag", "color": this.dkCols?"#7db39f":"#33c38e", isDownload: "N" },
    { name: "Bonus", btnDownload: false, btnLoader: false, btnLoaderKey:"dlUserBnusDeposits", value: '0.00', feather: "lock", "color": this.dkCols?"#be9090":"#ef6767", isDownload: "Y" },
    { name: "Bet", value: '0.00', feather: "user-check", "color": this.dkCols?"#86afd9":"#1c84ee", isDownload: "N" },
    { name: "Win", value: '0.00', feather: "pie-chart", "color": this.dkCols?"#be9090":"#ef6767", isDownload: "N" },
    { name: "Diff", value: '0.00', feather: "bar-chart-2", "color": this.dkCols?"#86afd9":"#ffcc5a", isDownload: "N" }
  ];
  chartLoading = false;
  private apiSubscriber: Subscription[]=[];
  myDashboard=[
    {
      type:'header',id:'header1',static:{showForm:true,btnVal:"Search",titleText:"Dashboard"},dynamicControls:this.dynamicControls,
      trigger: (formVal: any) => {
        this.getSearchQuery(formVal);
      }
    },
    {
      type:'cardList',id:'cardList1',loader:false,data:this.dashboardCount,
      loaderkey:apiData['GetDashBoardCount'].keyL,
      trigger: (formVal: any) => {
        this.onValueChange(formVal);
      }
    },
    {
      type:'header',id:'header2',static:{showForm:true,btnVal:"Search",titleText:"Overview"},dynamicControls:this.dynamicControls1,
      trigger: (formVal: any) => {
        this.getSearchQuery1(formVal);
      }
    }
  ];
  
  constructor(private apiservice :ApiService, private utilities:CommonFunctionService,private datePipe:DatePipe) {}

  ngOnInit(): void {
    this.GetDashboardCount();
    this.GetDashboardChart();
  }

  GetDashboardCount() {
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['GetDashBoardCount'], this.currentQuery).subscribe({
      next: (data:any) => {
        this.dashboardCount[0].value = this.utilities.roundOffNum(data.NewRegisterCount);
        this.dashboardCount[1].value = this.utilities.roundOffNum(data.NewDepositorCount);
        this.dashboardCount[2].value = this.utilities.roundOffNum(data.DepositorCount);
        this.dashboardCount[3].value = this.utilities.roundOffNum(data.TransactionCount);
        this.dashboardCount[4].value = this.utilities.roundOffNum(data.TotalDepositAmount);
        this.dashboardCount[4].btnDownload = !!data.TotalDepositAmount;
        this.dashboardCount[5].value = this.utilities.roundOffNum(data.AverageDepositAmount);
        this.dashboardCount[6].value = this.utilities.roundOffNum(data.TotalWithdrawAmount);
        this.dashboardCount[6].btnDownload = !!data.TotalWithdrawAmount;
        this.dashboardCount[7].value = this.utilities.roundOffNum(data.DepositWithdrawDiff);
        this.dashboardCount[8].value = this.utilities.roundOffNum(data.TotalDepositBonusAmount);
        this.dashboardCount[8].btnDownload = !!data.TotalDepositBonusAmount;
        this.dashboardCount[9].value = this.utilities.roundOffNum(data.TotalBetAmount);
        this.dashboardCount[10].value = this.utilities.roundOffNum(data.TotalWinAmount);
        this.dashboardCount[11].value = this.utilities.roundOffNum(data.BetWinDiff);
        this.myDashboard[1].data=this.dashboardCount;
      },
      error: (error)=> {
        console.error(error);
      }
    });
  }

  getSearchQuery(formVal:any){
    this.currentQuery.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'MM-dd-yyyy');
    this.currentQuery.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'MM-dd-yyyy');
    this.GetDashboardCount();
  }

  getSearchQuery1(formVal:any){
    this.currentQuery1.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'MM-dd-yyyy');
    this.currentQuery1.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'MM-dd-yyyy');
    this.GetDashboardChart();
  }

  onValueChange(formVal:any){
    let d1 = (moment(this.currentQuery.StartDateTime).format("DD/MM/yyyy HH:mm"));
    let d2 = (moment(this.currentQuery.EndDateTime).format("DD/MM/yyyy HH:mm"));
    let docDate = moment(this.currentQuery.StartDateTime).format("DD/MM/yyyy")+'_to_'+moment(this.currentQuery.EndDateTime).format("DD/MM/yyyy");
    if(formVal.type=='Deposit')
    {
      let request = "?StartDateTime=" + d1+'&EndDateTime='+d2;
      let docname = 'Download_Deposit_'+docDate;
      this.apiservice.exportExcel(config['dlUserDeposits'] + request,docname,'dlUserDeposits');
    }
    else if(formVal.type=='Withdraw'){
      let request = "?StartDateTime=" + d1 +'&EndDateTime='+d2;
      let docname = 'Download_Withdraw_'+docDate;
      this.apiservice.exportExcel(config['dlUserWithdraws'] + request,docname,'dlUserWithdraws');
    }
    else if(formVal.type=='Bonus'){
      let request = "?StartDateTime=" + d1 +'&EndDateTime='+d2;
      let docname = 'Download_BonusDeposit_'+docDate;
      this.apiservice.exportExcel(config['dlUserBnusDeposits'] + request,docname,'dlUserBnusDeposits');
    }
  }

  GetDashboardChart() {
    this.chartLoading=true;
    this.apiSubscriber[1] = this.apiservice.sendRequest(config['GetDashboardChart1'], this.currentQuery1,'DashboardChart1').subscribe((data: any) => {
      this.chartLoading=false;
      let deposit: any = [];
      let withdrawal: any = [];
      let reverse: any = [];
      let label = this.utilities.getDatesInRange(new Date(this.currentQuery1.StartDateTime), new Date(this.currentQuery1.EndDateTime));
      let displayLable: any = [];
      data.Deposit.forEach((depositElement: any, index: any) => {
        data.Deposit[index]['Date'] = moment(new Date(depositElement.Date)).format("MMM Do YY")
      });
      data.Withdraw.forEach((depositElement: any, index: any) => {
        data.Withdraw[index]['Date'] = moment(new Date(depositElement.Date)).format("MMM Do YY")
      });
      data.Reverse.forEach((depositElement: any, index: any) => {
        data.Reverse[index]['Date'] = moment(new Date(depositElement.Date)).format("MMM Do YY")
      });
      label.forEach((element: any) => {
        let depositIndex = data.Deposit.map((x: any) => {
          return x.Date;
        }).indexOf(moment(element).format("MMM Do YY"))
        if (depositIndex != -1) {
          deposit.push(data.Deposit[depositIndex].TotalAmount);
        } else {
          deposit.push(0);
        }
        let widrowIndex = data.Withdraw.map((x: any) => {
          return x.Date;
        }).indexOf(moment(element).format("MMM Do YY"))
        if (widrowIndex != -1) {
          withdrawal.push(data.Withdraw[widrowIndex].TotalAmount);
        } else {
          withdrawal.push(0);
        }
        let reverseIndex = data.Reverse.map((x: any) => {
          return x.Date;
        }).indexOf(moment(element).format("MMM Do YY"))
        if (reverseIndex != -1) {
          reverse.push(data.Reverse[reverseIndex].TotalAmount);
        } else {
          reverse.push(0);
        }
        displayLable.push(moment(element).format("DD  MMM"))
      });
      let basicData = {
        labels: displayLable,
        datasets: [
          { label: 'Deposit', data: deposit, fill: false, borderColor: '#3e95cd', tension: .4 },
          { label: 'Withdrawal', data: withdrawal, fill: false, borderColor: '#87599a', tension: .4 },
          { label: 'Reverse', data: reverse, fill: false, borderColor: '#88f39a', tension: .4 }
        ]
      };
      let chartStatus = Chart.getChart("line_chart");
      if (chartStatus != undefined) {
        chartStatus.destroy();
      }
      let tCol=this.dkCols?'#ddd':'#666';
      let gCol=this.dkCols?'#888':'#e5e5e5';
      const lineCanvasEle: any = document.getElementById('line_chart');
      let nc = new Chart(lineCanvasEle.getContext('2d'), {
        type: 'line',
        data: basicData,
        options: {
          responsive: true,
          plugins:{
            legend: { labels: { font:{ family:'BeVietnamPro' }, color:tCol  } }
          },
          scales:{
            x: { ticks:{ font:{ family:'BeVietnamPro' } , color:tCol } ,grid: { color:gCol} },
            y: {grid: { color: gCol}, ticks:{ font:{ family:'BeVietnamPro' }, color:tCol,callback(index) {
              let numData:any = index;
              let signage = '';
              if(numData && numData<0){
                signage='-';
                numData=Math.abs(numData);
              }
              if(numData && ((numData%1)!=0)){
                let x=numData.toFixed(2);
                x=x.toString();
                let afterPoint = '';
                if(x.indexOf('.') > 0){
                  afterPoint = x.substring(x.indexOf('.'),x.length);
                }
                x = Math.floor(x);
                x=x.toString();
                let lastThree = x.substring(x.length-3);
                let otherNumbers = x.substring(0,x.length-3);
                if(otherNumbers != ''){
                  lastThree = ',' + lastThree;
                }
                let res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree + afterPoint;
                return(signage+res);
              }
              else if(numData){
                let x=numData;
                x=x.toString();
                let lastThree = x.substring(x.length-3);
                let otherNumbers = x.substring(0,x.length-3);
                if(otherNumbers != ''){
                  lastThree = ',' + lastThree;
                }
                let res = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ",") + lastThree;
                return(signage+res);
              }
              else{
                return('0.00');
              }
            }, } }
          }
        }
      });
    }, (error) => {
      console.error(error)
    });
  }

  ngOnDestroy() {
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
    if(this.apiSubscriber[1]) {
      this.apiSubscriber[1].unsubscribe();
    }
  }
}