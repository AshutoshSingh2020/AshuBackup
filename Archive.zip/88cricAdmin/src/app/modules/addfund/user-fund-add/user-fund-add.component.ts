import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import {FormControl, Validators,FormBuilder,FormGroup} from '@angular/forms';

import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { Subscription } from 'rxjs';
import { apiData } from '@services/configapi';


@Component({
  selector: 'app-user-fund-add',
  templateUrl: './user-fund-add.component.html',
  styleUrls: ['./user-fund-add.component.scss']
})
export class UserFundAddComponent implements OnInit {

  
  @Input() userData:any;
  @Output() onCancel = new EventEmitter<any>();
  submitDisabled = false;
  disable = false;
  DataLoader=false;
  BankDataCollumns=[]
  BankDataRows:any=[];

  adduser !:FormGroup;
  resetDisable=false;
  approveDisabled=false;
  trxdisabled=false;
  trxdisabled1=false;
  assignWBank="0";
  apiLoader={uvc_list:false};
  ProviderList=[];
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  constructor(private apiservice: ApiService, private utilities : CommonFunctionService,private fb:FormBuilder) { 

    this.adduser = this.fb.group({
      TransactionType: ["", [Validators.required]],
      Amount: ["", [Validators.required]],
      addfund: [false, []],
      BonusCondition: ["", [Validators.required]],
      BonusAmount: ["", [Validators.required]],
      BonusConditionValue: ["", [Validators.required]],
      Description: ["", [Validators.required]],
   
    });
  }
  
  ngOnInit(){
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.uvc_list=('savefund' in loading)?true:false;
    });

  }

  onSubmit(){
  this.submitDisabled = true;
  let param = this.adduser.getRawValue();
  this.apiservice.apiRequest(apiData['savefund'],param).subscribe((data: any) => {
    if (data) {
      if (data.ErrorCode == "1") {
        this.utilities.toastMsg('success',"Success", data.ErrorMessage);
      } else {
        this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
      }
    }
  }, (error) => {
    console.log(error);
  });  
  }


  resetAll(){
    this.adduser.reset();
  }


}
