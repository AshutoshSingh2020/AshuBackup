import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserFundAddComponent } from './user-fund-add.component';

describe('UserFundAddComponent', () => {
  let component: UserFundAddComponent;
  let fixture: ComponentFixture<UserFundAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserFundAddComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UserFundAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
