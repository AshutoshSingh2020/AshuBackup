import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { AddfundRoutingModule } from './addfund-routing.module';
import { AddFundComponent } from './add-fund/add-fund.component';
import { UserFundAddComponent } from './user-fund-add/user-fund-add.component';


@NgModule({
  declarations: [
    AddFundComponent,
    UserFundAddComponent
  ],
  imports: [
    AddfundRoutingModule,
    SharedModule,
  ]
})
export class AddfundModule { }
