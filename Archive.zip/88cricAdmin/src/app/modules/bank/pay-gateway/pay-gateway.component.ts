import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-pay-gateway',
  templateUrl: './pay-gateway.component.html',
  styleUrls: ['./pay-gateway.component.scss']
})
export class PayGatewayComponent implements OnInit {
  @ViewChild('PGDialogOpen') PGDialogOpen!: TemplateRef<any>;
  allData:any=[];
  tableInfoData:any=[];
  tableCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Status',bg:'white-drop'},{value:'PaymentUrl',bg:'white-drop'},{value:'Tag',bg:'white-drop'},{value:'Title',bg:'white-drop'},{value:'SubTitle',bg:'white-drop'},{value:'Minimum Value',bg:'white-drop'},{value:'Maximum Value',bg:'white-drop'},
    {value:'ImageUrl',bg:'white-drop'},{value:'Description',bg:'white-drop'},{value:'Register Days',bg:'white-drop'},{value:'Deposit Amount',bg:'white-drop'},{value:'Short Order',bg:'white-drop'},{value:'Date',bg:'white-drop'}]
  ];
  tableDataCollumns=this.tableCollumnHeaders;
  dIndex={status:{row:0,col:0,use:false},depositAccess:{row:0,col:0,use:false}};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={crc_list:false};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private dialog: MatDialog) { 
    
  }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.crc_list=('getPGMaster' in loading)?true:false;
      if(this.dIndex.status.use)
      {
        this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon=('setPGStat' in loading)?'Loading':'Toggle';
      }
    });
    this.GetMasterData();
  }
  
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
  }

  GetMasterData() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['getPGMaster']).subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.tableDataCollumns=this.tableCollumnHeaders;
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:index+1,bg:'white-cell'},
            {value:element.StatusId,bg:'white-cell',icon:'Toggle'},
            {value:element.PaymentUrl,bg:'white-cell break-class'},
            {value:element.Tag,bg:'white-cell'},
            {value:element.Title,bg:'white-cell'},
            {value:element.SubTitle,bg:'white-cell'},
            {value:element.MinimumValue,bg:'white-cell'},
            {value:element.MaximumValue,bg:'white-cell'},
            {value:element.ImageUrl,bg:'white-cell break-class'},
            {value:element.Description,bg:'white-cell'},
            {value:element.RegisterDays,bg:'white-cell'},
            {value:element.DepositAmount,bg:'white-cell'},
            {value:element.ShortOrder,bg:'white-cell'},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'},
          ])
        });
      }
      else{
        this.tableDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }
  
  onValueChange(formVal:any){
    let allBankData = this.allData[formVal.row];
    if(formVal.col==1){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      let param = '?Id='+ allBankData.Id;
      this.savePGStatus(param);
    }
  }

  savePGStatus(param:any){
    this.apiservice.getRequest(config['setPGStat']+param,'setPGStat').subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value=!this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].value;
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }
  
  onSavePopup(){
    this.GetMasterData();
    this.closePopup();
  }

  closePopup(){
    this.dialog.closeAll();
  }

  TrxOpenPopup() {
    let dialogRef = this.dialog.open(this.PGDialogOpen, {
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.closePopup();
    })
  }
  
  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
}
