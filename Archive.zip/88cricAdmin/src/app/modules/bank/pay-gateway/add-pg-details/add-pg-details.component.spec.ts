import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPgDetailsComponent } from './add-pg-details.component';

describe('AddPgDetailsComponent', () => {
  let component: AddPgDetailsComponent;
  let fixture: ComponentFixture<AddPgDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddPgDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddPgDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
