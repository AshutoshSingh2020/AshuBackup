import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from "@angular/forms";

import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';

@Component({
  selector: 'app-add-pg-details',
  templateUrl: './add-pg-details.component.html',
  styleUrls: ['./add-pg-details.component.scss']
})
export class AddPgDetailsComponent implements OnInit {
  @Input() submitBtn!:boolean;
  @Output() onSave = new EventEmitter<any>();
  @Output() onCancel = new EventEmitter<any>();
  
  submitDisabled=false;
  
  resetBtn = true;
  pgForm!: FormGroup;
  adminPass = '';
  todayDate = new Date();
  
  constructor(private formBuilder: FormBuilder, private apiservice: ApiService, private utilities : CommonFunctionService) { }
  
  ngOnInit(){
    this.initializeForm();
  }
  
  initializeForm(){
    this.pgForm = this.formBuilder.group({
      PaymentUrl: ["", [Validators.required]],
      Description: ["", [Validators.required]],
      Tag: ["", [Validators.required]],
      Title: ["", [Validators.required]],
      SubTitle: ["", [Validators.required]],
      MinimumValue: ["", [Validators.required]],
      MaximumValue: ["", [Validators.required]],
      RegisterDays: [0, [Validators.required]],
      DepositAmount: [0, [Validators.required]],
      ImageUrl: ["", [Validators.required]]
    });
  }
  
  onBack(){
    this.onCancel.emit();
  }
  
  onSubmit(){
    if(this.pgForm.invalid){
      this.utilities.toastMsg('warning','Please enter Required Data!','');
    }
    else{
      this.submitDisabled=true;
      let FormValue = this.pgForm.getRawValue();
      if(!FormValue.id){
        delete FormValue.id;
        this.apiservice.sendRequest(config['saveNewPGMaster'],FormValue).subscribe((data: any) => {
          this.submitDisabled=false;
          if (data.ErrorCode === "1") {
            this.utilities.toastMsg('success',"Success", data.ErrorMessage);
            this.adminPass=data.ErrorMessage;
            this.pgForm.disable();
            this.onSave.emit();
            this.onCancel.emit();
          }
          else {
            this.utilities.toastMsg('warning',"Failed",data.Result + " : " + data.ErrorMessage);
          }
        }, (error) => {
          console.log(error);
        });
      }
    }
  }
}
