import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { config } from '@services/config';
import { apiData } from '@services/configapi';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.scss']
})

export class ViewDetailsComponent implements OnInit {
  @Input() detailData:any;
  @Output() onCancel = new EventEmitter<any>();
  allData:any=[];
  tableInfoData:any=[];
  tableCollumnHeaders:any = [
    [{value:'',bg:'white-drop'},
    {value:'15 Minutes',bg:'white-drop'},
    {value:'30 Minutes',bg:'white-drop'},
    {value:'1 Hour',bg:'white-drop'}]
  ];
  tableDataCollumns=this.tableCollumnHeaders;
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={crc_list:false};
  
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService) { }
  
  ngOnInit(){
    console.log(this.detailData);
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.crc_list=('getBankSummary' in loading)?true:false;
    });
    this.GetMasterData();
  }

  GetMasterData(){
    let param = {Id:this.detailData.Id};
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['getBankSummary'],param).subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.tableDataCollumns=this.tableCollumnHeaders;
        this.allData.forEach((element:any,index:any) => {
          let pShow = element.LabelText=='Percentage'?' %':'';
          this.tableInfoData.push([
            {value:element.LabelText,bg:'white-cell'},
            {value:element.Last15Minites + pShow,bg:'white-cell'},
            {value:element.Last30Minutes + pShow,bg:'white-cell'},
            {value:element.LastOneHour + pShow,bg:'white-cell'},
          ])
        });
      }
      else{
        this.tableDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }
  
  onBack(){
    this.onCancel.emit();
  }
}