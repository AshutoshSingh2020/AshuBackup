import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { config } from '@services/config';
import { apiData } from '@services/configapi';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-view-client-details',
  templateUrl: './view-client-details.component.html',
  styleUrls: ['./view-client-details.component.scss']
})

export class ViewClientDetailsComponent implements OnInit {
  searchQuery:any;
  @Input() detailData:any;
  @Output() onCancel = new EventEmitter<any>();
  allData:any=[];
  searchData:any=[];
  tableInfoData:any=[];
  tableCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},
    {value:'Client Name',bg:'white-drop'},
    {value:'Action',bg:'white-drop'}]
  ];
  tableDataCollumns=this.tableCollumnHeaders;
  dIndex={status:{row:0,col:0,use:false}};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={crc_list:false};
  customform: FormGroup;
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private fb:FormBuilder) { }
  
  ngOnInit(){
    this.customform = this.fb.group({
      search:['']
    });
    
    this.customform.get('search')?.valueChanges.subscribe((data)=>{
      this.filterData(data);
    });
    
    console.log(this.detailData);
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.crc_list=('getBClientList' in loading)?true:false;
      if(this.dIndex.status.use)
      {
        this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].icon=('addToBClient' in loading || 'delFromBClient' in loading)?'Loading':'feather';
      }
    });
    this.GetMasterData();
  }
  
  GetMasterData(){
    let param = {Id:this.detailData.Id};
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['getBClientList'],param).subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.tableDataCollumns=this.tableCollumnHeaders;
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:index+1,bg:'white-cell'},
            {value:element.CompanyName,bg:'white-cell'},
            ...(element.MappingId=='0'?[{value:'',bg:'white-cell',icon:'feather',iconvalue:'plus'}]:[{value:'',bg:'white-cell',icon:'feather',iconvalue:'trash'}]),
          ])
        });
      }
      else{
        this.tableDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }
  
  onValueChange(formVal:any){
    let rowData = this.allData[formVal.row];
    if(formVal.col==2&&formVal.type=='plus'){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      this.changeStatus(rowData,'add');
    }
    else if(formVal.col==2&&formVal.type=='trash'){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      this.changeStatus(rowData,'del');
    }
  }
  
  changeStatus(rowData:any,action:string){
    if(action=='add')
    {
      let param = {BankId:this.detailData.Id,PGId:rowData.Id}
      console.log(this.tableInfoData[this.dIndex.status.row]);
      this.apiservice.apiRequest(apiData['addToBClient'], param).subscribe((data: any) => {
        this.dIndex.status.use=false;
        if (data) {
          if (data.ErrorCode == "1") {
            this.utilities.toastMsg('success',"Success", data.ErrorMessage);
            this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].iconvalue='trash';
            console.log(this.tableInfoData[this.dIndex.status.row]);
          } else {
            this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
          }
        }
      }, (error) => {
        console.log(error);
      });
    }
    else{
      let param = {BankId:rowData.MappingId,PGId:0}
      console.log(this.tableInfoData[this.dIndex.status.row]);
      this.apiservice.apiRequest(apiData['delFromBClient'], param).subscribe((data: any) => {
        this.dIndex.status.use=false;
        if (data) {
          if (data.ErrorCode == "1") {
            this.utilities.toastMsg('success',"Success", data.ErrorMessage);
            this.tableInfoData[this.dIndex.status.row][this.dIndex.status.col].iconvalue='plus';
            console.log(this.tableInfoData[this.dIndex.status.row]);
          } else {
            this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
          }
        }
      }, (error) => {
        console.log(error);
      });
    }
  }
  
  onBack(){
    this.onCancel.emit();
  }
  
  filterData(searchq:any) {
    this.searchData=[];
    if (searchq) {
      this.searchData= this.allData.filter(search =>search.CompanyName.toLowerCase().includes(searchq.toLowerCase()));
    }
    if(this.searchData[0]){
      console.log('in if');
      this.tableInfoData = [];
      this.searchData.forEach((element:any,index:any) => {
        this.tableInfoData.push([
          {value:index+1,bg:'white-cell'},
          {value:element.CompanyName,bg:'white-cell'},
          ...(element.MappingId=='0'?[{value:'',bg:'white-cell',icon:'feather',iconvalue:'plus'}]:[{value:'',bg:'white-cell',icon:'feather',iconvalue:'trash'}]),
        ])
      });
    }
    else{
      this.tableInfoData = [];
      this.allData.forEach((element:any,index:any) => {
        this.tableInfoData.push([
          {value:index+1,bg:'white-cell'},
          {value:element.CompanyName,bg:'white-cell'},
          ...(element.MappingId=='0'?[{value:'',bg:'white-cell',icon:'feather',iconvalue:'plus'}]:[{value:'',bg:'white-cell',icon:'feather',iconvalue:'trash'}]),
        ])
      });
    }
  }
}