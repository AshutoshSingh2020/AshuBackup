import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { BanktransactionComponent } from './banktransaction/banktransaction.component';
import { PayGatewayComponent } from './pay-gateway/pay-gateway.component';
import { SearchMisingComponent } from './search-mising/search-mising.component';
import { PayoutBankComponent } from './payout-bank/payout-bank.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'banktransaction',
    pathMatch: 'full'
  },
  {
    path: 'banktransaction',
    component: BanktransactionComponent
  },
  {
    path: 'search-mising',
    component: SearchMisingComponent
  },
  {
    path: 'payout-bank',
    component: PayoutBankComponent
  },
  
  {
    path: 'paymentgatewaymaster',
    component: PayGatewayComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BankRoutingModule { }
