import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayoutBankComponent } from './payout-bank.component';

describe('PayoutBankComponent', () => {
  let component: PayoutBankComponent;
  let fixture: ComponentFixture<PayoutBankComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PayoutBankComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PayoutBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
