import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payout-bank',
  templateUrl: './payout-bank.component.html',
  styleUrls: ['./payout-bank.component.scss']
})
export class PayoutBankComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
