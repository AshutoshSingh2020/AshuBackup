import { NgModule } from '@angular/core';
import { BankRoutingModule } from './bank-routing.module';
import { SharedModule } from '@shared/shared.module';
import { BanktransactionComponent } from './banktransaction/banktransaction.component';
import { AddTrxDetailComponent } from './banktransaction/add-trx-detail/add-trx-detail.component';
import { AllbankComponent } from './allbank/allbank.component';
import { PayGatewayComponent } from './pay-gateway/pay-gateway.component';
import { AddPgDetailsComponent } from './pay-gateway/add-pg-details/add-pg-details.component';
import { ViewDetailsComponent } from './allbank/view-details/view-details.component';
import { ViewClientDetailsComponent } from './allbank/view-client-details/view-client-details.component';
import { SearchMisingComponent } from './search-mising/search-mising.component';
import { PayoutBankComponent } from './payout-bank/payout-bank.component';


@NgModule({
  declarations: [
    BanktransactionComponent,
    AddTrxDetailComponent,
    AllbankComponent,
    PayGatewayComponent,
    AddPgDetailsComponent,
    ViewDetailsComponent,
    ViewClientDetailsComponent,
    SearchMisingComponent,
    PayoutBankComponent
  ],
  imports: [
    BankRoutingModule,
    SharedModule,
  ]
})
export class BankModule { }
