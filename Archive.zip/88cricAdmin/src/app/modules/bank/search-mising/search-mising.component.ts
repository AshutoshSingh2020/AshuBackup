import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';
import { apiData } from '@services/configapi';
@Component({
  selector: 'app-search-mising',
  templateUrl: './search-mising.component.html',
  styleUrls: ['./search-mising.component.scss']
})
export class SearchMisingComponent implements OnInit {
  AllCallRequestinfo:any=[];
  CallRequestinfoData:any=[];
  udataToView={};
  dynamicControls = [{que:'Search',type:'input',subque:[]}];
  dIndex={Description:{row:0,col:0,use:false,value:''},refId:{row:0,col:0,use:false,value:''},refed:{row:0,col:0,use:false},status:{row:0,col:0,use:false}};
  UserCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Date',bg:'white-drop'},{value:'ReferenceId',bg:'white-drop'},{value:'Description',bg:'white-drop'},{value:'Amount',bg:'white-drop'},{value:'User Name',bg:'white-drop'},
    {value:'Mobile',bg:'white-drop'},{value:'Created Date',bg:'white-drop'}]
  ];
  UserDataCollumns=this.UserCollumnHeaders;
  currentQuery={"Search": "" ,"PageSize":200,"PageNo":1};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={crc_list:false};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private dialog: MatDialog) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.crc_list=('getBankTransaction' in loading)?true:false;
    });
    this.GetAllTranscation();
  }
  
  initializeData()
  {
    this.AllCallRequestinfo = [];
    this.CallRequestinfoData = [];
    this.udataToView = {};
  }
  
  GetAllTranscation() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['getBankTransaction'],this.currentQuery).subscribe((data: any) => {
      this.AllCallRequestinfo=data;
      if(this.AllCallRequestinfo[0]){
        this.UserDataCollumns=this.UserCollumnHeaders;
        let bg_cell = ''
        this.AllCallRequestinfo.forEach((element:any,index:any) => {
          bg_cell = element.FirstDeposit && (element.StatusCode == 'PR' || element.StatusCode == 'P')?'blue-blink-cell':'white-cell';
          this.CallRequestinfoData.push([
            {value:index+1,bg:bg_cell},
            // {value:element.Date?moment(element.Date).format("MMM DD, yyyy"):'',bg:bg_cell},
            {value:element.Date,bg:bg_cell},
            {value:element.ReferenceId,bg:bg_cell},
            {value:element.Description,bg:bg_cell},
            {value:'₹ ' +element.Amount,bg:bg_cell },
            {value:element.UserName,bg:bg_cell},
            {value:element.Mobile,bg:bg_cell},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:bg_cell,sufText:element.TimeAgo},
          ])
        });
      }
      else{
        this.UserDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.error(error);
    });
  }
  
  onValueChange(formVal:any){
    // if(formVal.value != '' && formVal.value != undefined && formVal.value != null && formVal.col==6){
    //   this.dIndex.Description= formVal.value;
    // }
    
    // if(formVal.col==9 &&formVal.type=='Complete'){

    //   if(this.dIndex.refed.use)
    //   {
    //     let rowOldVal={Desciption:this.CallRequestinfoData[this.dIndex.refed.row][6].value};
    //     this.CallRequestinfoData[this.dIndex.refed.row][6]={value:rowOldVal.Desciption,bg:'white-cell'};
    //   }
    //   this.dIndex.refed.row=formVal.row;
    //   this.dIndex.refed.col=formVal.col;
    //   this.dIndex.refed.use=true;
    //   let rowVal={Desciption:this.CallRequestinfoData[formVal.row][6].value};
    //   this.CallRequestinfoData[formVal.row][6]={value:rowVal.Desciption,bg:'white-cell',icon:'Textarea',loader:false,outSave:true};
    //   this.CallRequestinfoData[formVal.row][9].value="Save";
    // }

    // if(formVal.col==9 && formVal.type=='Save'){
    //   let bg_cell = ''
    //   let data = this.AllCallRequestinfo[formVal.row];
    //   data.Description =this.dIndex.Description;
    //   this.updatedesciption(data);
    //   this.dIndex.refed.row=formVal.row;
    //   this.dIndex.refed.col=formVal.col;
    //   this.dIndex.refed.use=true;
    //   this.CallRequestinfoData[formVal.row][6]={value:this.dIndex.Description,bg:'white-cell',icon:'',loader:false,outSave:true};
    //   this.CallRequestinfoData[formVal.row][9]={value:'',bg:bg_cell};
    // }
  }
  
  // updatedesciption(param:any){
  //   this.apiservice.apiRequest(apiData['saveCallRequest'],param).subscribe((data: any) => {
  //     if (data) {
  //       if (data.ErrorCode == "1") {
  //         this.utilities.toastMsg('success',"Success", data.ErrorMessage);
  //       } else {
  //         this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
  //       }
  //     }
  //   }, (error) => {
  //     console.error(error);
  //   });
  // }

  

  
  getSearchQuery(formVal:any)
  {
    console.log(formVal.Search.value);
    this.currentQuery.Search=formVal.Search.value;
    this.GetAllTranscation();
  }
  
  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }

}
