import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchMisingComponent } from './search-mising.component';

describe('SearchMisingComponent', () => {
  let component: SearchMisingComponent;
  let fixture: ComponentFixture<SearchMisingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchMisingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchMisingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
