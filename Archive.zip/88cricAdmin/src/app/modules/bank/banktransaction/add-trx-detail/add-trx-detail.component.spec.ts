import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTrxDetailComponent } from './add-trx-detail.component';

describe('AddTrxDetailComponent', () => {
  let component: AddTrxDetailComponent;
  let fixture: ComponentFixture<AddTrxDetailComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddTrxDetailComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddTrxDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
