import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { DatePipe } from '@angular/common';
import { Subscription } from 'rxjs';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-banktransaction',
  templateUrl: './banktransaction.component.html',
  styleUrls: ['./banktransaction.component.scss'],
  providers: [DatePipe]
})

export class BanktransactionComponent implements OnInit {
  assignList: any = [];
  export:boolean=false;
  ClienNameList: any = [];
  @ViewChild('TrxDialogOpen') TrxDialogOpen!: TemplateRef<any>;
  apiLoader={btc_list:false,btc_export:false};
  allData:any=[];
  tableInfoData:any=[];
  rowCount={f:0,l:0,t:0};
  pageCount=[10,50,100,200,500,1000];
  pagesTotal=1;
  paginatorBlock:any=[];
  maxDate=new Date();
  
  dynamicControls = [
    
  //   {que:'Type',type:'dropdown',options:['All','Date Range'],
  // subque:[{showIf:'Date Range',que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]}]},
  // {que:'Search',type:'input',subque:[]}

];
  
  trxCollumnHeaders:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Date',bg:'white-drop'},{value:'ReferenceId',bg:'white-drop'},{value:'Description',bg:'white-drop'},
    {value:'Amount',bg:'white-drop'},{value:'UserName',bg:'white-drop'},{value:'Mobile',bg:'white-drop'},{value:'Created Date',bg:'white-drop'}]
  ]
  
  trxDataCollumns=this.trxCollumnHeaders;

  currentQuery={"Search": "","PageNo": 1,"PageSize": this.pageCount[3],"StartDateTime": null,"EndDateTime": null};
  dIndex={info:{row:0,col:0,use:false}};
  private loaderSubscriber: Subscription;
private apiSubscriber: Subscription[]=[];
  
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog,private datePipe:DatePipe) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.btc_list=('GetBankTransaction' in loading)?true:false;
      if(this.dIndex.info.use)
      {
        if (this.dIndex.info && this.dIndex.info.row !== undefined && this.dIndex.info.col !== undefined) {
          let row = this.dIndex.info.row;
          let col = this.dIndex.info.col;
          if (row >= 0 && row < this.tableInfoData.length && col >= 0 && col < this.tableInfoData[row].length) {
            this.tableInfoData[row][col].loader = 'setBTrxDesc' in loading ? true : false;
          }
          } 
      }
  
    });
    this.getAllData();
  }
  
  getAllData()
  {
    this.GetAllTrx();
  }
  
  initializeData()
  {
    this.allData = [];
    this.tableInfoData = [];
  }
  
  onPaginatorChange(paginatorQuery:any){
    if(paginatorQuery.action=='pageSize'){
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if(paginatorQuery.action=='pageNo'){
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetAllTrx();
  }
  
  GetAllTrx() {
    this.initializeData();
    this.apiservice.apiRequest(apiData['GetBankTransaction'], this.currentQuery).subscribe((data: any) => {
      this.allData=data;
      if(this.allData[0]){
        this.trxDataCollumns=this.trxCollumnHeaders;
        this.pagesTotal=Math.ceil(this.allData[0].TotalCount/this.currentQuery.PageSize);
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
          {value:((this.currentQuery.PageNo-1)*this.currentQuery.PageSize)+(index+1),bg:'white-cell'},
          {value:element.Date,bg:'white-cell'},
          {value:element.ReferenceId,bg:'white-cell'},
          {value:element.Description,bg:'white-cell',loader:false},
          {value:element.Amount,bg:'white-cell'},
          {value:element.UserName,bg:'white-cell'},
          {value:element.Mobile,bg:'white-cell'},
          {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:'white-cell'}
          ])
        });
        this.rowCount={f:this.tableInfoData[0][0].value,l:this.tableInfoData[this.tableInfoData.length-1][0].value,t:this.allData[0].TotalCount};
        this.setPaginator();
      }
      else{
        this.rowCount={f:0,l:0,t:0};
        this.trxDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.log(error);
    });
  }

  onValueChange(formVal:any){
    let allBankData = this.allData[formVal.row];
    console.log(allBankData);
    if(formVal.col==3){
      let param =allBankData;
      this.dIndex.info.row=formVal.row;
      this.dIndex.info.col=formVal.col;
      this.dIndex.info.use=true;
      this.updateDescription(param,formVal.value);
    }
  }

  updateDescription(data:any,description:any){
    let param = {Id:data.Id,Description:description};
    this.apiservice.apiRequest(apiData['setBTrxDesc'],param).subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.getAllData();
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      this.utilities.toastMsg('error',"Failed","Some thing went Wrong");
      // console.log(error);
    });
  }

  setPaginator(){
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }
  
  getSearchQuery(formVal:any)
  {
    console.log(formVal);
    this.currentQuery.Search=formVal.Search.value;
    let typeVal = formVal.Type.value;
    if(typeVal=='All'){
      this.currentQuery.StartDateTime=null;
      this.currentQuery.EndDateTime=null;
    }
    else if(typeVal=='Date Range'){
      this.currentQuery.StartDateTime=moment(formVal.Type.subque[0].value1).format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
      this.currentQuery.EndDateTime=moment(formVal.Type.subque[0].value2).format('YYYY-MM-DDTHH:mm:ss.SSS') + 'Z';
      this.export = true;
    }
    this.currentQuery.PageNo = 1;
    this.GetAllTrx();
  }
  
  closePopup(){
    this.dialog.closeAll();
  }

  onSave(){
    this.GetAllTrx();
  }

  TrxOpenPopup() {
    let dialogRef = this.dialog.open(this.TrxDialogOpen, {
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {
      this.closePopup();
    })
  }

  DownloadExcelData(){
    let d1 = this.datePipe.transform(this.currentQuery.StartDateTime, 'dd/MM/yyyy HH:mm');
    let d2 = this.datePipe.transform(this.currentQuery.EndDateTime, 'dd/MM/yyyy HH:mm');
    let search = this.currentQuery.Search?this.currentQuery.Search:' ';
    d1 = d1?d1:' ';
    d2 = d2?d2:' ';
    let request = "?SearchText="+search+"&StartDateTime="+d1+"&EndDateTime="+d2;
    let docname = 'BankTranscation'+'_'+moment(d1)+'to_'+moment(d2);
    this.apiservice.exportExcel(config['exportBankTransaction'] + request,docname,'exportBankTransaction');
  }
}
