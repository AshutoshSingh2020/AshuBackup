import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { DatePipe } from '@angular/common';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import moment from 'moment';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-recon',
  templateUrl: './recon.component.html',
  styleUrls: ['./recon.component.scss'],
  providers: [DatePipe]
})

export class ReconComponent implements OnInit, OnDestroy {
  allData:any=[];
  tableInfoData:any=[];
  maxDate=new Date();
  maxDF=this.datePipe.transform(this.maxDate, 'yyyy-MM-dd');
  dIndex={dlstatus:{row:0,col:0,use:false,data:{}}};
  
  dynamicControls = [
    {que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]},
  ];
  
  collumnHeads:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Client',bg:'white-drop'},{value:'Withdrawal',bg:'white-drop'},
    {value:'Pending',bg:'white-drop'},{value:'View',bg:'white-drop'}]
  ];

  tableCollumns=this.collumnHeads;
  currentQuery={"StartDateTime": this.maxDF,"EndDateTime": this.maxDF};

  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={primary_list:false};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private datePipe: DatePipe) { }
   
  ngOnInit(): void
  {
    this.initSubscribe();
    this.getAllData();
  }
  
  getAllData()
  {
    this.GetPrimaryData();
  }

  initSubscribe()
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.primary_list=('getClientRecon' in loading);
      if(this.dIndex.dlstatus.use)
      {
        this.tableInfoData[this.dIndex.dlstatus.row][this.dIndex.dlstatus.col].icon=('downLoadWithdraw' in loading)?'Loading':'DownloadBtn';
      }
    });
  }

  resetSubscribe()
  {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
  
  initializeData()
  {
    this.resetSubscribe();
    this.allData = [];
    this.tableInfoData = [];
    this.initSubscribe();
  }
  
  GetPrimaryData()
  {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['getClientRecon'], this.currentQuery).subscribe({
      next: (data:any) => {
        this.allData=data;
      if(this.allData[0]){
        this.tableCollumns=this.collumnHeads;
        this.allData.forEach((element:any,index:any) => {
          this.tableInfoData.push([
            {value:index+1,bg:'white-cell'},
            {value:element.ClientName,bg:'white-cell'},
            {value:'₹ '+ this.utilities.roundOffNum(element.Withdrawal),bg:'white-cell'},
            {value:'₹ '+ this.utilities.roundOffNum(element.PayoutPendingBalance),bg:'white-cell'},
            {value:element.ClientId,icon:'DownloadBtn',downloadvalue:'dlRecon',bg:'white-cell'}
          ])
        });
      }
      else{
        this.tableCollumns=this.utilities.TableDataNone;
      }
      },
      error: (error)=> {
        console.error(error);
      }
    });
  }
  
  getSearchQuery(formVal:any)
  {
    console.log(formVal);
    this.currentQuery.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'yyyy-MM-dd');
    this.currentQuery.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'yyyy-MM-dd');
    this.GetPrimaryData();
  }

  onValueChange(formVal:any){
    if(formVal.col==4){
      this.dIndex.dlstatus.row=formVal.row;
      this.dIndex.dlstatus.col=formVal.col;
      this.dIndex.dlstatus.data=formVal.value;
      this.dIndex.dlstatus.use=true;
      this.DownloadWithdrawalRequestData();
    }
  }

  DownloadWithdrawalRequestData() {
    let d1 = (moment(this.currentQuery.StartDateTime).format("DD/MM/yyyy HH:mm"));
    let d2 = (moment(this.currentQuery.EndDateTime).format("DD/MM/yyyy HH:mm"));
    let ClientId = this.dIndex.dlstatus.data;
    let request = "?ClientId=" + ClientId + "&StartDateTime="+d1+"&EndDateTime="+d2;
    let docname = 'Recon_Download';
    this.apiservice.exportExcel(config['downLoadWithdraw'] + request,docname,'downLoadWithdraw');
  }

  ngOnDestroy()
  {
    this.resetSubscribe();
  }
}