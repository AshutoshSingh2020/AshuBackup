import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup } from "@angular/forms";

import { config } from '@services/config';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-data-add',
  templateUrl: './data-add.component.html',
  styleUrls: ['./data-add.component.scss']
})

export class DataAddComponent implements OnInit {
  @Input() submitBtn!:boolean;
  @Output() onSave = new EventEmitter<any>();
  @Output() onCancel = new EventEmitter<any>();
  
  submitDisabled=false;
  
  adminForm!: FormGroup;
  
  constructor(private formBuilder: FormBuilder, private apiservice: ApiService, private utilities : CommonFunctionService) { }
  
  ngOnInit(){
    this.initializeForm();
  }
  
  initializeForm(){
    this.adminForm = this.formBuilder.group({    
        Debit:["0"],
        Credit:["0"],
        Description:[""]
    });
  }
  
  onBack(){
    this.onCancel.emit();
  }
  
  onSubmit(){
    if(this.adminForm.invalid){
      this.utilities.toastMsg('warning','Please enter valid Data!','');
      return;
    }
    else{
      this.submitDisabled=true;
      let FormValue = this.adminForm.getRawValue();
      if(!FormValue.Description){
        this.utilities.toastMsg('warning',"Please provide Description!",'');
        this.submitDisabled=false;
        return;
      }
      if(!FormValue.Debit){
        this.utilities.toastMsg('warning',"Please provide Debit Amount!",'');
        this.submitDisabled=false;
        return;
      }
      if(!FormValue.Credit){
        this.utilities.toastMsg('warning',"Please provide Credit Amount!",'');
        this.submitDisabled=false;
        return;
      }
      this.apiservice.apiRequest(apiData['saveTally'],FormValue).subscribe((data: any) => {
        this.submitDisabled=false;
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.onCancel.emit();
          this.onSave.emit();
        }
        else {
          this.utilities.toastMsg('warning',"Failed",data.Result + " : " + data.ErrorMessage);
        }
      }, (error) => {
        console.error(error);
      });
    }
  }
}