import { NgModule } from '@angular/core';
import { ReconciliationRoutingModule } from './reconciliation-routing.module';
import { SharedModule } from '@shared/shared.module';
import { ReconComponent } from './recon/recon.component';
import { TallyComponent } from './tally/tally.component';
import { DataAddComponent } from './tally/data-add/data-add.component';
import { DownloadComponent } from './download/download.component';
import { PayGateComponent } from './pay-gate/pay-gate.component';


@NgModule({
  declarations: [
    ReconComponent,
    TallyComponent,
    DataAddComponent,
    DownloadComponent,
    PayGateComponent
  ],
  imports: [
    ReconciliationRoutingModule,
    SharedModule,
  ]
})
export class ReconciliationModule { }
