import { Component, OnDestroy, OnInit } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { DatePipe } from '@angular/common';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-download',
  templateUrl: './download.component.html',
  styleUrls: ['./download.component.scss'],
  providers: [DatePipe]
})

export class DownloadComponent implements OnInit, OnDestroy {
  tableInfoData:any=[];
  tableInfoData2:any=[];
  allData3:any=[];
  tableInfoData3:any=[];
  maxDate=new Date();
  maxDF=this.datePipe.transform(this.maxDate, 'yyyy-MM-dd');
  maxDF3=this.datePipe.transform(this.maxDate, 'MM-dd-yyyy');
  dIndex={dlstatus:{row:0,col:0,use:false,data:{}}};
  dIndex2={dlstatus:{row:0,col:0,use:false,data:{}}};
  dIndexh3={dlPGstatus:{row:0,col:0,use:false,data:{}},dlPOstatus:{row:0,col:0,use:false,data:{}}};
  dIndex3={dlPGstatus:{row:0,col:0,use:false,data:{}},dlPOstatus:{row:0,col:0,use:false,data:{}}};
  
  dynamicControls = [{changeAction:'submit',que:'Date',type:'date',minDate:null,maxDate:this.maxDate,defaultDate:this.maxDate,subque:[]}];
  dynamicControls2 = [{changeAction:'submit',que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]}];
  dynamicControls3 = [{que:'Date',type:'daterange',minDate:null,maxDate:this.maxDate,startDate:this.maxDate,endDate:this.maxDate,subque:[]}];
  
  collumnHeads:any = [[{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'Zone',bg:'white-drop'},{value:'Action',bg:'white-drop'}]];

  collumnHeads3:any = [
    [{value:'Sr. No',bg:'white-drop'},{value:'Name',bg:'white-drop'},
    {icon:'',downloadvalue:'AllPGData',value:'PG On Date',bg:'blue-drop'},
    {icon:'',value:'Payout On Date',bg:'red-drop',downloadvalue:'AllRData'}
    ]
  ]
  
  tableCollumns=this.collumnHeads;
 
  tableCollumns3=this.collumnHeads3;
  
  private loaderSubscriber: Subscription;
  
  private apiSubscriber: Subscription[]=[];
  apiLoader={list_3:false};
  
  timeZones=[{id:"IST",tZone:"IST"},{id:"UTC",tZone:"UTC"}];
  currentQuery={"SelectedDate": this.maxDF,"timeZone": this.timeZones[0].tZone};
  currentQuery2={"StartDateTime": this.maxDF,"EndDateTime": this.maxDF,"timeZone": this.timeZones[0].tZone};
  currentQuery3={"StartDateTime": this.maxDF3,"EndDateTime": this.maxDF3};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private datePipe: DatePipe) { }
  
  ngOnInit(): void
  {
    this.initSubscribe();
    this.getAllData();
    this.tableInfoData=[[
      {value:1,bg:'white-cell'},
      {value:"Player detail",bg:'white-cell'},
      {value:"tZone",bg:'white-cell',refArray:this.timeZones,sKey:'id',sValue:this.timeZones[0].tZone,icon:'ChangeDropdown',loader:false},
      {value:"",icon:'DownloadBtn',downloadvalue:'dlDailyUserActWGame',bg:'white-cell'}
    ]];
    this.tableInfoData2=[[
      {value:1,bg:'white-cell'},
      {value:"Game detail",bg:'white-cell'},
      {value:"tZone",bg:'white-cell',refArray:this.timeZones,sKey:'id',sValue:this.timeZones[0].tZone,icon:'ChangeDropdown',loader:false},
      {value:"",icon:'DownloadBtn',downloadvalue:'dlRecon',bg:'white-cell'}
    ]];
  }
  
  getAllData()
  {
    this.GetPrimaryData3();
  }
  
  initSubscribe()
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.list_3=('GetClientGatewayData' in loading)?true:false;
      if(this.allData3.length>0){
        if(this.dIndex.dlstatus.use)
        {
          this.tableInfoData[this.dIndex.dlstatus.row][this.dIndex.dlstatus.col].icon=('dlDailyUserActWGame' in loading)?'Loading':'DownloadBtn';
        }
        if(this.dIndex3.dlPOstatus.use)
        {
          this.tableInfoData3[this.dIndex3.dlPOstatus.row][this.dIndex3.dlPOstatus.col].icon=('dlAllPOdata' in loading)?'Loading':'Download';
        }
      }
    });
  }
  
  resetSubscribe()
  {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
  
  initializeData()
  {
    this.resetSubscribe();
    this.allData3 = [];
    this.tableInfoData3 = [];
    this.initSubscribe();
  }
  
  GetPrimaryData3()
  {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['GetClientGatewayData'], this.currentQuery3).subscribe((data: any) => {
      if(data){
        this.allData3 = data;
        this.allData3.forEach((element:any,index:any) => {
          this.tableInfoData3.push([
            {value:index+1,bg:'white-cell'},
            {value:element.ClientName,bg:'white-cell'},
            (element.TotalTransactionOnDate ? {value:'₹ '+this.utilities.roundOffNum(element.TotalTransactionOnDate),bg:'blue-cell',downloadvalue:'ClientPGData'}:{value:'₹ '+this.utilities.roundOffNum(element.TotalTransactionOnDate),bg:'blue-cell'}),
            (element.TotalPayoutTransactionOnDate ? {value:'₹ '+this.utilities.roundOffNum(element.TotalPayoutTransactionOnDate),bg:'red-cell',icon:'Download',downloadvalue:'ClientRData'}:{value:'₹ '+this.utilities.roundOffNum(element.TotalPayoutTransactionOnDate),bg:'red-cell'})
            
          ]);
        });
      }
      else{
        this.tableCollumns3=this.utilities.TableDataNone;
      }      
    }, (error) => {
      console.log(error);
    });
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.SelectedDate=this.datePipe.transform(formVal.Date.value, 'yyyy-MM-dd');
  }
  
  getSearchQuery3(formVal:any)
  {
    this.currentQuery3.StartDateTime=this.datePipe.transform(formVal.Date.value1, 'yyyy-MM-dd');
    this.currentQuery3.EndDateTime=this.datePipe.transform(formVal.Date.value2, 'yyyy-MM-dd');
    this.GetPrimaryData3();
  }
  
  onValueChange(formVal:any){
    if(formVal.col==2){
      this.currentQuery.timeZone=formVal.value;
    }
    else if(formVal.col==3){
      this.dIndex.dlstatus.row=formVal.row;
      this.dIndex.dlstatus.col=formVal.col;
      this.dIndex.dlstatus.data=formVal.value;
      this.dIndex.dlstatus.use=true;
      this.DownloadExcelData();
    }
  }
  
  onValueChange3(formVal:any){
    let cId = this.allData3[formVal.row].ClientId;
    if(formVal.col==3){
      this.dIndex3.dlPOstatus.row=formVal.row;
      this.dIndex3.dlPOstatus.col=formVal.col;
      this.dIndex3.dlPOstatus.data=formVal.value;
      this.dIndex3.dlPOstatus.use=true;
      let filtercId = cId?cId:0;
      this.DownloadExcelData3('PO',filtercId);
    }
  }

  DownloadExcelData() {
    let d1 = this.datePipe.transform(this.currentQuery.SelectedDate, 'yyyy-MM-dd');
    let request = "?SelectedDate="+d1+"&TimeZone="+this.currentQuery.timeZone;
    let docname = 'DailyUserAcivityWithGame_Download';
    this.apiservice.exportExcel(config['dlDailyUserActWGame'] + request,docname,'dlDailyUserActWGame');
  }
  
  DownloadExcelData3(id:string,cid:string) {
    let d1 = this.datePipe.transform(this.currentQuery3.StartDateTime, 'dd/MM/yyyy 00:00');
    let d2 = this.datePipe.transform(this.currentQuery3.EndDateTime, 'dd/MM/yyyy 23:59');
    let request = "?ClientId="+cid+"&StartDateTime="+d1+"&EndDateTime="+d2;
    if(id=='PO')
    {
      let docname = 'PayoutRecord_'+this.datePipe.transform(this.currentQuery3.StartDateTime, 'dd_MM_yyyy_00_00')+'_'+this.datePipe.transform(this.currentQuery3.EndDateTime, 'dd_MM_yyyy_23_59');
      this.apiservice.exportExcel(config['dlAllPOdata'] + request,docname,'dlAllPOdata');
    }
  }
  
  ngOnDestroy()
  {
    this.resetSubscribe();
  }
}
