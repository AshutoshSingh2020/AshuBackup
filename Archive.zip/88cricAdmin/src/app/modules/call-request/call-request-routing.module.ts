import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CallRequestCompleteComponent } from './call-request-complete/call-request-complete.component';
import { CallRequestComponent } from './call-request.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'callrequest',
    pathMatch: 'full'
  },
  {
    path: 'callrequest',
    component: CallRequestComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CallRequestRoutingModule { }
