import { Component, OnInit, OnDestroy, TemplateRef, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import moment from 'moment';
import { Subscription } from 'rxjs';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-call-request',
  templateUrl: './call-request.component.html',
  styleUrls: ['./call-request.component.scss']
})

export class CallRequestComponent implements OnInit {
  @ViewChild('CallRequestCompletePopUp') CallRequestCompletePopUp!: TemplateRef<any>;
  AllCallRequestinfo:any=[];
  CallRequestinfoData:any=[];
  udataToView={};
  dynamicControls = [{que:'Search',type:'input',subque:[]}];
  dIndex={Description:{row:0,col:0,use:false,value:''},refId:{row:0,col:0,use:false,value:''},refed:{row:0,col:0,use:false},status:{row:0,col:0,use:false}};
  UserCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Id',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'User Name',bg:'white-drop'},
    {value:'Mobile',bg:'white-drop'},{value:'Date',bg:'white-drop'},{value:'Remark',bg:'white-drop'},{value:'Action',bg:'white-drop'}]
  ];
  UserDataCollumns=this.UserCollumnHeaders;
  currentQuery={"Search": ""};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  apiLoader={crc_list:false};
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService,private dialog: MatDialog) { }
  
  ngOnInit(): void {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.apiLoader.crc_list=('getCallBackRequest' in loading)?true:false;
      if(this.dIndex.refed.use)
      {
     
        this.CallRequestinfoData[this.dIndex.refed.row][this.dIndex.refed.col].icon=('saveCallRequest' in loading)?'Loading':'';
        // console.log(this.CallRequestinfoData[this.dIndex.refed.row][this.dIndex.refed.col].icon)
      }
    });
    this.GetAllCallRequests();
  }
  
  initializeData()
  {
    this.AllCallRequestinfo = [];
    this.CallRequestinfoData = [];
    this.udataToView = {};
  }
  
  GetAllCallRequests() {
    this.initializeData();
    this.apiSubscriber[0] = this.apiservice.apiRequest(apiData['getCallBackRequest']).subscribe((data: any) => {
      this.AllCallRequestinfo=data;
      if(this.AllCallRequestinfo[0]){
        this.UserDataCollumns=this.UserCollumnHeaders;
        let bg_cell = ''
        this.AllCallRequestinfo.forEach((element:any,index:any) => {
          bg_cell = element.FirstDeposit && (element.StatusCode == 'PR' || element.StatusCode == 'P')?'blue-blink-cell':'white-cell';
          this.CallRequestinfoData.push([
            {value:index+1,bg:bg_cell},
            {value:element.UserId,bg:bg_cell},
            {value:element.FName + ' ' + element.LName,bg:bg_cell},
            {value:element.UserName,bg:bg_cell},
            {value:element.Mobile,bg:bg_cell},
            {value:element.CreatedDate?moment(element.CreatedDate).format("h:mm:ss A, DD-MMM-yyyy"):'',bg:bg_cell,sufText:element.TimeAgo},
            {value:element.Description,bg:bg_cell},
            ...(element.Description?[{value:'',bg:bg_cell}]:[{value:'Complete',bg:bg_cell,icon:'None'}]),
          ])
        });
      }
      else{
        this.UserDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.error(error);
    });
  }
  
  onValueChange(formVal:any){
    if(formVal.value != '' && formVal.value != undefined && formVal.value != null && formVal.col==6){
      this.dIndex.Description= formVal.value;
    }
    // console.log(formVal);
    if(formVal.type=='Complete'){

      if(this.dIndex.refed.use)
      {
        let rowOldVal={Desciption:this.CallRequestinfoData[this.dIndex.refed.row][6].value};
        this.CallRequestinfoData[this.dIndex.refed.row][6]={value:rowOldVal.Desciption,bg:'white-cell'};
      }
      this.dIndex.refed.row=formVal.row;
      this.dIndex.refed.col=formVal.col;
      this.dIndex.refed.use=true;
      let rowVal={Desciption:this.CallRequestinfoData[formVal.row][6].value};
      this.CallRequestinfoData[formVal.row][6]={value:rowVal.Desciption,bg:'white-cell',icon:'Textarea',loader:false,outSave:true};
      this.CallRequestinfoData[formVal.row][7].value="Save";
    }

    if(formVal.col==7 && formVal.type=='Save'){
      let bg_cell = ''
      let data = this.AllCallRequestinfo[formVal.row];
      data.Description =this.dIndex.Description;
      this.dIndex.refed.row=formVal.row;
      this.dIndex.refed.col=formVal.col;
      this.dIndex.refed.use=true;
      this.updatedesciption(data);
      this.CallRequestinfoData[formVal.row][6]={value:this.dIndex.Description,bg:'white-cell',icon:'',loader:false,outSave:true};
      this.CallRequestinfoData[formVal.row][7]={value:'',bg:bg_cell};
    }
  }
  
  updatedesciption(param:any){
    this.apiservice.apiRequest(apiData['saveCallRequest'],param).subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.error(error);
    });
  }
  onSavePopup(){
    this.GetAllCallRequests();
    this.dialog.closeAll();
  }
  
  CompleteOpenPopup() {
    let dialogRef = this.dialog.open(this.CallRequestCompletePopUp, {
      height: '900x',
      width: '600px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  getSearchQuery(formVal:any)
  {
    this.currentQuery.Search=formVal.C0;
    this.GetAllCallRequests();
  }
  
  ngOnDestroy() {
    if (this.loaderSubscriber) {
      this.loaderSubscriber.unsubscribe();
    }
    if(this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
}