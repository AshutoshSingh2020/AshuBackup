import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { CallRequestRoutingModule } from './call-request-routing.module';
import { CallRequestComponent } from './call-request.component';
import { CallRequestCompleteComponent } from './call-request-complete/call-request-complete.component';


@NgModule({
  declarations: [
    CallRequestComponent,
    CallRequestCompleteComponent
  ],
  imports: [
    CallRequestRoutingModule,
    SharedModule,
  ]
})
export class CallRequestModule { }
