import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MiseedPlayerComponent } from './miseed-player/miseed-player.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'missed-player',
    pathMatch: 'full'
  },
  {
    path: 'missed-player',
    component: MiseedPlayerComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RetentionRoutingModule { }
