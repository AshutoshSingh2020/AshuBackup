import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { RetentionRoutingModule } from './retention-routing.module';
import { MiseedPlayerComponent } from './miseed-player/miseed-player.component';


@NgModule({
  declarations: [
    MiseedPlayerComponent
  ],
  imports: [
    RetentionRoutingModule,
    SharedModule,

  ]
})
export class RetentionModule { }
