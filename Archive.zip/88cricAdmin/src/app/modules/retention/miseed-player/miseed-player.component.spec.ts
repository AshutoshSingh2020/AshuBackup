import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MiseedPlayerComponent } from './miseed-player.component';

describe('MiseedPlayerComponent', () => {
  let component: MiseedPlayerComponent;
  let fixture: ComponentFixture<MiseedPlayerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MiseedPlayerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MiseedPlayerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
