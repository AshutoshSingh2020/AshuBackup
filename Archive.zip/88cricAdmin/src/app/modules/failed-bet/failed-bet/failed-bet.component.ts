import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-failed-bet',
  templateUrl: './failed-bet.component.html',
  styleUrls: ['./failed-bet.component.scss']
})
export class FailedBetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
