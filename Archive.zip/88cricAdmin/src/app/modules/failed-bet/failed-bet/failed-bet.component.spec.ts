import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FailedBetComponent } from './failed-bet.component';

describe('FailedBetComponent', () => {
  let component: FailedBetComponent;
  let fixture: ComponentFixture<FailedBetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FailedBetComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FailedBetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
