import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FailedBetRoutingModule } from './failed-bet-routing.module';
import { FailedBetComponent } from './failed-bet/failed-bet.component';


@NgModule({
  declarations: [
    FailedBetComponent
  ],
  imports: [
    CommonModule,
    FailedBetRoutingModule
  ]
})
export class FailedBetModule { }
