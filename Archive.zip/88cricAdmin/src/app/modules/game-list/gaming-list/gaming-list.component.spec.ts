import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GamingListComponent } from './gaming-list.component';

describe('GamingListComponent', () => {
  let component: GamingListComponent;
  let fixture: ComponentFixture<GamingListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GamingListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GamingListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
