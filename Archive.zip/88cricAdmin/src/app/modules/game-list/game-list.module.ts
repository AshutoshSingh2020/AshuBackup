import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { GameListRoutingModule } from './game-list-routing.module';
import { GamingListComponent } from './gaming-list/gaming-list.component';


@NgModule({
  declarations: [
    GamingListComponent
  ],
  imports: [
    GameListRoutingModule,
    SharedModule,
  ]
})
export class GameListModule { }
