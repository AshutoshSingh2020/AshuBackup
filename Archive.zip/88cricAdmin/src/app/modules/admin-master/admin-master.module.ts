import { NgModule } from '@angular/core';
import { SharedModule } from '@shared/shared.module';
import { AdminMasterRoutingModule } from './admin-master-routing.module';
import { AddAdminComponent } from './add-admin/add-admin.component';
import { AddAdminDetailsComponent } from './add-admin-details/add-admin-details.component';


@NgModule({
  declarations: [
    AddAdminComponent,
    AddAdminDetailsComponent
  ],
  imports: [
    AdminMasterRoutingModule,
    SharedModule,
  ]
})
export class AdminMasterModule { }
