import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CommonFunctionService } from '@services/common-function.service';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { Subscription } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { apiData } from '@services/configapi';

@Component({
  selector: 'app-add-admin',
  templateUrl: './add-admin.component.html',
  styleUrls: ['./add-admin.component.scss']
})
export class AddAdminComponent implements OnInit {
  @ViewChild('AddAdminDialogOpen') AddAdminDialogOpen!: TemplateRef<any>;
  AllAdmininfo:any=[];
  AdmininfoData:any=[];
  dynamicControls = [
    {que:'select' ,changeAction:'submit',type:'select',default:{value:"-1",name:'All Status'},options:[{value:"1",name:'Active'},{value:"0",name:'Blocked'}],subque:[]},
    {que:'select1' ,changeAction:'submit',type:'select',default:{value:"0",name:'All Roles'},options:[],subque:[]},
    {que:'Search',type:'input',subque:[]}
  ];
  AdminCollumnHeaders:any = [
    [{value:'Sr. No.',bg:'white-drop'},{value:'Name',bg:'white-drop'},{value:'Gender',bg:'white-drop'},
    {value:'Mobile',bg:'white-drop'},{value:'Email',bg:'white-drop'},{value:'Role',bg:'white-drop'},
    {value:'Status',bg:'white-drop'},{value:'Deposit Access',bg:'white-drop'},{value:'IMPS Access',bg:'white-drop'}]
  ]
  AdminDataCollumns=[];
  currentQuery={ "Search": "", "intParam1": "-1", "intParam2": "0"};
  RolesList=[];
  addadminloader={getAdminRoles:false,getAllAdmins:false};
  dIndex={status:{row:0,col:0,use:false},depositAccess:{row:0,col:0,use:false},IMPSAccess:{row:0,col:0,use:false},roleChange:{row:0,col:0,use:false}};
  private loaderSubscriber: Subscription;
  private apiSubscriber: Subscription[]=[];
  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private dialog: MatDialog) { }
  ngOnInit(): void
  {
    this.loaderSubscriber = this.apiservice.loaderService.loading$.subscribe((loading:any={}) => {
      this.addadminloader.getAdminRoles=('getAdminRoles' in loading)?true:false;
      this.addadminloader.getAllAdmins=('getAllAdmins' in loading)?true:false;
      if(this.dIndex.status.use)
      {
        this.AdmininfoData[this.dIndex.status.row][this.dIndex.status.col].icon=('saveBlockAdmin' in loading)?'Loading':'Toggle';
      }
      if(this.dIndex.depositAccess.use)
      {
        this.AdmininfoData[this.dIndex.depositAccess.row][this.dIndex.depositAccess.col].icon=('saveDepositAccess' in loading)?'Loading':'Toggle';
      }
      if(this.dIndex.IMPSAccess.use)
      {
        this.AdmininfoData[this.dIndex.IMPSAccess.row][this.dIndex.IMPSAccess.col].icon=('saveIMPSAccess' in loading)?'Loading':'Toggle';
      }
      if(this.dIndex.roleChange.use)
      {
        this.AdmininfoData[this.dIndex.roleChange.row][this.dIndex.roleChange.col].loader=('saveRoleChange' in loading)?true:false;
      }
    });
    this.getAllData();
  }
  getAllData()
  {
    this.apiservice.apiRequest(apiData['getAdminRoles']).subscribe((data: any) => {
      this.RolesList = data;
      this.dynamicControls[1].options = this.RolesList.map(({Id, RoleName }) => ({ value:Id, name:RoleName }));
      this.GetAllAdmins();
    }, (error) => {
      console.error(error);
    });
  }
  initializeData(){
    this.AllAdmininfo=[];
    this.AdmininfoData=[];
    this.dIndex={status:{row:0,col:0,use:false},depositAccess:{row:0,col:0,use:false},IMPSAccess:{row:0,col:0,use:false},roleChange:{row:0,col:0,use:false}};
  }
  GetAllAdmins()
  {
    this.initializeData();
    this.apiservice.apiRequest(apiData['getAllAdmins'], this.currentQuery).subscribe((data: any) => {
      this.AllAdmininfo=data;
      if(this.AllAdmininfo[0]){
        this.AdminDataCollumns=this.AdminCollumnHeaders;
        this.AllAdmininfo.forEach((element:any,index:any) => {
          this.AdmininfoData.push([
            {value:index+1,bg:'white-cell'},
            {value:element.FName?(element.FName+' '+(element.LName?element.LName:'')):'',bg:'white-cell'},
            {value:element.Gender,bg:'white-cell'},
            {value:element.Mobile,bg:'white-cell'},
            {value:element.Email,bg:'white-cell'},
            {value:'RoleName',bg:'white-cell',refArray:this.RolesList,sKey:'Id',sValue:element.RoleId,icon:'EditDropdown',loader:false},
            {value:element.Status,bg:'white-cell',icon:'Toggle'},
            {value:element.DepositAccess,bg:'white-cell',icon:'Toggle'},
            ...(element.DepositAccess?[{value:element.IMPSAccess,bg:'white-cell',icon:'Toggle'}]:[{value:'',bg:'white-cell'}])
          ])
        });
      }
      else{
        this.AdminDataCollumns=this.utilities.TableDataNone;
      }
    }, (error) => {
      console.error(error);
    });
  }
  getSearchQuery(formVal:any)
  {
    this.currentQuery.intParam1=formVal.select.value;
    this.currentQuery.intParam2=formVal.select1.value;
    this.currentQuery.Search=formVal.Search.value;
    this.GetAllAdmins();
  }
  onValueChange(formVal:any)
  {
    let adminData = this.AllAdmininfo[formVal.row];
    if(formVal.col==5){
      this.dIndex.roleChange.row=formVal.row;
      this.dIndex.roleChange.col=formVal.col;
      this.dIndex.roleChange.use=true;
      let param = {Id: adminData.Id, newRoleId: formVal.value};
      this.saveRoleAdmin(param);
    }
    else if(formVal.col==6){
      this.dIndex.status.row=formVal.row;
      this.dIndex.status.col=formVal.col;
      this.dIndex.status.use=true;
      let param = {Id: adminData.Id};
      this.saveStatusAdmin(param);
    }
    else if(formVal.col==7){
      this.dIndex.depositAccess.row=formVal.row;
      this.dIndex.depositAccess.col=formVal.col;
      this.dIndex.depositAccess.use=true;
      let param = {Id:adminData.Id};
      this.saveDepositAccessAdmin(param);
    }
    else if(formVal.col==8){
      this.dIndex.IMPSAccess.row=formVal.row;
      this.dIndex.IMPSAccess.col=formVal.col;
      this.dIndex.IMPSAccess.use=true;
      let param = {Id:adminData.Id};
      this.saveIMPSAccessAdmin(param);
    }
  }
  saveRoleAdmin(param:any)
  {
    this.apiservice.apiRequest(apiData['saveRoleChange'] ,param).subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.GetAllAdmins();
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.error(error);
      console.error(error);
    });
  }
  saveStatusAdmin(param:any){
    this.apiservice.apiRequest(apiData['saveBlockAdmin'] , param).subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.AdmininfoData[this.dIndex.status.row][this.dIndex.status.col].value=!this.AdmininfoData[this.dIndex.status.row][this.dIndex.status.col].value;
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }
  saveDepositAccessAdmin(param:any){
    this.apiservice.apiRequest(apiData['saveDepositAccess'] , param).subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.AdmininfoData[this.dIndex.depositAccess.row][this.dIndex.depositAccess.col].value=!this.AdmininfoData[this.dIndex.depositAccess.row][this.dIndex.depositAccess.col].value;
          console.log(this.AdmininfoData[this.dIndex.depositAccess.row][this.dIndex.depositAccess.col].value);
          if(!this.AdmininfoData[this.dIndex.depositAccess.row][this.dIndex.depositAccess.col].value){
            this.AdmininfoData[this.dIndex.depositAccess.row][this.dIndex.depositAccess.col+1] = {value:'',bg:'white-cell'};
          }
          else{
            this.AdmininfoData[this.dIndex.depositAccess.row][this.dIndex.depositAccess.col+1] = {value:0,bg:'white-cell',icon:'Toggle'};
          }
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }
  saveIMPSAccessAdmin(param:any){
    this.apiservice.apiRequest(apiData['saveIMPSAccess'], param).subscribe((data: any) => {
      if (data) {
        if (data.ErrorCode == 1) {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
          this.AdmininfoData[this.dIndex.IMPSAccess.row][this.dIndex.IMPSAccess.col].value=!this.AdmininfoData[this.dIndex.IMPSAccess.row][this.dIndex.IMPSAccess.col].value;
        } else {
          this.utilities.toastMsg('error',"Failed",data.ErrorMessage);
        }
      }
    }, (error) => {
      console.log(error);
    });
  }
  AddAdminOpenPopup() {
    let dialogRef = this.dialog.open(this.AddAdminDialogOpen, {
      width: '800px',
      panelClass: 'screen-dialog',
    });
    dialogRef.afterClosed().subscribe(result => {})
  }
  
  closePopup(){
    this.dialog.closeAll();
  }
}