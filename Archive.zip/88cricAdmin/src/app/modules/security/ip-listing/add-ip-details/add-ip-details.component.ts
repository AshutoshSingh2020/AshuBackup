import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from "@angular/forms";

import { config } from '@services/config';
import { apiData } from '@services/configapi';
import { ApiService } from '@services/api.service';
import { CommonFunctionService } from '@services/common-function.service';

@Component({
  selector: 'app-add-ip-details',
  templateUrl: './add-ip-details.component.html',
  styleUrls: ['./add-ip-details.component.scss']
})
export class AddIpDetailsComponent implements OnInit {
  @Input() submitBtn!:boolean;
  @Output() onSave = new EventEmitter<any>();
  @Output() onCancel = new EventEmitter<any>();
  
  submitDisabled=false;
  
  adminForm!: FormGroup;
  
  constructor(private formBuilder: FormBuilder, private apiservice: ApiService, private utilities : CommonFunctionService) { }
  
  ngOnInit(){
    this.initializeForm();
  }
  
  initializeForm(){
    this.adminForm = this.formBuilder.group({
      IP:[""],
      Description:[""]
    });
  }
  
  onBack(){
    this.onCancel.emit();
  }
  
  onSubmit(){
    if(this.adminForm.invalid){
      this.utilities.toastMsg('warning','Please enter valid Data!','');
      return;
    }
    else{
      this.submitDisabled=true;
      let FormValue = this.adminForm.getRawValue();
      if(!FormValue.IP){
        this.utilities.toastMsg('warning',"Please provide IP Address!",'');
        this.submitDisabled=false;
        return;
      }
      this.apiservice.apiRequest(apiData['saveIP'],FormValue).subscribe((data: any) => {
        this.submitDisabled=false;
        if (data.ErrorCode === "1") {
          this.utilities.toastMsg('success',"Success", data.ErrorMessage);
            this.onCancel.emit();
            this.onSave.emit();
        }
        else {
          this.utilities.toastMsg('warning',"Failed",data.Result + " : " + data.ErrorMessage);
        }
      }, (error) => {
        console.error(error);
      });
    }
  }
}