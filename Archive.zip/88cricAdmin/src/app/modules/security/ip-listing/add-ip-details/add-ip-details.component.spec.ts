import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddIpDetailsComponent } from './add-ip-details.component';

describe('AddIpDetailsComponent', () => {
  let component: AddIpDetailsComponent;
  let fixture: ComponentFixture<AddIpDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddIpDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddIpDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
