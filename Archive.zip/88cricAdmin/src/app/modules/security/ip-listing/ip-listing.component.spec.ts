import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IpListingComponent } from './ip-listing.component';

describe('IpListingComponent', () => {
  let component: IpListingComponent;
  let fixture: ComponentFixture<IpListingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IpListingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IpListingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
