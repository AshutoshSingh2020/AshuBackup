import { NgModule } from '@angular/core';
import { SecurityRoutingModule } from './security-routing.module';
import { SharedModule } from '@shared/shared.module';
import { IpListingComponent } from './ip-listing/ip-listing.component';
import { AddIpDetailsComponent } from './ip-listing/add-ip-details/add-ip-details.component';


@NgModule({
  declarations: [
    IpListingComponent,
    AddIpDetailsComponent,
  
  ],
  imports: [
    SecurityRoutingModule,
    SharedModule,
  ]
})

export class SecurityModule { }