import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { IpListingComponent } from './ip-listing/ip-listing.component';


const routes: Routes = [
  {
    path: '',
    redirectTo: 'iplist',
    pathMatch: 'full'
  },
  {
    path: 'iplist',
    component: IpListingComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SecurityRoutingModule { }
