"use strict";
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var InvoiceSchema = new Schema({
  email: {
    type: String
  },
  userId: {
    type: String
  },
  amount: {
    
    type: Number,
  },
  currency: {
    type: String,
  },
  paidAmount: {
    type: Number,
    default: 0
  },
  receivingAddress: {
    type: String
  },
  balance: {
    type: Number,
  },
  conv_amount: {
    type: Number
  },
  newAccount: {
    accountNumber: String,  
    privateKey: String     
  },

  txnId: {
    type: String,
  },
  rate: {
    type: Object,
  },
  timestamp: {
    type: Number,
  },
  timeout: {
    type: Object,
  },
  cold_trans_done: {
    type: Boolean
  },
  label: {
    type: String
  }
});

module.exports = mongoose.model("invoice", InvoiceSchema);
