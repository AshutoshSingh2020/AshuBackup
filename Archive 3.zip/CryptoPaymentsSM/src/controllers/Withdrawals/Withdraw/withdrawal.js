const { withdraw_TRC20 } = require("../TRX/withdraw_trc_20");
const { withdrawTRX } = require("../TRX/withdrawTRX");
const { ETHwithdraw } = require("../ETH/withdraw_ETH");
const { withdraw_BCH } = require("../BCH/withdraw_BCH");
const { withdraw_BTC } = require("../BTC/withdraw_BTC");
const { withdraw_ERC20 } = require("../ETH/withdraw_ERC20");


const createWithdraw = async (req, res) => {
  try {
    const { amount, from_address, to_address,currency } = req.body;

    if (!amount || !from_address || !to_address) {
      return res.status(400).send({
        code: "400",
        status: "Fail",
        message: "Fill required details missing",
        data: [],
      });
    }
    

    let withdrawResult;

    switch (currency) {
      case "ETH":
        withdrawResult = await ETHwithdraw(req, res);
        break;
      case "TRX":
        withdrawResult =  await withdrawTRX(req, res);
            break;
      case "USDT_TRC20":
        withdrawResult =  await withdraw_TRC20(req, res);
             break;
      case "BTC":
        withdrawResult =  await withdraw_BTC(req, res);
             break;
      case "USDT_ERC20":
        withdrawResult =  await withdraw_ERC20(req, res);
             break;
      case "BCH":
        withdrawResult =  await withdraw_BCH(req, res);
             break;

    
      default:
        return res.status(400).send({
          code: "400",
          status: "Not Found",
          message: "Invalid Currency",
          data: {},
        });
    }

  } catch (error) {
    console.error("Error creating withdraw:", error);
    return res.status(500).json({
      code: 500,
      status: "Error",
      message: error.message,
      data: {},
    });
  }
};




module.exports = {
    createWithdraw,
};