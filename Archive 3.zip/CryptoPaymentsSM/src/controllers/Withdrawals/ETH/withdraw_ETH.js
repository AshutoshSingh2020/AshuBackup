const adminWallet = require("../../../models/adminWallet");
const {Web3} = require('web3');
const web3 = new Web3("https://sepolia.infura.io/v3/be482ba1b3ee458481c4a8f9919e636e")
const privateKey = Buffer.from( 'privateKey', 'hex');
const speakeasy = require('speakeasy');
const QRCode = require("qrcode");
const BigNumber = require('bignumber.js'); // For precise Ether calculations


// const web3eth = new Web3(process.env.ethereum_network_url);
const web3eth = new Web3(process.env.eth_explorer_url);

const sleep = (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Generate a secret key for a user
exports.generate2FASecret = async (req, res) => {
    const secret = speakeasy.generateSecret({ length: 20 });
    const otpauthUrl = secret.otpauth_url;

//     // Save the secret in the database for the user (associate with user ID)
//     // Example: await User.findByIdAndUpdate(req.user.id, { twoFASecret: secret.base32 });

    // Generate QR code
    QRCode.toDataURL(otpauthUrl, (err, data) => {
        if (err) {
            return res.status(500).json({ status: "Failed", message: "QR Code generation failed" });
        }
        res.status(200).json({
            status: "Success",
            message: "2FA setup successful",
            qrCode: data,
            secret: secret.base32, // Provide secret for backup if user needs it
        });
    });
};


// // Generate a Secret Key for a User
// const generateSecretKey = () => {
//     const secret = speakeasy.generateSecret({ length: 20 });
//     console.log("Base32 Secret Key:", secret.base32); // Save this for the user
//     console.log("OTPAuth URL (for QR Code):", secret.otpauth_url);
//     return secret.base32; // Return Base32 secret key to store in the user's profile or environment variable
// };

// // Example usage:
// const userSecretKey = generateSecretKey();
// // Save `userSecretKey` securely for the user (e.g., in the database or .env)





exports.ETHwithdraw = async (req, res) => {
    const {
        currency,
        amount,
        from_address,
        to_address,
        twofaToken,
    } = req.body;

    try {
        console.log("Withdrawal process started");

        // Fetch the wallet data for the provided from_address
        const wallet = await adminWallet.findOne({ walletAddress: from_address });
        console.log('Wallet fetched: ', wallet);

        if (!wallet || !wallet.currency || !wallet.currency.length) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Sender wallet or currency information not found",
                data: {}
            });
        }

        const senderPrivateKey = wallet.currency[0].privateKey;
        if (!senderPrivateKey) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Private key for the specified wallet and currency not found",
                data: {}
            });
        }

        // Step 1: Verify OTP (if required)
        // Uncomment and configure as needed for production
        /*
        const key = process.env.SECRET_KEY; // Use the pre-shared secret from setup
        const isVerified = speakeasy.totp.verify({
            secret: key,
            encoding: "base32",
            token: twofaToken,
        });

        if (!isVerified) {
            return res.status(403).json({
                status: "Failed",
                message: "Invalid 2FA code",
            });
        }
        */

        // Step 2: Withdrawal process
        const accountBalanceWei = await web3eth.eth.getBalance(from_address);
        const accountBalanceEther = new BigNumber(web3eth.utils.fromWei(accountBalanceWei, 'ether'));
        const amountWei = new BigNumber(web3eth.utils.toWei(amount.toString(), 'ether'));

        // Check if balance is sufficient
        if (accountBalanceWei < amountWei) {
            return res.status(400).json({
                status: "Failed",
                message: `Insufficient funds, account balance is ${accountBalanceEther.toFixed()} ETH`,
            });
        }

        // Fetch admin details
        const admin = await adminWallet.findOne({ currency });
        const adminFeeWei = new BigNumber(web3eth.utils.toWei((+admin?.withdrawalFee || 0).toString(), 'ether'));
        const adminAddress = process.env.ADMIN_ADDRESS || '0xcA5402b561F400fd615A6BAc439b0D7d5FD0c195';

        let gasPrice = await web3eth.eth.getGasPrice();
        let gasLimit = await web3eth.eth.estimateGas({
            from: from_address,
            to: to_address,
            value: amountWei.toString(),
        });

        let sendingAmount = amountWei.minus(adminFeeWei);
        const transactionFee = new BigNumber(gasPrice).times(gasLimit);

        // Check if sufficient balance remains for transaction fee
        if (sendingAmount.minus(transactionFee).isLessThan(0)) {
            return res.status(400).json({
                status: "Failed",
                message: "Insufficient funds after accounting for fees",
            });
        }

        sendingAmount = sendingAmount.minus(transactionFee);

        // Sign and send the transaction
        const ETHTransaction = await web3eth.eth.accounts.signTransaction(
            {
                from: from_address,
                to: to_address,
                value: sendingAmount.toString(),
                gas: gasLimit,
                gasPrice: gasPrice,
            },
            senderPrivateKey
        );

        const ETHReceipt = await web3eth.eth.sendSignedTransaction(ETHTransaction.rawTransaction);
        console.log("Transaction sent: ", ETHReceipt);

        // Send admin fee if applicable
        if (adminFeeWei.isGreaterThan(0)) {
            await sendAdminAmount(from_address, adminFeeWei.toString(), adminAddress, senderPrivateKey);
        }

        return res.status(200).json({
            status: "Success",
            transactionHash: ETHReceipt.transactionHash,
        });
    } catch (err) {
        console.error("Error in withdraw:", err);
        res.status(500).json({
            status: "Failed",
            message: err.message,
        });
    }
};

// Helper function to send admin fee
async function sendAdminAmount(from_address, adminFeeWei, adminAddress, senderPrivateKey) {
    try {
        const gasPrice = await web3eth.eth.getGasPrice();
        const gasLimit = await web3eth.eth.estimateGas({
            from: from_address,
            to: adminAddress,
            value: adminFeeWei,
        });

        const adminTransaction = await web3eth.eth.accounts.signTransaction(
            {
                from: from_address,
                to: adminAddress,
                value: adminFeeWei,
                gas: gasLimit,
                gasPrice: gasPrice,
            },
            senderPrivateKey
        );

        const adminReceipt = await web3eth.eth.sendSignedTransaction(adminTransaction.rawTransaction);
        console.log("Admin fee sent: ", adminReceipt.transactionHash);
    } catch (err) {
        console.error("Error sending admin fee:", err);
        throw new Error("Failed to send admin fee");
    }
}

// TRANSTION CODE 
// exports.withdraw = async (req, res) => {
//     const { from_address, to_address, amount } = req.body;

//     try {
//         const txCount = await web3.eth.getTransactionCount(from_address);

//         // Build the transaction object
//         const transactionObj = {
//             nonce: web3.utils.toHex(txCount),
//             to: to_address,
//             value: web3.utils.toHex(web3.utils.toWei(amount, 'ether')),
//             gasLimit: web3.utils.toHex(21000),
//             gasPrice: web3.utils.toHex(web3.utils.toWei('10', 'gwei')),
//         };

//         // Sign the transaction
//         const trx = new Tx(transactionObj, { chain: 'ropsten' });
//         trx.sign(privateKey);

//         const serializedTransaction = trx.serialize();
//         const raw = '0x' + serializedTransaction.toString('hex');

//         // Broadcast the transaction
//         const txHash = await web3.eth.sendSignedTransaction(raw);

//         console.log('Transaction Hash:', txHash);

//         // Save transaction to MongoDB
//         const trans1 = new Transaction({
//             _id: new mongoose.Types.ObjectId(),
//             from_address,
//             to_address,
//             amount,
//             gasLimit: transactionObj.gasLimit,
//             gasPrice: transactionObj.gasPrice,
//             Hash: txHash,
//         });

//         await trans1.save();

//         res.status(200).json({
//             Status: 'Transaction success',
//             trans1,
//         });
//     } catch (error) {
//         console.error('Error:', error.message || error);
//         res.status(500).json({
//             Status: 'Transaction failed',
//             error: error.message || error,
//         });
//     }
// };



// const sendAdminAmount = async (from_address, amount, to_address, senderPrivateKey) => {
//     try {
//         gasLimit = await web3eth.eth.estimateGas({
//             from: from_address,
//             to: to_address,
//             value: amount.toString()
//         });
//         gasPrice = await web3eth.eth.getGasPrice();
//         const transactionFee = +gasPrice * +gasLimit;
//         var sendingAmount = +amount - +transactionFee;
//         sendingAmount = web3eth.utils.fromWei(sendingAmount.toString(), 'ether');
//         sendingAmount = Math.floor(+sendingAmount * 1000000) / 1000000

//         sendingAmount = web3eth.utils.toWei(sendingAmount.toString(), 'ether');

//         const ETHTransaction = await web3eth.eth.accounts.signTransaction(
//             {
//                 from: from_address,
//                 to: to_address,
//                 value: sendingAmount.toString(),
//                 gas: gasLimit,
//             },
//             senderPrivateKey
//         );

//         // Deploy transaction
//         var hashi = undefined;
//         const ETHReceipt = await web3eth.eth.sendSignedTransaction(
//             ETHTransaction.rawTransaction
//         ).catch(function (error) {
//             console.log(error);
//             hashi = false
//         });

//         console.log("admin amount sent", ETHReceipt.transactionHash)
//     } catch (err) {
//         console.log("Error in sendAdminAmount", err)
//     }
// }