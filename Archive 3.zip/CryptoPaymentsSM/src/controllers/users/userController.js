const Keypair = require('../../models/Keys/Keypair');
const User = require('../../models/userModel');
const { generateKeyPair, hashKey, validateKeys } = require('../../utils/cryptoUtils');

const createUserRequest = async (req, res) => {
  const { clientId, privateKey, publicKey, email } = req.body;

  if (!clientId || !email) {
    return res.status(400).json({ message: 'ClientId and Email are required' });
  }

// 05e40056c57ac1c3d52520e2e0b4ef98
// db3f7b858c7e149d79917dc6ff9884b1fac968847fb785282006971ac521b28b

console.log('changes on user controller: ')


  try {
    let user = await User.findOne({ userId: clientId });

    if (user) {
        let keys = await Keypair.findOne({userId: clientId})

        return res.status(200).json({ 
          message: 'User Already Exist', 
          userId: keys.userId,
          email: user.email,
          publicKeyHash: keys.publicKeyHash,
          publicKeyHex:keys.publicKey,
          privateKeyHex:keys.privateKey
        });

    } else {
      let { publicKeyHash, privateKeyHex, publicKeyHex } = await generateKeyPair(clientId, email);


        // creating new user for the use case
      const newUser = new User({
        userId: clientId, 
        email,
        privateKey: privateKeyHex,
        publicKey: publicKeyHex
      });
      const data = await newUser.save();
      return res.status(200).json({ 
        message: 'User created successfully', 
        userId: data.userId,
        email: data.email,
        userIP: data.userIP,
        email: email,
        publicKeyHash: publicKeyHash,

        generatedKeys: { publicKeyHex, privateKeyHex } // Send back the generated keys
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { createUserRequest };