// var mongoose = require("mongoose");
// const Invoice = require("../../models/invoiceDataModel");
// const Api = require("../../models/apiModel");
// const Acc_Balance = require("../../models/dashboard_balance");
// const InvoiceTransaction = require("../../models/Invoice_transactionModel");
// const AdminWallet = require("../../models/adminWalletModel");
// const users = require("../../models/user.model");
// const { transactionEmail } = require("./../../../utils/transactionEmail");
// const Transaction_History = mongoose.model("Transaction_History");
// const TokenAddress = require("../../models/token_addresses");
// const coinrate = require("../../models/coin_rate");
// const Refund = require("../../models/confirmRefundModel");
// const { refundTransactionMail } = require("../../../utils/refundTransactionMail");
// const crypto = require("crypto");
// const TronWeb = require("tronweb");
// var ip = require("ip");
// const MerchantFees = require("../../models/merchantFees");

// const HttpProvider = TronWeb.providers.HttpProvider;
// const fullNode = new HttpProvider(process.env.tron_first_url);
// const solidityNode = new HttpProvider(process.env.tron_second_url);
// const eventServer = new HttpProvider(process.env.tron_third_url);
// const trxPrivateKey = process.env.trx_transaction_to_address_privKey;
// const tronWeb = new TronWeb(fullNode, solidityNode, eventServer, trxPrivateKey);

// const staticUrl = "https://app.coinuniverze.com";


const mongoose = require("mongoose");
const Invoice = require("../../../../models/Invoices/invoiceModel");
const users = require('../../../../models/userModel');
const userModel = require('../../../../models/userModel');
const Coinrate = require("../../../../models/coinrates/usdRate");
const AdminWallet = require("../../../../models/adminWallet");
const InvoiceTransaction = require("../../../../models/Invoices/invoiceTransactionModel");
const crypto = require("crypto");
const {TronWeb} = require("tronweb");  // Import TronWeb correctly
const ip = require("ip");

const tronWeb = new TronWeb({
    fullHost: 'https://api.trongrid.io',
    headers: { 'TRON-PRO-API-KEY': process.env.TRON_API_KEY },
  });

// const tronConfig = {
//     fullNode: process.env.tron_first_url,
//     solidityNode: process.env.tron_second_url,
//     eventServer: process.env.tron_third_url,
//     privateKey: process.env.trx_transaction_to_address_privKey
// };

// // Initialize TronWeb providers
// const HttpProvider = TronWeb.providers.HttpProvider;
// const fullNode = new HttpProvider(tronConfig.fullNode);
// const solidityNode = new HttpProvider(tronConfig.solidityNode);
// const eventServer = new HttpProvider(tronConfig.eventServer);
// const trxPrivateKey = tronConfig.privateKey;

// // Initialize the TronWeb instance
// const tronWebInstance = new TronWeb(fullNode, solidityNode, eventServer, trxPrivateKey);

// // Set the header after initializing TronWeb
// tronWebInstance.setHeader({ "TRON-PRO-API-KEY": process.env.TRON_API_KEY });


// const staticUrl = "https://app.coinuniverze.com";

const decryptePrivateKey = (data) => {
    try {
        var encrypted = Buffer.from(data, 'base64');
        var salt_len = 16, iv_len = 16;

        var salt = encrypted.slice(0, salt_len);

        var iv = encrypted.slice(0 + salt_len, salt_len + iv_len);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 256 / 8, 'sha256');

        var decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);

        decipher.write(encrypted.slice(salt_len + iv_len));
        decipher.end();

        const decrypted = decipher.read();
        return decrypted.toString()
    } catch (err) {
        console.log('decryptedPrivateKey Error: ', err)
    }
};

const encryptedPrivateKeys = async (data) => {
    try {

        var salt = crypto.randomBytes(16);
        var iv = crypto.randomBytes(16);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 32, 'sha256');
        var cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        cipher.write(data);
        cipher.end()

        var encrypted = cipher.read();

        return Buffer.concat([salt, iv, encrypted]).toString('base64')
    } catch (err) {
        console.log("encryptedPrivateKeys Error:", err)
    }
};

const createTRXAccount = async () => {
    try {
        var newAccount = await tronWeb.createAccount();

        var privateKey = await encryptedPrivateKeys(newAccount.privateKey);
        var newAddress = newAccount.address.base58;

        return { privateKey, newAddress };

    } catch (err) {
        console.log("createTRXAccount error:", err)
    }
}

const getTRC20Balance = async (address, currency, privateKey) => {
    try {
        var contract_Address = await TokenAddress.findOne({ coin_name: "USDT-TRC20" });
        contract_Address = contract_Address.contract_Address;
        //var contract_Address = "TERimdWJAHSFvkm5YyxpW37vieyHaNLMz9";
        var decryptedPrivateKey = await decryptePrivateKey(privateKey);
        const tronUSDT = new TronWeb(fullNode, solidityNode, eventServer, decryptedPrivateKey);
        const contractI = await tronWeb.contract().at(contract_Address);
        var balance = await contractI.methods.balanceOf(address).call();
        balance = parseInt(balance);
        balance = balance / 1000000;
        return balance;
    } catch (err) {
        console.log("getTRC20Balance error: ", err)
    }
}

const createInvoiceTRC20 = async (req, res) => {
    try {
      const { email, cryptoAmount, amount, currency, publicKey, clientId } = req.body;
  
      let usdAmount, paidAmount;
  
      // Find user by clientId
      const user = await userModel.findOne({ userId: clientId });
      if (!user) {
        return res.status(404).send({
          code: "404",
          status: "Not Found",
          message: "User not found",
          data: [],
        });
      }

              // Validate minimum TRX amount if cryptoAmount is true
              const minimumAmount = parseFloat(process.env.TRC20_MINIMUM_AMOUNT || 0);
              if (cryptoAmount && amount < minimumAmount) {
                  return res.status(400).send({
                      code: "400",
                      status: "Fail",
                      message: `TRC20 amount should be greater than ${minimumAmount}`,
                      data: {},
                  });
              }
      
  
      // Check for existing USDT_TRC20 or TRX accounts
      let usdtTrcAccount = user.coins.find(coin => coin.currency === "USDT_TRC20");
      let trxAccount = user.coins.find(coin => coin.currency === "TRX");  
      let accountNumber, privateKey;
  
      if (usdtTrcAccount) {
        // Use the existing USDT_TRC20 address
        accountNumber = usdtTrcAccount.address;
        privateKey = usdtTrcAccount.privateKey;
      } else if (trxAccount) {
        // Use the existing TRX address and assign it to USDT_TRC20
        accountNumber = trxAccount.address;
        privateKey = trxAccount.privateKey;
        // Save this TRX address as a USDT_TRC20 address for future use
        user.coins.push({ currency: "USDT_TRC20", address: accountNumber, privateKey:privateKey });
        await user.save();
      } else {
        // Create new TRX account if no existing accounts are found
        const newAccount = await createTRXAccount();
        if (!newAccount || !newAccount.newAddress || !newAccount.privateKey) {
          throw new Error("Failed to create TRX account");
        }
        accountNumber = newAccount.newAddress;
        privateKey = newAccount.privateKey;
  
        // Save the newly created USDT_TRC20 account to the user's coins
        user.coins.push({ currency: "USDT_TRC20", address: accountNumber, privateKey:privateKey });
        await user.save();
      }
  
      // Fetch the current USDT_TRC20 rate
      const rateData = await Coinrate.findOne({});
      if (!rateData) {
        throw new Error("Rate data not found");
      }
      const rate = rateData.usd_rate.USDT_TRC20;

            //txnid lgic
      txnId = ""
  
      // Calculate amounts based on the cryptoAmount flag
      if (cryptoAmount) {
        usdAmount = (amount * rate).toFixed(6);
        paidAmount = amount.toFixed(6);
      } else {
        usdAmount = amount.toFixed(6);
        paidAmount = (amount / rate).toFixed(6);
      }
  
      // Create a new invoice task
      const newTask = {
        userId: clientId,
        email,
        cryptoAmount,
        amount,
        usdAmount,
        paidAmount,
        currency,
        balance: 0,
        newAccount: { accountNumber, privateKey },
        rate: rate.toFixed(6),
        timestamp: Date.now(),
        timeout: Date.now() + 14400000, // 4-hour timeout
        cold_trans_done: false,
        initialTRX_Tx: false,
        publicKey,
        txnId
      };
  
      // Save the new invoice to the database
      const newInvoice = await Invoice.create(newTask);
      console.log("Invoice created:", newInvoice);
  
      // Calculate the remaining time for the invoice
      const remainingTime = new Date(newTask.timeout - Date.now()).toISOString().substr(11, 8);
  
      // Send a successful response
      res.status(200).send({
        code: "200",
        status: "OK",
        message: "Invoice created successfully",
        data: {
          paymentStatus: "PENDING",
          paymentId: newInvoice._id,
          emailAddress: email,
          name: newInvoice.name || "Unnamed",
          usdAmount,
          totalRemainingAmount: paidAmount,
          currency,
          totalAmount: paidAmount,
          totalReceivedAmount: 0,
          conversionRate: rate.toFixed(6),
          address: accountNumber,
          remainingTime,
          paymentQRCode: accountNumber,
          txnId:txnId,
        },
      });
    } catch (err) {
      console.error("createInvoiceTRC20 error:", err);
      res.status(500).send({
        code: "500",
        status: "Internal Server Error",
        message: err.message || "An error occurred while creating the invoice",
        data: [],
      });
    }
  };
  

const invoiceStatusTRC20 = async (req, res, invoiceUser, timer) => {
    try {
        //0.1 -0.001
        //console.log(invoiceUser.currency);
       // var contract_Address = await TokenAddress.findOne({ coin_name: "USDT-TRC20" });
        //console.log(contract_Address)
        // contract_Address = contract_Address.contract_Address;
     //   console.log('----')
        //var contract_Address = "TERimdWJAHSFvkm5YyxpW37vieyHaNLMz9";
        // var decryptedPrivateKey = await decryptePrivateKey(
        //     invoiceUser.newAccount.privateKey
        // );

        var trongenieFees = 0;
        var trongenieFeesAddress;
        var balance = tronWeb.fromSun((await tronWeb.trx.getBalance(invoiceUser.newAccount.accountNumber)));
        balance = Number(balance);
        // console.log(decryptedPrivateKey)
        // const tronUSDT = new TronWeb(fullNode, solidityNode, eventServer, decryptedPrivateKey);
        // const contractI = await tronUSDT.contract().at(contract_Address);
        // console.log(invoiceUser.newAccount.accountNumber)
        // var balance = await contractI.methods.balanceOf(invoiceUser.newAccount.accountNumber).call();
        // console.log(balance, '-----')
        // balance = parseInt(balance)
        // console.log(balance, '-----')
        // balance = balance / 1000000

        const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });
        if (invoiceUser.invoiceFeeStatus) {
            const invoiceFeeData = await InvoiceFee.findOne({ currency: invoiceUser.currency })
            trongenieFeesAddress = invoiceFeeData.feeAddress;
            trongenieFees = invoiceFeeData.fee;

        }
        // var adminAmount = adminWallet.txFees;
        var adminAmount = "1";

        // var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        // var merchantRate = 0, merchantAmount = 0, merchantAddress;
        // if (merchantFees) {
        //     merchantFees = merchantFees.feeObject
        //     for (value of merchantFees) {
        //         if (value.currency == invoiceUser.currency) {
        //             merchantRate = value.rate;
        //             merchantAddress = value.address
        //             break;
        //         }
        //     }
        // }

        // if (merchantRate > 0) {
        //     merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6)
        // }

        var remainingCurrencyAmount = Number(invoiceUser.paidAmount - balance).toFixed(6);
        // var userAmount = Number(invoiceUser.paidAmount - adminAmount - merchantAmount).toFixed(6);
        var userAmount = Number(invoiceUser.paidAmount - adminAmount).toFixed(6);
        console.log(remainingCurrencyAmount, userAmount, adminAmount)

        var response = {
            code: "200",
            status: "OK",
            message: "Successful",
            data: {
                paymentStatus: "PENDING",
                paymentId: invoiceUser._id,
                emailAddress: invoiceUser.email,
                name: invoiceUser.name,
                usdAmount: invoiceUser.usdAmount,
                totalRemainingAmount: remainingCurrencyAmount,
                currency: invoiceUser.currency,
                totalAmount: invoiceUser.paidAmount,
                totalReceivedAmount: balance,
                conversionRate: invoiceUser.rate,
                address: invoiceUser.newAccount.accountNumber,
             //   statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                remainingTime:
                    timer.hours + ":" + timer.minutes + ":" + timer.seconds,
                paymentQRCode: invoiceUser.newAccount.accountNumber,
                txnId:""
            },
        };

        if (remainingCurrencyAmount <= 0) {

            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == "TRX") {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            var newAddressTRXBalance = await tronWeb.trx.getBalance(invoiceUser.newAccount.accountNumber);

            newAddressTRXBalance = tronWeb.fromSun(newAddressTRXBalance);
            console.log("TRON New ACCOUNT balance: " + newAddressTRXBalance)
            console.log(+newAddressTRXBalance < 20.01)
            if (+newAddressTRXBalance < 20) {
                if (invoiceUser.initialTRX_Tx == false) {
                    const Acc = await Acc_Balance.findOne({
                        email: invoiceUser.userEmail
                    })

                    const trxAcc = Acc.accounts.filter((data) => {
                        return data.symbol == "TRX"
                    })

                    var sendToNew = 20
                    for (var i = 0; i < trxAcc.length; i++) {
                        var bal_check = await tronWeb.trx.getBalance(trxAcc[i].account_number)
                        bal_check = tronWeb.fromSun(bal_check);
                        const privateKey = await decryptePrivateKey(trxAcc[i].account_detail.privateKey)
                        console.log(bal_check, 'ppppppp')
                        if (bal_check > 20) {
                            console.log('----')
                            const receipt = await tronWeb.trx.sendTransaction(
                                invoiceUser.newAccount.accountNumber,
                                tronWeb.toSun(sendToNew),
                                privateKey
                            );
                            console.log(receipt, '-----')
                            await Invoice.findByIdAndUpdate(
                                { _id: invoiceUser._id },
                                { initialTRX_Tx: true }
                            )
                            console.log(receipt, "receipt")
                            break
                        }
                    }
                }
            }

            const trans = await contractI.methods.transfer(
                accountAddress,
                tronWeb.toSun(userAmount)
            ).send({
                feeLimit: 10000000
            })

            await Invoice.updateOne(
                { _id: invoiceUser._id },
                {
                    cold_trans_done: true,
                    initialTRX_Tx: false
                }
            );

            var new_task = new InvoiceTransaction({
                paymentId: invoiceUser._id,
                paidAmount: invoiceUser.paidAmount,
                Transaction: trans,
            });
            new_task.save();
            console.log(`Transaction successful with hash: ${trans}`);


            if(merchantAmount > 0){

                var receipt = await contractI.methods.transfer(
                    merchantAddress,
                    tronWeb.toSun(merchantAmount)
                ).send({
                    feeLimit: 10000000
                })
                console.log(`Transaction successful with hash: ${receipt}`);

            }

            if (adminAmount >= 0.1) {
                console.log('adminfees')
                const admin = await contractI.methods.transfer(
                    adminWallet.walletAddress,
                    tronWeb.toSun(adminAmount)
                ).send({
                    feeLimit: 10000000
                })
                console.log(admin, 'admin transaction')

                await InvoiceTransaction.updateOne(
                    { paymentId: invoiceUser._id },
                    { adminTransaction: admin }
                );
            }

            var formattedTime = new Date().getTime();
            const transactionId = trans;
            var link = `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`

            var emailProvider, companyName, domain;
            if (invoiceUser.emailProvider) {
                emailProvider = invoiceUser.emailProvider;
                companyName = invoiceUser.companyName;
                domain = invoiceUser.domain;
            }

            const emailBody = {
                email: invoiceUser.email,
                firstName: "User",
                amount: invoiceUser.paidAmount,
                currency: invoiceUser.currency,
                paidfrom: invoiceUser.newAccount.accountNumber,
                paidto: accountAddress,
                transactionId,
                formattedTime,
                link,
                emailProvider,
                apiName: invoiceUser.name,
                companyName,
                domain
            };

            await transactionEmail(emailBody)

            var user = await users.find({ email: invoiceUser.userEmail }, { _id: 1 });

            var Merchantobject = {

                "email": invoiceUser.email,
                "ip": ip.address(),
                "txId": trans,
                "fee": 0,
                "currency": invoiceUser.currency,
                "paidFrom": invoiceUser.newAccount.address,
                "senderTag": "",
                "receiverTag": "",
                "amount": invoiceUser.paidAmount,
                "usdRate": invoiceUser.rate,
                "adminFee": adminAmount,
                "actualamount": invoiceUser.paidAmount,
                "ordertype": "",
                "description": "",
                "status": 1,
                "transactionType": "MerchantApi",
                "explorer": `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`,
                "userId": invoiceUser.id,
                "paidTo": accountAddress,
                "initialedDate": formattedTime,
                "confirmedDate": formattedTime

            }


            await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true })

            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "PAID",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: 0,
                    currency: invoiceUser.currency,
                    totalAmount: invoiceUser.paidAmount,
                    totalReceivedAmount: invoiceUser.paidAmount,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                  //  statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                    remainingTime: "00:00:00",
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                },
            });



        } else {

            res.status(200).send(response);
        }
    } catch (err) {
        console.log(err, "Error in invoiceStatusTRC20: ");
    }
}

const invoiceCronTRC20 = async (invoiceUser) => {
    try {
        //0.1 -0.001
        var contract_Address = await TokenAddress.findOne({ coin_name: "USDT-TRC20" });
        contract_Address = contract_Address.contract_Address;
        //var contract_Address = "TERimdWJAHSFvkm5YyxpW37vieyHaNLMz9";
        var decryptedPrivateKey = await decryptePrivateKey(
            invoiceUser.newAccount.privateKey
        );
        const tronUSDT = new TronWeb(fullNode, solidityNode, eventServer, decryptedPrivateKey);
        const contractI = await tronUSDT.contract().at(contract_Address);
        console.log(invoiceUser.newAccount.accountNumber)
        var balance = await contractI.methods.balanceOf(invoiceUser.newAccount.accountNumber).call();

        balance = parseInt(balance)

        balance = balance / 1000000

        const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });
        var adminAmount = adminWallet.txFees;

        var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        var merchantRate = 0, merchantAmount = 0, merchantAddress;
        if (merchantFees) {
            merchantFees = merchantFees.feeObject
            for (value of merchantFees) {
                if (value.currency == invoiceUser.currency) {
                    merchantRate = value.rate;
                    merchantAddress = value.address
                    break;
                }
            }
        }

        if (merchantRate > 0) {
            merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6)
        }

        var remainingCurrencyAmount = Number(invoiceUser.paidAmount - balance).toFixed(6);
        var userAmount = Number(invoiceUser.paidAmount - adminAmount - merchantAmount).toFixed(6);

        console.log(remainingCurrencyAmount, userAmount, adminAmount)

        if (remainingCurrencyAmount <= 0) {

            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == "TRX") {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            var newAddressTRXBalance = await tronWeb.trx.getBalance(invoiceUser.newAccount.accountNumber);

            newAddressTRXBalance = tronWeb.fromSun(newAddressTRXBalance);
            console.log("TRON New ACCOUNT balance: " + newAddressTRXBalance)
            console.log(+newAddressTRXBalance < 20.01)
            if (+newAddressTRXBalance < 20) {
                if (invoiceUser.initialTRX_Tx == false) {
                    const Acc = await Acc_Balance.findOne({
                        email: invoiceUser.userEmail
                    })

                    const trxAcc = Acc.accounts.filter((data) => {
                        return data.symbol == "TRX"
                    })

                    var sendToNew = 20
                    for (var i = 0; i < trxAcc.length; i++) {
                        var bal_check = await tronWeb.trx.getBalance(trxAcc[i].account_number)
                        bal_check = tronWeb.fromSun(bal_check);
                        const privateKey = await decryptePrivateKey(trxAcc[i].account_detail.privateKey)
                        console.log(bal_check, 'ppppppp')
                        if (bal_check > 20) {
                            console.log('----')
                            const receipt = await tronWeb.trx.sendTransaction(
                                invoiceUser.newAccount.accountNumber,
                                tronWeb.toSun(sendToNew),
                                privateKey
                            );
                            console.log(receipt, '-----')
                            await Invoice.findByIdAndUpdate(
                                { _id: invoiceUser._id },
                                { initialTRX_Tx: true }
                            )
                            console.log(receipt, "receipt")
                            break
                        }
                    }
                }
            }

            const trans = await contractI.methods.transfer(
                accountAddress,
                tronWeb.toSun(userAmount)
            ).send({
                feeLimit: 10000000
            })

            await Invoice.updateOne(
                { _id: invoiceUser._id },
                {
                    cold_trans_done: true,
                    initialTRX_Tx: false
                }
            );

            var new_task = new InvoiceTransaction({
                paymentId: invoiceUser._id,
                paidAmount: invoiceUser.paidAmount,
                Transaction: trans,
            });
            new_task.save();
            console.log(`Transaction successful with hash: ${trans}`);

            if(merchantAmount > 0){

                var receipt = await contractI.methods.transfer(
                    merchantAddress,
                    tronWeb.toSun(merchantAmount)
                ).send({
                    feeLimit: 10000000
                })
                console.log(`Transaction successful with hash: ${receipt}`);

            }

            if (adminAmount >= 0.1) {
                console.log('adminfees')
                const admin = await contractI.methods.transfer(
                    adminWallet.walletAddress,
                    tronWeb.toSun(adminAmount)
                ).send({
                    feeLimit: 10000000
                })
                console.log(admin, 'admin transaction')

                await InvoiceTransaction.updateOne(
                    { paymentId: invoiceUser._id },
                    { adminTransaction: admin }
                );
            }

            var formattedTime = new Date().getTime();
            const transactionId = trans;
            var link = `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`

            var emailProvider, companyName, domain;
            if (invoiceUser.emailProvider) {
                emailProvider = invoiceUser.emailProvider;
                companyName = invoiceUser.companyName;
                domain = invoiceUser.domain;
            }

            const emailBody = {
                email: invoiceUser.email,
                firstName: "User",
                amount: invoiceUser.paidAmount,
                currency: invoiceUser.currency,
                paidfrom: invoiceUser.newAccount.accountNumber,
                paidto: accountAddress,
                transactionId,
                formattedTime,
                link,
                emailProvider,
                apiName: invoiceUser.name,
                companyName,
                domain
            };

            await transactionEmail(emailBody)

            var user = await users.find({ email: invoiceUser.userEmail }, { _id: 1 });

            var Merchantobject = {

                "email": invoiceUser.email,
                "ip": ip.address(),
                "txId": trans,
                "fee": 0,
                "currency": invoiceUser.currency,
                "paidFrom": invoiceUser.newAccount.address,
                "senderTag": "",
                "receiverTag": "",
                "amount": invoiceUser.paidAmount,
                "usdRate": invoiceUser.rate,
                "adminFee": adminAmount,
                "actualamount": invoiceUser.paidAmount,
                "ordertype": "",
                "description": "",
                "status": 1,
                "transactionType": "MerchantApi",
                "explorer": `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`,
                "userId": invoiceUser.id,
                "paidTo": accountAddress,
                "initialedDate": formattedTime,
                "confirmedDate": formattedTime

            }


            await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true })




        }
    } catch (err) {
        console.log("Error in invoiceCronTRC20: ", err);
    }
}

const refundTransactionTRC20 = async (req, res, id, sender, receiver, privateKey, currency, paymentId) => {
    try {

        var contract_Address = await TokenAddress.findOne({ coin_name: currency });
        //console.log(contract_Address)
        contract_Address = contract_Address.contract_Address;
        //var contract_Address = "TERimdWJAHSFvkm5YyxpW37vieyHaNLMz9";
        var decryptedPrivateKey = await decryptePrivateKey(
            privateKey
        );
        console.log(decryptedPrivateKey)
        const tronUSDT = new TronWeb(fullNode, solidityNode, eventServer, decryptedPrivateKey);
        const contractI = await tronUSDT.contract().at(contract_Address);

        var balance = await contractI.methods.balanceOf(sender).call();
        console.log(balance, '-----')
        balance = parseInt(balance)
        console.log(balance, '-----')
        balance = balance / 1000000

        var amount = balance;



        var newAddressTRXBalance = await tronWeb.trx.getBalance(sender);

        newAddressTRXBalance = tronWeb.fromSun(newAddressTRXBalance);
        console.log("TRON New ACCOUNT balance: " + newAddressTRXBalance)
        console.log(+newAddressTRXBalance < 20.01)
        if (+newAddressTRXBalance < 20) {
            const invoiceEmail = await Invoice.findOne({ _id: paymentId }, { userEmail: 1 });
            const Acc = await Acc_Balance.findOne({
                email: invoiceEmail.userEmail
            })

            const trxAcc = Acc.accounts.filter((data) => {
                return data.symbol == "TRX"
            })

            var sendToNew = 20
            for (var i = 0; i < trxAcc.length; i++) {
                var bal_check = await tronWeb.trx.getBalance(trxAcc[i].account_number)
                bal_check = tronWeb.fromSun(bal_check);
                const privateKey = await decryptePrivateKey(trxAcc[i].account_detail.privateKey)
                console.log(bal_check, 'ppppppp')
                if (bal_check > 20) {
                    console.log('----')
                    var receipt = await tronWeb.trx.sendTransaction(
                        sender,
                        tronWeb.toSun(sendToNew),
                        privateKey
                    );

                    console.log(receipt, "1st trans receipt")
                    break
                }
            }

        }


        var receipt = await contractI.methods.transfer(
            receiver,
            tronWeb.toSun(amount)
        ).send({
            feeLimit: 10000000
        })

        console.log(`Transaction successful with hash1: ${receipt}`);

        if (receipt) {
            const refundData = await Refund.findOneAndUpdate({ _id: id }, {
                refund_txid: receipt,
                refundConfirmed: true,
                toAddress: receiver,
                amount: amount.toFixed(6)
            }, { new: true });
            await sendEmail(id);
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "Successful",
                data: {
                    status: "PAID",
                    paymentId: refundData.paymentId,
                    currency: refundData.currency,
                    amount: refundData.amount,
                    address: refundData.toAddress,
                    transactionHash: refundData.refund_txid,
                    transactionHashRedirectURL: `https://${process.env.tron_explorer_url}/#/transaction/` + refundData.refund_txid,
                },
            });
        }



    } catch (err) {
        console.log("refundTransaction error:", err)
        return res.status(500).json({
            code: 500,
            status: "Error",
            message: err.message,
            data: {},
        });
    }
}

const sendEmail = async function (refundId) {

    try {
        const refundData = await Refund.findOne({ _id: refundId });
        const email = refundData.email;
        const currency = refundData.currency;
        const amount = refundData.amount;
        const toAddress = refundData.toAddress;
        const txId = refundData.refund_txid;
        var emailProvider = refundData.emailProvider;
        var apiKey = refundData.apiKey;
        var companyName = refundData.companyName;
        var domain = refundData.domain;

        const emailBody = {
            email,
            currency,
            amount,
            toAddress,
            txId,
            emailProvider,
            apiKey,
            companyName,
            domain
        }
        console.log("mail initiated")
        await refundTransactionMail(emailBody);
        console.log("mail confirmed")
    } catch (err) {
        console.log("Error in sendEmail: ", err)
    }
}

module.exports = {
    createInvoiceTRC20,
    invoiceStatusTRC20,
    invoiceCronTRC20,
    getTRC20Balance,
    refundTransactionTRC20
}