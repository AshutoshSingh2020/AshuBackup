const express = require('express');
const withdrawController = require('../controllers/Withdrawals/ETH/withdraw_ETH');
const withdrawTRXController = require('../controllers/Withdrawals/TRX/withdrawTRX');
const withdrawTRC20Controller = require('../controllers/Withdrawals/TRX/withdraw_trc_20');
const withdraw = require('../controllers/Withdrawals/Withdraw/withdrawal');
const invoiceWithdraw = require('../controllers/Withdrawals/Withdraw/invoiceWithdrawal');
// const withdrawController = require('../controllers/Withdrawals/ETH/withdraw_ETH');
// const withdrawController = require('../controllers/Withdrawals/ETH/withdraw_ETH');
// const withdrawController = require('../controllers/Withdrawals/ETH/withdraw_ETH');

const router = express.Router();

router.post("/ETH_withdraw", withdrawController.ETHwithdraw);
router.post("/TRX_withdraw", withdrawTRXController.withdrawTRX);
router.post("/TRC20_withdraw", withdrawTRC20Controller.withdraw_TRC20);
router.post("/withdrawal", withdraw.createWithdraw);
router.post("/invoice_withdrawal", invoiceWithdraw.getWithdrawInvoice);
// router.post("/ETH_withdraw", withdrawController.ETHwithdraw);
// router.post("/ETH_withdraw", withdrawController.ETHwithdraw);
// router.post("/ETH_withdraw", withdrawController.ETHwithdraw);

router.get("/ETH_withdraw1", withdrawController.generate2FASecret);
console.log('smal channges');

module.exports = router;
