const express = require('express');
const   trx  = require('../controllers/Invoices/Tron/TRX/TRX')
const  {publicInvoiceStatus} = require('../controllers/Invoices/InvoiceStatus/InvoiceStatus')
const validateApiKeys = require('../middleware/authMiddleware')

const router = express.Router();

router.post("/createTRXAccount", trx.createTRXAccount);

// router.post("/createInvoiceETH", eth.createInvoiceETH);

// router.post("/publicInvoiceStatus", publicInvoiceStatus);


module.exports = router;