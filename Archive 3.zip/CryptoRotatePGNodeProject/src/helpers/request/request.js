const axios = require('axios');
const { json } = require('express');

const apiRequest = async (url, option,username,password) => {
    let encodedAuth = Buffer.from(`${username}:${password}`).toString('base64');
    try {
        const curlCommand = `curl -X POST '${url}' -H 'Content-Type: application/json' -H 'Authorization: Basic ${encodedAuth}' -d '${JSON.stringify(option)}'`;
        console.log('cURL Command:', curlCommand);
        let header = {
            'Content-Type': 'application/json',
            'Authorization': `Basic ${encodedAuth}`
        };
        const response = await axios.post(url, option, { headers: header });
        console.log("Response:---"+JSON.stringify(response.data))
        return response;
    } catch (error) {
        console.error('Error api: ' + error)
        throw error
    }
};
const apiCronRequest = async (url, option) => {
    // let encodedAuth = Buffer.from(`${username}:${password}`).toString('base64');
    try {
        const curlCommand = `curl -X POST '${url}' -H 'Content-Type: application/json' -d '${JSON.stringify(option)}'`;
        console.log('cURL Command:', curlCommand);
        let header = {
            'Content-Type': 'application/json',
        };
        const response = await axios.post(url, option, { headers: header });
        return response;
    } catch (error) {
        console.error('Error api: ' + error)
        throw error
    }
};
const apiGetRequest = async (url, option,username,password) => {
    let encodedAuth = Buffer.from(`${username}:${password}`).toString('base64');
    try {
        let header = {
            'Content-Type': 'application/json',
            'Authorization': `Basic ${encodedAuth}`
        };
        const response = await axios.get(url, {params: option,headers: header });
        return response;
    } catch (error) {
        console.error('Error api: ' + error)
        throw error
    }
};
module.exports = {
    apiRequest,
    apiGetRequest,
    apiCronRequest
};
