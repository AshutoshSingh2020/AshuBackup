const axios = require('axios');
const decrptData = async (data) => {
    let username = '1005';
    let password = 'e578a857be8e4397a5e8a5f34f6f15e0';
    let encodedAuth = Buffer.from(`${username}:${password}`).toString('base64');

    let url = process.env.API_URL+'crpapi/getaddressdata';
    try {
        let option = { "Result": data };
        const curlCommand = `curl -X POST '${url}' -H 'Content-Type: application/json' -H 'Authorization: Basic ${encodedAuth}' -d '${JSON.stringify(option)}'`;
        console.log('cURL Command:', curlCommand);
        let header = {
            'Content-Type': 'application/json',
            'Authorization': `Basic ${encodedAuth}`
        };
        const response = await axios.post(url,option ,header);
        return response.data;
    } catch (error) {
        console.error('Error api: ' + error)
        throw error
    }
};
module.exports = {
    decrptData
};