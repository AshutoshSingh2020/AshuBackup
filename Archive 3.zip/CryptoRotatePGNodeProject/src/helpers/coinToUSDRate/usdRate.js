const axios = require('axios');
const cron = require("node-cron");

const API_KEY = '57241df2-85eb-49f4-8bf0-998a8e31f445';
const BASE_URL = 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest';

const usdRate = async () => {
  try {
    const response = await axios.get(BASE_URL, {
      headers: { 'X-CMC_PRO_API_KEY': API_KEY },
      params: { symbol: 'BNB,BTC,TRX,ETH,LTC,DOGE,BCH,SOL,XRP,SUPER,SHIB,MATIC,ADA,STX', convert: 'USD' }
    });
    
    const data = response.data.data;
    console.log('coinrate updated: ', data);
    const usdRateObject = {
      // BNB: Number(data.BNB.quote.USD.price.toFixed(5)),
      BTC: Number(data.BTC.quote.USD.price.toFixed(5)),
      TRX: Number(data.TRX.quote.USD.price.toFixed(5)),
      ETH: Number(data.ETH.quote.USD.price.toFixed(5)),
      // LTC: Number(data.LTC.quote.USD.price.toFixed(5)),
      // DOGE: Number(data.DOGE.quote.USD.price.toFixed(5)),
      BCH: Number(data.BCH.quote.USD.price.toFixed(5)),
      // SOL: Number(data.SOL.quote.USD.price.toFixed(5)),
      // XRP: Number(data.XRP.quote.USD.price.toFixed(5)),
      // SUPER: Number(data.SUPER.quote.USD.price.toFixed(5)),
      // SHIB: Number(data.SHIB.quote.USD.price.toFixed(5)),
      // MATIC: Number(data.MATIC.quote.USD.price.toFixed(5)),
      // ADA: Number(data.ADA.quote.USD.price.toFixed(5)),
      // STX: Number(data.STX.quote.USD.price.toFixed(5)),
    };
    console.log('coinrate updated: ', usdRateObject);
return usdRateObject;
    // console.log('coinrate updated: ', usdRateObject);
    // await CoinRate.findOneAndUpdate({}, { usd_rate: usdRateObject }, { upsert: true });
  } catch (err) {
    console.log(err, "WebRate.js err");
  }
};

// Schedule cron job to run every minute
// cron.schedule("0 * * * *", async () => {
//   console.log("Running USD rate update...");
//   await usdRate();
// });

module.exports = usdRate;
