var ip = require("ip");
const rp = require("request-promise");
const { createAccount } = require("../BitcoinCash/CreateBCHAccount")
const bitcore = require('bitcore-lib-cash');
const usdRate = require('../../../helpers/coinToUSDRate/usdRate');
const axios = require('axios');
const { apiRequest, apiCronRequest } = require('../../../helpers/request/request');
const Decimal = require('decimal.js');
const { decrptData } = require('../../../helpers/security/encDec.js');
const validateBCHAddress = async (address) => {
    try {
        new bitcore.Address(address);
        return true;
    } catch (error) {
        return false;
    }
}
const getBCHBalance = async (address) => {
    // try {
    //     const url = `https://blockchain.info/q/addressbalance/${address}?cors=true`;

    //     // Fetch balance from Blockchain API
    //     const response = await axios.get(url);

    //     // Balance is returned in satoshis (1 BCH = 100,000,000 Satoshis)
    //     const balanceInSatoshis = response.data;
    //     const balanceInBCH = balanceInSatoshis / 100000000;

    //     console.log(`Balance: ${balanceInBCH} BCH`);
    //     return balanceInBCH;
    // } catch (error) {
    //     console.error("Error fetching BCH balance:", error.response?.data || error.message);
    //     return null;
    // }
    try {
        const url = `https://rest.cryptoapis.io/addresses-latest/utxo/bitcoin-cash/mainnet/${address}/balance?context=`;
        const response = await axios.get(url, {
            headers: {
                'X-API-Key': process.env.BCH_API_KEY,
                'Accept': 'application/json'
            }
        });
        //   console.log(response.data.data.item.confirmedBalance.amount)
        // ✅ Extract balance in Satoshis
        // const balanceInSatoshis = response.data.balance.confirmed;
        // const balanceInBCH = balanceInSatoshis / 100000000;

        console.log(`Balance: ${response.data.data.item.confirmedBalance.amount} BCH`);
        return response.data.data.item.confirmedBalance.amount ? response.data.data.item.confirmedBalance.amount : 0
    } catch (error) {
        console.error("Error fetching BCH balance:", error.response?.data || error.message);
        return null;
    }
    // try {
    //     const url = `https://api.fullstack.cash/v5/electrumx/balance/${address}`;
    //     const response = await axios.get(url);

    //     // ✅ Extract balance in Satoshis
    //     const balanceInSatoshis = response.data.balance.confirmed;
    //     const balanceInBCH = balanceInSatoshis / 100000000;

    //     console.log(`Balance: ${balanceInBCH} BCH`);
    //     return balanceInBCH
    // } catch (error) {
    //     console.error("Error fetching BCH balance:", error.response?.data || error.message);
    //     return null;
    // }
    // try {
    //     const url = `https://api.blockchair.com/bitcoin-cash/dashboards/address/${address}`;
    //     const response = await axios.get(url);
    //     const balance = response.data.data[address].address.balance; 
    //     return balance / 1e8; 
    // } catch (error) {
    //     console.error("Error fetching BCH balance:", error.response?.data || error.message);
    //     return null;
    // }
};
const createInvoiceBCH = async (req, res) => {
    try {
        const { email, amount, cryptoAmount, currency, publicKey, userId, address, requestId, username, password ,cURL,sURL} = req.body;

        var balance = 0;
        const minimumAmount = parseFloat(process.env.BCH_MINIMUM_AMOUNT || 0);
        if (amount < minimumAmount) {
            return res.status(400).send({
                code: "400",
                status: "Fail",
                message: `BCH amount should be greater than ${minimumAmount}`,
                data: {},
            });
        }
        let accountNumber, privateKey, mnemonic;
        if (address) {
            console.log('BCH Address: ', address);
            if (!await validateBCHAddress(address)) {
                throw new Error('Invalid BCH address');
            }
            accountNumber = address;
            privateKey = "";
            mnemonic = "";
            let add = 'bc1qq904ynep5mvwpjxdlyecgeupg22dm8am6cfvgq';
            balance = await getBCHBalance(address);
            console.log("BCH" + balance);
        } else {
            const newAccount = await createAccount();
            console.log('in else condition for private key', newAccount)
            if (!newAccount || !newAccount.address || !newAccount.privateKey || !newAccount.publicKey) {
                throw new Error("Failed to create BCH account");
            }
            console.log(newAccount.address);
            accountNumber = (newAccount.address).split(':')[1];
            privateKey = newAccount.privateKey;
            mnemonic = newAccount.publicKey;
            balance = 0;
        }
        const rateData = await usdRate();
        const rate = Number(rateData.BCH);
        txnId = "";
        let usdAmount = '';
        let paidAmount = '';
        if (rate && amount) {
            const numericAmount = Number(amount);
            const numericRate = Number(rate);
            usdAmount = cryptoAmount ? Number((Number(numericAmount) * numericRate)).toFixed(6) : numericAmount.toFixed(6);
            paidAmount = cryptoAmount ? numericAmount.toFixed(6) : (numericAmount / numericRate).toFixed(6);
        }
        const timeout = Date.now() + 14400000;
        const remainingTime = new Date(timeout - Date.now()).toISOString().substr(11, 8);
        const invoiceData = {
            "userId": userId,
            "requestid": requestId,
            "currency": currency,
            "amount": amount,
            "paidAmount": paidAmount,
            "PrivateKey": privateKey,
            "address": accountNumber,
            "balance": balance,
            "memonic": mnemonic,
            "email": email,
            "rate": rate.toFixed(6),
            "surl": sURL,
            "curl": cURL

        }
        console.log(invoiceData)
        const invoiceResponse = await apiRequest(process.env.API_URL + 'crpapi/PaymentV1', invoiceData, username, password);
        const response = invoiceResponse.data;
        if (response.ErrorCode != '1') {
            throw new Error("Failed to create Invoice :  " + response.ErrorMessage);

        }
        res.status(200).send({
            code: "200",
            status: "OK",
            message: "Invoice created successfully",
            data: response
        });
    } catch (err) {
        console.error("createInvoice BCH error:", err);
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: err.message || "An error occurred while creating the invoice",
            data: [],
        });
    }

};
// const getBCHTransactions = async (address)=> {
//     try {
//         const url = `https://api.blockchair.com/bitcoin-cash/dashboards/address/${address}?transaction_details=true`;
//         const response = await axios.get(url);
//         const transactions = response.data.data[address].transactions;

//         // Process transactions into the required format
//         const formattedTransactions = transactions.map(datum => {
//             // Convert Unix timestamp to human-readable format
//             const blockTimeIST = new Date(datum.time);

//             // Extract sender and receiver address
//             const fromAddress = datum.inputs.length > 0 ? datum.inputs[0].recipient : "Unknown";
//             const toAddress = datum.outputs.length > 0 ? datum.outputs[0].recipient : "Unknown";

//             return {
//                 transactionId: datum.hash,
//                 transactionStatus: datum.block_id ? "Confirmed" : "Unconfirmed",
//                 transactionFees: datum.fee / 100000000, // Convert from satoshis to BCH
//                 amount: Math.abs(datum.balance_change) / 100000000, // Convert from satoshis to BCH
//                 toAddress: toAddress, // Receiver address
//                 fromAddress: fromAddress, // Sender address
//                 transactionDate: blockTimeIST.toISOString().replace("T", " ").slice(0, 19), // Format (YYYY-MM-DD HH:MM:SS)
//                 txConfirmed: datum.block_id ? true : false
//             };
//         });

//         return formattedTransactions;
//     } catch (error) {
//         console.error("Error fetching BCH transactions:", error.response?.data || error.message);
//         return [];
//     }
// }
const sleep = async (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}
const toCashAddress = async (address) => {
    const cashAddr = new bitcore.Address(address).toCashAddress();
    return cashAddr;
}
// const getBCHTransactions = async (address) => {
//     try {
//         const cashAddress = await toCashAddress(address);
//         const url = `https://api.fullstack.cash/v5/electrumx/transactions/${cashAddress}`;
//         const response = await axios.get(url);
//         const transactions = response.data.transactions.slice(0, 10); 
//         const formattedTransactions = [];
//         for (let i = 0; i < transactions.length; i++) {
//             const txHash = transactions[i].tx_hash;
//             console.log("txHash"+txHash);
//             const txDetailsUrl = `https://api.fullstack.cash/v5/electrumx/tx/data/${txHash}`;
//             const txDetailsResponse = await axios.get(txDetailsUrl);

//             const datum = txDetailsResponse.data.details;
//             console.log("datum  : "+ JSON.stringify(datum))
//             const blockTimeIST = new Date(datum.blocktime * 1000);
//             const fromAddress = datum.vin.length > 0 ? datum.vin[0].address : "Unknown";
//             const toAddress = datum.vout.length > 0 ? datum.vout[0].scriptPubKey.addresses[0] : "Unknown";

//             formattedTransactions.push({
//                 transactionId: datum.txid,
//                 transactionStatus: datum.confirmations > 0 ? "Confirmed" : "Unconfirmed",
//                 transactionFees: datum.fee / 100000000,
//                 amount: datum.vout[0].value,
//                 toAddress: toAddress,
//                 fromAddress: fromAddress,
//                 transactionDate: blockTimeIST.toISOString().replace("T", " ").slice(0, 19),
//                 txConfirmed: datum.confirmations > 0 ? true : false
//             });
//             await sleep(1000);
//         }
//         return formattedTransactions;
//     } catch (error) {
//         console.error("Error fetching BCH transactions:", error.response?.data || error.message);
//         return [];
//     }
// }
const getBCHTransactions = async (address) => {
    try {
        const cashAddress = await toCashAddress(address);
        const url = `https://rest.cryptoapis.io/addresses-latest/utxo/bitcoin-cash/mainnet/${cashAddress}/transactions?sortingOrder=descending&limit=5`;
        const response = await axios.get(url, {
            headers: {
                'X-API-Key': process.env.BCH_API_KEY,
                'Accept': 'application/json'
            }
        });
        //   console.log(response.data.data.items[0].recipients)
        let data = formatTransactions(response.data.data.items);

        return data;
    } catch (error) {
        console.error("Error fetching BCH transactions:", error.response?.data || error.message);
        return [];
    }
}
const formatTransactions = async (transaction) => {
    const formattedTransactions = [];
    // Extract general transaction info
    transaction.forEach((tx) => {
        console.log(tx)
        const transactionId = tx.id;
        const transactionStatus = tx.minedInBlock ? "Confirmed" : "Unconfirmed";
        const transactionFees = parseFloat(tx.fee.amount);
        const blockTimeIST = new Date(tx.timestamp * 1000); // Convert Unix timestamp
        const txConfirmed = tx.minedInBlock ? true : false;

        // Extract sender and recipient info
        const fromAddress = tx.senders?.length > 0 ? (tx.senders[0].address).split(":")[1] : "Unknown";
        console.log("transactionId" + transactionId)
        // Iterate through all recipients to create individual transactions
        tx.recipients.forEach((recipient) => {
            // console.log("recipient"+recipient);
            // console.log("Ashu")
            formattedTransactions.push({
                transactionId: transactionId,
                transactionStatus: transactionStatus,
                transactionFees: transactionFees,
                amount: recipient.value.amount, // Convert amount to number
                toAddress: (recipient.address).split(":")[1],
                fromAddress: fromAddress,
                transactionDate: blockTimeIST.toISOString().replace("T", " ").slice(0, 19),
                txConfirmed: txConfirmed
            });
        });

    });
    return formattedTransactions;
};
const filterTransactions = (transactions, targetAmount, targetDate) => {
    return transactions.filter(txn =>
        txn.amount === targetAmount && new Date(txn.transactionDate) > new Date(targetDate) && txn.txConfirmed
    );
};

const invoiceStatusBCH = async (req, res, invoiceUser, timer) => {
    try {
        const { id, username, password } = req.body;
        // var old_balance = new Decimal('7.782937');
        var old_balance = new Decimal(invoiceUser.balance);
        // var staticAdd = 'qq0pg56eg90m7rv6en7l0vv4gpudh8wf3swa0hqsu2';
        // var staticAdd = 'qp9lfwsfy6ffg855yq8hekcesc72fs6t3s79239lm9';
        // const data = await getBCHTransactions(staticAdd);
        // console.log("transactions"+JSON.stringify(data));
        // for (let index = 0; index < transactions.length; index++) {
        //     const element = transactions[index];
        //     console.log(JSON.stringify(element))
        // }
        // console.log("otherTransactions"+otherTransactions);
        // return
        var staticAdd = invoiceUser.address;
        if (!await validateBCHAddress(staticAdd)) {
            throw new Error('Invalid BCH address');
        }
        var balance = new Decimal(await getBCHBalance(staticAdd));
        console.log("new Balance" + balance)
        console.log("old Balance" + old_balance)
        if (!balance) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Balance Not fetch",
                    txnId: ""
                }
            });
        }
        var receive_amount = balance - old_balance;
        // var receive_amount = formatUnits(bal,18);
        // console.log("bal"+bal)

        // var receive_amount =ethers.formatEther(bal);
        var formattedDate = invoiceUser.createdDate.replace('T', ' ').substring(0, 19);
        // console.log("recienve"+receive_amount)
        console.log("balance :---" + balance)
        console.log(" Recive Amount balance :---" + receive_amount)
        console.log(" formatDate :---" + formattedDate)
        console.log(invoiceUser)
        if (receive_amount > 0 && balance > old_balance) {
            const data = await getBCHTransactions(staticAdd);
            const transactions = await data;
            console.log(transactions)
            if (transactions.length <= 0) {
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "Transcation not fetch",
                        txnId: ""
                    }
                });
            }

            const matchingTransaction = await filterTransactions(transactions, receive_amount, formattedDate);
            if (matchingTransaction[0]) {
                console.log('Matching transaction found:', matchingTransaction);
                let option = {
                    "requestid": id,
                    "status": "PAID",
                    "txnId": matchingTransaction[0].transactionId,
                    "totalReceivedAmount": receive_amount

                };
                const updateData = await apiRequest(process.env.API_URL + 'crpapi/ClaimPaymentv1', option, username, password)
                const finalUpdate = updateData.data;
                console.log("response" + finalUpdate)
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: finalUpdate,
                })
            } else {
                console.log('No matching transaction found.');
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "No matching transaction found.",
                        txnId: ""
                    }
                });
            }
        } else {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "Pending",
                    paymentId: invoiceUser.paymentId,
                    emailAddress: invoiceUser.emailAddress,
                    name: invoiceUser.name,
                    totalRemainingAmount: 0,
                    currency: invoiceUser.currency,
                    totalAmount: balance,
                    totalReceivedAmount: receive_amount,
                    conversionRate: invoiceUser.conversionRate,
                    address: invoiceUser.address,
                    remainingTime: timer,
                    paymentQRCode: invoiceUser.address,
                    txnId: invoiceUser.txnId
                },
            })
        }
    } catch (err) {
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: err.message || "An error occurred while Status Checking",
            data: {
                txnId: ""
            },
        });
    }
}

const invoiceCronBCH = async (req, res, invoiceUser, timer) => {
    try {
        const { id, username, password } = req.body;
        // var old_balance = new Decimal('7.782937');
        var old_balance = new Decimal(invoiceUser.balance);
        // var staticAdd = 'bc1qq904ynep5mvwpjxdlyecgeupg22dm8am6cfvgq';
        // const receivedTransactions = await gettranscationBTC(staticAdd);
        // console.log("transactions"+JSON.stringify(receivedTransactions));
        // for (let index = 0; index < transactions.length; index++) {
        //     const element = transactions[index];
        //     console.log(JSON.stringify(element))
        // }
        // console.log("otherTransactions"+otherTransactions);
        // return
        var staticAdd = invoiceUser.address;
        if (!await validateBCHAddress(staticAdd)) {
            throw new Error('Invalid BTC address');
        }
        var balance = new Decimal(await getBCHBalance(staticAdd));
        console.log("new Balance" + balance)
        console.log("old Balance" + old_balance)
        if (!balance) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Balance Not fetch"
                }
            });
        }
        var receive_amount = balance - old_balance;
        // var receive_amount = formatUnits(bal,18);
        // console.log("bal"+bal)

        // var receive_amount =ethers.formatEther(bal);
        var formattedDate = invoiceUser.createdDate.replace('T', ' ').substring(0, 19);
        // console.log("recienve"+receive_amount)
        console.log("balance :---" + balance)
        console.log(" Recive Amount balance :---" + receive_amount)
        console.log(" formatDate :---" + formattedDate)
        console.log(invoiceUser)
        if (receive_amount > 0 && balance > old_balance) {
            const data = await gettranscationBTC(staticAdd);
            const transactions = await data;
            console.log(transactions)
            if (transactions.length <= 0) {
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "Transcation not fetch"
                    }
                });
            }

            const matchingTransaction = await filterTransactions(transactions, receive_amount, formattedDate);
            if (matchingTransaction[0]) {
                console.log('Matching transaction found:', matchingTransaction);
                let option = {
                    "requestid": id,
                    "status": "PAID",
                    "txnId": matchingTransaction[0].transactionId,
                    "totalReceivedAmount": receive_amount

                };
                const updateData = await apiRequest(process.env.API_URL + 'crpapi/ClaimPaymentv1', option, username, password)
                const finalUpdate = updateData.data;
                console.log("response" + finalUpdate)
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: finalUpdate,
                })
            } else {
                console.log('No matching transaction found.');
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "No matching transaction found."
                    }
                });
            }
        } else {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "Pending",
                    paymentId: invoiceUser.paymentId,
                    emailAddress: invoiceUser.emailAddress,
                    name: invoiceUser.name,
                    totalRemainingAmount: 0,
                    currency: invoiceUser.currency,
                    totalAmount: balance,
                    totalReceivedAmount: receive_amount,
                    conversionRate: invoiceUser.conversionRate,
                    address: invoiceUser.address,
                    remainingTime: timer,
                    paymentQRCode: invoiceUser.address,
                    txnId: invoiceUser.txnId
                },
            })
        }
    } catch (err) {
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: err.message || "An error occurred while Status Checking",
            data: [],
        });
    }

}

const withdrawBCH = async (req, res, data) => {
    try {
        const { currency, amount, from_address, to_address, yeketavirp } = data;
        const privateDec = await decrptData(yeketavirp);
        console.log("private" + JSON.stringify(privateDec))
        console.log("from_address" + from_address)
        console.log("to_address" + to_address)
        // let txID = '04287177fa0e5c42416c4e2e4f28f9a9808e3d7984ab4b476f1a98e41c885d08';
        // let txID = 'da97dd70465b236c5b49d59fc3836149fb0f64fa7ca5fb14189aaaadeb98a63f';
        // const transactionInfo = await tronWeb.trx.getTransaction(txID);
        // const transactionInfo1 = await getTransactionConfirmations(txID);
        // console.log("transactionInfo : " + JSON.stringify(transactionInfo, null, 2))
        // return
        // let from = 'TD5Am1yhZ1zKypGntNPaJ4fw1qPCTTLpyp';
        // let to = 'TC4KvZcpz2KkRPkDQmD53fgp4aFSd2NWxy';
        // let private = '2c500f1eda329a2f1b1ee74c5c4407f23c8a3dd58634008fe77dd3cdf8363884';
        // let amountb = '1';
        if (!await validateBCHAddress(from_address) && !await validateBCHAddress(to_address)) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Invalid addresses",
                    paymentStatus: "",
                    Amount: '',
                    transactionId: "",
                },
            })
        }
        // const bandwidth = await tronWeb.trx.getBandwidth(from_address);
        const balance = await getBCHBalance(from_address);
        console.log("balance: " + Number(balance))
        console.log("amount: " + Number(amount))
        // console.log("bandwidth+" + bandwidth)
        if (Number(balance) < (Number(amount) + 1)) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Insufficient funds to transfer",
                    paymentStatus: "",
                    Amount: '',
                    transactionId: "",
                }
            });
        }


        const BLOCKCYPHER_URL = "https://rest.cryptoapis.io/v2";
        const PRIVATE_KEY_WIF = new bitcore.PrivateKey.fromWIF(privateDec);
        const SENDER_ADDRESS = PRIVATE_KEY_WIF.toAddress().toString();;
        const RECEIVER_ADDRESS = to_address;
        const API_TOKEN = process.env.BCH_API_KEY;
        const NETWORK = bitcoin.networks.bitcoin;

        const utxoResponse = await axios.get(`${BLOCKCYPHER_URL}/blockchain-data/bitcoin-cash/addresses/${SENDER_ADDRESS}/unspent-outputs?limit=5`,
            { headers: { "X-API-Key": API_TOKEN } }
        );
        const utxos = utxoResponse.data.data.items;

        if (!utxos || utxos.length === 0) {
            console.log("No UTXOs available. Fund your wallet first.");
            return;
        }

        const transaction = new bitcore.Transaction()
            .from(
                utxos.map((utxo) => ({
                    txId: utxo.transactionId,
                    outputIndex: utxo.index,
                    script: utxo.script,
                    satoshis: utxo.amount * 1e8,
                }))
            )
            .to(RECEIVER_ADDRESS, bitcore.Unit.fromBTC(amount).toSatoshis())
            .fee(1000)
            .change(SENDER_ADDRESS)
            .sign(PRIVATE_KEY_WIF);

        const rawTx = transaction.serialize();
        
        const broadcastResponse = await axios.post(
            `${BLOCKCYPHER_URL}/blockchain-tools/bitcoin-cash/broadcast`,
            { transactionHex: rawTx },
            { headers: { "X-API-Key": API_TOKEN } }
        );
        const transactionId = broadcastResponse.data.data.transactionId;
        if (transactionId) {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "Pending",
                    Amount: amount,
                    transactionId: transactionId,
                },
            });

        } else {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "ERROR",
                data: {
                    msg: "Transaction Id not fetched",
                    paymentStatus: "",
                    Amount: '',
                    transactionId: "",
                },
            });
        }
    } catch (error) {
        console.log(error, "Error in withdrawBCH ", error);
        return res.status(500).send({
            code: 500,
            status: "ERROR",
            message: "Transaction failed",
            error: error.message,
            data: {
                paymentStatus: "",
                Amount: '',
                transactionId: "",
            }
        });
    }
};
module.exports = {
    createInvoiceBCH,
    invoiceStatusBCH,
    invoiceCronBCH,
    getBCHBalance,
    withdrawBCH
}