const { invoiceCronTRX } = require('../Tron/TRX/TRX');
const { invoiceCronTRC20 } = require('../Tron/USDT/TRC20_USDT');
const { invoiceCronETH } = require('../../Invoices/Ethereum/ETH/eth');
const { invoiceCronERC20 } = require('../../Invoices/Ethereum/USDT/ERC20_USDT');
const { statusCheckTRX } = require('../Tron/TRX/TRX')
const statusMark = async (req, res, next) => {
    const { trxId, currency } = req.body
    if (!trxId || !currency) {
        return res.status(400).send({
            code: "400",
            status: "Fail",
            message: "Fill required details missing",
            data: {
                currency: "",
                trxId: "",
            }
        });
    }
    switch (currency) {
        case "TRX":
            await statusCheckTRX(req, res)
            break;
        case "USDT_TRC20":
            await statusCheckTRX(req, res)
            break;
        case "ETH":
            await invoiceCronETH(req, res)
            break;
        case "USDT_ERC20":
            await invoiceCronERC20(req, res)
            break;
        default:
            return res.status(400).send({
                code: "400",
                status: "Not Found",
                message: "Invalid Currency",
                data: {},
            });
    }
}
module.exports = {
    statusMark
}