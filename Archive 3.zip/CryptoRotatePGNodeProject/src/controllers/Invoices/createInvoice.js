const { createInvoiceTRX } = require("./Tron/TRX/TRX");
const { createInvoiceETH } = require("./Ethereum/ETH/eth");
const { createInvoiceTRC20 } = require("./Tron/USDT/TRC20_USDT");
const { createInvoiceBTC } = require('./Bitcoin/btc');
const { createInvoiceBCH } = require('./BitcoinCash/BCH');
const { createInvoiceERC20 } = require('./Ethereum/USDT/ERC20_USDT');

const { apiRequest} = require('../../helpers/request/request')

const createInvoice = async (req, res) => {
  try {
    const { userId, email,amount, currency, publicKey,username,password ,requestId} = req.body;

    if (!userId || !currency || !email || !username || !password || !requestId){
      return res.status(400).send({
        code: "400",
        status: "Fail",
        message: "Fill required details missing",
        data: [],
      });
    }

    let option = {
      "UserId": userId,
      "ClientId": username,
      "CryptoCurrency": currency,
      "email":email
    }
      console.log(process.env.API_URL+'crpapi/GetUsersAccountDetails');
      const response = await apiRequest(process.env.API_URL+'crpapi/GetUsersAccountDetails',option,username,password);
      console.log("Adddress"+response.data )
      console.log("Adddress"+response.data.address )
      req.body.address = response.data.address
      
    // const user = await userModel.findOne({ userId: clientId });
    // if (!user) {
    //   return res.status(404).send({
    //     code: "404",
    //     status: "Not Found",
    //     message: "User not found",
    //     data: [],
    //   });
    // }

  // console.log("Modify request"+req.body);
  // return;
    let invoiceResult;

    switch (currency) {
      case "ETH":
        invoiceResult = await createInvoiceETH(req, res);
        break;
      case "TRX":
        invoiceResult = await createInvoiceTRX(req, res);
        break;
      case "BTC":
        invoiceResult = await createInvoiceBTC(req, res);
        break;
      case "USDT_ERC20":
        invoiceResult = await createInvoiceERC20(req, res);
        break;
      case "BCH":
        invoiceResult = await createInvoiceBCH(req, res);
        break;
      case "USDT_TRC20":
        invoiceResult = await createInvoiceTRC20(req, res);
        break;

      default:
        return res.status(400).send({
          code: "400",
          status: "Not Found",
          message: "Invalid Currency",
          data: {},
        });
    }

    // if (invoiceResult && !user.coins.some(coin => coin.currency === currency)) {
    //   user.coins.push({ currency, address: invoiceResult.address });
    //   await user.save();
    // }

    // return res.status(200).send({
    //   code: "200",
    //   status: "Success",
    //   message: "Invoice created successfully",
    //   data: invoiceResult,
    // });
  } catch (error) {
    console.error("Error creating invoice:", error);
    return res.status(500).json({
      code: 500,
      status: "Error",
      message: error.message,
      data: {},
    });
  }
};




module.exports = {
  createInvoice,
};
