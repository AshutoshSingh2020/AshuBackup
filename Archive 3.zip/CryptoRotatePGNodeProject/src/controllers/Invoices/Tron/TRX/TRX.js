
const { TronWeb } = require("tronweb");
const usdRate = require('../../../../helpers/coinToUSDRate/usdRate');
const { apiRequest, apiCronRequest } = require("../../../../helpers/request/request");
const trxconfig = require('../../../../config/trx.json')
const tronWeb = new TronWeb({
    fullHost: 'https://api.trongrid.io',
    headers: { 'TRON-PRO-API-KEY': process.env.TRON_API_KEY },
});
const Decimal = require('decimal.js');
const { decrptData } = require('../../../../helpers/security/encDec');
const { sleep } = require("tronweb/utils");
const getTRXBalance = async (sender) => {
    try {
        const bal = await tronWeb.trx.getBalance(sender);
        const balance = tronWeb.fromSun(bal);
        return balance;
    } catch (err) {
        console.log('TRX balance Error : ', err)
        return 0;
    }
}

const createTRXAccount1 = async () => {
    try {
        var newAccount = await tronWeb.createAccount();
        var privateKey = newAccount.privateKey;
        // var privateKey = await encryptedPrivateKeys(newAccount.privateKey);
        var newAddress = newAccount.address.base58;
        return { privateKey, newAddress };
    } catch (err) {
        console.log("createTRXAccount error:", err)
    }
}
const createTRXAccount = async () => {
    try {
        var newAccount = await tronWeb.createAccount();
        var privateKey = newAccount.privateKey;
        // var privateKey = await encryptedPrivateKeys(newAccount.privateKey);
        var newAddress = newAccount.address.base58;
        return { privateKey, newAddress };
    } catch (err) {
        console.log("createTRXAccount error:", err)
    }
}

const createInvoiceTRX = async (req, res) => {
    try {
        const { email, cryptoAmount, amount, currency, publicKey, userId, address, requestId, username, password, cURL, sURL } = req.body;

        // Find user by userId
        // const user = await userModel.findOne({ userId: userId });
        // if (!user) {
        //     return res.status(404).send({
        //         code: "404",
        //         status: "Not Found",
        //         message: "User not found",
        //         data: [],
        //     });
        // }
        console.log(address)
        // return
        // Validate minimum TRX amount if cryptoAmount is true
        var balance = 0;
        const minimumAmount = parseFloat(process.env.TRX_MINIMUM_AMOUNT || 0);
        if (cryptoAmount && amount < minimumAmount) {
            return res.status(400).send({
                code: "400",
                status: "Fail",
                message: `TRX amount should be greater than ${minimumAmount}`,
                data: {},
            });
        }

        // console.log('before trxAccount: ');
        // let trxAccount = user.coins.find(coin => coin.currency === "TRX");
        let usdtTrcAccount = "";
        // let usdtTrcAccount = user.coins.find(coin => coin.currency === "USDT_TRC20");
        // console.log('before trxAccount: ', usdtTrcAccount);
        // Determine account address for TRX
        console.log();
        let accountNumber, privateKey;
        if (address) {
            // Prioritize existing TRX account
            console.log('trxAccount: ', address);
            // accountNumber = trxAccount.address;
            // privateKey = trxAccount.privateKey;
            accountNumber = address;
            privateKey = "";
            balance = await getTRXBalance(address);
            // privateKey = trxAccount.privateKey;
        } else {
            // Create new TRX account if no existing TRX or USDT_TRC20 account found
            const newAccount = await createTRXAccount();
            // let newAccount=""
            console.log('in else condition for private key', newAccount)
            if (!newAccount || !newAccount.newAddress || !newAccount.privateKey) {
                throw new Error("Failed to create TRX account");
            }
            accountNumber = newAccount.newAddress;
            privateKey = newAccount.privateKey;
            balance = 0;
            // Save the newly created TRX account to the user's coins
            // user.coins.push({
            //     currency: "TRX",
            //     address: accountNumber,
            //     privateKey: privateKey
            // });
            // await user.save();
        }

        // Fetch the current TRX to USD rate
        // const rateData = await Coinrate.findOne({});
        // if (!rateData) {
        //     throw new Error("Rate data not found");
        // }
        const rateData = await usdRate();
        const rate = Number(rateData.TRX);
        //txnid lgic
        // console.log(rate)
        // return
        txnId = ""
        let usdAmount = ''
        let paidAmount = ''
        // Calculate amounts based on cryptoAmount flag
        if (rate && amount) {
            const numericAmount = Number(amount);
            const numericRate = Number(rate);
            usdAmount = cryptoAmount ? Number((Number(numericAmount) * numericRate)).toFixed(6) : numericAmount.toFixed(6);
            paidAmount = cryptoAmount ? numericAmount.toFixed(6) : (numericAmount / numericRate).toFixed(6);
        }
        const timeout = Date.now() + 14400000; // 4-hour timeout

        // Create a new invoice
        // const newInvoiceData = {
        //     userId: userId,
        //     email,
        //     cryptoAmount,
        //     amount,
        //     usdAmount,
        //     paidAmount,
        //     currency,
        //     balance: 0,
        //     newAccount: { accountNumber },
        //     // rate: rate.toFixed(6),
        //     timestamp: Date.now(),
        //     timeout,
        //     cold_trans_done: false,
        //     publicKey,
        //     txnId,
        // };
        const invoiceData = {
            "userId": userId,
            "requestid": requestId,
            "currency": currency,
            "amount": amount,
            "paidAmount": paidAmount,
            "PrivateKey": privateKey,
            "address": accountNumber,
            "balance": balance,
            "email": email,
            "rate": rate.toFixed(6),
            "surl": sURL,
            "curl": cURL

        }
        console.log(invoiceData)
        const invoiceResponse = await apiRequest(process.env.API_URL + 'crpapi/PaymentV1', invoiceData, username, password);
        const response = invoiceResponse.data;
        // const newInvoice = await Invoice.create(newInvoiceData);
        // return
        // Calculate remaining time for the invoice
        const remainingTime = new Date(timeout - Date.now()).toISOString().substr(11, 8);
        if (response.ErrorCode != '1') {
            throw new Error("Failed to create Invoice :  " + response.ErrorMessage);
        }

        // Return the response with invoice details
        return res.status(200).send({
            code: "200",
            status: "OK",
            message: "Invoice created successfully for uat",
            data: response
        });
    } catch (err) {
        console.error("createInvoiceTRX error:", err);
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: err.message || "An error occurred while creating the invoice",
            data: [],
        });
    }
};

//old
const getTronScanTransactionsTRX = async (address) => {
    try {


        const responseData = await fetch(trxconfig.tronscan.baseURL + trxconfig.tronscan.API.TRXtransactions.endpoint + address, { method: 'GET', headers: trxconfig.tronscan.headers });
        const response = await responseData.json();
        console.log(response);
        if (response.Error) {
            throw new Error(response.Error);
        }
        let transactions = []; let otherTransactions = [];
        for (let datum of await response.data) {
            let timestamp = datum.timestamp;
            let date = new Date(timestamp);
            let istDate = new Date(date.toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));
            let year = istDate.getFullYear();
            let month = String(istDate.getMonth() + 1).padStart(2, '0');
            let day = String(istDate.getDate()).padStart(2, '0');
            let hours = String(istDate.getHours()).padStart(2, '0');
            let minutes = String(istDate.getMinutes()).padStart(2, '0');
            let seconds = String(istDate.getSeconds()).padStart(2, '0');
            let formattedDate = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
            let txData = datum.contractData;
            // console.log(typeof(txData.amount))
            let datumObj = {
                transactionId: datum.hash,
                transactionStatus: datum.contractRet,
                transactionFees: datum.cost.fee / 1000000,
                amount: Number(txData.amount) / 1000000,
                toAddress: txData.to_address,
                fromAddress: txData.owner_address,
                date: formattedDate,
                token: datum.tokenInfo.tokenName,
                tokenAbbr: datum.tokenInfo.tokenAbbr,
                trxConfirmed: datum.confirmed,
            }
            if (!((datumObj.amount <= 0.00005 && datumObj.transactionFees < 0.00005) || datum.tokenInfo.tokenAbbr != 'trx')) {
                transactions.push({ ...datumObj });
            }
            else {
                otherTransactions.push({ ...datumObj, asset: txData.asset_name });
            }
        }
        // console.log(otherTransactions)
        return { transactions, otherTransactions }
    } catch (error) {
        console.log(error)
    }
}
const filterTransactions = (transactions = [], walletAddress, referenceDateTime) => {
    const refDateTime = new Date(referenceDateTime);

    console.log("refdata" + refDateTime)
    console.log("refdata" + walletAddress)
    const filteredTransactions = transactions.filter(transaction => {
        const transactionDate = new Date(transaction.date);
        console.log("date" + transactionDate)
        // return transaction.toAddress === walletAddress && transactionDate > refDateTime && transaction.trxConfirmed;
        return transaction.toAddress === walletAddress && transaction.trxConfirmed;
    });

    // Check if the total amount matches the target amount
    // if (totalAmount === targetAmount) {
    return filteredTransactions;
    // } else {
    //     return []; // Return an empty array if no match
    // }
};
const findMatchingTransaction = (transactions, receive_amount) => {
    // console.log("Amount" + transactions[0].amount)
    // console.log("hash" + transactions[0].transactionId)
    // console.log("cons" + transactions[0].transactionStatus)
    // console.log("cons" + receive_amount)
    // console.log("cons" + transactions.length)
    return transactions.find(transaction => areNumbersEqual(transaction.amount, receive_amount));
};
const areNumbersEqual = async (num1, num2, epsilon = 1e-10) => {
    return Math.abs(num1 - num2) < epsilon;
}



const invoiceStatusTRX = async (req, res, invoiceUser, timer) => {
    try {
        const { id, username, password } = req.body;
        // var old_balance = new Decimal('7.782937');
        // var old_balance = new Decimal(invoiceUser.balance);
        // var staticAdd = 'TFfmwQX3NeRAsZWQMtvktEwdv5SUVMRV3R';
        var staticAdd = invoiceUser.address;
        var balance = new Decimal(await getTRXBalance(staticAdd));
        // console.log("old"+old_balance)
        if (!balance) {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Balance Not fetch",
                    requestid: id,
                    txnId: '',
                    totalReceivedAmount: ''
                }
            });
        }
        // var receive_amount = balance.minus(old_balance);
        var formattedDate = invoiceUser.createdDate.replace('T', ' ').substring(0, 19);
        // console.log("recienve"+receive_amount)
        console.log("balance :---" + balance)
        // console.log(" Recive Amount balance :---" + receive_amount)
        console.log(" formatDate :---" + formattedDate)
        console.log(invoiceUser)
        // if (receive_amount > 0.00005) {
        const data = getTronScanTransactionsTRX(staticAdd);
        const { transactions, otherTransactions } = await data;
        console.log(transactions);
        if (transactions.length <= 0) {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Transcation not fetch",
                    requestid: id,
                    status: "Failed",
                    txnId: '',
                    totalReceivedAmount: ''
                }
            });
        }
        var filteredTransactions = [];
        console.log(JSON.stringify(transactions));
        // if(receive_amount <= 0.00005){   
        // console.log("filll")
        //  filteredTransactions = filterTransactions(otherTransactions, staticAdd, formattedDate, receive_amount);
        // }else{
        filteredTransactions = filterTransactions(transactions, staticAdd, formattedDate);
        console.log("filteredTransactions" + JSON.stringify(filteredTransactions));
        if (filteredTransactions.length <= 0) {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Transcation not Filtered properly",
                    requestid: id,
                    status: "Failed",
                    txnId: '',
                    totalReceivedAmount: '',
                    balance: 0
                }
            });
        }
        // }

        // const matchingTransaction = await findMatchingTransaction(filteredTransactions, receive_amount);
        // filteredTransactions.forEach(val=>{
        // }
        // if (matchingTransaction) {
        //     console.log('Matching transaction found:', matchingTransaction);
        //check transcaton history
        let finalUpdate = {};
        for (let val of filteredTransactions) {
            let option = {
                "requestid": id,
                "status": "PAID",
                "txnId": val.transactionId,
                "totalReceivedAmount": val.amount
            };
            await sleep(10)
            let updateData = await apiRequest(process.env.API_URL + 'crpapi/ClaimPaymentv1', option, username, password)
            await sleep(10)
            finalUpdate = updateData.data;
            console.log("finalUpdate  " + JSON.stringify(finalUpdate))
            if (finalUpdate.ErrorCode == '1') {
              return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: finalUpdate,
            })
            }

        }
        // } else {
        //     console.log('No matching transaction found.');
        //     return res.status(201).json({
        //         code: 201,
        //         status: "OK",
        //         message: "successful",
        //         data: {
        //             msg: "No matching transaction found.",
        //             requestid: id,
        //             status: "Failed",
        //             txnId: '',
        //             totalReceivedAmount: ''
        //         }
        //     });
        // }
        // } else {
        return res.status(201).json({
            code: 201,
            status: "OK",
            message: "successful",
            data: {
                paymentStatus: "Pending",
                paymentId: invoiceUser.paymentId,
                emailAddress: invoiceUser.emailAddress,
                name: invoiceUser.name,
                totalRemainingAmount: 0,
                currency: invoiceUser.currency,
                totalAmount: balance,
                totalReceivedAmount: 0,
                conversionRate: invoiceUser.conversionRate,
                address: invoiceUser.address,
                remainingTime: timer,
                paymentQRCode: invoiceUser.address,
                txnId: invoiceUser.txnId
            },
        })
        // }
    } catch (err) {
        console.log(err, "Error in invoiceStatusTRX: ", err);
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: err.message || "An error occurred while Status Checking",
            data: [],
        });
    }
}
const invoiceCronTRX = async (req, res) => {
    var expireTime = Date.now() - 28800000;
    const { id, balance, currency, address, createdDate } = req.body;
    try {

        if (!balance || !currency || !address || !createdDate) {
            return res.status(400).send({
                code: "400",
                status: "Fail",
                message: "Fill required details missing",
                data: [],
            });
        }
        var old_balance = new Decimal(balance);
        var staticAdd = address;
        var amount = new Decimal(await getTRXBalance(staticAdd));
        if (!amount) {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Balance Not fetch",
                    requestid: id,
                    status: "",
                    txnId: "",
                    totalReceivedAmount: ""
                }
            });
        }
        var receive_amount = amount.minus(old_balance);
        var formattedDate = createdDate.replace('T', ' ').substring(0, 19);

        console.log("balance :---" + amount)
        console.log(" Recive Amount balance :---" + receive_amount)
        console.log(" formatDate :---" + formattedDate);

        if (receive_amount > 0 && amount > old_balance) {

            const data = getTronScanTransactionsTRX(staticAdd);
            const { transactions, otherTransactions } = await data;
            if (transactions.length <= 0) {
                return res.status(201).json({
                    code: 201,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "Transcation not fetch",
                        requestid: id,
                        status: "",
                        txnId: "",
                        totalReceivedAmount: ""
                    }
                });
            }
            const filteredTransactions = filterTransactions(transactions, staticAdd, formattedDate, receive_amount);
            if (filteredTransactions.length <= 0) {
                return res.status(201).json({
                    code: 201,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "Transcation not Filtered properly",
                        requestid: id,
                        status: "",
                        txnId: "",
                        totalReceivedAmount: ""
                    }
                });
            }
            const filteredTransactions2 = filterTransactions(otherTransactions, staticAdd, formattedDate, receive_amount);
            const matchingTransaction = await findMatchingTransaction(filteredTransactions, receive_amount);
            if (matchingTransaction) {
                console.log('Matching transaction found:', matchingTransaction);

                //check transcaton history
                let option = {
                    "requestid": id,
                    "status": "PAID",
                    "txnId": matchingTransaction.transactionId,
                    "totalReceivedAmount": receive_amount

                };
                const updateData = await apiCronRequest(process.env.API_URL + 'apppayment/ClaimPaymentv1', option);
                const finalUpdate = updateData.data;
                //     console.log(finalUpdate)
                return res.status(200).json(finalUpdate);
            } else {
                console.log('No matching transaction found.');
                return res.status(201).json({
                    code: 201,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "No matching transaction found.",
                        requestid: id,
                        status: "",
                        txnId: "",
                        totalReceivedAmount: ""
                    },
                });;
            }
        } else {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "Pending",
                    totalRemainingAmount: 0,
                    currency: currency,
                    balance: balance,
                },
            })
        }

    } catch (error) {
        console.log(error, "Error in invoiceCronTRX: ", error);
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: error.message || "An error occurred while Status Checking",
            data: {
                requestid: id,
                status: "",
                txnId: "",
                totalReceivedAmount: ""
            },
        });
    }
};
const statusCheckTRX = async (req, res) => {
    try {
        const { trxId, currency } = req.body;
        const transaction = await tronWeb.trx.getTransactionInfo(trxId)
        if (!transaction) {
            console.log('Transaction not found.');
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Transaction not found",
                    status: "0"
                }
            });
        }
        const currentBlock = await tronWeb.trx.getCurrentBlock();
        const currentBlockNumber = currentBlock.block_header.raw_data.number;
        const transactionBlock = await tronWeb.trx.getBlock(transaction.blockNumber);
        const transactionBlockNumber = transactionBlock.block_header.raw_data.number;
        const confirmations = currentBlockNumber - transactionBlockNumber + 1;

        console.log(`Transaction has ${confirmations} confirmation(s).`);
        if (confirmations >= 20) {
            console.log('Transaction is confirmed.');
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Transaction is confimed",
                    status: "1"
                }
            });
        } else {
            console.log('Transaction is unconfirmed.');
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Transaction is unconfirmed",
                    status: "0"
                }
            });
        }
    } catch (error) {
        console.error('Error determining transaction confirmations:', error);
        console.log(error, "Error in withdrawTRX: ", error);
        return res.status(500).send({
            code: 500,
            status: "ERROR",
            message: "Transaction not fetch",
            error: error.message,
            data: {
                msg: "Transaction not fetch",
                status: "0"
            }
        });
    }
}

const withdrawTRX = async (req, res, data) => {
    try {
        const { currency, amount, from_address, to_address, yeketavirp } = data;
        const privateDec = await decrptData(yeketavirp);
        console.log("private" + JSON.stringify(privateDec))
        console.log("from_address" + from_address)
        console.log("to_address" + to_address)
        // let txID = '04287177fa0e5c42416c4e2e4f28f9a9808e3d7984ab4b476f1a98e41c885d08';
        // let txID = 'da97dd70465b236c5b49d59fc3836149fb0f64fa7ca5fb14189aaaadeb98a63f';
        // const transactionInfo = await tronWeb.trx.getTransaction(txID);
        // const transactionInfo1 = await getTransactionConfirmations(txID);
        // console.log("transactionInfo : " + JSON.stringify(transactionInfo, null, 2))
        // return
        // let from = 'TD5Am1yhZ1zKypGntNPaJ4fw1qPCTTLpyp';
        // let to = 'TC4KvZcpz2KkRPkDQmD53fgp4aFSd2NWxy';
        // let private = '2c500f1eda329a2f1b1ee74c5c4407f23c8a3dd58634008fe77dd3cdf8363884';
        // let amountb = '1';

        if (!tronWeb.isAddress(from_address) && !tronWeb.isAddress(to_address)) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Invalid addresses",
                    paymentStatus: "",
                    Amount: '',
                    transactionId: "",
                },
            })
        }
        const bandwidth = await tronWeb.trx.getBandwidth(from_address);
        const balance = await getTRXBalance(from_address);
        console.log("balance+" + balance)
        console.log("bandwidth+" + bandwidth)

        if (bandwidth < 267) {
            if (balance < (amount + 1)) {
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "Insufficient gas fee to transfer",
                        paymentStatus: "",
                        Amount: '',
                        transactionId: "",
                    }
                });
            }
        }
        if (balance < (amount + 1)) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Insufficient funds to transfer",
                    paymentStatus: "",
                    Amount: '',
                    transactionId: "",
                }
            });
        }
        console.log("Transcation+" + amount)
        const trans = await tronWeb.trx.sendTransaction(
            to_address,
            tronWeb.toSun(amount),
            privateDec.Result
        );
        const transactionId = trans.txid;
        if (transactionId) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "Pending",
                    Amount: amount,
                    transactionId: transactionId,
                },
            });

        } else {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "ERROR",
                data: {
                    msg: "Transaction Id not fetched",
                    paymentStatus: "",
                    Amount: '',
                    transactionId: "",
                },
            });

        }
    } catch (error) {
        console.log(error, "Error in withdrawTRX: ", error);
        return res.status(500).send({
            code: 500,
            status: "ERROR",
            message: "Transaction failed",
            error: error.message,
            data: {
                paymentStatus: "",
                Amount: '',
                transactionId: "",
            }
        });
    }
};
module.exports = {
    createInvoiceTRX,
    invoiceStatusTRX,
    invoiceCronTRX,
    getTRXBalance,
    withdrawTRX,
    statusCheckTRX
}

