
const crypto = require("crypto");
const { TronWeb } = require("tronweb");
const trxconfig = require('../../../../config/trx.json')
const Decimal = require('decimal.js');
const { apiRequest, apiCronRequest } = require("../../../../helpers/request/request");
const tronWeb = new TronWeb({
    fullHost: 'https://api.trongrid.io',
    headers: { 'TRON-PRO-API-KEY': process.env.TRON_API_KEY },
});
const { getTRXBalance } = require('../TRX/TRX');
const { decrptData } = require('../../../../helpers/security/encDec');
const { sleep } = require("tronweb/utils");
const decryptePrivateKey = (data) => {
    try {
        var encrypted = Buffer.from(data, 'base64');
        var salt_len = 16, iv_len = 16;

        var salt = encrypted.slice(0, salt_len);

        var iv = encrypted.slice(0 + salt_len, salt_len + iv_len);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 256 / 8, 'sha256');

        var decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);

        decipher.write(encrypted.slice(salt_len + iv_len));
        decipher.end();

        const decrypted = decipher.read();
        return decrypted.toString()
    } catch (err) {
        console.log('decryptedPrivateKey Error: ', err)
    }
};



const createTRXAccount = async () => {
    try {
        var newAccount = await tronWeb.createAccount();
        var privateKey = newAccount.privateKey;
        var newAddress = newAccount.address.base58;
        return { privateKey, newAddress };
    } catch (err) {
        console.log("createTRXAccount error:", err)
    }
}

const getTRC20Balance = async (address, currency, privateKey) => {
    try {
        // var contract_Address = await TokenAddress.findOne({ coin_name: "USDT-TRC20" });
        // contract_Address = contract_Address.contract_Address;
        var contract_Address = "TERimdWJAHSFvkm5YyxpW37vieyHaNLMz9";
        var decryptedPrivateKey = await decryptePrivateKey(privateKey);
        const tronUSDT = new TronWeb(fullNode, solidityNode, eventServer, decryptedPrivateKey);
        const contractI = await tronWeb.contract().at(contract_Address);
        var balance = await contractI.methods.balanceOf(address).call();
        balance = parseInt(balance);
        balance = balance / 1000000;
        return balance;
    } catch (err) {
        console.log("getTRC20Balance error: ", err)
    }
}
const getUSDTBalance = async (targetAddress) => {
    try {
        var usdtContractAddress = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t";
        if (!tronWeb.isAddress(targetAddress)) {
            throw new Error('Invalid TRON address.');
        }
        const targetAddressHex = tronWeb.address.toHex(targetAddress);
        const functionSelector = 'balanceOf(address)';
        const parameter = [
            {
                type: 'address',
                value: targetAddress,
            },
        ];
        const transaction = await tronWeb.transactionBuilder.triggerSmartContract(
            usdtContractAddress,
            functionSelector,
            {},
            parameter
        );
        const balanceHex = transaction.constant_result[0];
        const balance = tronWeb.toBigNumber('0x' + balanceHex).toNumber();
        const usdtBalance = balance / 1e6;
        return usdtBalance;
    } catch (error) {
        console.error('Error fetching balance:', error);
        throw error;
    }
}
//   const getTronScanBalanceUSDT = async (address)=>{
//     const accountData = await fetch(trxconfig.tronscan.baseURL+trxconfig.tronscan.API.USDTbalance.endpoint+address,{method:'GET',headers:trxconfig.tronscan.headers});

//     console.log("-----"+trxconfig.tronscan.baseURL+trxconfig.tronscan.API.USDTbalance.endpoint+address)
//     const account = await accountData.json();
//     const balance = await extractUsdtBalance(account)
//     // let balance = {trx:account.withPriceTokens[1].balance/1000000};
//     return balance

// }
// const extractUsdtBalance = (data) => {
//       for (const token of data.withPriceTokens) {
//         if (token.tokenAbbr === 'USDT' && token.tokenType === 'trc20') {
//           return parseFloat(token.balance) / Math.pow(10, token.tokenDecimal);
//         }
//       }
//     return null;
//   };
const getTronScanTransactionsUSDT = async (address) => {
    const responseData = await fetch(trxconfig.tronscan.baseURL + trxconfig.tronscan.API.USDTtransactions.endpoint + address, { method: 'GET', headers: trxconfig.tronscan.headers });
    const response = await responseData.json();
    let transactions = [];
    for (let datum of await response.token_transfers) {
        let timestamp = datum.block_ts;
        let date = new Date(timestamp);
        let istDate = new Date(date.toLocaleString("en-US", { timeZone: "Asia/Kolkata" }));
        let year = istDate.getFullYear();
        let month = String(istDate.getMonth() + 1).padStart(2, '0');
        let day = String(istDate.getDate()).padStart(2, '0');
        let hours = String(istDate.getHours()).padStart(2, '0');
        let minutes = String(istDate.getMinutes()).padStart(2, '0');
        let seconds = String(istDate.getSeconds()).padStart(2, '0');
        let formattedDate = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        let datumObj = {
            transactionId: datum.transaction_id,
            transactionStatus: datum.contractRet,
            contractType: datum.contract_type,
            amount: datum.quant / 1000000,
            toAddress: datum.to_address,
            fromAddress: datum.from_address,
            date: formattedDate,
            usdtConfirmed: datum.confirmed,
        }
        if (datum.contract_address == trxconfig.USDT.contractAddress) {
            transactions.push({ ...datumObj });
        }
    }
    // console.log(transactions[0])
    return transactions
}

const getTronScanBalanceUSDT = async (address) => {
    const accountData = await fetch(trxconfig.tronscan.baseURL + trxconfig.tronscan.API.USDTbalance.endpoint + address, { method: 'GET', headers: trxconfig.tronscan.headers });
    const account = await accountData.json();
    const tokenObject = account.withPriceTokens.find(item => item.tokenId == trxconfig.USDT.contractAddress);
    let balance = { USDT: tokenObject ? tokenObject.balance / 1000000 : 0 };
    return balance.USDT
}
const createInvoiceTRC20 = async (req, res) => {
    try {
        const { email, cryptoAmount, amount, currency, publicKey, userId, address, requestId, username, password,sURL,cURL } = req.body;
        var balance = 0;
        const minimumAmount = parseFloat(process.env.TRC20_MINIMUM_AMOUNT || 0);
        if (cryptoAmount && amount < minimumAmount) {
            return res.status(400).send({
                code: "400",
                status: "Fail",
                message: `TRC20 amount should be greater than ${minimumAmount}`,
                data: {},
            });
        }

        let accountNumber, privateKey;
        if (address) {
            accountNumber = address;
            privateKey = "";
            balance = await getTronScanBalanceUSDT(address);
        } else {
            const newAccount = await createTRXAccount();
            if (!newAccount || !newAccount.newAddress || !newAccount.privateKey) {
                throw new Error("Failed to create TRX account");
            }
            accountNumber = newAccount.newAddress;
            privateKey = newAccount.privateKey;
            balance = 0;
        }
        const rate = 1;
        txnId = ""
        let usdAmount = ''
        let paidAmount = ''

        if (rate && amount) {
            const numericAmount = Number(amount);
            const numericRate = Number(rate);
            usdAmount = cryptoAmount ? Number((Number(numericAmount) * numericRate)).toFixed(6) : numericAmount.toFixed(6);
            paidAmount = cryptoAmount ? numericAmount.toFixed(6) : (numericAmount / numericRate).toFixed(6);
        }
        const timeout = Date.now() + 14400000; // 4-hour timeout


        const invoiceData = {
            "userId": userId,
            "requestid": requestId,
            "currency": currency,
            "amount": amount,
            "paidAmount": paidAmount,
            "PrivateKey": privateKey,
            "address": accountNumber,
            "balance": balance,
            "email": email,
            "rate": rate.toFixed(6),
            "surl": sURL,
            "curl": cURL

        }
        console.log(invoiceData)
        const invoiceResponse = await apiRequest(process.env.API_URL + 'crpapi/PaymentV1', invoiceData, username, password);
        const response = invoiceResponse.data;
        const remainingTime = new Date(timeout - Date.now()).toISOString().substr(11, 8);
        if (response.ErrorCode != '1') {
            throw new Error("Failed to create Invoice :  " + response.ErrorMessage);
        }

        res.status(200).send({
            code: "200",
            status: "OK",
            message: "Invoice created successfully",
            data: response
        });

    } catch (err) {
        console.error("createInvoiceTRC20 error:", err);
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: err.message || "An error occurred while creating the invoice",
            data: [],
        });
    }
};
const withdrawUSDTTRC = async (req, res, data) => {
    try {
        const { currency, amount, from_address, to_address, yeketavirp } = data;
        const privateDec = await decrptData(yeketavirp);
        if (!tronWeb.isAddress(from_address) && !tronWeb.isAddress(to_address)) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Invalid addresses",
                    paymentStatus: "",
                    Amount: '',
                    transactionId: "",
                },
            })
        }
        const trxbalance = await getTRXBalance(from_address);
        // if (trxbalance < 30) {
        //     return res.status(200).json({
        //         code: 200,
        //         status: "OK",
        //         message: "successful",
        //         data: {
        //             msg: "Insufficiant TRX for transfer",
        //             paymentStatus: "",
        //             Amount: '',
        //             transactionId: "",
        //         }
        //     });
        // }
        const usdtA = await getTronScanBalanceUSDT(from_address);
        // console.log("usdtA" + usdtA)
        if (usdtA < amount) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Insufficiant funds for transfer",
                    paymentStatus: "",
                    Amount: '',
                    transactionId: "",
                }
            });
        }

        const USDT_CONTRACT_ADDRESS = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';

        tronWeb.setAddress(from_address)
        tronWeb.setPrivateKey(privateDec.Result);


        // Create contract instancecontract

        const contract = await tronWeb.contract().at(USDT_CONTRACT_ADDRESS);
        const balanceInSun = await contract.methods.balanceOf(from_address).call();
        // console.log('token balance: ', balanceInSun);
        const decimals = await contract.methods.decimals().call();
        // console.log('decimal: ', decimals);
        const accountBalance = tronWeb.fromSun(balanceInSun);

        // Validate transaction amount
        if (parseFloat(accountBalance) < parseFloat(amount)) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: `Insufficient funds. Current balance: ${accountBalance} USDT`,
                data: { currentBalance: accountBalance }
            });
        }

        // Additional transaction checks
        const amountInSun = tronWeb.toSun(amount);

        // Validate recipient address
        if (!tronWeb.isAddress(to_address)) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Invalid recipient address",
                data: {}
            });
        }

        // Prepare transaction parameters
        const transactionOptions = {
            feeLimit: 30000000, // Increased fee limit for more robust transaction
            from: from_address,
            privateKey: privateDec.Result
        };

        // console.log('transaction options: ', transactionOptions);

        console.log('to_address:  ', to_address, 'amountInSun:  ', amountInSun, 'transactionOptions: ', transactionOptions)
        // Send the transaction
        // Send the transaction
        const transaction = await contract.methods.transfer(to_address, amountInSun).send(transactionOptions);

        // Wait for transaction receipt
        console.log("transaction : " + transaction);
        // const transactionReceipt = await tronWeb.trx.getTransactionInfo(transaction);

        // Additional confirmation check
        // const txid = transaction || transactionReceipt.id;

        // Log transaction details for audit
        // console.log('USDT Transaction Details:', {
        //     from: from_address,
        //     to: to_address,
        //     amount: amount,
        //     txid: txid,
        //     transactionReceipt: transactionReceipt
        // });

        // Verify transaction status
        // const transactionStatus = await tronWeb.trx.getTransaction(txid);

        if (!transaction) {
            return res.status(200).json({
                statuscode: 200,
                status: "Failes",
                message: "USDT transaction Failed",
                data: {
                    paymentStatus: "Failed",
                    Amount: amount,
                    transactionId: transaction,
                    transactionHash: transaction
                }
            });
        }

        // Return successful response
        // tronWeb.setAddress(null);
        // tronWeb.setPrivateKey(null);
        return res.status(200).json({
            statuscode: 200,
            status: "Success",
            message: "USDT transaction completed successfully",
            data: {
                paymentStatus: "Pending",
                Amount: amount,
                transactionId: transaction,
                transactionHash: `https://tronscan.org/#/transaction/${transaction}`
            }
        });
    } catch (error) {
        return res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: error.message || "An error occurred while creating the invoice",
            data: [],
        });

    }

};
const filterTransactions = (transactions = [], walletAddress) => {
    const refDateTime = new Date(referenceDateTime);
    const filteredTransactions = transactions.filter(transaction => {
        const transactionDate = new Date(transaction.date);
        return transaction.toAddress === walletAddress  && transaction.usdtConfirmed;
    });
    return filteredTransactions;
};
const findMatchingTransaction = (transactions, receive_amount) => {
    // console.log("Amount" + transactions[0].amount)
    // console.log("hash" + transactions[0].transactionId)
    // console.log("cons" + transactions[0].transactionStatus)
    // console.log("cons" + receive_amount)
    // console.log("cons" + transactions.length)
    console.log("transcation length" + transactions.length)
    return transactions.find(transaction => areNumbersEqual(transaction.amount, receive_amount));
};
const areNumbersEqual = async (num1, num2, epsilon = 1e-10) => {
    return Math.abs(num1 - num2) < epsilon;
}

const invoiceStatusTRC20 = async (req, res, invoiceUser, timer) => {
    try {
        //Ashutosh Singh

        const { id, username, password } = req.body;
        // console.log(invoiceUser)
        // const data = await getTronScanTransactionsUSDT(staticAdd);
        // console.log("balance SAju---"+balance)
        // return
        // var old_balance = new Decimal('7.782937');
        // var old_balance = new Decimal(invoiceUser.balance);
        // var staticAdd = 'TFfmwQX3NeRAsZWQMtvktEwdv5SUVMRV3R';
        var staticAdd = invoiceUser.address;

        // Assuming getTRXBalance returns a promise that resolves to a string representation of the balance
        var balance = new Decimal(await getTronScanBalanceUSDT(staticAdd));
        if (!balance) {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Balance Not fetch",
                    requestid: id,
                    status: "Failed",
                    txnId: '',
                    totalReceivedAmount: ''
                }
            });
        }
        // var receive_amount = balance.minus(old_balance);
        var formattedDate = invoiceUser.createdDate.replace('T', ' ').substring(0, 19);

        // console.log("balance :---" + balance)
        // console.log(" Recive Amount balance :---" + receive_amount)
        console.log(" formatDate :---" + formattedDate)
        console.log(invoiceUser)
        // if (receive_amount > 0 && balance > old_balance) {
            const data = getTronScanTransactionsUSDT(staticAdd);
            const transactions = await data;
            if (transactions.length <= 0) {
                return res.status(201).json({
                    code: 201,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "Transcation not fetch",
                        requestid: id,
                        status: "Failed",
                        txnId: '',
                        totalReceivedAmount: ''
                    }
                });
            }
            const filteredTransactions = filterTransactions(transactions, staticAdd);
            if (filteredTransactions.length <= 0) {
                return res.status(201).json({
                    code: 201,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "Transcation not Filtered properly",
                        requestid: id,
                        status: "Failed",
                        txnId: '',
                        totalReceivedAmount: ''
                    }
                });
            }
            for(let val of filteredTransactions){
                let option = {
                    "requestid": id,
                    "status": "PAID",
                    "txnId": val.transactionId,
                    "totalReceivedAmount": val.amount

                };
                await sleep(10);
                 const updateData = await apiRequest(process.env.API_URL + 'crpapi/ClaimPaymentv1', option, username, password);
                 await sleep(10);
                const finalUpdate = updateData.data;
                if(finalUpdate.ErrorCode == '1'){
                    return res.status(200).json({
                        code: 200,
                        status: "OK",
                        message: "successful",
                        data: finalUpdate
                    })
                }
            }
            // const matchingTransaction = await findMatchingTransaction(filteredTransactions, receive_amount);
            // if (matchingTransaction) {
            //     console.log('Matching transaction found:', matchingTransaction);

            //     //check transcaton history
            //     let option = {
            //         "requestid": id,
            //         "status": "PAID",
            //         "txnId": matchingTransaction.transactionId,
            //         "totalReceivedAmount": receive_amount

            //     };
            //     const updateData = await apiRequest(process.env.API_URL + 'crpapi/ClaimPaymentv1', option, username, password)
            //     const finalUpdate = updateData.data;
            //     console.log(finalUpdate)
            //     return res.status(200).json({
            //         code: 200,
            //         status: "OK",
            //         message: "successful",
            //         data: finalUpdate
            //     })
            // } else {
            //     console.log('No matching transaction found.');
            //     return res.status(201).json({
            //         code: 201,
            //         status: "OK",
            //         message: "successful",
            //         data: {
            //             msg: "No matching transaction found.",
            //             requestid: id,
            //             status: "Failed",
            //             txnId: '',
            //             totalReceivedAmount: ''
            //         }
            //     });
            // }


        // } else {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "Pending",
                    paymentId: invoiceUser.paymentId,
                    emailAddress: invoiceUser.emailAddress,
                    name: invoiceUser.name,
                    totalRemainingAmount: 0,
                    currency: invoiceUser.currency,
                    totalAmount: balance,
                    totalReceivedAmount: 0,
                    conversionRate: invoiceUser.conversionRate,
                    address: invoiceUser.address,
                    remainingTime: timer,
                    paymentQRCode: invoiceUser.address,
                    txnId: invoiceUser.txnId
                },
            })
        // }

        //Ashutosh Singh

    } catch (err) {
        console.log(err, "Error in invoiceStatusTRC20: ");
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: err.message || "An error occurred while Status Checking",
            data: [],
        });
    }
}

async function getTransactionFee(sender, receiver, usdtAmount) {
    try {

        // Validate addresses
        if (!tronWeb.isAddress('TEbvZAPmWcs1UDVh9nXUJQWPoeazNrEY4P') || !tronWeb.isAddress(receiver)) {
            throw new Error('Invalid sender or receiver address');
        }

        console.log('address recivere and sender ', receiver, sender);
        // USDT contract on TRON
        const usdtContract = await tronWeb.contract().at("TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t");

        // Convert USDT amount to Sun units (6 decimals for USDT)
        const amount = tronWeb.toSun(10);

        // Create unsigned transaction
        const unsignedTx = await usdtContract.methods.transfer(receiver, amount).send({
            from: 'TEbvZAPmWcs1UDVh9nXUJQWPoeazNrEY4P',
            shouldPollResponse: true  // Wait for confirmation
        });

        // Get transaction details
        const txInfo = await tronWeb.trx.getTransactionInfo(unsignedTx);

        if (txInfo && txInfo.receipt) {
            const energyUsed = txInfo.receipt.energy_usage_total || 0;
            const bandwidthUsed = txInfo.receipt.net_usage || 0;
            const energyFee = txInfo.receipt.energy_fee || 0;
            const bandwidthFee = txInfo.receipt.net_fee || 0;

            return {
                energyUsed,
                bandwidthUsed,
                energyFeeTrx: energyFee / 1e6,
                bandwidthFeeTrx: bandwidthFee / 1e6,
                totalCostTrx: (energyFee + bandwidthFee) / 1e6
            };
        } else {
            throw new Error("Transaction details not found");
        }
    } catch (error) {
        console.error("Error fetching transaction cost:", error);
        throw error;
    }
}


const invoiceCronTRC20 = async (req, res) => {
    try {
        const { id, balance, currency, address, createdDate } = req.body;
        if (!id || !balance || !currency || !address || !createdDate) {
            return res.status(400).send({
                code: "400",
                status: "Fail",
                message: "Fill required details missing",
                data: [],
            });
        }
        var old_balance = new Decimal(balance);
        // var staticAdd = 'TFfmwQX3NeRAsZWQMtvktEwdv5SUVMRV3R';
        var staticAdd = address;

        // Assuming getTRXBalance returns a promise that resolves to a string representation of the balance
        var amount = new Decimal(await getTronScanBalanceUSDT(staticAdd));
        if (!amount) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Balance Not fetch",
                    requestid: id,
                    status: "",
                    txnId: "",
                    totalReceivedAmount: ""
                }
            });
        }
        var receive_amount = amount.minus(old_balance);
        var formattedDate = createdDate.replace('T', ' ').substring(0, 19);

        console.log("balance :---" + amount)
        console.log(" Recive Amount balance :---" + receive_amount)
        console.log(" formatDate :---" + formattedDate)
        console.log(invoiceUser)
        if (receive_amount > 0 && amount > old_balance) {
            const data = getTronScanTransactionsUSDT(staticAdd);
            const transactions = await data;
            if (transactions.length <= 0) {
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "Transcation not fetch",
                        requestid: id,
                        status : "",
                        txnId: "",
                        totalReceivedAmount: ""
                    }
                });
            }
            const filteredTransactions = filterTransactions(transactions, staticAdd, formattedDate, receive_amount);
            if (filteredTransactions.length <= 0) {
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "Transcation not Filtered properly",
                        requestid: id,
                        status: "",
                        txnId: "",
                        totalReceivedAmount: ""
                    }
                });
            }
            const filteredTransactions2 = filterTransactions(otherTransactions, staticAdd, formattedDate, receive_amount);
            const matchingTransaction = await findMatchingTransaction(filteredTransactions, receive_amount);
            if (matchingTransaction) {
                console.log('Matching transaction found:', matchingTransaction);

                //check transcaton history
                let option = {
                    "requestid": id,
                    "status": "PAID",
                    "txnId": matchingTransaction.transactionId,
                    "totalReceivedAmount": receive_amount

                };
                const updateData = await apiCronRequest(process.env.API_URL + 'apppayment/ClaimPaymentv1', option);
                const finalUpdate = updateData.data;
                // console.log(finalUpdate)
                return res.status(200).json(finalUpdate);
            } else {
                console.log('No matching transaction found.');
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "No matching transaction found.",
                        requestid: id,
                        status: "",
                        txnId: "",
                        totalReceivedAmount: ""
                    },
                });
            }

        } else {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "Pending",
                    currency: currency,
                    balance: balance,
                    totalAmount: amount,
                    totalReceivedAmount: 0,
                    address: address,
                    remainingTime: "00:00:00",
                    paymentQRCode: address,
                    txnId: "",
                },
            })
        }
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            code: 500,
            status: "OK",
            message: "Failled",
            data: {
                paymentStatus: 'Failed',
                requestid: id,
                status: error.message,
                txnId: "",
                totalReceivedAmount: ""
            },
        })
    }
};


module.exports = {
    createInvoiceTRC20,
    invoiceStatusTRC20,
    invoiceCronTRC20,
    getTRC20Balance,
    withdrawUSDTTRC
}