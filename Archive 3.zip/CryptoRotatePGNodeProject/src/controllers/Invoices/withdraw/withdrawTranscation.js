const { withdrawTRX } = require('../Tron/TRX/TRX');
const { withdrawUSDTTRC } = require('../Tron/USDT/TRC20_USDT');
const { withdrawTranscationETH } = require('../../Invoices/Ethereum/ETH/eth');
const { withdrawERC20 } = require('../../Invoices/Ethereum/USDT/ERC20_USDT')
const { decrptData } = require('../../../helpers/security/encDec');
const { withdraBTC } = require('../../Invoices/Bitcoin/btc');
const { withdrawBCH } = require('../../Invoices/BitcoinCash/BCH');
const withdrawRequest = async (req, res, next) => {
    // const { Result } = req.body;
    const decryptData = req.body;
    // const decryptData = await decrptData(Result);
    const { currency, amount, from_address, to_address, yeketavirp } = decryptData;
    if (!currency || !amount || !from_address || !to_address || !yeketavirp) {
        return res.status(400).send({
            code: "400",
            status: "Fail",
            message: "Fill required details missing",
            data: {
                "currency": "",
                "amount": "",
                "from_address": "",
                "to_address": "",
                "yeketavirp": ""
            }
        });
    }
    console.log("currency" + currency)
    console.log("amount" + amount)
    console.log("currency" + currency)
    switch (currency) {
        case "TRX":
            await withdrawTRX(req, res, decryptData)
            break;
        case "USDT_TRC20":
            await withdrawUSDTTRC(req, res, decryptData)
            break;
        case "ETH":
            await withdrawTranscationETH(req, res, decryptData)
            break;
        case "USDT_ERC20":
            await withdrawERC20(req, res, decryptData)
            break;
        case "BTC":
            await withdraBTC(req, res, decryptData)
            break;
        case "BCH":
            await withdrawBCH(req, res, decryptData)
            break;
        default:
            return res.status(400).send({
                code: "400",
                status: "Not Found",
                message: "Invalid Currency",
                data: {},
            });
    }
}
module.exports = { withdrawRequest }