const { invoiceCronTRX } = require('../Tron/TRX/TRX');
const { invoiceCronTRC20 } = require('../Tron/USDT/TRC20_USDT');
const { invoiceCronETH } = require('../../Invoices/Ethereum/ETH/eth');
const { invoiceCronERC20 } = require('../../Invoices/Ethereum/USDT/ERC20_USDT');
const pendingInvoices = async (req, res, next) => {
    const { id, currency, balance, createdDate, address } = req.body
    if (!id || !balance || !currency || !address || !createdDate) {
        return res.status(400).send({
            code: "400",
            status: "Fail",
            message: "Fill required details missing",
            data: {
                currency: "",
                balance: "",
                createdDate: "",
                address: "",

            }
        });
    }
    switch (currency) {
        case "TRX":
            await invoiceCronTRX(req, res)
            break;
        case "USDT_TRC20":
            await invoiceCronTRC20(req, res)
            break;
        case "ETH":
            await invoiceCronETH(req, res)
            break;
        case "USDT_ERC20":
            await invoiceCronERC20(req, res)
            break;
        default:
            return res.status(400).send({
                code: "400",
                status: "Not Found",
                message: "Invalid Currency",
                data: {},
            });
    }
}
module.exports = {
    pendingInvoices
}