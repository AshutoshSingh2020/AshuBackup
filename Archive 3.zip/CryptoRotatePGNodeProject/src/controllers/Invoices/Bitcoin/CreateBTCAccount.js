const { BIP32Factory } = require('bip32');
const ecc = require('tiny-secp256k1');
const bip32 = BIP32Factory(ecc);
const bip39 = require('bip39');
const bitcoin = require('bitcoinjs-lib');
const network = bitcoin.networks.bitcoin; // Use 'bitcoin.networks.testnet' for Testnet
const path = `m/44'/0'/0'/0`; // Derivation path for Mainnet

// Generate a mnemonic phrase
let mnemonic = bip39.generateMnemonic();
const seed = bip39.mnemonicToSeedSync(mnemonic);
let root = bip32.fromSeed(seed, network);
let account = root.derivePath(path);
let node = account.derive(0).derive(0);

const createBTCAddress = async () => {
    const btcAddress = bitcoin.payments.p2pkh({
        pubkey: node.publicKey,
        network: network,
    }).address;
    return {
        address: btcAddress,
        key: node.toWIF(), // Get the private key in WIF format
        mnemonic: mnemonic // Include the mnemonic
    };
}

// console.log(`
// Wallet generated:
// - Address : ${createBTCAddress},
// - Key : ${node.toWIF()},
// - Mnemonic : ${mnemonic}
// `);

module.exports = {
    createBTCAddress
}