const axios = require('axios');
const rp = require("request-promise");
const { createBTCAddress } = require("../Bitcoin/CreateBTCAccount");

const Decimal = require('decimal.js');
const usdRate = require('../../../helpers/coinToUSDRate/usdRate');
const { apiRequest, apiCronRequest } = require('../../../helpers/request/request');
const bitcoin = require('bitcoinjs-lib');
const btcconfig = require('../../../config/btc.json')
const { decrptData } = require('../../../helpers/security/encDec.js');
const { sleep } = require('tronweb/utils');

const balance_BTC = async function (wallet) {
    try {
        // const USER = process.env.RPC_USER;
        // const PASS = process.env.RPC_PASSWORD;

        const USER = process.env.RPC_USER;
        const PASS = process.env.RPC_PASSWORD;

        const bitcoinPort = process.env.bitcoin_tunnel_port
        var auth = "Basic " + new Buffer.from(USER + ":" + PASS).toString("base64");
        var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"getbalance","params":[]}`;
        var options = {
            //   url: `http://127.0.0.1:${bitcoinPort}/wallet/${wallet}`,
            url: `https://go.getblock.io/8a67bcbf1e084cb4b295dfef163b8085`,
            method: "POST",
            headers: {
                "Authorization": auth
            },
            body: dataString
        };
        const a = await rp(options).then((data) => {
            return data
        }).catch((err) => {
            return err.error
        })
        let bal = JSON.parse(a)
        bal = bal.result
        console.log('bitcoin balance ', bal)
        return bal;
    } catch (err) {
        console.log("Error in send_btc_swap:", err)
    }
}

const getBTCBalance = async (address) => {
    try {
        console.log(address, '-------')
        const requestOptions = {
            method: "GET",
            uri: `https://api.blockcypher.com/v1/btc/${process.env.bitcoin_network}/addrs/${address}/balance`,
            json: true,
            gzip: true,
        };

        var a = await rp(requestOptions)
            .then((data) => {
                return data;
            })
            .catch((err) => {
                console.log(err);
            });

        // a = "0.00001243"
        a = a.balance;
        a = a / 100000000;
        // balance = JSON.parse(balance)
        // balance = balance.result;
        return a;
    } catch (err) {
        console.log('getBTCBalance error:', err);
    }
};

const validateBitcoinAddress = async (address) => {
    try {
        bitcoin.address.toOutputScript(address, bitcoin.networks.bitcoin);
        return true;
    } catch (error) {
        return false;
    }
}

const createInvoiceBTC = async (req, res) => {
    try {
        const { email, amount, cryptoAmount, currency, publicKey, userId, address, requestId, username, password, sURL, cURL } = req.body;

        var balance = 0;
        const minimumAmount = parseFloat(process.env.BTC_MINIMUM_AMOUNT || 0);
        if (amount < minimumAmount) {
            return res.status(400).send({
                code: "400",
                status: "Fail",
                message: `BTC amount should be greater than ${minimumAmount}`,
                data: {},
            });
        }
        let accountNumber, privateKey, mnemonic;
        if (address) {
            console.log('btc Address: ', address);
            if (!await validateBitcoinAddress(address)) {
                throw new Error('Invalid BTC address');
            }
            accountNumber = address;
            privateKey = "";
            mnemonic = "";
            let add = 'bc1qq904ynep5mvwpjxdlyecgeupg22dm8am6cfvgq';
            balance = await getBTCBalance(address);
            console.log("BTC" + balance);
        } else {
            const newAccount = await createBTCAddress();
            console.log('in else condition for private key', newAccount)
            if (!newAccount || !newAccount.address || !newAccount.key || !newAccount.mnemonic) {
                throw new Error("Failed to create BTC account");
            }
            accountNumber = newAccount.address;
            privateKey = newAccount.key;
            mnemonic = newAccount.mnemonic;
            balance = 0;
        }
        const rateData = await usdRate();
        const rate = Number(rateData.BTC);
        txnId = "";
        let usdAmount = '';
        let paidAmount = '';
        if (rate && amount) {
            const numericAmount = Number(amount);
            const numericRate = Number(rate);
            usdAmount = cryptoAmount ? Number((Number(numericAmount) * numericRate)).toFixed(6) : numericAmount.toFixed(6);
            paidAmount = cryptoAmount ? numericAmount.toFixed(6) : (numericAmount / numericRate).toFixed(6);
        }
        const timeout = Date.now() + 14400000;
        const remainingTime = new Date(timeout - Date.now()).toISOString().substr(11, 8);
        const invoiceData = {
            "userId": userId,
            "requestid": requestId,
            "currency": currency,
            "amount": amount,
            "paidAmount": paidAmount,
            "PrivateKey": privateKey,
            "address": accountNumber,
            "balance": balance,
            "memonic": mnemonic,
            "email": email,
            "rate": rate.toFixed(6),
            "surl": sURL,
            "curl": cURL

        }
        console.log(invoiceData)
        const invoiceResponse = await apiRequest(process.env.API_URL + 'crpapi/PaymentV1', invoiceData, username, password);
        const response = invoiceResponse.data;
        if (response.ErrorCode != '1') {
            throw new Error("Failed to create Invoice :  " + response.ErrorMessage);
        }

        res.status(200).send({
            code: "200",
            status: "OK",
            message: "Invoice created successfully",
            data: response
        });
    } catch (err) {
        console.error("createInvoiceBTC error:", err);
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: err.message || "An error occurred while creating the invoice",
            data: [],
        });
    }

};
const gettranscationBTC = async (address) => {
    const responseData = await fetch(
        btcconfig.blockstream.baseURL + btcconfig.blockstream.API.BTCtransactions.endpoint + address + "/txs",
        { method: "GET" }
    );

    const response = await responseData.json();

    let receivedTransactions = [];

    for (let datum of response) {
        if (datum.status.confirmed) {
            for (let output of datum.vout) {
                if (output.scriptpubkey_address === address) {
                    let blockTimeUTC = new Date(datum.status.block_time * 1000);
                    let blockTimeIST = new Date(blockTimeUTC.getTime() + (5.5 * 60 * 60 * 1000));

                    receivedTransactions.push({
                        transactionId: datum.txid,
                        transactionStatus: "Confirmed",
                        transactionFees: datum.fee / 100000000,
                        amount: output.value / 100000000,
                        toAddress: output.scriptpubkey_address,
                        fromAddress: datum.vin[0].prevout.scriptpubkey_address,
                        transactionDate: blockTimeIST.toISOString().replace("T", " ").slice(0, 19),
                        txConfirmed: datum.status.confirmed
                    });
                }
            }
        }
    }

    return receivedTransactions;
};
const filterTransactions = (transactions, targetAddress) => {
    return transactions.filter(txn =>
        txn.toAddress === targetAddress && txn.txConfirmed
    );
};

const invoiceStatusBTC = async (req, res, invoiceUser, timer) => {
    try {
        const { id, username, password } = req.body;
        // var old_balance = new Decimal('7.782937');
        // var old_balance = new Decimal(invoiceUser.balance);
        // var staticAdd = 'bc1qq904ynep5mvwpjxdlyecgeupg22dm8am6cfvgq';
        // const receivedTransactions = await gettranscationBTC(staticAdd);
        // console.log("transactions"+JSON.stringify(receivedTransactions));
        // for (let index = 0; index < transactions.length; index++) {
        //     const element = transactions[index];
        //     console.log(JSON.stringify(element))
        // }
        // console.log("otherTransactions"+otherTransactions);
        // return
        var staticAdd = invoiceUser.address;
        if (!await validateBitcoinAddress(staticAdd)) {
            throw new Error('Invalid BTC address');
        }
        var balance = new Decimal(await getBTCBalance(staticAdd));
        console.log("new Balance" + balance)
        // console.log("old Balance" + old_balance)
        if (!balance) {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Balance Not fetch",
                    requestid: id,
                    status: "Failed",
                    txnId: '',
                    totalReceivedAmount: ''
                }
            });
        }
        // var receive_amount = balance - old_balance;
        // var receive_amount = formatUnits(bal,18);
        // console.log("bal"+bal)

        // var receive_amount =ethers.formatEther(bal);
        var formattedDate = invoiceUser.createdDate.replace('T', ' ').substring(0, 19);
        // console.log("recienve"+receive_amount)
        console.log("balance :---" + balance)
        // console.log(" Recive Amount balance :---" + receive_amount)
        console.log(" formatDate :---" + formattedDate)
        console.log(invoiceUser)
        // if (receive_amount > 0 && balance > old_balance) {
        const data = await gettranscationBTC(staticAdd);
        const transactions = await data;
        console.log(transactions)
        if (transactions.length <= 0) {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Transcation not fetch",
                    requestid: id,
                    status: "Failed",
                    txnId: '',
                    totalReceivedAmount: ''
                }
            });
        }

        const matchingTransaction = await filterTransactions(transactions, staticAdd);
        if (matchingTransaction.length <= 0) {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    msg: "No matching transaction found.",
                    requestid: id,
                    status: "Failed",
                    txnId: '',
                    totalReceivedAmount: ''
                }
            });
        }
        for (let val of matchingTransaction) {
            // console.log('Matching transaction found:', matchingTransaction);
            let option = {
                "requestid": id,
                "status": "PAID",
                "txnId": val.transactionId,
                "totalReceivedAmount": val.amount

            };
            await sleep(10);
            const updateData = await apiRequest(process.env.API_URL + 'crpapi/ClaimPaymentv1', option, username, password)
            await sleep(10);
            const finalUpdate = updateData.data;
            if (finalUpdate.ErrorCode == '1') {
                console.log("response" + finalUpdate)
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: finalUpdate,
                });

            }

        }

        // } else {
        //     console.log('No matching transaction found.');

        // }
        // } else {
        return res.status(201).json({
            code: 201,
            status: "OK",
            message: "successful",
            data: {
                paymentStatus: "Pending",
                paymentId: invoiceUser.paymentId,
                emailAddress: invoiceUser.emailAddress,
                name: invoiceUser.name,
                totalRemainingAmount: 0,
                currency: invoiceUser.currency,
                totalAmount: balance,
                totalReceivedAmount: 0,
                conversionRate: invoiceUser.conversionRate,
                address: invoiceUser.address,
                remainingTime: timer,
                paymentQRCode: invoiceUser.address,
                txnId: invoiceUser.txnId
            },
        });
        // }
    } catch (err) {
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: err.message || "An error occurred while Status Checking",
            data: [],
        });
    }

};


const invoiceCronBTC = async (invoiceUser) => {
    var expireTime = Date.now() - 28800000;
    try {
        const { id, balance, currency, address, createdDate } = req.body;
        if (!balance || !currency || !address || !createdDate) {
            return res.status(400).send({
                code: "400",
                status: "Fail",
                message: "Fill required details missing",
                data: [],
            });
        }
        var old_balance = new Decimal(balance);
        var staticAdd = address;
        var amount = new Decimal(await getBTCBalance(staticAdd));
        if (!amount) {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Balance Not fetch",
                    txnId: ""
                }
            });
        }
        var receive_amount = amount - old_balance;
        var formattedDate = createdDate.replace('T', ' ').substring(0, 19);
        console.log("old_balance :---" + old_balance)
        console.log("balance :---" + amount)
        console.log(" Recive Amount balance :---" + receive_amount)
        console.log(" formatDate :---" + formattedDate);
        if (receive_amount > 0 && amount > old_balance) {
            const data = await gettranscationBTC(staticAdd);
            const transactions = await data;
            console.log(transactions)
            if (transactions.length <= 0) {
                return res.status(201).json({
                    code: 201,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "Transcation not fetch",
                        txnId: ""
                    }
                });
            }
            const matchingTransaction = await filterTransactions(transactions, receive_amount, formattedDate, staticAdd);
            if (matchingTransaction[0]) {
                console.log('Matching transaction found:', matchingTransaction);
                let option = {
                    "requestid": id,
                    "status": "PAID",
                    "txnId": matchingTransaction[0].transactionId,
                    "totalReceivedAmount": receive_amount

                };
                const updateData = await apiCronRequest(process.env.API_URL + 'apppayment/ClaimPaymentv1', option);
                const finalUpdate = updateData.data;
                console.log("response" + finalUpdate)
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: finalUpdate,
                })
            } else {
                console.log('No matching transaction found.');
                return res.status(201).json({
                    code: 201,
                    status: "OK",
                    message: "successful",
                    data: {
                        msg: "No matching transaction found.",
                        txnId: ""
                    }
                });
            }
        } else {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "Pending",
                    totalRemainingAmount: 0,
                    currency: currency,
                    balance: balance,
                    txnId: "",
                },
            })
        }
    } catch (error) {
        console.log('getting error' + error);
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: err.message || "An error occurred while Status Checking",
            data: {
                txnId: ""
            },
        });
    }
};
const withdraBTC = async (req, res, data) => {
    try {
        const { currency, amount, from_address, to_address, yeketavirp } = data;
        const privateDec = await decrptData(yeketavirp);
        console.log("private" + JSON.stringify(privateDec))
        console.log("from_address" + from_address)
        console.log("to_address" + to_address)
        // let txID = '04287177fa0e5c42416c4e2e4f28f9a9808e3d7984ab4b476f1a98e41c885d08';
        // let txID = 'da97dd70465b236c5b49d59fc3836149fb0f64fa7ca5fb14189aaaadeb98a63f';
        // const transactionInfo = await tronWeb.trx.getTransaction(txID);
        // const transactionInfo1 = await getTransactionConfirmations(txID);
        // console.log("transactionInfo : " + JSON.stringify(transactionInfo, null, 2))
        // return
        // let from = 'TD5Am1yhZ1zKypGntNPaJ4fw1qPCTTLpyp';
        // let to = 'TC4KvZcpz2KkRPkDQmD53fgp4aFSd2NWxy';
        // let private = '2c500f1eda329a2f1b1ee74c5c4407f23c8a3dd58634008fe77dd3cdf8363884';
        // let amountb = '1';
        if (!await validateBitcoinAddress(from_address) && !await validateBitcoinAddress(to_address)) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Invalid addresses",
                    paymentStatus: "",
                    Amount: '',
                    transactionId: "",
                },
            })
        }
        // const bandwidth = await tronWeb.trx.getBandwidth(from_address);
        const balance = await getBTCBalance(from_address);
        console.log("balance: " + Number(balance))
        console.log("amount: " + Number(amount))
        // console.log("bandwidth+" + bandwidth)
        if (Number(balance) < (Number(amount) + 1)) {
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    msg: "Insufficient funds to transfer",
                    paymentStatus: "",
                    Amount: '',
                    transactionId: "",
                }
            });
        }


        const BLOCKCYPHER_URL = "https://api.blockcypher.com/v1/btc/main";
        const PRIVATE_KEY_WIF = privateDec;
        const SENDER_ADDRESS = from_address;
        const RECEIVER_ADDRESS = to_address;
        const API_TOKEN = '3bbdda23950848179231f4c1b2e0a0a1';
        const NETWORK = bitcoin.networks.bitcoin;

        const utxoResponse = await axios.get(`${BLOCKCYPHER_URL}/addrs/${SENDER_ADDRESS}?unspentOnly=true`);
        const utxos = utxoResponse.data.txrefs;

        if (!utxos || utxos.length === 0) {
            console.log("No UTXOs available. Fund your wallet first.");
            return;
        }
        let totalInput = 0;
        let inputCount = 0;
        const txb = new bitcoin.TransactionBuilder(NETWORK);

        for (const utxo of utxos) {
            txb.addInput(utxo.tx_hash, utxo.tx_output_n);
            totalInput += utxo.value;
            inputCount++;

            if (totalInput >= 10000) break;
        }

        const amountToSend = amount;
        const fee = 500;
        const change = totalInput - amountToSend - fee;
        txb.addOutput(RECEIVER_ADDRESS, amountToSend);
        if (change > 0) txb.addOutput(SENDER_ADDRESS, change);
        const keyPair = bitcoin.ECPair.fromWIF(PRIVATE_KEY_WIF, NETWORK);
        for (let i = 0; i < inputCount; i++) {
            txb.sign(i, keyPair);
        }

        const rawTx = txb.build().toHex();

        const transactionId = rawTx;
        if (transactionId) {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "Pending",
                    Amount: amount,
                    transactionId: transactionId,
                },
            });

        } else {
            return res.status(201).json({
                code: 201,
                status: "OK",
                message: "ERROR",
                data: {
                    msg: "Transaction Id not fetched",
                    paymentStatus: "",
                    Amount: '',
                    transactionId: "",
                },
            });
        }
    } catch (error) {
        console.log(error, "Error in withdrawBTC: ", error);
        return res.status(500).send({
            code: 500,
            status: "ERROR",
            message: "Transaction failed",
            error: error.message,
            data: {
                paymentStatus: "",
                Amount: '',
                transactionId: "",
            }
        });
    }
};
module.exports = {
    createInvoiceBTC,
    invoiceStatusBTC,
    invoiceCronBTC,
    getBTCBalance,
    balance_BTC,
    withdraBTC
}