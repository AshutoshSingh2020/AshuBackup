// const Speakeasy = require("speakeasy");
// var QRCode = require('qrcode');
// const { sendQRCodeEmail } = require('../helpers/mailer')
// const Admin = require("../models/adminModels/adminModel");
// const User = require('../models/user.model')
// const dashboardController = require("./dashboardController");

// function isValidateEmail(Vemail) {
//   const re =
//     /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
//   return re.test(String(Vemail).toLowerCase());
// }

// //============================ 2FA ADMIN PART ==================================================================//

// exports.admintwofactorsetupFunction = async (req, res) => {
//   try {

//     const secretadmin = Speakeasy.generateSecret({ name: "SUBADMIN_COINUNIVERZE" });
    
//     var email = req.body.email
//     email = email.replace(/\s+/g, '');
//     email = email.toLowerCase();

//     if (!isValidateEmail(email)) {
//       return res.status(401).json({
//         statuscode: 401,
//         status: " Not Found",
//         message: "Please Enter a Valid Email",
//         data: {},
//       });
//     }

//     const admin = await Admin.findOne({ email: email });

//     if (admin.Google_2fa_Secret == null && admin.Google_2fa_QRCode_URL == null && admin.Google_2fa_auth == false) {

//       QRCode.toDataURL(secretadmin.otpauth_url, async (err, data_url) => {

//         var encrypted = dashboardController.encrypt(secretadmin.base32);

//         await Admin.findOneAndUpdate({ email: email }, { Google_2fa_Secret: encrypted });
//         await Admin.findOneAndUpdate({ email: email }, { Google_2fa_QRCode_URL: data_url });
//         await sendQRCodeEmail(email, data_url, secretadmin.base32)

//         return res.status(200).json({
//           statuscode: 200,
//           status: "OK",
//           message: "QR Code Generated Successfully",
//           data: {
//             QR_data: data_url,
//             email: email,
//             SecretKey: secretadmin.base32
//           },
//         });
//       })
//     } else {

//       var decrypted = dashboardController.decrypt(admin.Google_2fa_Secret);

//       return res.status(200).send({
//         statuscode: 200,
//         status: "OK",
//         message: "2FA Google Already Created.",
//         data: {
//           email: email,
//           SecretKey: decrypted,
//           QR_data: admin.Google_2fa_QRCode_URL
//         },
//       });
//     }
//   } catch (err) {
//     console.log(err, "error at line no. 33 in 2fagoogle.js")
//   }
// }


// exports.admintotpvalidateFunction = async (email, token, secret) => {
//   try {
//     console.log(email, token)
//     if (isValidateEmail(email)) {
//       let isVerified = Speakeasy.totp.verify({
//         email: email,
//         secret: secret,
//         encoding: 'base32',
//         token: token,
//         window: 0
//       });

//       if (isVerified) {
//         return true
//       } else {
//         return false
//       }
//     }
//   } catch (err) {
//     console.log(err, "error at line no. 147 in 2fagoogle.js")
//   }
// }

// //===========================AFTER QR CODE GENERATED VERIFY CORRECT  IN SIGNUP TIME ADMIN======================================//

// exports.OtpvalidateFunction = async (req, res) => {
//   try {
//     const { email, token, secret } = req.body

//     if (isValidateEmail(email)) {
//       let isVerified = Speakeasy.totp.verify({
//         email: email,
//         secret: secret,
//         encoding: 'base32',
//         token: token,
//         window: 0
//       });

//       if (isVerified) {
//         return res.status(200).json({
//           statuscode: 200,
//           status: " OK",
//           message: "QR CODE and Secret Key Verified SUCCESSFULLY",
//           data: {
//             email: email,
//             SecretKey: secret
//           },
//         })
//       } else {
//         return res.status(400).json({
//           statuscode: 400,
//           status: "Failed",
//           message: "QR CODE and Secret Key Mismatched",
//           data: {},
//         })
//       }
//     }
//   } catch (err) {
//     console.log(err, "error at line no. 147 in 2fagoogle.js")
//   }
// } 