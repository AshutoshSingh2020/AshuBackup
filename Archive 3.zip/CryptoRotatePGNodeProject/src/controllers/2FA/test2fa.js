// // const User = require('../../models/userModel');
// const Speakeasy = require("speakeasy");
// const QRCode = require('qrcode');
// const crypto = require('crypto');


// // Use environment variable for secret, or generate a persistent secret
// const secret = process.env.ENCRYPTION_SECRET 
//     ? Buffer.from(process.env.ENCRYPTION_SECRET, 'hex') 
//     : (() => {
//         const generatedSecret = crypto.randomBytes(32);
//         // Optionally log a warning about generating a new secret
//         console.warn('No ENCRYPTION_SECRET found. Generated a new secret. IMPORTANT: This may break existing encrypted data.');
//         return generatedSecret;
//     })();

// const algorithm = 'aes-256-cbc';

// // Function to encrypt data
// const encrypt = (data) => {
//     try {
//         // Ensure data is converted to string
//         const stringData = String(data);
        
//         const iv = crypto.randomBytes(16); // Generate a new IV for each encryption
//         const cipher = crypto.createCipheriv(algorithm, Buffer.from(secret), iv);
//         let encrypted = cipher.update(stringData, 'utf8', 'hex');
//         encrypted += cipher.final('hex');
//         return `${iv.toString('hex')}:${encrypted}`;
//     } catch (error) {
//         console.error('Encryption error:', error);
//         throw new Error('Encryption failed');
//     }
// };

// // Function to decrypt data
// const decrypt = (data) => {
//     try {
//         // Validate input
//         if (!data || typeof data !== 'string' || !data.includes(':')) {
//             throw new Error('Invalid encrypted data format');
//         }

//         const [ivHex, encryptedData] = data.split(':');
//         const iv = Buffer.from(ivHex, 'hex');
//         const decipher = crypto.createDecipheriv(algorithm, Buffer.from(secret), iv);
//         let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
//         decrypted += decipher.final('utf8');
//         return decrypted;
//     } catch (error) {
//         console.error('Decryption error:', error);
//         throw new Error('Decryption failed');
//     }
// };

// // Function to hash a key (for integrity checks)
// const hashKey = (key) => {
//     return crypto.createHash('sha256').update(key).digest('hex');
// };



// function isValidateEmail(Vemail) {
//     const re =
//         /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
//     return re.test(String(Vemail).toLowerCase());
// }

// exports.create_2FA_Google = async (req, res) => {
//     try {
//         var { email } = req.body
//         email = email.replace(/\s+/g, '');
//         email = email.toLowerCase();

//         if (!isValidateEmail(email)) {
//             return res.status(400).send({
//                 statuscode: 400,
//                 status: "Failed",
//                 message: "Email Is Invalid",
//                 data: {},
//             });
//         }

//         const Search = "await User.findOne({ email: email })";
        
//         // Check if Google 2FA is already set up
//         if (Search.Google_2fa_data && Search.Google_2fa_data.length > 0) {
//             const decrypted_Secret = decrypt(Search.Google_2fa_data[0].Google_2fa_Secret);
            
//             return res.status(200).send({
//                 statuscode: 200,
//                 status: "OK",
//                 message: "2FA Google Already Created",
//                 data: {
//                     qrCode: Search.Google_2fa_data[0].QrCode_Url,
//                     secretKey: decrypted_Secret
//                 },
//             });
//         }

//         // Generate a new secret for Google Authenticator
//         const secret = Speakeasy.generateSecret({ 
//             name: `YourAppName:${email}`,
//             length: 32 
//         });

//         // Generate QR code
//         const qrCodeUrl = await new Promise((resolve, reject) => {
//             QRCode.toDataURL(secret.otpauth_url, (err, data_url) => {
//                 if (err) reject(err);
//                 resolve(data_url);
//             });
//         });

//         // Encrypt the secret before storing
//         const encrypted_Secret = encrypt(secret.base32);

//         // Prepare data to save
//         const data = {
//             Google_2fa_Secret: encrypted_Secret,
//             QrCode_Url: qrCodeUrl,
//             Date_Created: new Date()
//         };

//         // Update user with Google 2FA data
//         // await User.findOneAndUpdate(
//         //     { email: email }, 
//         //     { 
//         //         $push: { Google_2fa_data: data },
//         //         Google_2fa_auth: false 
//         //     }
//         // );

//         return res.status(200).json({
//             statuscode: 200,
//             status: "OK",
//             message: "2FA Google Account Created Successfully",
//             data: {
//                 secretKey: secret.base32,
//                 qrCode: qrCodeUrl
//             },
//         });

//     } catch (err) {
//         console.error(err, "Error in Creating Google 2FA");
//         return res.status(500).json({
//             statuscode: 500,
//             status: "Error",
//             message: "Internal Server Error",
//             data: {}
//         });
//     }
// }

// exports.activate_2FA_Google = async (req, res) => {
//     try {
//         const email = req.body.email;
//         const { token } = req.body;

//         console.log('token: ', token);

//         const Search = "await User.findOne({ email: email })";
//         console.log('seach email : ', Search)
        

//         // Check if Google 2FA is set up
//         if (!Search.Google_2fa_data || Search.Google_2fa_data.length === 0) {
//             return res.status(400).send({
//                 statuscode: 400,
//                 status: "Failed",
//                 message: "Google 2FA Not Set Up",
//                 data: {},
//             });
//         }

//         // Decrypt the secret
//         const decrypted_Secret = decrypt(Search.Google_2fa_data[0].Google_2fa_Secret);
//         console.log('decrypted_Secret: ',decrypted_Secret )
//         // Verify the token


//         let isVerified = false
//         if(decrypted_Secret ==  token){
//             isVerified=true;
//         }

//         if (isVerified) {
//             // Update user to enable Google 2FA
//             Search.Google_2fa_auth = true;
//             await Search.save();

//             return res.status(200).json({
//                 statuscode: 200,
//                 status: "OK",
//                 message: "Google 2FA Activated Successfully",
//                 data: {}
//             });
//         } else {
//             return res.status(400).json({
//                 statuscode: 400,
//                 status: "Failed",
//                 message: "Invalid Verification Token",
//                 data: {}
//             });
//         }
//     } catch (err) {
//         console.error(err, "Error in Activating Google 2FA");
//         return res.status(500).json({
//             statuscode: 500,
//             status: "Error",
//             message: "Internal Server Error",
//             data: {}
//         });
//     }
// }

// exports.validate_2FA_Google_Token = async (req, res) => {
//     try {
//         const { Code } = req.body;
//         const email = req.body.email;

//         const Search = "await User.findOne({ email: email })";

//         // Check if Google 2FA is enabled
//         if (!Search.Google_2fa_auth) {
//             return res.status(401).send({
//                 statuscode: 401,
//                 status: "Failed",
//                 message: "Google 2FA Is Disabled",
//                 data: {}
//             });
//         }

//         // Check if 2FA data exists
//         if (!Search.Google_2fa_data || Search.Google_2fa_data.length === 0) {
//             return res.status(402).send({
//                 statuscode: 402,
//                 status: "Failed",
//                 message: "Google 2FA Account Not Found",
//                 data: {}
//             });
//         }

//         // Decrypt the secret
//         const decrypted_Secret = decrypt(Search.Google_2fa_data[0].Google_2fa_Secret);

//         // Verify the token
//         let isVerified = Speakeasy.totp.verify({
//             secret: decrypted_Secret,
//             encoding: 'base32',
//             token: Code,
//             window: 1 // Allow 1 time step before and after for clock skew
//         });

//         if (isVerified) {
//             return res.status(200).json({
//                 statuscode: 200,
//                 status: "OK",
//                 message: "Google Authenticator Token Valid Successfully",
//                 data: {}
//             });
//         } else {
//             return res.status(400).json({
//                 statuscode: 400,
//                 status: "Failed",
//                 message: "Invalid Google Authenticator Token",
//                 data: {}
//             });
//         }
//     } catch (err) {
//         console.error(err, "Error in Validating Google 2FA Token");
//         return res.status(500).json({
//             statuscode: 500,
//             status: "Error",
//             message: "Internal Server Error",
//             data: {}
//         });
//     }
// }