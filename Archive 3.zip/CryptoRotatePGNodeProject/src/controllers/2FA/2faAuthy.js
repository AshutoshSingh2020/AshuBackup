// var QRCode = require('qrcode');
// const User = require('../models/user.model')
// const dashboardController = require("./dashboardController");
// const accountSid = process.env.AUTHY_2FA_ACC_SID;
// const authToken = process.env.AUTHY_2FA_AuthToken;
// const Speakeasy = require("speakeasy");

// const client = require('twilio')(accountSid, authToken);

// function isValidateEmail(Vemail) {
//     const re =
//         /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
//     return re.test(String(Vemail).toLowerCase());
// }

// exports.get_2FA_Status = async (req, res) => {
//     try {
//         var email = req.decoded.email

//         const Search = await User.findOne({ email: email });

//         return res.status(200).json({
//             statuscode: 200,
//             status: "OK",
//             message: "2FA Status",
//             data: {
//                 Email_OTP: Search.Email_2fa_auth,
//                 Google_2FA: Search.Google_2fa_auth,
//                 Authy_2FA: Search.Authy_2fa_auth,
//             },
//         });
//     } catch (err) {
//         console.log(err, "Error in get2FA Status");
//     }
// }

// exports.create_2FAAuthy = async (req, res) => {
//     try {
//         var { email } = req.body
//         email = email.replace(/\s+/g, '');
//         email = email.toLowerCase();

//         if (!isValidateEmail(email)) {
//             return res.status(400).send({
//                 statuscode: 400,
//                 status: "Failed",
//                 message: "Email Is Invalid",
//                 data: {},
//             });
//         }

//         const Search = await User.findOne({ email: email });
//         var find = Search.Authy_2fa_data
//         console.log(find.length, '.....')

//         if (find.length != 0) {

//             var decrypted_Secret_Key = dashboardController.decrypt(Search.Authy_2fa_data[0].Secret_Key);

//             return res.status(200).send({
//                 statuscode: 200,
//                 status: "OK",
//                 message: "2FA Authy Already Created.",
//                 data: {

//                     qrCode: Search.Authy_2fa_data[0].QrCode_Url,
//                     SecretKey: decrypted_Secret_Key
//                 },
//             });
//         } else {
//             const new_factor = await client.verify.services(process.env.AUTHY_2FA_Service_ID)
//                 .entities(process.env.AUTHY_2FA_AuthToken)
//                 .newFactors.create({
//                     friendlyName: email,
//                     factorType: 'totp'
//                 })
//             console.log(new_factor)

//             var encrypted_Secret_Key = dashboardController.encrypt(new_factor.binding.secret);
//             var encrypted_Factor_SID = dashboardController.encrypt(new_factor.sid);

//             var data = {

//                 Secret_Key: encrypted_Secret_Key,
//                 QrCode_Url: new_factor.binding.uri,
//                 Factor_SID: encrypted_Factor_SID,
//                 FriendlyName: new_factor.friendlyName,
//                 Account_Status: new_factor.status,
//                 Factor_Type: new_factor.factorType,
//                 Date_Created: new_factor.dateCreated,
//                 Date_Updated: new_factor.dateUpdated
//             }

//             User.findOneAndUpdate({ email: email }, {
//                 $push: { Authy_2fa_data: data }
//             }).then(() => {
//                 console.log(`SAVE push data`)
//             }).catch((err) => {
//                 console.log(err, "errr push")
//             })

//             return res.status(200).json({
//                 statuscode: 200,
//                 status: "OK",
//                 message: "2FA Authy Account Is Created SuccessFully",
//                 data: {
//                     Secret_Key: new_factor.binding.secret,
//                     QrCode_Url: new_factor.binding.uri,
//                     Factor_SID: new_factor.sid,
//                     FriendlyName: new_factor.friendlyName,
//                     Account_Status: new_factor.status,
//                     Factor_Type: new_factor.factorType,
//                     Date_Created: new_factor.dateCreated,
//                     Date_Updated: new_factor.dateUpdated
//                 },
//             });
//         }
//     } catch (err) {
//         console.log(err, "Error in Creating Authy 2FA");
//     }
// }
// exports.act_2FAAuthy_Key = async (req, res) => {
//     try {
//         const email = req.decoded.email

//         var { token } = req.body

//         const Search = await User.findOne({ email: email });

//         var find = Search.Authy_2fa_data
//         console.log(find.length, 'dododo')

//         if (find.length == 0) {

//             return res.status(402).send({
//                 statuscode: 402,
//                 status: "Failed",
//                 message: "Authy 2FA Account is Not Found.",
//                 data: {},
//             });
//         }
//         var decrypted_Factor_SID = dashboardController.decrypt(Search.Authy_2fa_data[0].Factor_SID);
//         var Factor_ID = decrypted_Factor_SID

//         if (Search.Authy_2fa_data[0].Account_Status == "verified") {

//             return res.status(200).json({
//                 statuscode: 200,
//                 status: "OK",
//                 message: "2FA Authy Account Already Activated",
//                 data: {}
//             })
//         }
//         const factor = await client.verify.services(process.env.AUTHY_2FA_Service_ID)
//             .entities(process.env.AUTHY_2FA_AuthToken)
//             .factors(Factor_ID)
//             .update({ authPayload: token })

//         if (factor.status == "verified") {

//             await User.updateOne(
//                 { email: email, "Authy_2fa_data.FriendlyName": email },
//                 { $set: { "Authy_2fa_data.$.Account_Status": "verified" } }).then(() => {
//                     console.log("saved");
//                 })

//             Search.Authy_2fa_auth = true
//             await Search.save();

//             return res.status(200).json({
//                 statuscode: 200,
//                 status: "OK",
//                 message: "2FA Authy Secret Key Verified SuccessFully",
//                 data: {
//                     Account_id: factor.accountSid,
//                     Factor_Id: factor.sid,
//                     Status: factor.status
//                 },
//             });
//         } else {
//             return res.status(400).json({
//                 statuscode: 400,
//                 status: "Failed",
//                 message: "UnVerified Token",
//                 data: {},
//             });
//         }
//     } catch (err) {
//         console.log(err, "Error in Activate Secret KEY AUTHY");
//     }
// }

// exports.validate_2FAAuthy_Token = async (req, res) => {
//     try {
//         var { Code } = req.body
//         const email = req.decoded.email

//         const Search = await User.findOne({ email: email });

//         if (Search.Authy_2fa_auth == false) {

//             return res.status(401).send({
//                 statuscode: 401,
//                 status: "Failed",
//                 message: "Authy 2FA Is Disabled",
//                 data: {}
//             });
//         }

//         if (Search.Authy_2fa_data[0].Account_Status == "unverified") {

//             return res.status(401).send({
//                 statuscode: 401,
//                 status: "Failed",
//                 message: "Authy 2FA Account is Not Activated.",
//                 data: {},
//             });
//         }

//         var find = Search.Authy_2fa_data
//         console.log(find.length, 'dododo')

//         if (find.length == 0) {

//             return res.status(402).send({
//                 statuscode: 402,
//                 status: "Failed",
//                 message: "Authy 2FA Account is Not Found.",
//                 data: {},
//             });
//         } else {

//             var decrypted_Factor_SID = dashboardController.decrypt(Search.Authy_2fa_data[0].Factor_SID);
//             var Factor_ID = decrypted_Factor_SID

//             const challenge = await client.verify.services(process.env.AUTHY_2FA_Service_ID)
//                 .entities(process.env.AUTHY_2FA_AuthToken)
//                 .challenges.create({
//                     authPayload: Code,
//                     factorSid: Factor_ID
//                 })

//             if (challenge.status == "approved") {

//                 return res.status(200).json({
//                     statuscode: 200,
//                     status: "OK",
//                     message: "TOTP Valid SuccessFully",
//                     data: {
//                         Factor_ID: Factor_ID,
//                         Status: challenge.status,
//                     },
//                 });
//             } else {
//                 return res.status(400).json({
//                     statuscode: 400,
//                     status: "Failed",
//                     message: "TOTP InCorrect.",
//                     data: {},
//                 });
//             }
//         }
//     } catch (err) {
//         console.log(err, "Error in ValidationCode Authy 2FA");
//     }
// }

// exports.get_2FA_Dis = async (req, res) => {
//     try {
//         var email = req.decoded.email

//         var { Type, Status, Code } = req.body

//         var Search = await User.findOne({ email: email });

//         if (!Search) {

//             return res.status(404).json({
//                 statuscode: 404,
//                 status: "Not Found",
//                 message: "Account Not Found",
//                 data: {},
//             });
//         }


//         switch (Type) {

//             case '2FA_Google':

//                 if (Status == "Disable") {

//                     var find = Search.Google_2fa_data
//                     console.log(find.length, '.....')

//                     if (find.length == 0) {

//                         return res.status(401).send({
//                             statuscode: 401,
//                             status: "Failed",
//                             message: "2FA Google already Disabled .",
//                             data: {},
//                         });
//                     }

//                     var decrypted_Secret = dashboardController.decrypt(Search.Google_2fa_data[0].Google_2fa_Secret);

//                     let isVerified = Speakeasy.totp.verify({
//                         email: email,
//                         secret: decrypted_Secret,
//                         encoding: 'base32',
//                         token: Code,
//                         window: 0
//                     });

//                     if (isVerified) {
                        
//                         Search.Google_2fa_data = []
//                         Search.Google_2fa_auth = false
//                         await Search.save();
                        
//                     } else {
//                         return res.status(400).json({
//                             statuscode: 400,
//                             status: "Failed",
//                             message: "Please Enter Valid Verification code",
//                             data: {},
//                         });
//                     }
//                 } else {
//                     return res.status(404).json({
//                         statuscode: 404,
//                         status: "Failed",
//                         message: "It Only For Disable Purpose",
//                         data: {},
//                     });
//                 }

//                 break;

//             case '2FA_Authy':

//                 if (Status == "Disable") {

//                     if (Search.Authy_2fa_data[0].Account_Status == "unverified") {

//                         return res.status(401).send({
//                             statuscode: 401,
//                             status: "Failed",
//                             message: "Authy 2FA Account is Not Activated.",
//                             data: {},
//                         });
//                     }

//                     var find = Search.Authy_2fa_data
//                     console.log(find.length, '.....')

//                     if (find.length == 0) {

//                         return res.status(401).send({
//                             statuscode: 401,
//                             status: "Failed",
//                             message: "2FA Authy already Disabled .",
//                             data: {},
//                         });
//                     }
//                     var decrypted_Factor_SID = dashboardController.decrypt(Search.Authy_2fa_data[0].Factor_SID);
//                     var Factor_ID = decrypted_Factor_SID

//                     const challenge = await client.verify.services(process.env.AUTHY_2FA_Service_ID)
//                         .entities(process.env.AUTHY_2FA_AuthToken)
//                         .challenges.create({
//                             authPayload: Code,
//                             factorSid: Factor_ID
//                         })

//                     if (challenge.status == "approved") {

//                         Search.Authy_2fa_data = []
//                         Search.Authy_2fa_auth = false
//                         await Search.save();

//                     } else {
//                         return res.status(400).json({
//                             statuscode: 400,
//                             status: "Failed",
//                             message: "Please Enter Valid Verification code",
//                             data: {},
//                         });
//                     }
//                 } else {
//                     return res.status(404).json({
//                         statuscode: 404,
//                         status: "Failed",
//                         message: "It Only For Disable Purpose",
//                         data: {},
//                     });
//                 }

//                 break;
//             default:
//                 return res.status(404).json({
//                     statuscode: 404,
//                     status: "Not Found",
//                     message: "Type Not Exist",
//                     data: {},
//                 });
//                 break;
//         }

//         return res.status(200).json({
//             statuscode: 200,
//             status: "OK",
//             message: `${Type} Is Successfully Disabled`,
//             data: {
//                 Email_OTP: Search.Email_2fa_auth,
//                 Google_2FA: Search.Google_2fa_auth,
//                 Authy_2FA: Search.Authy_2fa_auth,
//             },
//         });
//     } catch (err) {
//         console.log(err, "Error in get2FA Disabled");
//     }
// }
