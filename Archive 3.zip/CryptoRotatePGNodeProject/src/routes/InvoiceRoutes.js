const express = require('express');
const { createInvoice } = require('../controllers/Invoices/createInvoice')
const { publicInvoiceStatus } = require('../controllers/Invoices/InvoiceStatus/InvoiceStatus')
const { startInvoiceCrontrx } = require('../controllers/Invoices/Tron/USDT/TRC20_USDT')
const validateApiKeys = require('../middleware/authMiddleware')
const { pendingInvoices } = require('../controllers/Invoices/SetCron/cronjob');
const { withdrawRequest } = require('../controllers/Invoices/withdraw/withdrawTranscation')
const { statusMark } = require('../controllers/Invoices/StatusCheck/statuscheckhash')

const router = express.Router();

// router.post("/createInvoice",validateApiKeys, createInvoice);

router.post("/createInvoice", createInvoice);

router.post("/publicInvoiceStatus", publicInvoiceStatus);
router.post("/pendingInvoices", pendingInvoices);
router.post("/withdrawRequest", withdrawRequest);
router.post("/statusMark", statusMark);
// router.post("/with", );


module.exports = router;