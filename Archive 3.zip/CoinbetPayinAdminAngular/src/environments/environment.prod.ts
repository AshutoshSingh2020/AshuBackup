export const environment = {
    production: true,
    apiUrl: 'https://client.paytoononline.com/'
};
