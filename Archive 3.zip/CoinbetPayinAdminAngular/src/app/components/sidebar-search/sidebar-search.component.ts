import {
  Component,
  CUSTOM_ELEMENTS_SCHEMA,
  OnChanges,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import {MENU} from '@modules/main/menu-sidebar/menu-sidebar.component';
import {Dropdown, ProfabricComponentsModule} from '@profabric/angular-components';

@Component({
  selector: 'app-sidebar-search',
  imports: [ProfabricComponentsModule],
  templateUrl: './sidebar-search.component.html',
  styleUrl: './sidebar-search.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA], 

})
export class SidebarSearchComponent {
  public searchText: string = '';
    public foundMenuItems: any[] = [];
    @ViewChild('dropdown') dropdown!: Dropdown;

    constructor() {}

    ngOnInit(): void {}

    handleSearchTextChange(event: { target: { value: string; }; }) {
        this.foundMenuItems = [];

        if (event.target.value) {
            this.searchText = event.target.value;
            this.findMenuItems(MENU);
            return;
        } else {
            this.searchText = '';
            // this.dropdown.isOpen = false;
        }
    }

    handleIconClick() {
        this.searchText = '';
        // this.dropdown.isOpen = false;
    }

    handleMenuItemClick() {
        this.searchText = '';
        // this.dropdown.isOpen = false;
    }

    findMenuItems(menu: any[]) {
        if (!this.searchText) {
            return;
        }

        menu.forEach((menuItem) => {
            if (
                menuItem.path &&
                menuItem.name
                    .toLowerCase()
                    .includes(this.searchText.toLowerCase())
            ) {
                this.foundMenuItems.push(menuItem);
            }
            if (menuItem.children) {
                return this.findMenuItems(menuItem.children);
            }
        });

        if (this.foundMenuItems.length > 0) {
            // this.dropdown.isOpen = true;
        }
    }

    boldString(str: string, substr: string) {
        return str.replaceAll(
            this.capitalizeFirstLetter(substr),
            `<strong class="text-light">${this.capitalizeFirstLetter(
                substr
            )}</strong>`
        );
    }

    capitalizeFirstLetter(string: string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }
}
