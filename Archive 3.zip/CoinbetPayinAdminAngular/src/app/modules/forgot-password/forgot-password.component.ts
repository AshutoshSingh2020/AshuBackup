import { Component, OnInit, OnDestroy, Renderer2, HostBinding, inject, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { AppService } from '@services/app.service';
import { UntypedFormGroup, UntypedFormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@/shared/shared.module';

@Component({
  selector: 'app-forgot-password',
  imports: [
    RouterModule,
    SharedModule,
   
  ],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],

})
export class ForgotPasswordComponent {
  @HostBinding('class') class = 'login-box';
  public forgotPasswordForm!: UntypedFormGroup;
  public isAuthLoading = false;

  constructor(
      private renderer: Renderer2,
      private toastr: ToastrService,
      private appService: AppService
  ) {}

  ngOnInit(): void {
      this.renderer.addClass(
          document.querySelector('app-root'),
          'login-page'
      );
      this.forgotPasswordForm = new UntypedFormGroup({
          email: new UntypedFormControl(null, Validators.required)
      });
  }

  forgotPassword() {
      if (this.forgotPasswordForm.valid) {
      } else {
          this.toastr.error('Hello world!', 'Toastr fun!');
      }
  }

  ngOnDestroy(): void {
      this.renderer.removeClass(
          document.querySelector('app-root'),
          'login-page'
      );
  }
}
