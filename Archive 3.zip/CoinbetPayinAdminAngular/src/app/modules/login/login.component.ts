import { Component, OnInit, OnDestroy, Renderer2, HostBinding, inject } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { AppService } from '@services/app.service';
import { UntypedFormGroup, UntypedFormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@/shared/shared.module';

@Component({
  selector: 'app-login',
  imports: [RouterModule,
   SharedModule,
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  @HostBinding('class') class = 'login-box';
  public loginForm!: UntypedFormGroup;
  public isAuthLoading = false;
  public isGoogleLoading = false;
  public isFacebookLoading = false;
  siteUrl = (window.location.hostname).substring((window.location.hostname).indexOf(".") + 1);
  
  passwordType = 'password';
  eyeType = 'eye';
  
  constructor(private renderer: Renderer2, private toastr: ToastrService, private appService: AppService) {if(localStorage.getItem('CompanyDetails')){localStorage.removeItem('CompanyDetails')}}
  
  ngOnInit() {
    this.appService.myVariable$.subscribe((value: boolean) => {
      this.isAuthLoading=value;
    });
    this.renderer.addClass(document.querySelector('app-root'),'login-page');
    this.loginForm = new UntypedFormGroup({
      email: new UntypedFormControl(null, Validators.required),
      password: new UntypedFormControl(null, Validators.required)
    });
  }
  
  async loginByAuth() {
    if (this.loginForm.valid) {
      await this.appService.loginByAuth(this.loginForm.value);
    } else {
      this.toastr.error('Form is not valid!','',{positionClass: 'toast-top-center'});
    }
  }
  
  togglePassVisible(){
    if(this.passwordType == 'password')
    {
      this.passwordType = 'text';
      this.eyeType = 'eye-off';
    }
    else
    {
      this.passwordType = 'password';
      this.eyeType = 'eye';
    }
  }
  
  ngOnDestroy() {
    this.renderer.removeClass(document.querySelector('app-root'),'login-page');
  }
}
