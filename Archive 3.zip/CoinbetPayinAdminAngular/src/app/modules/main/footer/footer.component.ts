import {Component, HostBinding} from '@angular/core';
import {DateTime} from 'luxon';
import packageInfo from './../../../../../package.json';
import { SharedModule } from '@/shared/shared.module';

@Component({
  selector: 'app-footer',
  imports: [
       SharedModule,
  ],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.scss'
})
export class FooterComponent {
  @HostBinding('class') classes: string = 'main-footer';
  public appVersion = packageInfo.version;
  public currentYear: string = DateTime.now().toFormat('y');
}

