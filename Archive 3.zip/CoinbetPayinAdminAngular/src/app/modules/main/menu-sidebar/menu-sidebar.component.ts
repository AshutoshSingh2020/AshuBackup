import {AppState} from '@/store/state';
import {UiState} from '@/store/ui/state';
import {Store} from '@ngrx/store';
import {AppService} from '@services/app.service';
import {Observable} from 'rxjs';
import { Component, HostBinding, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MenuItemComponent } from '@components/menu-item/menu-item.component';
import { SharedModule } from '@/shared/shared.module';

const BASE_CLASSES = 'main-sidebar elevation-4';

@Component({
  selector: 'app-menu-sidebar',
  imports: [
    RouterModule, MenuItemComponent,
    SharedModule,
   
  ],
  templateUrl: './menu-sidebar.component.html',
  styleUrl: './menu-sidebar.component.scss'
})
export class MenuSidebarComponent {
  @HostBinding('class') classes: string = BASE_CLASSES;
    public ui!: Observable<UiState>;
    public userCompany: any;
    public menu:any = [];

    compnayDetails = localStorage.getItem('CompanyDetails')?JSON.parse(localStorage.getItem('CompanyDetails')||'{}'):{};
    constructor(
        public appService: AppService,
        private store: Store<AppState>
    ) {}

    ngOnInit() {
        this.ui = this.store.select('ui');
        this.ui.subscribe((state: UiState) => {
            this.classes = `${BASE_CLASSES} ${state.sidebarSkin}`;
        });
        let userData=JSON.parse(localStorage.getItem('CompanyDetails')||'{}');
        this.userCompany = userData.CompanyName.toUpperCase();
        if(userData.RoleStatus!='BOCS'){
            this.menu = MENU;
        }
        else{
            this.menu = MENUBOCS;
        }
    }
}

export const MENU = [
    {
        name: 'Dashboard',
        iconClasses: 'home',
        path: ['/dashboard']
    },
    {
        name: 'Deposit',
        iconClasses: 'briefcase',
        path: ['/deposit']
    },
    {
        name: 'Chargeback',
        iconClasses: 'corner-up-right',
        path: ['/chargeback']
    },
    {
        name: 'Settlement',
        iconClasses: 'credit-card',
        path: ['/settlement']
    }
];
export const MENUBOCS = [
    {
        name: 'Deposit',
        iconClasses: 'briefcase',
        path: ['/deposit']
    },
    {
        name: 'Chargeback',
        iconClasses: 'corner-up-right',
        path: ['/chargeback']
    }
];