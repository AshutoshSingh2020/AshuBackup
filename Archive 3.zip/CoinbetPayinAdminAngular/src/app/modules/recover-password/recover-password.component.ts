import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ApiService } from '@services/api.service';
import { config } from '../../services/config';
import { Router } from '@angular/router';
import { Component, OnInit, OnDestroy, Renderer2, HostBinding, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@/shared/shared.module';

@Component({
    selector: 'app-recover-password',
    imports: [
        RouterModule,
        SharedModule,
    ],
    templateUrl: './recover-password.component.html',
    styleUrl: './recover-password.component.scss'
})
export class RecoverPasswordComponent {
    @HostBinding('class') class = 'login-box';

    public recoverPasswordForm!: FormGroup;
    public isAuthLoading = false;

    constructor(private renderer: Renderer2, private toastr: ToastrService, private apiservice: ApiService, private formBuilder: FormBuilder, private router: Router) { }

    ngOnInit(): void {
        this.renderer.addClass(document.querySelector('app-root'), 'login-page');
        this.recoverPasswordForm = this.formBuilder.group({
            password: ['', (Validators.required)],
            confirmPassword: ['', (Validators.required)]
        });

    }

    recoverPassword() {
        if (this.recoverPasswordForm.invalid) {
            this.toastr.warning('Please fill all fields properly', 'Error!', { positionClass: 'toast-top-center' });
        } else {
            let request = "?ConfrimPassword=" + this.recoverPasswordForm.get('confirmPassword')?.getRawValue() + "&NewPassword=" + this.recoverPasswordForm.get('password')?.getRawValue();
            this.isAuthLoading = true;
            this.apiservice.getRequest(config['ChangePassword'] + request).subscribe((data: any = {}) => {
                this.isAuthLoading = false;
                if ('RStatus' in data && data.RStatus == 'Failed') {
                    this.toastr.warning(data.Msg, data.RStatus, { positionClass: 'toast-top-center' });
                }
                else {
                    this.toastr.success('Password Changed!', 'Success!', { positionClass: 'toast-top-center' });
                    this.router.navigate(['/']);
                }

            }, (error) => {
                this.isAuthLoading = false;
                console.log(error);
                this.toastr.warning('Please try again', 'Error!', { positionClass: 'toast-top-center' });
            });

        }
    }

    ngOnDestroy(): void {
        this.renderer.removeClass(document.querySelector('app-root'), 'login-page');
    }
}
