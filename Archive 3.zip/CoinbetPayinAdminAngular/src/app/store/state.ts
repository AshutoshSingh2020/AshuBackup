import {UiState} from './ui/state';

export interface AppState {
    auth: any;
    ui: UiState;
}
