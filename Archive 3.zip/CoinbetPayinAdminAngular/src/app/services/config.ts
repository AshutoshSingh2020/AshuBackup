export const config: any = {
    // 'loginApi':'loginApi/UserLogin',
    'loginApi':'loginApi/CrpUserLogin',
    'GetDashBoardCount':'dashboardApi/GetDashBoardCount',
    'GetDeposits':'dashboardApi/GetDeposits',
    'GetSettlement':'dashboardApi/GetSettlement',
    'GetChargebackList':'dashboardApi/GetChargebackList',
    'DownLoadDepositExcel':'dashboardApi/DownLoadDepositExcel',
    'DownLoadStatementExcel':'dashboardApi/DownLoadStatementExcel',
    'MakeCallBackAllClient':'api/OtherApi/MakeCallBackAllClient',
    'TransferFund':'dashboardApi/TransferFund',
    'ChangePassword':'passwordchangeApi/ChangePassword'
 }