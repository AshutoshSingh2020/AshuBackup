import { SharedModule } from '@/shared/shared.module';
import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-main-menu',
  imports: [
    SharedModule
  ],
  templateUrl: './main-menu.component.html',
  styleUrl: './main-menu.component.scss'
})
export class MainMenuComponent implements OnInit{

  constructor() { }

  ngOnInit(): void {
  }

}