import { SharedModule } from '@/shared/shared.module';
import { Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-sub-menu',
  imports: [
    SharedModule
  ],
  templateUrl: './sub-menu.component.html',
  styleUrl: './sub-menu.component.scss'
})
export class SubMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
