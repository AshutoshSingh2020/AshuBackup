import { Component, OnInit, OnDestroy, Renderer2, HostBinding, inject } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { config } from '../../services/config';
import { CommonFunctionService } from '../../services/common-function.service';
import { ToastrService } from 'ngx-toastr';
import { TitleHeaderComponent } from '@/shared/title-header/title-header.component';
import { AdvanceTableComponent } from '@/shared/advance-table/advance-table.component';
import { AdvanceTablePaginatorComponent } from '@/shared/advance-table-paginator/advance-table-paginator.component';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@/shared/shared.module';
import moment from 'moment';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-deposit',
  imports: [
    TitleHeaderComponent,
    AdvanceTableComponent,
    AdvanceTablePaginatorComponent,
    RouterModule,
    SharedModule,
  ],
  templateUrl: './deposit.component.html',
  styleUrl: './deposit.component.scss'
})
export class DepositComponent {
  todayDate = new Date();
  dateValue: any = [new Date(), new Date()];
  exportLoader = false;
  buttonData = [{ name: 'Export', disabled: true, value: 'export' }]
  searchOptions = [{ name: 'All', value: 0 }, { name: 'Success', value: 1 }, { name: 'Created', value: 2 }];
  currentQuery: any = [];
  depositCollumns: any = [];
  depositCollumnLoading = false;
  depositCollumnNone: any = [[{ value: 'No Data Found', bg: 'white-drop' }]]
  depositCollumnHeaders: any = [
    [{ value: 'Sr. No.', bg: 'white-drop' },
    { value: 'RequestId', bg: 'white-drop' },
    { value: 'Request Amount', bg: 'white-drop' },
    { value: 'Paid Amount', bg: 'white-drop' },
    { value: 'Fees Amount', bg: 'white-drop' },
    { value: 'Net Amount', bg: 'white-drop' },
    { value: 'Name', bg: 'white-drop' },
    { value: 'Phone', bg: 'white-drop' },
    { value: 'TransactionId', bg: 'white-drop' },
    { value: 'UTR', bg: 'white-drop' },
    { value: 'Status', bg: 'white-drop' },
    { value: 'Mode', bg: 'white-drop' },
    { value: 'Created Date', bg: 'white-drop' },
    { value: 'Updated Date', bg: 'white-drop' },
    { value: 'Action', bg: 'white-drop' }]
  ];

  depositData: Array<{ TotalCount: number;[key: string]: any }> = [];
  depositRows: Array<Array<{ value: any; bg: string; sufText?: string; icon?: string }>> = [];
  pageNo = 1;
  rowCount: any = { f: 0, l: 0, t: 0 };
  pageCount = [10, 50, 100, 500, 1000];
  pagesTotal = 1;
  paginatorBlock: any = [];
  private apiSubscriber: Subscription[] = [];

  constructor(private apiservice: ApiService, private utilities: CommonFunctionService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.apiservice.myVariable$.subscribe((value: boolean) => {
      this.exportLoader = value;
    });

    let searchQuery = {
      "Dates": [this.dateValue[0], this.dateValue[1]],
      "Search": '',
      "intParam1": 0,
      "PageNo": 1,
      "PageSize": this.pageCount[0]
    };
    this.currentQuery = searchQuery;
    this.GetDepositData(this.currentQuery);
  }

  initializeData() {
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
  setPaginator() {
    this.paginatorBlock = [];
    if (this.currentQuery.PageNo <= 4) {
      for (let i = 1; i <= 10 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
    else {
      for (let i = this.currentQuery.PageNo - 3; i <= this.currentQuery.PageNo + 6 && i <= this.pagesTotal; i++) {
        this.paginatorBlock.push(i);
      }
    }
  }

  searchDeposit(searchQuery: any) {
    this.currentQuery.Dates = searchQuery.Dates;
    this.currentQuery.Search = searchQuery.searchInput;
    this.currentQuery.intParam1 = searchQuery.Option;
    this.currentQuery.PageNo = 1;
    this.GetDepositData(this.currentQuery);
  }

  onPaginatorChange(paginatorQuery: any) {
    if (paginatorQuery.action == 'next') {
      this.currentQuery.PageNo = this.currentQuery.PageNo + 1;
    }
    else if (paginatorQuery.action == 'previous') {
      this.currentQuery.PageNo = this.currentQuery.PageNo - 1;
    }
    else if (paginatorQuery.action == 'pageSize') {
      this.currentQuery.PageNo = 1;
      this.currentQuery.PageSize = paginatorQuery.pageSize;
    }
    else if (paginatorQuery.action == 'pageNo') {
      this.currentQuery.PageNo = paginatorQuery.pageNo;
    }
    this.GetDepositData(this.currentQuery);
  }

  GetDepositData(searchQuery: any) {
    this.initializeData();
    let request = {
      "StartDateTime": moment(searchQuery.Dates[0]).format("MM-DD-yyyy"),
      "EndDateTime": moment(searchQuery.Dates[1]).format("MM-DD-yyyy"),
      "Search": searchQuery.Search,
      "intParam1": searchQuery.intParam1,
      "PageNo": searchQuery.PageNo,
      "PageSize": searchQuery.PageSize
    };
    this.depositRows = [];
    this.depositCollumns = [];
    this.pagesTotal = 1;
    this.buttonData[0].disabled = true;
    this.depositData = [];
    this.depositCollumnLoading = true;
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['GetDeposits'], request).subscribe((data: any) => {
      this.depositCollumnLoading = false;
      this.currentQuery = searchQuery;
      this.depositData = data;
      if (this.depositData[0]) {
        this.buttonData[0].disabled = false;
        this.depositCollumns = this.depositCollumnHeaders;
        this.pagesTotal = Math.ceil(this.depositData[0].TotalCount / searchQuery.PageSize);
        this.depositData.forEach((element: any, index: any) => {
          this.depositRows.push([
            { value: ((this.currentQuery.PageNo - 1) * this.currentQuery.PageSize) + (index + 1), bg: 'white-cell' },
            { value: element.RequestId, bg: 'white-cell' },
            { value: this.utilities.roundOffNum(element.Amount), bg: 'white-cell' },
            { value: element.PaidAmount ? this.utilities.roundOffNum(element.PaidAmount) : '', bg: 'white-cell' },
            { value: element.FeesAmount ? this.utilities.roundOffNum(element.FeesAmount) : '', bg: 'white-cell' },
            { value: element.NetAmount ? this.utilities.roundOffNum(element.NetAmount) : '', bg: 'white-cell' },
            { value: element.Name, bg: 'white-cell' },
            { value: element.Phone, bg: 'white-cell' },
            { value: element.TransactionId, bg: 'white-cell' },
            ... (!element.TempUTR ? [{ value: element.ReferenceId, bg: 'white-cell' }] : [{ value: element.ReferenceId, bg: 'white-cell', sufText: 'Temp : ' + element.TempUTR }]),
            { value: element.TransactionStatus, bg: 'white-cell' },
            { value: element.PaymentMode, bg: 'white-cell' },
            { value: element.CreatedDate ? moment(element.CreatedDate).format("h:mm:ss a DD MMM yyyy") : '', bg: 'white-cell' },
            { value: element.UpdatedDate ? moment(element.UpdatedDate).format("h:mm:ss a DD MMM yyyy") : '', bg: 'white-cell' },
            { value: element.PGOrderId ? 'CallBack' : '', bg: 'white-cell', icon: element.PGOrderId ? 'None' : '' }
          ])
        });
        this.rowCount = { f: this.depositRows[0][0].value, l: this.depositRows[this.depositRows.length - 1][0].value, t: this.depositData[0].TotalCount };
        this.setPaginator();
      }
      else {
        this.rowCount = { f: 0, l: 0, t: 0 };
        this.depositCollumns = this.depositCollumnNone;
      }
    }, (error) => {
      this.depositCollumnLoading = false;
      console.log(error);
    });
  }

  onValueChange(val: any) {
    if (val.col == 14) {
      let request = "?TransactionId=" + this.depositData[val.row]['TransactionId'];
      this.depositRows[val.row][val.col].icon = 'Loading';
      this.apiSubscriber[1] = this.apiservice.getRequest(config['MakeCallBackAllClient'] + request).subscribe((data: any) => {
        this.depositRows[val.row][val.col].icon = 'None';
        if (data.ErrorCode == '1') {
          if (data.Result) {
            window.open(data.Result, '_blank')?.focus();
          } else {
            console.error('data.Result is null or undefined');
          }
        }
        else {
          this.toastr.clear();
          this.toastr.warning(this.depositData[val.row]['TransactionId'], data.ErrorMessage, { positionClass: 'toast-top-center' });
        }
      }, (error) => {
        this.depositRows[val.row][val.col].icon = 'None';
        console.log(error);
      });
    }

  }

  btnGridAction() {
    this.DownloadDepositData();
  }

  DownloadDepositData() {
    let request = "?Search=" + this.currentQuery.Search + "&intParam1=" + this.currentQuery.intParam1 + "&StartDateTime=" + moment(this.currentQuery.Dates[0]).format("DD/MM/yyyy") + "&EndDateTime=" + moment(this.currentQuery.Dates[1]).format("DD/MM/yyyy");
    let docname = 'Deposit_Download_' + moment(this.currentQuery.Dates[0]).format("DD/MM/yyyy");
    this.apiservice.exportExcel(config['DownLoadDepositExcel'] + request, docname);
  }

  ngOnDestroy() {
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
    if (this.apiSubscriber[1]) {
      this.apiSubscriber[1].unsubscribe();
    }
  }
}

