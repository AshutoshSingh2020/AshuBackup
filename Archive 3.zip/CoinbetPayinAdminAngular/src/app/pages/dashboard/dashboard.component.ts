import { Component, OnInit, OnDestroy, Renderer2, HostBinding, inject } from '@angular/core';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { CommonFunctionService } from '@services/common-function.service'
import { RouterModule } from '@angular/router';
import { TitleHeaderComponent } from '@/shared/title-header/title-header.component';
import { CardListComponent } from '@/shared/card-list/card-list.component';
import { SharedModule } from '@/shared/shared.module';
import { Subscription } from 'rxjs';
import moment from 'moment';

@Component({
  selector: 'app-dashboard',
  imports: [TitleHeaderComponent, CardListComponent,
    RouterModule,
    SharedModule,
  ],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent {
  todayDate = new Date();
  dateDashValue: Date[] = [new Date, new Date];
  dashboardCount: { name: string; value: string; icon: string; feather: string; color: string }[] = [];
  dashboardCountLoading = false;
  private apiSubscriber: Subscription[] = [];

  constructor(private apiservice: ApiService, private utilities: CommonFunctionService) { }

  ngOnInit(): void {
    this.GetDashboardCount(this.dateDashValue);
  }

  initializeData() {
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
  GetDashboardCount(DateValues: Date[]) {
    this.initializeData();
    let request = {
      "StartDateTime": moment(DateValues[0]).format("MM-DD-yyyy"),
      "EndDateTime": moment(DateValues[1]).format("MM-DD-yyyy")
    };
    this.dashboardCount = [];
    this.dashboardCountLoading = true;
    this.apiSubscriber[0] = this.apiservice.sendRequest(config['GetDashBoardCount'], request).subscribe((data: any) => {
      this.dashboardCountLoading = false;
      this.dashboardCount = [
        { "name": "Payment Volume", "value": '₹ ' + this.utilities.roundOffNum(data.TotalValume), "icon": "ion-person-add", "feather": "user-plus", "color": "#33c38e" },
        { "name": "Transaction Charges", "value": '₹ ' + this.utilities.roundOffNum(data.Charges), "icon": "ion-paper-airplane", "feather": "send", "color": "#ef6767" },
        { "name": "Number of Payment", "value": this.utilities.roundOffNum(data.TotatPaymentCount), "icon": "ion-pie-graph", "feather": "pie-chart", "color": "#1c84ee" },
        { "name": "Number of Request", "value": this.utilities.roundOffNum(data.NumberOfRequest), "icon": "ion-stats-bars", "feather": "bar-chart", "color": "#ffcc5a" },
        { "name": "Withdrawal Balance", "value": '₹ ' + this.utilities.roundOffNum(data.NetBalance), "icon": "ion-pie-graph", "feather": "book", "color": "#1c84ee" },
      ];
    }, (error) => {
      this.dashboardCountLoading = false;
      console.log(error);
    });
  }

  ngOnDestroy() {
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
}


