import { Component, OnInit, OnDestroy, Renderer2, HostBinding, inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '@/shared/shared.module';

@Component({
  selector: 'app-profile',
  imports: [
    RouterModule,
    SharedModule,
  ],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss'
})
export class ProfileComponent {

}
