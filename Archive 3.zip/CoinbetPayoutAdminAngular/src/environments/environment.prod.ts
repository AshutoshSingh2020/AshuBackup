export const environment = {
    production: true,
    apiUrl: 'https://payout.paytoononline.com/'
    // apiUrl: 'https://payoutuatadmin.paytoononline.com/'

    
};
