export const config: any = {
    'loginApi':'loginApi/UserLogin',
    'GetUserData':'dashboardApi/GetUserData',
    'GetDashBoardCount':'dashboardApi/GetDashBoardCount',
    'GetWithdraw':'dashboardApi/GetWithdraw',
    'GetSettlement':'dashboardApi/GetSettlement',
    'DownLoadWithdrawExcel':'dashboardApi/DownLoadWithdrawExcel',
    'DownLoadStatementExcel':'dashboardApi/DownLoadStatementExcel',
    'ChangePassword':'passwordchangeApi/ChangePassword'
 }