import { Component, HostBinding, OnDestroy, OnInit, Renderer2 } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ApiService } from '@services/api.service';
import { config } from '../../services/config';
import { Router, RouterModule } from '@angular/router';
import { SharedModule } from '@/shared/shared.module';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-recover-password',
  imports: [
    RouterModule,
    SharedModule
  ],
  templateUrl: './recover-password.component.html',
  styleUrl: './recover-password.component.scss'
})
export class RecoverPasswordComponent implements OnInit, OnDestroy {
  @HostBinding('class') class = 'login-box';

  public recoverPasswordForm!: FormGroup;
  public isAuthLoading = false;
  private apiSubscriber: Subscription[] = [];

  constructor(private renderer: Renderer2, private toastr: ToastrService, private apiservice: ApiService, private formBuilder: FormBuilder, private router: Router) { }

  ngOnInit(): void {
    this.renderer.addClass(document.querySelector('app-root'), 'login-page');
    this.recoverPasswordForm = this.formBuilder.group({
      password: ['', (Validators.required)],
      confirmPassword: ['', (Validators.required)]
    });
  }

  initializeData() {
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
  }
  recoverPassword() {
    this.initializeData();
    if (this.recoverPasswordForm.invalid) {
      this.toastr.warning('Please fill all fields properly', 'Error!', { positionClass: 'toast-top-center' });
    } else {
      let request = "?ConfrimPassword=" + this.recoverPasswordForm.get('confirmPassword')?.getRawValue() + "&NewPassword=" + this.recoverPasswordForm.get('password')?.getRawValue();
      this.isAuthLoading = true;
      this.apiSubscriber[0] = this.apiservice.getRequest(config['ChangePassword'] + request).subscribe((data: any = {}) => {
        this.isAuthLoading = false;
        if ('RStatus' in data && data.RStatus == 'Failed') {
          this.toastr.warning(data.Msg, data.RStatus, { positionClass: 'toast-top-center' });
        }
        else {
          this.toastr.success('Password Changed!', 'Success!', { positionClass: 'toast-top-center' });
          this.router.navigate(['/']);
        }
      }, (error) => {
        this.isAuthLoading = false;
        console.log(error);
        this.toastr.warning('Please try again', 'Error!', { positionClass: 'toast-top-center' });
      });

    }
  }

  ngOnDestroy(): void {
    if (this.apiSubscriber[0]) {
      this.apiSubscriber[0].unsubscribe();
    }
    this.renderer.removeClass(document.querySelector('app-root'), 'login-page');
  }
}
