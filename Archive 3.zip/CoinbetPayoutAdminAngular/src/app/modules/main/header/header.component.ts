import { AppState } from '@/store/state';
import { ToggleControlSidebar, ToggleSidebarMenu } from '@/store/ui/actions';
import { UiState } from '@/store/ui/state';
import { Component, HostBinding, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { AppService } from '@services/app.service';
import { Observable, Subscription } from 'rxjs';
import { ApiService } from '@services/api.service';
import { config } from '@services/config';
import { CommonFunctionService } from '@services/common-function.service';
import { Router, RouterModule } from '@angular/router';
import { SharedModule } from '@/shared/shared.module';
const BASE_CLASSES = 'main-header navbar navbar-expand';
@Component({
    selector: 'app-header',
    imports: [
        RouterModule,
        SharedModule
    ],
    templateUrl: './header.component.html',
    styleUrl: './header.component.scss'
})
export class HeaderComponent implements OnInit {
    @HostBinding('class') classes: string = BASE_CLASSES;
    public ui!: Observable<UiState>;
    userBalance = '0.00';

    private apiSubscriber: Subscription[] = [];
    constructor(private appService: AppService, private store: Store<AppState>, private apiservice: ApiService, private utilities: CommonFunctionService) { }

    ngOnInit() {
        this.ui = this.store.select('ui');
        this.ui.subscribe((state: UiState) => {
            this.classes = `${BASE_CLASSES} ${state.navbarVariant}`;
        });
        this.getAllData();
    }

    initializeData() {
        if (this.apiSubscriber[0]) {
          this.apiSubscriber[0].unsubscribe();
        }
      }
    getAllData() {
        this.initializeData();
        this.apiSubscriber[0] = this.apiservice.getRequest(config['GetUserData']).subscribe((data: any = {}) => {
            this.userBalance = this.utilities.roundOffNum(data.AccountBalance);
        }, (error) => {
            console.log(error);
        });
    }

    logout() {
        this.appService.logout();
    }

    onToggleMenuSidebar() {
        this.store.dispatch(new ToggleSidebarMenu());
    }

    onToggleControlSidebar() {
        this.store.dispatch(new ToggleControlSidebar());
    }

    ngOnDestroy() {
        if (this.apiSubscriber[0]) {
          this.apiSubscriber[0].unsubscribe();
        }
      }
}
