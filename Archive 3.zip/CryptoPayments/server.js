const express = require('express');
const dotenv = require('dotenv');
const userRoutes = require('./src/routes/userRoutes');
const invoiceRoutes = require('./src/routes/InvoiceRoutes')
const ethRoutes = require('./src/routes/eth.Routes')
const withdraw = require('./src/routes/withdraw.Routes')
const google = require('./src/routes/2faroute')

//const trxRoutes = require('./src/routes/trx.Routes')
const erc20Routes = require('./src/routes/erc20.Routes')
const webhook = require('./src/routes/webhook.Routes')
const connectDB = require('./src/config/db');
const { errorHandler } = require('./src/middleware/errorMiddleware');
const { startInvoiceCrontrc20 } = require('./src/controllers/Invoices/Tron/USDT/TRC20_USDT');
const { startInvoiceCrontrx } = require('./src/controllers/Invoices/Tron/TRX/TRX')
const { startInvoiceCronERC20 } = require('./src/controllers/Invoices/Ethereum/USDT/ERC20_USDT');
const { startInvoiceCronETH } = require('./src/controllers/Invoices/Ethereum/ETH/eth');


dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to the database
connectDB();

// Middleware
app.use(express.json()); // Body parser for JSON requests

app.use("/api/v1/user", userRoutes); // This should work now
app.use("/api/v1/invoice", invoiceRoutes); 
app.use("/api/v1/eth", ethRoutes); 
app.use("/api/v1/withdraw", withdraw); 
// app.use("/api/v1/trx", trxRoutes); 
app.use("/api/v1/erc_20", erc20Routes); 
app.use("/api/v1/webhook", webhook); 

app.use("/api/v1/google", google); 

// Routes
app.get('/', (req, res) => {
  res.status(200).json({ "message": "server connected Successfully" });
});

startInvoiceCrontrc20();
startInvoiceCrontrx();
startInvoiceCronERC20();
startInvoiceCronETH();


// Error Handling Middleware
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});