const mongoose = require('mongoose');

const keyPairSchema = new mongoose.Schema({
    userId:{ type: String, unique: true, required: true },
    publicKey: { type: String, required: true },
    privateKey: { type: String, required: true },
    publicKeyHash: { type: String, required: true }
});

module.exports = mongoose.model('KeyPair', keyPairSchema);
