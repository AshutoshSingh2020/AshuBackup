const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const adminWalletSchema = new Schema(
  {
    walletAddress: { type: String, required: true },
    currency: [
      {
        coin: { type: String, required: true },
        senderAddress: { type: String },
        privateKey: { type: String },
        receiverAddress: { type: String, required: true },
      },
    ],
    walletType: { type: String, required: true },
    txFees: { type: String, required: true },
    txRate: { type: String, required: true },
    sendingTxFees: { type: String, required: true },
    walletName: { type: String },
    withdrawalFee: { type: Number, default: 0 },
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

const adminWallet = mongoose.model("adminWallet", adminWalletSchema);
module.exports = adminWallet;
