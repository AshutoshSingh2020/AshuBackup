'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;



var WithdrawSchema = new Schema({
  currency: {
    type: String
  },
  amount : {
    type : String
  },
  from_address : {
    type : String
  },
  to_address:{
    type : String,
  },
  txId : {
    type :String
  },
  transactionHash : {
    type : String
  },
  createdAt : {
    type : Date,
  },
  updatedAt : {
    type : Date,
  }
  
});


module.exports = mongoose.model('Withdraw',WithdrawSchema);