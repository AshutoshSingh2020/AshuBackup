"use strict";
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var InvoiceSchema = new Schema({
  status : {
    type: String,
    default:'pending'
  },
  email : {
    type : String
  },
  amount: {
    type: Number,
  },
  currency: {
    type: String,
  }, 
  cryptoAmount: {
    type: Boolean
  },
  balance: {
    type: Number,
  },
  conv_amount : {
    type : Number
  },
  newAccount: {
    type: Object,
  },
  txnId: {
    type: String,
  },
  rate: {
    type: Number,
  },
  timestamp : {
    type : Number,
  },
  timeout : {
    type : Object,
  },
  cold_trans_done : {
    type : Boolean
  },
  refundCount: {
    type : Boolean,
    default: false
  },
  userEmail: {
    type : String
  },
  refundAmount: {
    type: Number,
    default:0
  },
  reminderCount: {
    type: Number,
    default:0
  },
  initialTRX_Tx: {
    type: Boolean
  },
  refundLink:{
    type:String
  },
  publicKey:{
    type:String
  },
  usdAmount:{
    type:Number
  },
  paidAmount:{
    type:Number
  }
  
});

module.exports = mongoose.model("Invoice", InvoiceSchema);
