"use strict";
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var InvoiceSchema = new Schema({
  email: {
    type: String
  },
  userId: {
    type: String
  },
  paymentStatus: {
    type: String,
    enum: ['PENDING', 'PAID', 'EXPIRED', 'FAILED'],
    default: 'PENDING'  // Sets default value for new invoices
  },
  amount: {
    
    type: Number,
  },
  previousBalance: {
    
    type: Number,
    default: 0
  },
  currency: {
    type: String,
  },
  paidAmount: {
    type: Number,
    default: 0
  },
  receivingAddress: {
    type: String
  },
  balance: {
    type: Number,
  },
  conv_amount: {
    type: Number
  },
  newAccount: {
    accountNumber: String,  
    privateKey: String     
  },

  txnId: {
    type: String,
  },
  rate: {
    type: Object,
  },
  timestamp: {
    type: Number,
  },
  timeout: {
    type: Object,
  },
  cold_trans_done: {
    type: Boolean
  },
  label: {
    type: String
  }
});

module.exports = mongoose.model("invoice", InvoiceSchema);
