const crypto = require('crypto');

// Use a 32-byte (256-bit) key for AES-256-CBC
const secret = crypto.randomBytes(32);
const algorithm = 'aes-256-cbc';

// Function to encrypt data
const encrypt = (data) => {
    const iv = crypto.randomBytes(16); // Generate a new IV for each encryption
    const cipher = crypto.createCipheriv(algorithm, Buffer.from(secret), iv);
    let encrypted = cipher.update(data, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    return `${iv.toString('hex')}:${encrypted}`;
};

// Function to decrypt data
const decrypt = (data) => {
    const [ivHex, encryptedData] = data.split(':');
    const iv = Buffer.from(ivHex, 'hex');
    const decipher = crypto.createDecipheriv(algorithm, Buffer.from(secret), iv);
    let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
};

// Function to hash a key (for integrity checks)
const hashKey = (key) => {
    return crypto.createHash('sha256').update(key).digest('hex');
};

module.exports = { encrypt, decrypt, hashKey };