const adminWallet = require("../../models/adminWallet");
const {Web3} = require('web3');
const web3 = new Web3("https://sepolia.infura.io/v3/be482ba1b3ee458481c4a8f9919e636e")
const privateKey = Buffer.from( 'privateKey', 'hex');
const speakeasy = require('speakeasy');
const QRCode = require("qrcode");


// const web3eth = new Web3(process.env.ethereum_network_url);
const web3eth = new Web3(process.env.eth_explorer_url);

const sleep = (ms) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

// Generate a secret key for a user
// exports.generate2FASecret = async (req, res) => {
//     const secret = speakeasy.generateSecret({ length: 20 });
//     const otpauthUrl = secret.otpauth_url;

//     // Save the secret in the database for the user (associate with user ID)
//     // Example: await User.findByIdAndUpdate(req.user.id, { twoFASecret: secret.base32 });

//     // Generate QR code
//     qrcode.toDataURL(otpauthUrl, (err, data) => {
//         if (err) {
//             return res.status(500).json({ status: "Failed", message: "QR Code generation failed" });
//         }
//         res.status(200).json({
//             status: "Success",
//             message: "2FA setup successful",
//             qrCode: data,
//             secret: secret.base32, // Provide secret for backup if user needs it
//         });
//     });
// };


// // Generate a Secret Key for a User
// const generateSecretKey = () => {
//     const secret = speakeasy.generateSecret({ length: 20 });
//     console.log("Base32 Secret Key:", secret.base32); // Save this for the user
//     console.log("OTPAuth URL (for QR Code):", secret.otpauth_url);
//     return secret.base32; // Return Base32 secret key to store in the user's profile or environment variable
// };

// // Example usage:
// const userSecretKey = generateSecretKey();
// // Save `userSecretKey` securely for the user (e.g., in the database or .env)



exports.withdraw = async (req, res) => {
    const {
        currency,
        amount,
        from_address,
        senderPrivateKey,
        full_amount,
        to_address,
        twofaToken,
    } = req.body;

    try {
        console.log("Withdrawal process started");

        // // Step 1: Verify OTP
        // const key = process.env.SECRET_KEY; // Use the pre-shared secret from setup
        // const isVerified = speakeasy.totp.verify({
        //     secret: key,
        //     encoding: "base32",
        //     token: twofaToken,
        // });

        // if (!isVerified) {
        //     return res.status(403).json({
        //         status: "Failed",
        //         message: "Invalid 2FA code",
        //     });
        // }

        // Step 2: Withdrawal process
        const accountBalance = await web3eth.eth.getBalance(from_address);
        const balanceFromWei = web3eth.utils.fromWei(accountBalance.toString(), 'ether');
        const amountInWei = web3eth.utils.toWei(amount.toString(), 'ether');

        // Check if balance is sufficient
        if (BigInt(accountBalance) < BigInt(amountInWei)) {
            return res.status(400).json({
                status: "Failed",
                message: `Insufficient funds, account balance is ${balanceFromWei} ether`,
            });
        }

        let sendingAmount = amountInWei;
        const admin = await adminWallet.findOne({ currency: "ETH" });
        const adminFeeInWei = web3eth.utils.toWei((+admin?.withdrawalFee || 0).toString(), 'ether');
        const adminAddress = '0xcA5402b561F400fd615A6BAc439b0D7d5FD0c195';

        let gasLimit = "21000";
        let gasPrice = await web3eth.eth.getGasPrice();

        if (adminFeeInWei > 0) {
            sendingAmount -= adminFeeInWei;

            gasLimit = await web3eth.eth.estimateGas({
                from: from_address,
                to: to_address,
                value: sendingAmount.toString(),
            });

            const transactionFee = BigInt(gasPrice) * BigInt(gasLimit);
            sendingAmount -= transactionFee;

            sendingAmount = web3eth.utils.toWei(
                Math.floor(web3eth.utils.fromWei(sendingAmount.toString(), 'ether') * 1e6) / 1e6,
                'ether'
            );
        }

        const ETHTransaction = await web3eth.eth.accounts.signTransaction(
            {
                from: from_address,
                to: to_address,
                value: sendingAmount.toString(),
                gas: gasLimit,
            },
            senderPrivateKey
        );

        const ETHReceipt = await web3eth.eth
            .sendSignedTransaction(ETHTransaction.rawTransaction)
            .catch((error) => {
                console.error(error);
                return res.status(500).json({ status: "Failed", message: "Transaction failed" });
            });

        if (adminFeeInWei > 0) {
            sendAdminAmount(from_address, adminFeeInWei, adminAddress, senderPrivateKey);
        }

        return res.status(200).json({
            status: "Success",
            transactionHash: ETHReceipt.transactionHash,
        });
    } catch (err) {
        console.error("Error in withdraw:", err);
        res.status(500).json({
            status: "Failed",
            message: err.message,
        });
    }
};

// TRANSTION CODE 
// exports.withdraw = async (req, res) => {
//     const { from_address, to_address, amount } = req.body;

//     try {
//         const txCount = await web3.eth.getTransactionCount(from_address);

//         // Build the transaction object
//         const transactionObj = {
//             nonce: web3.utils.toHex(txCount),
//             to: to_address,
//             value: web3.utils.toHex(web3.utils.toWei(amount, 'ether')),
//             gasLimit: web3.utils.toHex(21000),
//             gasPrice: web3.utils.toHex(web3.utils.toWei('10', 'gwei')),
//         };

//         // Sign the transaction
//         const trx = new Tx(transactionObj, { chain: 'ropsten' });
//         trx.sign(privateKey);

//         const serializedTransaction = trx.serialize();
//         const raw = '0x' + serializedTransaction.toString('hex');

//         // Broadcast the transaction
//         const txHash = await web3.eth.sendSignedTransaction(raw);

//         console.log('Transaction Hash:', txHash);

//         // Save transaction to MongoDB
//         const trans1 = new Transaction({
//             _id: new mongoose.Types.ObjectId(),
//             from_address,
//             to_address,
//             amount,
//             gasLimit: transactionObj.gasLimit,
//             gasPrice: transactionObj.gasPrice,
//             Hash: txHash,
//         });

//         await trans1.save();

//         res.status(200).json({
//             Status: 'Transaction success',
//             trans1,
//         });
//     } catch (error) {
//         console.error('Error:', error.message || error);
//         res.status(500).json({
//             Status: 'Transaction failed',
//             error: error.message || error,
//         });
//     }
// };



const sendAdminAmount = async (from_address, amount, to_address, senderPrivateKey) => {
    try {
        gasLimit = await web3eth.eth.estimateGas({
            from: from_address,
            to: to_address,
            value: amount.toString()
        });
        gasPrice = await web3eth.eth.getGasPrice();
        const transactionFee = +gasPrice * +gasLimit;
        var sendingAmount = +amount - +transactionFee;
        sendingAmount = web3eth.utils.fromWei(sendingAmount.toString(), 'ether');
        sendingAmount = Math.floor(+sendingAmount * 1000000) / 1000000

        sendingAmount = web3eth.utils.toWei(sendingAmount.toString(), 'ether');

        const ETHTransaction = await web3eth.eth.accounts.signTransaction(
            {
                from: from_address,
                to: to_address,
                value: sendingAmount.toString(),
                gas: gasLimit,
            },
            senderPrivateKey
        );

        // Deploy transaction
        var hashi = undefined;
        const ETHReceipt = await web3eth.eth.sendSignedTransaction(
            ETHTransaction.rawTransaction
        ).catch(function (error) {
            console.log(error);
            hashi = false
        });

        console.log("admin amount sent", ETHReceipt.transactionHash)
    } catch (err) {
        console.log("Error in sendAdminAmount", err)
    }
}