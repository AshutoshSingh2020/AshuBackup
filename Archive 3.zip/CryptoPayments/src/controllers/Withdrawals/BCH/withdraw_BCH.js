const adminWallet = require("../../../models/adminWallet");
const rp = require('request-promise');
var mongoose = require("mongoose")
    // Acc_Balance = mongoose.model('Acc_Balance')

const USER = process.env.BCH_RPC_USER;
const PASS = process.env.BCH_RPC_PASSWORD;

const bitcoinPort = process.env.bitcoinCash_tunnel_port

exports.withdraw_BCH = async (req, res, currency, amount, from_address, to_address) => {
    try {
        // Your logic for the withdraw operation should go here
        // For now, it seems you want to return a message to create an admin wallet

        // Simulate a response object if you have one
        const response = {}; // Replace with actual response data

        return res.status(200).json({
            statuscode: 200,
            status: "Please create an admin wallet",
            message: response,
            data: {}
        });

    } catch (error) {
        console.log("Error in withdraw: ", error);
        return res.status(500).json({
            statuscode: 500,
            status: "Error",
            message: "An error occurred during the withdrawal process",
            error: error.message
        });
    }
};



// exports.withdraw = async (req, res, currency, amount, from_address, senderPrivateKey, full_amount, to_address, email) => {
//     try {
//         const account_acc = await Acc_Balance.findOne({ email: email });
//         var walletName = JSON.parse(account_acc.wallet);
//         walletName = walletName.result.name;

//         var account_balance = await balance_BCH(walletName);
//         console.log("account_balance:", account_balance);
//         account_balance = JSON.parse(account_balance);
//         account_balance = account_balance.result;

//         if (account_balance < amount) {
//             return res.status(404).json({
//                 statuscode: 404,
//                 status: "Failed",
//                 message: `Insuffiecient funds, account balance is ${account_balance}`,
//                 data: {}
//             });
//         }

//         var sendingAmount = amount;

//         const admin = await adminWallet.findOne({ currency: "BCH" });
//         var adminfee = +admin.withdrawalFee
//         var adminaddress = admin.walletAddress;

//         const fee = await BCHEstimateGas();

//         var sendall = false;
//         if (adminfee > 0) {
//             sendingAmount = +sendingAmount - +adminfee;
//             sendingAmount = +sendingAmount - +fee;
//         } else {
//             if (full_amount == 1) {
//                 sendall = true;
//                 sendingAmount = +account_balance;
//             }
//         }

//         const SendTX = await send_BCH(to_address, sendingAmount, walletName, sendall);
//         var transactionHash = JSON.parse(SendTX);

//         if (transactionHash.error) {
//             var response = `${transactionHash.error.message}`;
//             if (response == `Insufficient funds`) {
//                 response = `Insuffiecient funds, transaction fee`;
//             }
//             return res.status(404).json({
//                 statuscode: 404,
//                 status: "Failed",
//                 message: response,
//                 data: {}
//             });
//         }

//         if (adminfee > 0) {
//             adminfee = +adminfee - +fee;
//             const sendAdminAmount = await send_BCH(adminaddress, adminfee, walletName, false);
//         }

//         transactionHash = transactionHash.result;

//         return transactionHash;


//     } catch (error) {
//         console.log(error, "Error in withdraw  ", error)
//     }
// }

// const send_BCH = async function (to, amount, wallet, sendall) {
//     try {
//         var auth = "Basic " + new Buffer.from(USER + ":" + PASS).toString("base64");
//         var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"sendtoaddress","params":["${to}","${amount}", "", "", ${sendall}]}`;
//         var options = {
//             url: `http://127.0.0.1:${bitcoinPort}/wallet/${wallet}`,
//             method: "POST",
//             headers: {
//                 "Authorization": auth
//             },
//             body: dataString
//         };
//         const a = await rp(options).then((data) => {
//             return data
//         }).catch((err) => {
//             return err.error
//         })

//         return a;
//     } catch (err) {
//         console.log("Error in send_BCH_swap:", err)
//     }

// }

// const balance_BCH = async function (wallet) {
//     try {
//         var auth = "Basic " + new Buffer.from(USER + ":" + PASS).toString("base64");
//         var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"getbalance","params":[]}`;
//         var options = {
//             url: `http://127.0.0.1:${bitcoinPort}/wallet/${wallet}`,
//             method: "POST",
//             headers: {
//                 "Authorization": auth
//             },
//             body: dataString
//         };
//         const a = await rp(options).then((data) => {
//             return data
//         }).catch((err) => {
//             return err.error
//         })

//         return a;
//     } catch (err) {
//         console.log("Error in send_BCH_swap:", err)
//     }
// }

// const BCHEstimateGas = async () => {
//     try {
//         var auth = "Basic " + new Buffer.from(USER + ":" + PASS).toString("base64");
//         var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"estimatefee","params":[]}`;
//         var options = {
//             url: `http://127.0.0.1:${bitcoinPort}`,
//             method: "POST",
//             headers: {
//                 "Authorization": auth
//             },
//             body: dataString
//         };
//         var a = rp(options).then((data) => {
//             var obj = JSON.parse(data);
//             var feerate = obj.result;
//             return feerate;
//         }).catch((err) => {
//             console.log(err.error)
//         })

//         a = await a
//         return a;

//     } catch (err) {
//         console.log("Error in BCHEstimateGas: ", err)
//     }
// }
