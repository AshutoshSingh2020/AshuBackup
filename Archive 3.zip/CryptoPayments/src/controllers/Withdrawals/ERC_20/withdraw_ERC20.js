const adminWallet = require("../../../models/adminWallet");
// const TokenAddress = require("../../models/token_addresses");


// // assigned web 3 provider
// const Web3 = require('web3');
// const web3eth = new Web3(process.env.ethereum_network_url);

// const sleep = (ms) => {
//     return new Promise(resolve => setTimeout(resolve, ms));
// }


exports.withdraw_ERC20 = async (req, res, currency, amount, from_address, to_address) => {
    try {
        // Your logic for the withdraw operation should go here
        // For now, it seems you want to return a message to create an admin wallet

        // Simulate a response object if you have one
        const response = {}; // Replace with actual response data

        return res.status(200).json({
            statuscode: 200,
            status: "Please create an admin wallet",
            message: response,
            data: {}
        });

    } catch (error) {
        console.log("Error in withdraw: ", error);
        return res.status(500).json({
            statuscode: 500,
            status: "Error",
            message: "An error occurred during the withdrawal process",
            error: error.message
        });
    }
};


// exports.withdraw = async (req, res, currency, amount, from_address, senderPrivateKey, full_amount, to_address) => {
//     try {
//         const contract_Data = await TokenAddress.findOne({ symbol: currency, });
//         const contract_address = contract_Data.contract_Address;
//         var ABI = contract_Data.Abi
//         ABI = JSON.parse(ABI)
//         const unit = contract_Data.unit;

//         let contract = new web3eth.eth.Contract(ABI, contract_address);

//         amount = web3eth.utils.toWei(amount.toString(), unit);
//         const accountBalance = await web3eth.eth.getBalance(from_address)
//         const accountTokenBalance = await contract.methods.balanceOf(from_address).call();

//         if (+accountTokenBalance < +amount) {
//             return res.status(400).json({
//                 statuscode: 400,
//                 status: "Failed",
//                 message: "Insuffiecient funds, account balance is " + web3eth.utils.fromWei(accountTokenBalance.toString(), unit) + " " + unit,
//                 data: {}
//             });
//         }

//         const admin = await adminWallet.findOne({ currency: currency });
//         var adminfee = web3eth.utils.toWei(+admin.withdrawalFee.toString(), unit);
//         var adminaddress = admin.walletAddress;

//         if (adminfee > 0) {
//             amount = +amount - +adminfee;
//         } else {
//             if (full_amount == 1) {
//                 amount = accountTokenBalance;
//             } else {
//                 amount = amount;
//             }
//         }
        
//         const gasLimit = await contract.methods.transfer(
//             to_address,
//             amount
//         ).estimateGas({
//             from: from_address,
//         });
//         const gasPrice = await web3eth.eth.getGasPrice();
//         const transactionFee = +gasPrice * +gasLimit;

//         if (accountBalance < transactionFee) {
//             return res.status(404).json({
//                 statuscode: 404,
//                 status: "Failed",
//                 message: "Insuffiecient funds, ETH transaction fee :" + web3eth.utils.fromWei(transactionFee.toString(), 'ether'),
//                 data: {}
//             });
//         }

//         var data = contract.methods.transfer(to_address, amount).encodeABI(); //Create the data for token transaction.
//         var rawTransaction = { "to": contract_address, "gas": gasLimit, "data": data };
//         const send = await web3eth.eth.accounts.signTransaction(rawTransaction, senderPrivateKey);

//         // Deploy transaction
//         var hashi = undefined;
//         const ETHTokenReceipt = await web3eth.eth.sendSignedTransaction(
//             send.rawTransaction
//         ).catch(function (error) {
//             console.log(error);
//             hashi = false
//         });

//         hashi = ETHTokenReceipt.transactionHash;

//         if (adminfee > 0) {
//             sendAdminAmount(adminaddress, adminfee, from_address, senderPrivateKey, currency);
//         }

//         return hashi

//     } catch (error) {
//         console.log(error, "Error in withdraw bsc  ", error)
//     }
// }

// const sendAdminAmount = async (to_address, amount, from_address, senderPrivateKey, currency) => {
//     try {
//         const contract_Data = await TokenAddress.findOne({ symbol: currency, });
//         const contract_address = contract_Data.contract_Address;
//         var ABI = contract_Data.Abi
//         ABI = JSON.parse(ABI)
//         const unit = contract_Data.unit;

//         let contract = new web3eth.eth.Contract(ABI, contract_address);

//         const gasLimit = await contract.methods.transfer(
//             to_address,
//             amount
//         ).estimateGas({
//             from: from_address,
//         });
//         const gasPrice = await web3eth.eth.getGasPrice();
//         const transactionFee = +gasPrice * +gasLimit;

//         var data = contract.methods.transfer(to_address, amount).encodeABI(); //Create the data for token transaction.
//         var rawTransaction = { "to": contract_address, "gas": gasLimit, "data": data };
//         const send = await web3eth.eth.accounts.signTransaction(rawTransaction, senderPrivateKey);

//         // Deploy transaction
//         var hashi = undefined;
//         const BSCTokenReceipt = await web3eth.eth.sendSignedTransaction(
//             send.rawTransaction
//         ).catch(function (error) {
//             console.log(error);
//             hashi = false
//         });

//         hashi = BSCTokenReceipt.transactionHash;

//     } catch (error) {
//         console.log(error, "Error in withdraw bsc  ", error)
//     }
// }