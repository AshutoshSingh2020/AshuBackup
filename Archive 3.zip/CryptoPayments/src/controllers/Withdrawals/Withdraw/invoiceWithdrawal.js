const WithdrawModel = require('../../../models/Transactions/withdrawTranHistory');

exports.getWithdrawInvoice = async (req, res) => {
    const { payment_id } = req.body;

    try {
        if (!payment_id) {
            return res.status(400).json({ 
                status: "Failed", 
                message: "Payment ID is required." 
            });
        }

        // Use the model's findById method
        const Invoice = await WithdrawModel.findById(payment_id);

        if (!Invoice) {
            return res.status(404).json({
                status: "Failed",
                message: "No invoice found for the given payment ID.",
            });
        }

        console.log('Invoice: ', Invoice);

        // Send success response
        res.status(200).json({
            status: "Success",
            data: Invoice,
        });

    } catch (err) {
        console.error("Error in InvoiceWithdraw:", err);
        res.status(500).json({
            status: "Failed",
            message: err.message,
        });
    }
};
