const { TronWeb } = require("tronweb");
const adminWallet = require("../../../models/adminWallet"); // Import admin wallet model
const ip = require("ip");

const tronWeb = new TronWeb({
    fullHost: 'https://api.trongrid.io',
    headers: { 'TRON-PRO-API-KEY': process.env.TRON_API_KEY },
});

exports.withdraw_TRC20 = async (req, res) => {
    const { currency, amount, from_address, full_amount, to_address } = req.body;

    try {
        // Fetch the wallet data for the provided from_address
        const wallet = await adminWallet.findOne({ walletAddress: from_address });

        if (!wallet) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Sender wallet not found",
                data: {}
            });
        }

        // Ensure private key exists for the specified currency
        const senderPrivateKey = wallet.currency[0]?.privateKey;
        if (!senderPrivateKey) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Private key for the specified wallet and currency not found",
                data: {}
            });
        }

        // const contractAddress = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"
        

        // var balance = tronWeb.fromSun((await tronWeb.trx.getBalance(contractAddress)));
        // balance = Number(balance);
     
        // Validate contract address
        // const contractAddress = currency.contractAddress; // Use actual TRC20 contract address
        // if (!tronWeb.isAddress(contractAddress)) {
        //     return res.status(400).json({
        //         statuscode: 400,
        //         status: "Failed",
        //         message: "Invalid contract address",
        //         data: {}
        //     });
        // }
        var contractAddress = "TERimdWJAHSFvkm5YyxpW37vieyHaNLMz9";
        const contract = await tronWeb.contract().at(contractAddress);
        const balanceInSun = await contract.methods.balanceOf(from_address).call();
        console.log("dtaaaaaaaaaaa", balanceInSun);
        balance = parseInt(balance);
        balance = balance / 1000000;
       
        // Fetch balance and decimals        
     


        const decimals = await contract.methods.decimals().call();
        const accountBalance = tronWeb.toDecimal(balanceInSun) / Math.pow(10, decimals);

        console.log('Token balance:', accountBalance, 'Decimals:', decimals);

        // Validate transaction amount
        if (parseFloat(accountBalance) < parseFloat(amount)) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: `Insufficient funds. Current balance: ${accountBalance}`,
                data: { currentBalance: accountBalance }
            });
        }

        // Convert amount to Sun
        const amountInSun = Math.floor(parseFloat(amount) * Math.pow(10, decimals));

        // Validate recipient address
        if (!tronWeb.isAddress(to_address)) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Invalid recipient address",
                data: {}
            });
        }

        // Prepare transaction options
        const transactionOptions = {
            feeLimit: 30000000, // Adjust fee limit
            callValue: 0, // TRC20 tokens do not use TRX call value
            from: from_address,
            privateKey: senderPrivateKey
        };

        console.log('Transaction options:', transactionOptions);
        console.log('Sending to address:', to_address, 'Amount in Sun:', amountInSun);

        // Execute transfer
        const transaction = await contract.methods.transfer(to_address, amountInSun).send(transactionOptions);
        const transactionReceipt = await tronWeb.trx.getTransactionInfo(transaction);

        // Verify transaction status
        const transactionStatus = await tronWeb.trx.getTransaction(transaction);
        if (!transactionStatus || !transactionStatus.ret || transactionStatus.ret[0].contractRet !== 'SUCCESS') {
            throw new Error('Transaction failed or not confirmed');
        }

        const txid = transaction || transactionReceipt.id;

        console.log('USDT Transaction Details:', {
            from: from_address,
            to: to_address,
            amount,
            txid,
            transactionReceipt
        });

        // Return success response
        return res.status(200).json({
            statuscode: 200,
            status: "Success",
            message: "USDT transaction completed successfully",
            data: {
                amount,
                from_address,
                to_address,
                txid,
                transactionHash: `https://tronscan.org/#/transaction/${txid}`
            }
        });

    } catch (error) {
        console.error("Transaction Confirmation Error:", {
            message: error.message,
            stack: error.stack
        });

        return res.status(500).json({
            statuscode: 500,
            status: "Failed",
            message: "Transaction confirmation failed",
            data: {
                originalError: error.message
            }
        });
    }
};
