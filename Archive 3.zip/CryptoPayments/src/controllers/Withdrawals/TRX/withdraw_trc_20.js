const { TronWeb } = require("tronweb");
const adminWallet = require("../../../models/adminWallet"); // Import admin wallet model
const ip = require("ip");

const tronWeb = new TronWeb({
    fullHost: 'https://api.trongrid.io',
    headers: { 'TRON-PRO-API-KEY': process.env.TRON_API_KEY },
});

exports.withdraw_TRC20 = async (req, res) => {
    const { amount, from_address, to_address } = req.body;

    try {
        // Input validation
        if (!from_address || !to_address || !amount) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Missing required transaction parameters",
                data: {}
            });
        }

        // Fetch the wallet data for the provided from_address
        const wallet = await adminWallet.findOne({ walletAddress: from_address });
        if (!wallet) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Sender wallet not found",
                data: {}
            });
        }

        // Extract private key
        const senderPrivateKey = wallet.currency[0].privateKey;
        if (!senderPrivateKey) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Private key for the specified wallet not found",
                data: {}
            });
        }

        // USDT Contract Address (Tron Mainnet)
        const USDT_CONTRACT_ADDRESS = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';

        tronWeb.setAddress('TGHUwGNCUq91Fb3tnZu6cy4dH69TJMUyoU')
        tronWeb.setPrivateKey(senderPrivateKey);


        // Create contract instance
        const contract = await tronWeb.contract().at(USDT_CONTRACT_ADDRESS);
        // Fetch and validate balance
        const balanceInSun = await contract.methods.balanceOf(from_address).call();
        console.log('token balance: ', balanceInSun);
        const decimals = await contract.methods.decimals().call();
        console.log('decimal: ', decimals);
        const accountBalance = tronWeb.fromSun(balanceInSun);

        // Validate transaction amount
        if (parseFloat(accountBalance) < parseFloat(amount)) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: `Insufficient funds. Current balance: ${accountBalance} USDT`,
                data: { currentBalance: accountBalance }
            });
        }

        // Additional transaction checks
        const amountInSun = tronWeb.toSun(amount);

        // Validate recipient address
        if (!tronWeb.isAddress(to_address)) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Invalid recipient address",
                data: {}
            });
        }

        // Prepare transaction parameters
        const transactionOptions = {
            feeLimit: 30000000, // Increased fee limit for more robust transaction
            from: from_address,
            privateKey: senderPrivateKey
        };

        console.log('transaction options: ', transactionOptions);

        console.log('to_address:  ', to_address, 'amountInSun:  ', amountInSun, 'transactionOptions: ', transactionOptions)
        // Send the transaction
        // Send the transaction
        const transaction = await contract.methods.transfer(to_address, amountInSun).send(transactionOptions);

        // Wait for transaction receipt
        const transactionReceipt = await tronWeb.trx.getTransactionInfo(transaction);

        // Additional confirmation check
        const txid = transaction || transactionReceipt.id;

        // Log transaction details for audit
        console.log('USDT Transaction Details:', {
            from: from_address,
            to: to_address,
            amount: amount,
            txid: txid,
            transactionReceipt: transactionReceipt
        });

        // Verify transaction status
        const transactionStatus = await tronWeb.trx.getTransaction(txid);

        if (!transactionStatus || !transactionStatus.ret || transactionStatus.ret[0].contractRet !== 'SUCCESS') {
            throw new Error('Transaction failed or not confirmed');
        }

        // Return successful response
        return res.status(200).json({
            statuscode: 200,
            status: "Success",
            message: "USDT transaction completed successfully",
            data: {
                amount,
                from_address,
                to_address,
                txid: txid,
                transactionHash: `https://tronscan.org/#/transaction/${txid}`
            }
        });


    } catch (error) {
        console.error("Transaction Confirmation Error:", {
            message: error.message,
            stack: error.stack
        });

        return res.status(500).json({
            statuscode: 500,
            status: "Failed",
            message: "Transaction confirmation failed",
            data: {
                originalError: error.message
            }
        });
    };
}


