const { TronWeb } = require("tronweb");  
const adminWallet = require("../../../models/adminWallet");
const WithdrawSchema = require("../../../models/Transactions/withdrawTranHistory");// Import TronWeb correctly
const ip = require("ip");
const mongoose = require('mongoose');

// const TronWeb = require('tronweb');
// const HttpProvider = TronWeb.providers.HttpProvider;
// const fullNode = new HttpProvider(process.env.tron_first_url);
// const solidityNode = new HttpProvider(process.env.tron_second_url);
// const eventServer = new HttpProvider(process.env.tron_third_url);

const tronWeb = new TronWeb({
    fullHost: 'https://api.trongrid.io',
    headers: { 'TRON-PRO-API-KEY': process.env.TRON_API_KEY },
});

exports.withdraw_TRX = async (req, res) => {
    let { currency, amount, from_address, full_amount, to_address } = req.body;

    try {
        // Fetch the wallet data for the provided from_address
        const wallet = await adminWallet.findOne({ walletAddress: from_address });
        // console.log('wallet: ', wallet);

        if (!wallet) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Sender wallet not found",
                data: {}
            });
        }

        const senderPrivateKey = wallet.currency[0].privateKey;


        
        if (!senderPrivateKey) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Private key for the specified wallet and currency not found",
                data: {}
            });
        }

        // Check account balance
        const accountBalance = tronWeb.fromSun(await tronWeb.trx.getBalance(from_address));

        console.log('accountbalance: ', accountBalance);

        if (+accountBalance < +amount) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: `Insufficient funds, account balance is ${accountBalance} TRX`,
                data: {}
            });
        }

        // Check bandwidth and calculate fees
        const bandwidth = await tronWeb.trx.getBandwidth(from_address);
        const accountInfo = await tronWeb.trx.getAccount(to_address);
        const newAddFee = accountInfo.balance ? 0 : 1.1;

        if (full_amount === 1) {
            if (+bandwidth < 270) {
                amount = +accountBalance - 1;
            } else {
                amount = +accountBalance;
            }
            amount = Number(+amount - +newAddFee).toFixed(6);
            amount = tronWeb.toSun(amount);
        } else {
            if (+accountBalance < (+amount + newAddFee)) {
                return res.status(400).json({
                    statuscode: 400,
                    status: "Failed",
                    message: `Insufficient funds, account balance is ${accountBalance} TRX & new address fee ${newAddFee} TRX`,
                    data: {}
                });
            }

            if (+bandwidth < 270 && +accountBalance < (+amount + newAddFee + 1)) {
                return res.status(400).json({
                    statuscode: 400,
                    status: "Failed",
                    message: `Insufficient funds, less bandwidth left fee 1 TRX`,
                    data: {}
                });
            }
            amount = tronWeb.toSun(amount);
        }

        // Perform the transaction
        const tronTx = await tronWeb.trx.sendTransaction(to_address, amount, senderPrivateKey);
     
        // Save transaction history to the WithdrawSchema table
        const withdrawRecord = new WithdrawSchema({
            currency,
            amount: tronWeb.fromSun(amount),
            from_address,
            to_address,
            txId: tronTx.txid,
            transactionHash: `https://tronscan.org/#/transaction/${tronTx.txid}`,
            createdAt: new Date(),
            updatedAt: new Date(),
        });
// console.log("data",withdrawRecord._id);

        await withdrawRecord.save();

        // Send a success response
        return res.status(200).json({
            statuscode: 200,
            status: "Success",
            message: "Transaction successful",
            data: {
                paymentId: withdrawRecord._id,
                amount: tronWeb.fromSun(amount),
                from_address,
                to_address,
                txid: tronTx.txid,
                transactionHash: `https://tronscan.org/#/transaction/${tronTx.txid}`,
            },
        });

    } catch (error) {
        console.error("Error Details:", error.response?.data || error.message || error);
        return res.status(400).json({
            statuscode: 400,
            status: "Failed",
            message: error.response?.data?.message || error.message || "Unknown error",
            data: {}
        });
    }
};

