const axios = require('axios');
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const Invoice = require('../../models/Invoices/invoiceModel');

const app = express();

// Middleware to parse JSON payload
app.use(bodyParser.json());

// Replace this secret with the one provided by your payment processor
const WEBHOOK_SECRET = 'ycdgbhshcisjdnxmsjicydwdmi';

const EXTERNAL_API_URL = 'https://payuatapi.paytoononline.com/api/Common/WebhookUpdateCryptoApprovalDeposit';

const webhook = async (req, res) => {
    try {
        const signature = req.headers['x-webhook-signature'] || req.headers['X-Webhook-Signature'];
        const payload = JSON.stringify(req.body);

        // Validate the webhook signature
        const expectedSignature = crypto
            .createHmac('sha256', WEBHOOK_SECRET)
            .update(payload)
            .digest('hex');
// console.log(expectedSignature);

        if (signature !== expectedSignature) {
            return res.status(400).json({ message: 'Invalid signature' });
        }

        // Extract and validate payment ID
        const { _id } = req.body;
        if (!mongoose.Types.ObjectId.isValid(_id)) {
            return res.status(400).json({ message: 'Invalid or missing Payment ID' });
        }

        // Query the Invoice model
        const invoice = await Invoice.findById(_id);
        if (!invoice) {
            return res.status(404).json({ message: 'Payment ID not found in Invoice model' });
        }

        let externalResponse;

        if (invoice.cold_trans_done) {
            // Construct success response with all possible fields
            const successResponse = {
                message: 'Payment received successfully',
                payment_id: invoice._id.toString(),
                amount: invoice.amount,
                paidAmount: invoice.paidAmount,
                currency: invoice.currency,
                status: 'Done',
                txnId: invoice.txnId || null,
                email: invoice.email,
                userId: invoice.userId,
                rate: invoice.rate,
                timestamp: invoice.timestamp,
            };

            // Log the payload being sent
           // console.log('Payload sent to external API (success):', successResponse);

            // Send success response to external API
            externalResponse = await axios.post(EXTERNAL_API_URL, successResponse, {
                headers: {
                    'Content-Type': 'application/json',
                },
            });
        } else {
            // Construct error response
            const errorResponse = {
                Result: 'Failed',
                ErrorMessage: 'Payment not done',
                ErrorCode: '2',
                Id: invoice._id.toString(),
            };

            // Log the payload being sent
         //   console.log('Payload sent to external API (error):', errorResponse);

            // Send error response to external API
            externalResponse = await axios.post(EXTERNAL_API_URL, errorResponse, {
                headers: {
                    'Content-Type': 'application/json',
                },
            });
        }

        // Log and return the external API response
        console.log('External API response:', externalResponse.data);
        return res.status(200).json(externalResponse.data);

    } catch (error) {
        console.error('Error processing webhook:', error.message);
        return res.status(500).json({ message: 'Internal server error' });
    }
};

module.exports = { webhook };
