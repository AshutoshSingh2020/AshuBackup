const Invoice = require("../../models/Invoices/invoiceModel");
const cron = require("node-cron");
// const { invoiceCronETH } = require("./eth");
const { invoiceCronTRX } = require("./Tron/TRX/TRX");
// const { invoiceCronBTC } = require("./btc");
// const { invoiceCronTRC20 } = require("./trc_20");

const invoiceCron = async () => {

    try {
        var expireTime = Date.now() - 28800000;

        const invoices = await Invoice.find({ status: "pending", timestamp: { $gt: expireTime } });

        for (invoiceUser of invoices) {
            switch (invoiceUser.currency) {
                // case "ETH":
                //     invoiceCronETH(invoiceUser);
                //     break;
               
                case "TRX":
                    invoiceCronTRX(invoiceUser);
                    break;
                // case "BTC":
                //     invoiceCronBTC(invoiceUser);
                //     break;
              
                // case "USDT_TRC20":
                //     invoiceCronTRC20(invoiceUser);
                //     break;
                default:
                    console.log("Invalid currency");
                    break;
            }
        }
    } catch (err) {
        console.log("invoiceCron error:", err);
    }
}

cron.schedule(' */10 * * * * *', async () => {
    try {
        console.log("RUNNING DIRECT INVOICE CRON");
        await invoiceCron();
    } catch (err) {
        console.log('invoiceCron error', err);
    }
});