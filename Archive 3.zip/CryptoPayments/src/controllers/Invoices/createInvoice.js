const { createInvoiceTRX } = require("./Tron/TRX/TRX");
const { createInvoiceETH } = require("./Ethereum/ETH/eth");
// const { createInvoiceBSC } = require("./bsc");
 const { createInvoiceTRC20 } = require("./Tron/USDT/TRC20_USDT");
 const { createInvoiceBTC } = require('./Bitcoin/btc');
// const { createInvoiceDOGE } = require('./doge');
// const { createInvoiceLTC } = require('./ltc');
 const { createInvoiceBCH } = require('./BitcoinCash/BCH');
 const { createInvoiceERC20 } = require('./Ethereum/USDT/ERC20_USDT');
const userModel = require("../../models/userModel");
// const { createInvoiceBEP20 } = require('./bep20');
// const { createInvoiceXRP } = require('./xrp');
// const { createInvoiceMATIC } = require('./matic');
// const { createInvoiceADA } = require('./ada');
// const { createInvoiceSOL } = require('./sol');
// const { createInvoiceSTX } = require('./stx');

const createInvoice = async (req, res) => {
  try {
    const { clientId, email, currency, amount, publicKey } = req.body;

    if (!clientId || !currency || !amount || !email) {
      return res.status(400).send({
        code: "400",
        status: "Fail",
        message: "Fill required details missing",
        data: [],
      });
    }

    const user = await userModel.findOne({ userId: clientId });
    if (!user) {
      return res.status(404).send({
        code: "404",
        status: "Not Found",
        message: "User not found",
        data: [],
      });
    }
    

    let invoiceResult;

    switch (currency) {
      case "ETH":
        invoiceResult = await createInvoiceETH(req, res);
        break;
      case "TRX":
          invoiceResult =  await createInvoiceTRX(req, res);
            break;
      case "BTC":
        invoiceResult = await createInvoiceBTC(req, res);
          break;
      case "USDT_ERC20":
        invoiceResult =  await createInvoiceERC20(req, res);
          break;
      case "BCH":
        invoiceResult =  await createInvoiceBCH(req, res);
            break;
      case "USDT_TRC20":
        invoiceResult =  await createInvoiceTRC20(req, res);
            break;
    
      default:
        return res.status(400).send({
          code: "400",
          status: "Not Found",
          message: "Invalid Currency",
          data: {},
        });
    }

    if (invoiceResult && !user.coins.some(coin => coin.currency === currency)) {
      user.coins.push({ currency, address: invoiceResult.address });
      await user.save();
    }

    // return res.status(200).send({
    //   code: "200",
    //   status: "Success",
    //   message: "Invoice created successfully",
    //   data: invoiceResult,
    // });
  } catch (error) {
    console.error("Error creating invoice:", error);
    return res.status(500).json({
      code: 500,
      status: "Error",
      message: error.message,
      data: {},
    });
  }
};




module.exports = {
  createInvoice,
};
