// var mongoose = require("mongoose");
// const Invoice = require("../../models/invoiceDataModel");
// const Api = require("../../models/apiModel");
// const Acc_Balance = require("../../models/dashboard_balance");
// const InvoiceTransaction = require("../../models/Invoice_transactionModel");
// const AdminWallet = require("../../models/adminWalletModel");
// const users = require("../../models/user.model");
// const { transactionEmail } = require("./../../../utils/transactionEmail");
// const Transaction_History = mongoose.model("Transaction_History");
// const TokenAddress = require("../../models/token_addresses");
// const coinrate = require("../../models/coin_rate");
// const Refund = require("../../models/confirmRefundModel");
// const { refundTransactionMail } = require("../../../utils/refundTransactionMail");
// const crypto = require("crypto");
// const TronWeb = require("tronweb");
// var ip = require("ip");
// const MerchantFees = require("../../models/merchantFees");

// const HttpProvider = TronWeb.providers.HttpProvider;
// const fullNode = new HttpProvider(process.env.tron_first_url);
// const solidityNode = new HttpProvider(process.env.tron_second_url);
// const eventServer = new HttpProvider(process.env.tron_third_url);
// const trxPrivateKey = process.env.trx_transaction_to_address_privKey;
// const tronWeb = new TronWeb(fullNode, solidityNode, eventServer, trxPrivateKey);

// const staticUrl = "https://app.coinuniverze.com";


const mongoose = require("mongoose");
const Invoice = require("../../../../models/Invoices/invoiceModel");
const users = require('../../../../models/userModel');
const userModel = require('../../../../models/userModel');
const Coinrate = require("../../../../models/coinrates/usdRate");
const AdminWallet = require("../../../../models/adminWallet");
const InvoiceTransaction = require("../../../../models/Invoices/invoiceTransactionModel");
const crypto = require("crypto");
const {TronWeb} = require("tronweb");  // Import TronWeb correctly
const ip = require("ip");

const cron = require('node-cron');


const tronWeb = new TronWeb({
    fullHost: 'https://api.trongrid.io',
    headers: { 'TRON-PRO-API-KEY': process.env.TRON_API_KEY },
  });

// const tronConfig = {
//     fullNode: process.env.tron_first_url,
//     solidityNode: process.env.tron_second_url,
//     eventServer: process.env.tron_third_url,
//     privateKey: process.env.trx_transaction_to_address_privKey
// };

// // Initialize TronWeb providers
// const HttpProvider = TronWeb.providers.HttpProvider;
// const fullNode = new HttpProvider(tronConfig.fullNode);
// const solidityNode = new HttpProvider(tronConfig.solidityNode);
// const eventServer = new HttpProvider(tronConfig.eventServer);
// const trxPrivateKey = tronConfig.privateKey;

// // Initialize the TronWeb instance
// const tronWebInstance = new TronWeb(fullNode, solidityNode, eventServer, trxPrivateKey);

// // Set the header after initializing TronWeb
// tronWebInstance.setHeader({ "TRON-PRO-API-KEY": process.env.TRON_API_KEY });


// const staticUrl = "https://app.coinuniverze.com";

const decryptePrivateKey = (data) => {
    try {
        var encrypted = Buffer.from(data, 'base64');
        var salt_len = 16, iv_len = 16;

        var salt = encrypted.slice(0, salt_len);

        var iv = encrypted.slice(0 + salt_len, salt_len + iv_len);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 256 / 8, 'sha256');

        var decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);

        decipher.write(encrypted.slice(salt_len + iv_len));
        decipher.end();

        const decrypted = decipher.read();
        return decrypted.toString()
    } catch (err) {
        console.log('decryptedPrivateKey Error: ', err)
    }
};

const encryptedPrivateKeys = async (data) => {
    try {

        var salt = crypto.randomBytes(16);
        var iv = crypto.randomBytes(16);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 32, 'sha256');
        var cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        cipher.write(data);
        cipher.end()

        var encrypted = cipher.read();

        return Buffer.concat([salt, iv, encrypted]).toString('base64')
    } catch (err) {
        console.log("encryptedPrivateKeys Error:", err)
    }
};

const createTRXAccount = async () => {
    try {
        var newAccount = await tronWeb.createAccount();

        var privateKey = await encryptedPrivateKeys(newAccount.privateKey);
        var newAddress = newAccount.address.base58;

        return { privateKey, newAddress };

    } catch (err) {
        console.log("createTRXAccount error:", err)
    }
}

const getTRC20Balance = async (address, currency, privateKey) => {
    try {
        var contract_Address = await TokenAddress.findOne({ coin_name: "USDT-TRC20" });
        contract_Address = contract_Address.contract_Address;
        //var contract_Address = "TERimdWJAHSFvkm5YyxpW37vieyHaNLMz9";
        var decryptedPrivateKey = await decryptePrivateKey(privateKey);
        const tronUSDT = new TronWeb(fullNode, solidityNode, eventServer, decryptedPrivateKey);
        const contractI = await tronWeb.contract().at(contract_Address);
        var balance = await contractI.methods.balanceOf(address).call();
        balance = parseInt(balance);
        balance = balance / 1000000;
        return balance;
    } catch (err) {
        console.log("getTRC20Balance error: ", err)
    }
}

const createInvoiceTRC20 = async (req, res) => {
    try {
      const { email, cryptoAmount, amount, currency, publicKey, clientId } = req.body;
  
      let usdAmount, paidAmount;
  
      // Find user by clientId
      const user = await userModel.findOne({ userId: clientId });
      if (!user) {
        return res.status(404).send({
          code: "404",
          status: "Not Found",
          message: "User not found",
          data: [],
        });
      }

              // Validate minimum TRX amount if cryptoAmount is true
              const minimumAmount = parseFloat(process.env.TRC20_MINIMUM_AMOUNT || 0);
              if (cryptoAmount && amount < minimumAmount) {
                  return res.status(400).send({
                      code: "400",
                      status: "Fail",
                      message: `TRC20 amount should be greater than ${minimumAmount}`,
                      data: {},
                  });
              }
      
  
      // Check for existing USDT_TRC20 or TRX accounts
      let usdtTrcAccount = user.coins.find(coin => coin.currency === "USDT_TRC20");
      let trxAccount = user.coins.find(coin => coin.currency === "TRX");  
      let accountNumber, privateKey;
  
      if (usdtTrcAccount) {
        // Use the existing USDT_TRC20 address
        accountNumber = usdtTrcAccount.address;
        privateKey = usdtTrcAccount.privateKey;
      } else if (trxAccount) {
        // Use the existing TRX address and assign it to USDT_TRC20
        accountNumber = trxAccount.address;
        privateKey = trxAccount.privateKey;
        // Save this TRX address as a USDT_TRC20 address for future use
        user.coins.push({ currency: "USDT_TRC20", address: accountNumber, privateKey:privateKey });
        await user.save();
      } else {
        // Create new TRX account if no existing accounts are found
        const newAccount = await createTRXAccount();
        if (!newAccount || !newAccount.newAddress || !newAccount.privateKey) {
          throw new Error("Failed to create TRX account");
        }
        accountNumber = newAccount.newAddress;
        privateKey = newAccount.privateKey;
  
        // Save the newly created USDT_TRC20 account to the user's coins
        user.coins.push({ currency: "USDT_TRC20", address: accountNumber, privateKey:privateKey });
        await user.save();
      }
  
      // Fetch the current USDT_TRC20 rate
      const rateData = await Coinrate.findOne({});
      if (!rateData) {
        throw new Error("Rate data not found");
      }
      const rate = rateData.usd_rate.USDT_TRC20;

            //txnid lgic
      txnId = ""
  
      // Calculate amounts based on the cryptoAmount flag
      if (cryptoAmount) {
        usdAmount = (amount * rate).toFixed(6);
        paidAmount = amount.toFixed(6);
      } else {
        usdAmount = amount.toFixed(6);
        paidAmount = (amount / rate).toFixed(6);
      }
  
      // Create a new invoice task
      const newTask = {
        userId: clientId,
        email,
        cryptoAmount,
        amount,
        usdAmount,
        paidAmount,
        currency,
        balance: 0,
        newAccount: { accountNumber, privateKey },
        rate: rate.toFixed(6),
        timestamp: Date.now(),
        timeout: Date.now() + 14400000, // 4-hour timeout
        cold_trans_done: false,
        initialTRX_Tx: false,
        publicKey,
        txnId
      };
  
      // Save the new invoice to the database
      const newInvoice = await Invoice.create(newTask);
      console.log("Invoice created:", newInvoice);
  
      // Calculate the remaining time for the invoice
      const remainingTime = new Date(newTask.timeout - Date.now()).toISOString().substr(11, 8);
  
      // Send a successful response
      res.status(200).send({
        code: "200",
        status: "OK",
        message: "Invoice created successfully",
        data: {
          paymentStatus: "PENDING",
          paymentId: newInvoice._id,
          emailAddress: email,
          name: newInvoice.name || "Unnamed",
          usdAmount,
          totalRemainingAmount: paidAmount,
          currency,
          totalAmount: paidAmount,
          totalReceivedAmount: 0,
          conversionRate: rate.toFixed(6),
          address: accountNumber,
          remainingTime,
          paymentQRCode: accountNumber,
          txnId:txnId,
        },
      });
    } catch (err) {
      console.error("createInvoiceTRC20 error:", err);
      res.status(500).send({
        code: "500",
        status: "Internal Server Error",
        message: err.message || "An error occurred while creating the invoice",
        data: [],
      });
    }
  };
  

  const invoiceStatusTRC20 = async (req, res, invoiceUser, timer) => {
    try {
        var decryptedPrivateKey = await decryptePrivateKey(
            invoiceUser.newAccount.privateKey
        );
        const contract_Address = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';

        const adminWallet = await AdminWallet.findOne({
            "currency.coin": "TRX"
        }).lean();

        tronWeb.setPrivateKey(decryptedPrivateKey);
        const contractI = await tronWeb.contract().at(contract_Address);
        var balance = await contractI.methods.balanceOf(invoiceUser.newAccount.accountNumber).call();
        balance = parseInt(balance) / 1000000;
        console.log('usdt balance: ', balance);

        // Calculate new payment amount if balance increased
        if (balance > invoiceUser.previousBalance) {
            const newPaymentAmount = balance - invoiceUser.previousBalance;
            const updatedPaidAmount = (invoiceUser.paidAmount || 0) + newPaymentAmount;
            
            // Calculate remaining amount needed for full payment
            const requiredAmount = invoiceUser.amount; // total amount needed
            var remainingAmount = Number(requiredAmount - updatedPaidAmount).toFixed(6);
            
            if (balance >= 500) {
                const adminFeePercentage = 0.1; // 0.1% admin fee
                const adminFeeAmount = (balance * adminFeePercentage / 100).toFixed(6);
                
                // Check TRX balance for transaction fees
                var trxBalance = await tronWeb.trx.getBalance(invoiceUser.newAccount.accountNumber);
                trxBalance = tronWeb.fromSun(trxBalance);
                
                // If TRX balance is low, fund from admin wallet
                if (trxBalance < 20) {
                    try {
                        // Get admin wallet TRX balance
                        var adminTrxBalance = await tronWeb.trx.getBalance(adminWallet.accountNumber);
                        adminTrxBalance = tronWeb.fromSun(adminTrxBalance);
                        
                        // Calculate required TRX amount
                        const requiredTrx = 20 - trxBalance;
                        
                        if (adminTrxBalance > requiredTrx) {
                            // Transfer TRX from admin wallet
                            const trxTransfer = await tronWeb.trx.sendTransaction(
                                invoiceUser.newAccount.accountNumber,
                                tronWeb.toSun(requiredTrx),
                                adminWallet.privateKey
                            );
                            console.log('TRX funded from admin wallet:', trxTransfer);
                            
                            // Wait for transaction confirmation
                            await new Promise(resolve => setTimeout(resolve, 3000));
                        } else {
                            console.error('Insufficient TRX in admin wallet for funding');
                            throw new Error('Admin wallet TRX balance too low');
                        }
                    } catch (error) {
                        console.error('Error funding TRX from admin wallet:', error);
                        throw error;
                    }
                }
                
                // Process admin fee transaction
                try {
                    const adminTx = await contractI.methods.transfer(
                        adminWallet.walletAddress,
                        tronWeb.toSun(adminFeeAmount)
                    ).send({
                        feeLimit: 10000000
                    });
                    
                    console.log('Admin fee transaction:', adminTx);
                    
                    // Update invoice with admin transaction
                    await Invoice.findByIdAndUpdate(
                        invoiceUser._id,
                        {
                            $set: {
                                adminTransaction: adminTx,
                                adminFeeAmount: adminFeeAmount
                            }
                        }
                    );
                } catch (error) {
                    console.error('Error processing admin fee:', error);
                    throw error;
                }
            }

            const updateData = {
                balance: balance,
                previousBalance: balance,
                paidAmount: updatedPaidAmount
            };

            // Check if invoice is fully paid
            if (updatedPaidAmount >= invoiceUser.amount) {
                updateData.paymentStatus = 'PAID';
                await Invoice.findByIdAndUpdate(
                    invoiceUser._id,
                    { $set: updateData }
                );

                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "Payment completed successfully",
                    data: {
                        paymentStatus: "PAID",
                        paymentId: invoiceUser._id,
                        emailAddress: invoiceUser.email,
                        totalRemainingAmount: 0,
                        currency: invoiceUser.currency,
                        totalAmount: invoiceUser.amount,
                        totalReceivedAmount: updatedPaidAmount,
                        conversionRate: invoiceUser.rate,
                        address: invoiceUser.newAccount.accountNumber,
                        remainingTime: "00:00:00",
                        paymentQRCode: invoiceUser.newAccount.accountNumber
                    }
                });
            }

            await Invoice.findByIdAndUpdate(
                invoiceUser._id,
                { $set: updateData }
            );
        }

        const currentTimestamp = Date.now();
        const fourHoursInMillis = 4 * 60 * 60 * 1000;
        const timeDifference = currentTimestamp - invoiceUser.timestamp;
        
        let paymentStatus = timeDifference > fourHoursInMillis ? "EXPIRED" : "PENDING";
        let remainingMillis = Math.max(fourHoursInMillis - timeDifference, 0);
        let hours = Math.floor(remainingMillis / (1000 * 60 * 60));
        let minutes = Math.floor((remainingMillis % (1000 * 60 * 60)) / (1000 * 60));
        let seconds = Math.floor((remainingMillis % (1000 * 60)) / 1000);
        
        let remainingTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

        // If payment expired, update status in database
        if (paymentStatus === "EXPIRED") {
            await Invoice.findByIdAndUpdate(
                invoiceUser._id,
                { paymentStatus: "EXPIRED" }
            );
        }

        // Calculate remaining amount based on most recent paid amount
        const remainingAmountToDisplay = Number(invoiceUser.amount - (invoiceUser.paidAmount || 0)).toFixed(6);

        return res.status(200).json({
            code: "200",
            status: "OK",
            message: "Successful",
            data: {
                paymentStatus,
                paymentId: invoiceUser._id,
                emailAddress: invoiceUser.email,
                totalRemainingAmount: remainingAmountToDisplay,
                currency: invoiceUser.currency,
                totalAmount: invoiceUser.amount,
                totalReceivedAmount: invoiceUser.paidAmount || 0,
                conversionRate: invoiceUser.rate,
                address: invoiceUser.newAccount.accountNumber,
                remainingTime,
                paymentQRCode: invoiceUser.newAccount.accountNumber
            }
        });
    } catch (err) {
        console.error("Error in invoiceStatusTRC20:", err);
        return res.status(500).json({
            code: 500,
            status: "ERROR",
            message: "Internal server error"
        });
    }
};

async function getTransactionFee(sender, receiver, usdtAmount) {
    try {
        
        // Validate addresses
        if (!tronWeb.isAddress('TEbvZAPmWcs1UDVh9nXUJQWPoeazNrEY4P') || !tronWeb.isAddress(receiver)) {
            throw new Error('Invalid sender or receiver address');
        }

        console.log('address recivere and sender ', receiver, sender);
        // USDT contract on TRON
        const usdtContract = await tronWeb.contract().at("TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t");
        
        // Convert USDT amount to Sun units (6 decimals for USDT)
        const amount = tronWeb.toSun(10);

        // Create unsigned transaction
        const unsignedTx = await usdtContract.methods.transfer(receiver, amount).send({
            from: 'TEbvZAPmWcs1UDVh9nXUJQWPoeazNrEY4P',
            shouldPollResponse: true  // Wait for confirmation
        });

        // Get transaction details
        const txInfo = await tronWeb.trx.getTransactionInfo(unsignedTx);

        if (txInfo && txInfo.receipt) {
            const energyUsed = txInfo.receipt.energy_usage_total || 0;
            const bandwidthUsed = txInfo.receipt.net_usage || 0;
            const energyFee = txInfo.receipt.energy_fee || 0;
            const bandwidthFee = txInfo.receipt.net_fee || 0;

            return {
                energyUsed,
                bandwidthUsed,
                energyFeeTrx: energyFee / 1e6,
                bandwidthFeeTrx: bandwidthFee / 1e6,
                totalCostTrx: (energyFee + bandwidthFee) / 1e6
            };
        } else {
            throw new Error("Transaction details not found");
        }
    } catch (error) {
        console.error("Error fetching transaction cost:", error);
        throw error;
    }
}

// Example usage:
// const fees = await getTransactionFee(
//     'TPeiAUJ8S6xmZmVZzKuOxHjU7kV299cgKG',  // sender
//     'TEbvZAPmWcs1UDVh9nXUJQWPoeazNrEY4P',  // receiver
//     100  // USDT amount

// );

const startInvoiceCrontrc20 = () => {
    cron.schedule('*/15 * * * *', async () => {
        try {
            console.log('Running invoice cron job...');
            
            // Find all pending invoices that haven't been processed
            const pendingInvoices = await Invoice.find({
                cold_trans_done: false,
                timeout: { $gt: Date.now() } // Only process non-expired invoices
            });

            // Process each pending invoice
            for (const invoice of pendingInvoices) {
                try {
                    await invoiceCronTRC20(invoice);
                } catch (error) {
                    console.error(`Error processing invoice ${invoice._id}:`, error);
                    // Continue with next invoice even if one fails
                }
            }

        } catch (error) {
            console.error('Error in invoice cron job:', error);
        }
    });
};

// const startInvoiceCrontrx = () => {
//     // '*/10 * * * *' means run every 15 minutes
//     cron.schedule(' */10 * * * *', async () => {
//         console.log('Starting invoice processing cron job...');
//         await invoiceCronTRC20();
//         console.log('Completed invoice processing cron job');
//     });
    
//     console.log('Cron job scheduled to run every 15 minutes `');
// }

const invoiceCronTRC20 = async () => {
    try {
        // Change expiry time from 8 hours to 4 hours to match invoiceStatus
        var expireTime = Date.now() - (4 * 60 * 60 * 1000); // 4 hours in milliseconds

        // Fetch pending invoices
        const invoices = await Invoice.find({ 
            paymentStatus: "PENDING", 
            timestamp: { $gt: expireTime } 
        });
        
        if (!invoices || invoices.length === 0) {
            console.log("No pending invoices found.");
            return;
        }

        for (const invoice of invoices) {
            try {
                if (!invoice || !invoice.newAccount || !invoice.newAccount.accountNumber) {
                    console.error("Invalid invoice: newAccount missing", invoice);
                    continue;
                }

                // Decrypt private key
                const decryptedPrivateKey = await decryptePrivateKey(invoice.newAccount.privateKey);
                const contract_Address = 'TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t';
                const currency = 'TRX';

                // Fetch admin wallet
                const adminWallet = await AdminWallet.findOne({ "currency.coin": currency });
                if (!adminWallet) {
                    console.error("Admin wallet not found for currency:", invoice.currency);
                    continue;
                }

                tronWeb.setPrivateKey(decryptedPrivateKey);
                const contractI = await tronWeb.contract().at(contract_Address);

                // Get current USDT balance
                const balance = await contractI.methods.balanceOf(invoice.newAccount.accountNumber).call();
                const currentBalance = parseInt(balance) / 1000000;

                // Calculate expiry status using 4-hour window
                const currentTimestamp = Date.now();
                const fourHoursInMillis = 4 * 60 * 60 * 1000;
                const timeDifference = currentTimestamp - invoice.timestamp;
                
                // If expired, update status and skip processing
                if (timeDifference > fourHoursInMillis) {
                    await Invoice.findByIdAndUpdate(
                        invoice._id,
                        { paymentStatus: "EXPIRED" }
                    );
                    continue;
                }

                // Check if balance has increased
                if (currentBalance > invoice.previousBalance) {
                    // Calculate new payment amount
                    const newPaymentAmount = currentBalance - invoice.previousBalance;
                    const updatedPaidAmount = (invoice.paidAmount || 0) + newPaymentAmount;
                    
                    // Process admin transaction if balance >= 500
                    if (currentBalance >= 500) {
                        const adminFeePercentage = 0.1;
                        const adminFeeAmount = (currentBalance * adminFeePercentage / 100).toFixed(6);

                        // Check and fund TRX if needed
                        var trxBalance = await tronWeb.trx.getBalance(invoice.newAccount.accountNumber);
                        trxBalance = tronWeb.fromSun(trxBalance);

                        if (trxBalance < 20) {
                            try {
                                var adminTrxBalance = await tronWeb.trx.getBalance(adminWallet.accountNumber);
                                adminTrxBalance = tronWeb.fromSun(adminTrxBalance);
                                const requiredTrx = 20 - trxBalance;

                                if (adminTrxBalance > requiredTrx) {
                                    const trxTransfer = await tronWeb.trx.sendTransaction(
                                        invoice.newAccount.accountNumber,
                                        tronWeb.toSun(requiredTrx),
                                        adminWallet.privateKey
                                    );
                                    console.log('TRX funded from admin wallet:', trxTransfer);
                                    await new Promise(resolve => setTimeout(resolve, 3000));
                                }
                            } catch (error) {
                                console.error('Error funding TRX from admin wallet:', error);
                                continue;
                            }
                        }

                        // Process admin fee transaction
                        try {
                            const adminTx = await contractI.methods.transfer(
                                adminWallet.walletAddress,
                                tronWeb.toSun(adminFeeAmount)
                            ).send({
                                feeLimit: 10000000
                            });

                            await Invoice.findByIdAndUpdate(
                                invoice._id,
                                {
                                    $set: {
                                        adminTransaction: adminTx,
                                        adminFeeAmount: adminFeeAmount
                                    }
                                }
                            );
                        } catch (error) {
                            console.error('Error processing admin fee:', error);
                        }
                    }

                    // Update invoice data
                    const updateData = {
                        balance: currentBalance,
                        previousBalance: currentBalance,
                        paidAmount: updatedPaidAmount
                    };

                    // Check if payment is complete
                    if (updatedPaidAmount >= invoice.amount) {
                        updateData.paymentStatus = 'PAID';
                        
                        // Process transfer to user account
                        const accountAddress = await getAccountAddress(invoice);
                        if (accountAddress) {
                            try {
                                const trans = await contractI.methods.transfer(
                                    accountAddress,
                                    tronWeb.toSun(updatedPaidAmount)
                                ).send({
                                    feeLimit: 10000000
                                });

                                // Record transaction
                                const newTransaction = new InvoiceTransaction({
                                    paymentId: invoice._id,
                                    paidAmount: updatedPaidAmount,
                                    Transaction: trans,
                                });
                                await newTransaction.save();

                                // Update transaction history
                               // await updateTransactionHistory(invoice, trans, accountAddress, updatedPaidAmount);
                            } catch (error) {
                                console.error('Error processing final transfer:', error);
                            }
                        }
                    }

                    // Update invoice with new data
                    await Invoice.findByIdAndUpdate(
                        invoice._id,
                        { $set: updateData }
                    );
                }
            } catch (error) {
                console.error(`Error processing invoice ${invoice._id}:`, error);
                continue;
            }
        }
    } catch (err) {
        console.error("Error in invoiceCronTRC20:", err);
    }
};

// Helper function to get account address
const getAccountAddress = async (invoice) => {
    try {
        const accountDetails = await Acc_Balance.findOne({ email: invoice.userEmail });
        if (!accountDetails || !accountDetails.accounts) return null;

        const trxAccount = accountDetails.accounts.find(acc => acc.symbol === "TRX");
        return trxAccount ? trxAccount.account_number : null;
    } catch (error) {
        console.error('Error getting account address:', error);
        return null;
    }
};

// Helper function to update transaction history
const updateTransactionHistory = async (invoice, transactionId, accountAddress, paidAmount) => {
    try {
        const formattedTime = new Date().getTime();
        const user = await users.findOne({ email: invoice.userEmail }, { _id: 1 });

        const merchantObject = {
            email: invoice.email,
            ip: ip.address(),
            txId: transactionId,
            fee: 0,
            currency: invoice.currency,
            paidFrom: invoice.newAccount.address,
            senderTag: "",
            receiverTag: "",
            amount: paidAmount,
            usdRate: invoice.rate,
            adminFee: invoice.adminFeeAmount || 0,
            actualamount: paidAmount,
            ordertype: "",
            description: "",
            status: 1,
            transactionType: "MerchantApi",
            explorer: `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`,
            userId: invoice.id,
            paidTo: accountAddress,
            initialedDate: formattedTime,
            confirmedDate: formattedTime
        };

        await Transaction_History.findOneAndUpdate(
            { user_id: user._id },
            { $push: { Merchant: merchantObject } },
            { upsert: true }
        );
    } catch (error) {
        console.error('Error updating transaction history:', error);
    }
};





module.exports = {
    createInvoiceTRC20,
    invoiceStatusTRC20,
    invoiceCronTRC20,
    getTRC20Balance,
    startInvoiceCrontrc20,
    // startInvoiceCrontrx
}