const { inspectBN } = require("@raydium-io/raydium-sdk");
const BigNumber = require('ethers')
const mongoose = require("mongoose");
const crypto = require("crypto");
const { TronWeb } = require("tronweb"); 
const ip = require("ip");

// Models Define
const InvoiceTransaction = require("../../../../models/Invoices/invoiceTransactionModel");
const Invoice = require("../../../../models/Invoices/invoiceModel");
const Coinrate = require("../../../../models/coinrates/usdRate");
const AdminWallet = require("../../../../models/adminWallet");
const userModel = require('../../../../models/userModel');
const users = require('../../../../models/userModel');
const cron = require('node-cron');
const { console } = require("inspector");


const tronWeb = new TronWeb({
    fullHost: 'https://api.trongrid.io',
    headers: { 'TRON-PRO-API-KEY': process.env.TRON_API_KEY },
});

exports.withdrawTRX = async (req, res) => {
    const {
        currency,
        amount,
        from_address,
        senderPrivateKey,
        full_amount,
        to_address,
        fullRemainingAmount,
    } = req.body;
    try {
        // const customTronWeb = new TronWeb({
        //     fullHost: 'https://api.trongrid.io',
        //     headers: { 'TRON-PRO-API-KEY': `TNFzVzsQcBcujCBNxZxSpsZg1yymvducgK` },
        //     privateKey: senderPrivateKey,
        // });
        var accountBalance = tronWeb.fromSun((await tronWeb.trx.getBalance(from_address)));
        // var accountBalance = await customTronWeb.trx.getBalance(from_address);
        // accountBalance = tronWeb.fromSun(accountBalance);
        console.log("balanceeee",accountBalance);
        

        if (+accountBalance < +amount) {
            return res.status(400).json({
                statuscode: 400,
                status: "Failed",
                message: "Insufficient funds, account balance is " + accountBalance + " TRX",
                data: {}
            });
        }

        const bandwidth = await tronWeb.trx.getBandwidth(from_address);
        const accountinfo = await tronWeb.trx.getAccount(to_address);
        var newAddFee = accountinfo.balance ? 0 : 1.1;

        if (full_amount == 1) {
            if (+bandwidth < 270) {
                amount = +accountBalance - 1;
            } else {
                amount = +accountBalance;
            }
            amount = Number(+amount - +newAddFee).toFixed(6);
            amount = tronWeb.toSun(amount);

        } else if (fullRemainingAmount == 1) {
            if (+bandwidth < 270) {
                amount = +amount - 1;
            } else {
                amount = +amount;
            }

            amount = Number(+amount - +newAddFee).toFixed(6);
            amount = tronWeb.toSun(amount);

            if (Number(amount) < 0) {
                return res.status(400).json({
                    statuscode: 400,
                    status: "Failed",
                    message: `Insufficient funds`,
                    data: {}
                });
            }
        } else {
            if (+accountBalance < (+amount + newAddFee)) {
                return res.status(400).json({
                    statuscode: 400,
                    status: "Failed",
                    message: `Insufficient funds, account balance is ${accountBalance} TRX & new address fee ${newAddFee} TRX`,
                    data: {}
                });
            }

            if (+bandwidth < 270 && +accountBalance < (+amount + newAddFee + 1)) {
                return res.status(400).json({
                    statuscode: 400,
                    status: "Failed",
                    message: `Insufficient funds, less bandwidth left fee 1 TRX`,
                    data: {}
                });
            }
            amount = tronWeb.toSun(amount);
        }

        const tronTx = await tronWeb.trx.sendTransaction(to_address, amount, senderPrivateKey);
        return tronTx.txid;

    } catch (error) {
        console.error("Error Details:", error.response?.data || error.message || error);
        return res.status(400).json({
            statuscode: 400,
            status: "Failed",
            message: error.response?.data?.message || error.message || "Unknown error",
            data: {}
        });
    }
};
// Validate URLs and private key
//   if (!tronConfig.fullNode || !tronConfig.solidityNode || !tronConfig.eventServer) {
//     throw new Error("One or more TRON URLs are missing or invalid");
//   }

//   if (!tronConfig.privateKey) {
//     throw new Error("Private key is missing");
//   }

// Initialize TronWeb providers
//   const HttpProvider = TronWeb.providers.HttpProvider;
//   const fullNode = new HttpProvider(tronConfig.fullNode);
//   const solidityNode = new HttpProvider(tronConfig.solidityNode);
//   const eventServer = new HttpProvider(tronConfig.eventServer);
//   const trxPrivateKey = tronConfig.privateKey;

// Initialize the TronWeb instance
//   const tronWebInstance = new TronWeb(fullNode, solidityNode, eventServer, trxPrivateKey);
// const tronWebInstance = new TronWeb(fullNode);


// Set the header after initializing TronWeb
//   tronWebInstance.setHeader({ "TRON-PRO-API-KEY": process.env.TRON_API_KEY });


//const staticUrl = "https://app.coinuniverze.com";

const decryptePrivateKey = (data) => {
    try {
        var encrypted = Buffer.from(data, 'base64');
        var salt_len = 16, iv_len = 16;

        var salt = encrypted.slice(0, salt_len);

        var iv = encrypted.slice(0 + salt_len, salt_len + iv_len);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 256 / 8, 'sha256');

        var decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);

        decipher.write(encrypted.slice(salt_len + iv_len));
        decipher.end();

        const decrypted = decipher.read();
        return decrypted.toString()
    } catch (err) {
        console.log('decryptedPrivateKey Error: ', err)
    }
};

const encryptedPrivateKeys = async (data) => {
    try {

        var salt = crypto.randomBytes(16);
        var iv = crypto.randomBytes(16);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 32, 'sha256');
        var cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        cipher.write(data);
        cipher.end()

        var encrypted = cipher.read();

        return Buffer.concat([salt, iv, encrypted]).toString('base64')
    } catch (err) {
        console.log("encryptedPrivateKeys Error:", err)
    }
};

const getTRXBalance = async (sender) => {
    try {
        const bal = await tronWeb.trx.getBalance(sender);
        const balance = tronWeb.fromSun(bal);
        return balance;
    } catch (err) {
        console.log('TRX balance Error : ', err)
    }
}

const createTRXAccount = async () => {
    try {
        var newAccount = await tronWeb.createAccount();

        var privateKey = await encryptedPrivateKeys(newAccount.privateKey);
        var newAddress = newAccount.address.base58;

        return { privateKey, newAddress };

    } catch (err) {
        console.log("createTRXAccount error:", err)
    }
}

const createInvoiceTRX = async (req, res) => {
    try {
        const { email, cryptoAmount, amount, currency, publicKey, clientId } = req.body;

        // Find user by clientId
        const user = await userModel.findOne({ userId: clientId });
        if (!user) {
            return res.status(404).send({
                code: "404",
                status: "Not Found",
                message: "User not found",
                data: [],
            });
        }

        
        // Validate minimum TRX amount if cryptoAmount is true
        const minimumAmount = parseFloat(process.env.TRX_MINIMUM_AMOUNT || 0);
        if (cryptoAmount && amount < minimumAmount) {
            return res.status(400).send({
                code: "400",
                status: "Fail",
                message: `TRX amount should be greater than ${minimumAmount}`,
                data: {},
            });
        }

        console.log('before trxAccount: ');
        let trxAccount = user.coins.find(coin => coin.currency === "TRX");
        let usdtTrcAccount = user.coins.find(coin => coin.currency === "USDT_TRC20");
        console.log('before trxAccount: ', usdtTrcAccount);
        // Determine account address for TRX
        let accountNumber, privateKey;
        if (trxAccount) {
            // Prioritize existing TRX account
            console.log('trxAccount: ', trxAccount);
            accountNumber = trxAccount.address;
            privateKey = trxAccount.privateKey;
        } else if (usdtTrcAccount) {
            // If no TRX account, use USDT_TRC20 account details
            accountNumber = usdtTrcAccount.address;
            privateKey = usdtTrcAccount.privateKey;

            // Create a new TRX entry using USDT_TRC20 account details
            user.coins.push({
                currency: "TRX",
                address: accountNumber,
                privateKey: privateKey
            });
            await user.save();
        } else {
            // Create new TRX account if no existing TRX or USDT_TRC20 account found
            const newAccount = await createTRXAccount();
            console.log('in else condition for private key', newAccount)
            if (!newAccount || !newAccount.newAddress || !newAccount.privateKey) {
                throw new Error("Failed to create TRX account");
            }
            accountNumber = newAccount.newAddress;
            privateKey = newAccount.privateKey;

            // Save the newly created TRX account to the user's coins
            user.coins.push({
                currency: "TRX",
                address: accountNumber,
                privateKey: privateKey
            });
            await user.save();
        }

        // Fetch the current TRX to USD rate
        const rateData = await Coinrate.findOne({});
        if (!rateData) {
            throw new Error("Rate data not found");
        }
        const rate = rateData.usd_rate.TRX;
        //txnid lgic
        txnId = ""

        // Calculate amounts based on cryptoAmount flag
        const usdAmount = cryptoAmount ? (amount * rate).toFixed(6) : amount.toFixed(6);
        const paidAmount = cryptoAmount ? amount.toFixed(6) : (amount / rate).toFixed(6);
        const timeout = Date.now() + 14400000; // 4-hour timeout

        // Create a new invoice
        const newInvoiceData = {
            userId: clientId,
            email,
            cryptoAmount,
            amount,
            usdAmount,
            paidAmount,
            currency,
            balance: 0,
            newAccount: { accountNumber},
            rate: rate.toFixed(6),
            timestamp: Date.now(),
            timeout,
            cold_trans_done: false,
            publicKey,
            txnId,
        };
        const newInvoice = await Invoice.create(newInvoiceData);

        // Calculate remaining time for the invoice
        const remainingTime = new Date(timeout - Date.now()).toISOString().substr(11, 8);

        // Return the response with invoice details
        res.status(200).send({
            code: "200",
            status: "OK",
            message: "Invoice created successfully",
            data: {
                paymentStatus: "PENDING",
                paymentId: newInvoice._id.toString(),
                emailAddress: email,
                name: newInvoice.name || "Unnamed",
                usdAmount,
                totalRemainingAmount: paidAmount,
                totalAmount: paidAmount,
                totalReceivedAmount: 0,
                conversionRate: rate.toFixed(6),
                address: accountNumber,
                //   statusUrl: `${staticUrl}/#/invoice/${newInvoice._id}`,
                remainingTime,
                paymentQRCode: accountNumber,
                txnId: txnId
            },
        });
    } catch (err) {
        console.error("createInvoiceTRX error:", err);
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: err.message || "An error occurred while creating the invoice",
            data: [],
        });
    }
};

//old
const invoiceStatusTRX = async (req, res, invoiceUser, timer) => {
    try {

        var trongenieFees = 1.5;
        var trongenieFeesAddress;

        var balance = tronWeb.fromSun((await tronWeb.trx.getBalance(invoiceUser.newAccount.accountNumber)));
        balance = Number(balance);
        console.log('balance: ', balance);
        console.log('invoice user', invoiceUser);

      // Fetch the admin wallet based on the currency
      const adminWallet = await AdminWallet.findOne({ 'currency.coin': invoiceUser.currency });

      if (!adminWallet) {
          return res.status(400).json({
              code: 400,
              status: "ERROR",
              message: "Admin wallet not found for the specified currency"
          });
      }

   
        var adminAmount = "1";
        let accountAddress = adminWallet.walletAddress;

        console.log('status updated')


        var remainingCurrencyAmount = invoiceUser.paidAmount - balance;
        // var userAmount = +invoiceUser.paidAmount - +adminAmount - +trongenieFees - +merchantAmount;
        var userAmount = +invoiceUser.paidAmount - +adminAmount - +trongenieFees;

        var balance = Number(tronWeb.fromSun(await tronWeb.trx.getBalance(invoiceUser.newAccount.accountNumber))).toFixed(6);
        console.log('balance:', balance)
      console.log('balance');
        var cold_transaction_Status = invoiceUser.cold_trans_done;

        if (cold_transaction_Status) {
            console.log('cold_transaction_status: ', cold_transaction_Status);

            let Amount = Number(invoiceUser.balance.toFixed(6));
            console.log('Amount: ', Amount);

            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "PAID",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: 0,
                    currency: invoiceUser.currency,
                    totalAmount: Amount,
                    totalReceivedAmount: invoiceUser.balance,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                    remainingTime: "00:00:00",
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                    txnId: invoiceUser.txnId
                },
            })
        }

        // Ensure there's enough balance for a transaction (leave some for gas)
        const MINIMUM_GAS_FEE = 0.50000;
        console.log('balance and minimumgasfess: ', balance, MINIMUM_GAS_FEE);
        if (balance > MINIMUM_GAS_FEE) {
            const transferableAmount = Number(tronWeb.toSun(balance - MINIMUM_GAS_FEE)).toFixed(6);
            console.log('transferable Amount: ', transferableAmount);// Deduct gas fee from balance

            const user = await userModel.findOne({ userId: invoiceUser.userId });
            if (user) {
                let trxAccount = user.coins.find(coin => coin.currency === "TRX");
                var decryptedPrivateKey = await decryptePrivateKey(trxAccount.privateKey);

                console.log('Decrypted private key: ', decryptedPrivateKey);

                // let accountAddress = 'TBfnCdC3wHRKp5euUWNdU8d3rzM16oHr25'; 
               // let accountAddress =  'TLcz5fn9KNKu7edazFqyPz9UiEfXWWRspx'// Replace with the target address

               // let accountAddress = 'TBfnCdC3wHRKp5euUWNdU8d3rzM16oHr25'; // Replace with the target address

               
                const transaction = await tronWeb.trx.sendTransaction(
                    accountAddress,
                    transferableAmount,
                    decryptedPrivateKey
                );

                console.log('Transaction: ', transaction);
                console.log('transaction id: ', transaction.transaction.txID);
                const paidAmount = invoiceUser.balance + transferableAmount; // Perform addition and format

      

                // Store as a string
                invoiceUser.paidAmount = paidAmount; // Already a string due to `.toFixed()`
                invoiceUser.txId = transaction.txid;
                invoiceUser.cold_trans_done=true;

                await Invoice.updateOne(
                    { _id: req.body.id },
                    { txnId: transaction.transaction.txID, cold_trans_done: true }
                )

                await invoiceUser.save();

                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        paymentStatus: "PAID",
                        paymentId: invoiceUser._id,
                        emailAddress: invoiceUser.email,
                        name: invoiceUser.name,
                        usdAmount: invoiceUser.usdAmount,
                        totalRemainingAmount: 0,
                        currency: invoiceUser.currency,
                        totalAmount: invoiceUser.paidAmount,
                        totalReceivedAmount: invoiceUser.balance,
                        conversionRate: invoiceUser.rate,
                        address: invoiceUser.newAccount.accountNumber,
                        remainingTime: "00:00:00",
                        paymentQRCode: invoiceUser.newAccount.accountNumber,
                        txnId: transaction.transaction.txID
                    },
                });
            }
        }

        console.log(remainingCurrencyAmount, userAmount, adminAmount)
        if (remainingCurrencyAmount <= 0) {

            const accountDetails = await Acc_Balance.findOne({ email: invoiceUser.userEmail });
            const accountAddress = accountDetails.accounts;
            
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == invoiceUser.currency) {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            var decryptedPrivateKey = await decryptePrivateKey(
                invoiceUser.newAccount.privateKey
            );

            console.log('decryptedKey: ', decryptePrivateKey);

            //trongenieFeesAddress transaction
            if (invoiceUser.invoiceFeeStatus) {
                console.log("invoiceFeeTrans")
                await tronWeb.trx.sendTransaction(
                    trongenieFeesAddress,
                    tronWeb.toSun(trongenieFees),
                    decryptedPrivateKey
                )
            }

            //trongenieFeesAddress transaction
            if (merchantAmount > 0) {
                console.log("merchantTrans")
                await tronWeb.trx.sendTransaction(
                    merchantAddress,
                    tronWeb.toSun(merchantAmount),
                    decryptedPrivateKey
                )
            }

            //user transaction
            const trans = await tronWeb.trx.sendTransaction(
                accountAddress,
                tronWeb.toSun(userAmount),
                decryptedPrivateKey
            )
await Invoice.updateOne(
    { _id: req.body.id },
    { txnId: transaction.transaction.txID, cold_trans_done: true, },
    { paymentStatus: "PAID" }

);


            var new_task = new InvoiceTransaction({
                paymentId: req.body.id,
                paidAmount: invoiceUser.paidAmount,
                Transaction: trans,
            });
            new_task.save();
            console.log(`user Transaction successful with hash: ${trans.txid}`);

            //console.log(adminWallet[0].walletAddress, adminWallet[0].txFees, decryptedPrivateKey,'9jg')
            if (adminAmount > 0.4) {
                console.log('adminfees')
                const admin = await tronWeb.trx.sendTransaction(
                    adminWallet.walletAddress,
                    tronWeb.toSun(adminAmount),
                    decryptedPrivateKey
                );

                await InvoiceTransaction.updateOne(
                    { paymentId: req.body.id },
                    { adminTransaction: admin }
                );
                console.log(`admin Transaction successful with hash: ${admin.txid}`);
            }

            var formattedTime = Date.now();
            const transactionId = trans.txid;
            var emailProvider, companyName, domain
            if (invoiceUser.emailProvider) {
                emailProvider = invoiceUser.emailProvider;
                companyName = invoiceUser.companyName;
                domain = invoiceUser.domain
            }
            var link = `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`
            const emailBody = {
                email: invoiceUser.email,
                firstName: "User",
                amount: invoiceUser.paidAmount,
                currency: invoiceUser.currency,
                paidfrom: invoiceUser.newAccount.accountNumber,
                paidto: accountAddress,
                transactionId,
                formattedTime,
                link,
                emailProvider,
                apiName: invoiceUser.name,
                companyName,
                domain
            };

          

            var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

            var Merchantobject = {

                "email": invoiceUser.email,
                "ip": ip.address(),
                "txId": trans,
                "fee": 0,
                "currency": invoiceUser.currency,
                "paidFrom": invoiceUser.newAccount.accountNumber,
                "senderTag": "",
                "receiverTag": "",
                "amount": invoiceUser.paidAmount,
                "usdRate": invoiceUser.rate,
                "adminFee": adminAmount,
                "otherFees": trongenieFees,
                "actualamount": invoiceUser.paidAmount,
                "ordertype": "",
                "description": "",
                "status": 1,
                "transactionType": "MerchantApi",
                "explorer": `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`,
                "userId": user._id,
                "paidTo": accountAddress,
                "initiatedDate": formattedTime,
                "confirmedDate": formattedTime

            }

            await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true })
            console.log('tx id: ', invoiceUser.txnId);


            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "PAID",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: 0,
                    currency: invoiceUser.currency,
                    totalAmount: invoiceUser.paidAmount,
                    totalReceivedAmount: invoiceUser.paidAmount,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                    //   statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                    remainingTime: "00:00:00",
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                },
            });

        } else {
            console.log('tx id: ', invoiceUser.txnId);
            var response = {
                code: "200",
                status: "OK",
                message: "Successful",
                data: {
                    paymentStatus: "PENDING",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: remainingCurrencyAmount,
                    currency: invoiceUser.currency,
                    totalAmount: invoiceUser.paidAmount,
                    totalReceivedAmount: balance,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                    //  statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                    remainingTime:
                        timer.hours + ":" + timer.minutes + ":" + timer.seconds,
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                    txnId: invoiceUser.txnId
                },
            };
            res.status(200).send(response);
        }


    } catch (err) {
        console.log(err, "Error in invoiceStatus TRX: ", err);
    }
}


const startInvoiceCrontrx = () => {
    // '*/15 * * * *' means run every 15 minutes
    cron.schedule(' */15 * * * *', async () => {
        console.log('Starting invoice processing cron job...');
        await invoiceCronTRX();
        console.log('Completed invoice processing cron job');
    });
    
    console.log('Cron job scheduled to run every 15 minutes');
}


const invoiceCronTRX = async () => {
    // console.log("Running invoiceCronTRX...");

    try {
        var expireTime = Date.now() - 28800000;

        const invoices = await Invoice.find({ paymentStatus: "PENDING", timestamp: { $gt: expireTime } });

        if (!invoices || invoices.length === 0) {
            console.log("No pending invoices found.");
            return;
        }

        for (const invoice of invoices) {
            if (!invoice || !invoice.newAccount || !invoice.newAccount.accountNumber) {
                console.error("Invalid invoice: newAccount missing", invoice);
                continue;
            }

            const currency = 'TRX'; // Assign currency separately

            var balance = tronWeb.fromSun((await tronWeb.trx.getBalance(invoice.newAccount.accountNumber)));
            balance = Number(balance);

            console.log(`Processing invoice for ${invoice.email}, balance: ${balance}`);
      
            const adminWallet = await AdminWallet.findOne({ "currency.coin": currency });


            let trongenieFees = 0, trongenieFeesAddress;
            if (invoice.invoiceFeeStatus) {
                const invoiceFeeData = await InvoiceFee.findOne({ currency });
                if (invoiceFeeData) {
                    trongenieFeesAddress = invoiceFeeData.feeAddress;
                    trongenieFees = invoiceFeeData.fee;
                }
            }

            var adminAmount = adminWallet?.txFees || 0;

            // var merchantFees = await MerchantFees.findOne({ publicKey: invoice.publicKey });
            // var merchantRate = 0, merchantAmount = 0, merchantAddress;
            // if (merchantFees && merchantFees.feeObject) {
            //     for (let value of merchantFees.feeObject) {
            //         if (value.currency == currency) {
            //             merchantRate = value.rate;
            //             merchantAddress = value.address;
            //             break;
            //         }
            //     }
            // }

            // if (merchantRate > 0) {
            //     merchantAmount = Number(invoice.paidAmount * merchantRate / 100).toFixed(6);
            // }

            var remainingCurrencyAmount = invoice.paidAmount - balance;
            // var userAmount = +invoice.paidAmount - +adminAmount - +trongenieFees - +merchantAmount;
            var userAmount = +invoice.paidAmount - +adminAmount - +trongenieFees;

            console.log(remainingCurrencyAmount, userAmount, adminAmount);
            if (remainingCurrencyAmount <= 0) {
                var accountAddress = await Acc_Balance.findOne({ email: invoice.email });
                if (!accountAddress || !accountAddress.accounts) {
                    console.error("No account found for user:", invoice.email);
                    continue;
                }
                
                let userAccount = accountAddress.accounts.find(acc => acc.symbol === currency);
                if (!userAccount) {
                    console.error("No matching account for currency:", currency);
                    continue;
                }
                accountAddress = userAccount.account_number;

                var decryptedPrivateKey = await decryptePrivateKey(invoice.newAccount.privateKey);

                if (invoice.invoiceFeeStatus && trongenieFees > 0) {
                    console.log("invoiceFeeTrans");
                    await tronWeb.trx.sendTransaction(trongenieFeesAddress, tronWeb.toSun(trongenieFees), decryptedPrivateKey);
                }

                if (merchantAmount > 0) {
                    console.log("merchantTrans");
                    await tronWeb.trx.sendTransaction(merchantAddress, tronWeb.toSun(merchantAmount), decryptedPrivateKey);
                }

                const trans = await tronWeb.trx.sendTransaction(accountAddress, tronWeb.toSun(userAmount), decryptedPrivateKey);
                await Invoice.updateOne({ _id: invoice._id }, { cold_trans_done: true });

                var new_task = new InvoiceTransaction({
                    paymentId: invoice._id,
                    paidAmount: invoice.paidAmount,
                    Transaction: { txid: trans.txid }, // Wrap transaction ID properly
                });
                new_task.save();
                console.log(`User Transaction successful with hash: ${trans.txid}`);

                if (adminAmount > 0.4) {
                    console.log("adminfees");
                    const admin = await tronWeb.trx.sendTransaction(adminWallet.walletAddress, tronWeb.toSun(adminAmount), decryptedPrivateKey);

                    await InvoiceTransaction.updateOne({ paymentId: invoice._id }, { adminTransaction: { txid: admin.txid } });
                    console.log(`Admin Transaction successful with hash: ${admin.txid}`);
                }

                var formattedTime = Date.now();
                const transactionId = trans.txid;

                var emailBody = {
                    email: invoice.email,
                    firstName: "User",
                    amount: invoice.paidAmount,
                    currency,
                    paidfrom: invoice.newAccount.accountNumber,
                    paidto: accountAddress,
                    transactionId,
                    formattedTime,
                    link: `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`,
                    emailProvider: invoice.emailProvider || "",
                    apiName: invoice.name || "",
                    companyName: invoice.companyName || "",
                    domain: invoice.domain || "",
                };

                await transactionEmail(emailBody);

                var user = await users.findOne({ email: invoice.email }, { _id: 1 });

                if (!user) {
                    console.error("User not found for email:", invoice.email);
                    continue;
                }

                var Merchantobject = {
                    email: invoice.email,
                    ip: ip.address(),
                    txId: { txid: trans.txid },
                    fee: 0,
                    currency,
                    paidFrom: invoice.newAccount.accountNumber,
                    senderTag: "",
                    receiverTag: "",
                    amount: invoice.paidAmount,
                    usdRate: invoice.rate,
                    adminFee: adminAmount,
                    otherFees: trongenieFees,
                    actualamount: invoice.paidAmount,
                    ordertype: "",
                    description: "",
                    status: 1,
                    transactionType: "MerchantApi",
                    explorer: `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`,
                    userId: user._id,
                    paidTo: accountAddress,
                    initiatedDate: formattedTime,
                    confirmedDate: formattedTime
                };

                await Transaction_History.findOneAndUpdate(
                    { user_id: user._id }, 
                    { $push: { Merchant: Merchantobject } }, 
                    { upsert: true }
                );
            }
        }
    } catch (err) {
        console.error("Error in invoiceCronTRX:", err);
    }
};



const refundTransactionTRX = async (req, res, id, sender, receiver, privateKey) => {
    try {
        var amount = await getTRXBalance(sender);

        var decryptedPrivateKey = await decryptePrivateKey(privateKey);

        //user transaction
        var receipt = await tronWeb.trx.sendTransaction(
            receiver,
            tronWeb.toSun(amount),
            decryptedPrivateKey
        )
        console.log(
            `Transaction successful with hash: ${receipt.txid}`
        );
        if (receipt.txid) {
            const refundData = await Refund.findOneAndUpdate({ _id: id }, {
                refund_txid: receipt.txid,
                refundConfirmed: true,
                toAddress: receiver,
                amount: amount.toFixed(6)
            }, { new: true });
            await sendEmail(id);
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "Successful",
                data: {
                    status: "PAID",
                    paymentId: refundData.paymentId,
                    currency: refundData.currency,
                    amount: refundData.amount,
                    address: refundData.toAddress,
                    transactionHash: refundData.refund_txid,
                    transactionHashRedirectURL: `https://${process.env.tron_explorer_url}/#/transaction/` + refundData.refund_txid,
                },
            });
        }
    } catch (err) {
        console.log("refundTransaction error:", err)
        return res.status(500).json({
            code: 500,
            status: "Error",
            message: err.message,
            data: {},
        });
    }
}

const sendEmail = async function (refundId) {

    try {
        const refundData = await Refund.findOne({ _id: refundId });
        const email = refundData.email;
        const currency = refundData.currency;
        const amount = refundData.amount;
        const toAddress = refundData.toAddress;
        const txId = refundData.refund_txid;
        var emailProvider = refundData.emailProvider;
        var apiKey = refundData.apiKey;
        var companyName = refundData.companyName;
        var domain = refundData.domain;

        const emailBody = {
            email,
            currency,
            amount,
            toAddress,
            txId,
            emailProvider,
            apiKey,
            companyName,
            domain
        }
        console.log("mail initiated")
        await refundTransactionMail(emailBody);
        console.log("mail confirmed")
    } catch (err) {
        console.log("Error in sendEmail: ", err)
    }
}

module.exports = {
    createInvoiceTRX,
    invoiceStatusTRX,
    invoiceCronTRX,
    getTRXBalance,
    refundTransactionTRX,
    startInvoiceCrontrx
}