
var mongoose = require("mongoose");
// const Invoice = require("../../models/invoiceDataModel");
// const InvoiceFee = require("../../models/invoiceFees");
// const Api = require("../../models/apiModel");
// const Backup = require("../../models/backupModel");
// const Acc_Balance = require("../../models/dashboard_balance");
// const InvoiceTransaction = require("../../models/Invoice_transactionModel");
// const AdminWallet = require("../../models/adminWalletModel");
// const users = require("../../models/user.model");
// const { transactionEmail } = require("./../../../utils/transactionEmail");
// const Transaction_History = mongoose.model("Transaction_History");
// const Coinrate = require("../../models/coinRate");
// const Refund = require("../../models/confirmRefundModel");
// const { refundTransactionMail } = require("../../../utils/refundTransactionMail");

const Invoice = require("../../../models/Invoices/invoiceModel");
const userModel = require('../../../models/userModel');
const Coinrate = require("../../../models/coinrates/usdRate");
const InvoiceTransaction = require("../../../models/Invoices/invoiceTransactionModel");
const AdminWallet = require("../../../models/adminWallet");
const crypto = require("crypto");
var ip = require("ip");
const rp = require("request-promise");
const createAccount = require("../BitcoinCash/CreateBCHAccount")
// const MerchantFees = require("../../models/merchantFees");

console.log('Payments for BTC')
//const Refund = require("../../models/confirmRefundModel");
const ethers = require('ethers');
const ethersprovider = new ethers.JsonRpcProvider(
    "https://sepolia.infura.io/v3/5d7769a2990747789f0c9f5927d5a860"
  )
//const staticUrl = "https://app.coinuniverze.com";

const BCHCOIN_PORT = 8050
const RPCUSER = "BCH123Root"
const RPCPASS = "BCH123Root"


const getRate = async (currency) => {
   var rate = undefined
   var rate = await CoinRate.find().then(el => {
      return el[0].usd_rate
   })
   rate = rate[currency]
   return rate;
}
const encryptedPrivateKeys = async (data) => {
    try {

        var salt = crypto.randomBytes(16);
        var iv = crypto.randomBytes(16);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 32, 'sha256');
        var cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        cipher.write(data);
        cipher.end()

        var encrypted = cipher.read();
        // console.log(Buffer.concat([salt, iv, encrypted]).toString('base64'));
        return Buffer.concat([salt, iv, encrypted]).toString('base64')
    } catch (err) {
        console.log("encryptedPrivateKeys Error:", err)
    }
};


const createNewAddress = async (wallet, label) => {
    var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"getnewaddress","params":[]}`
    var auth = "Basic " + new Buffer.from(RPCUSER + ":" + RPCPASS).toString("base64");
    var options = {
        url: `http://127.0.0.1:${BCHCOIN_PORT}/wallet/${wallet}`,
        method: "POST",
        headers: {
            "Authorization": auth
        },
        body: dataString
    };
    const newaddress = rp(options).then((data) => {
        return data
    }).catch((err) => {
        return err.error
    })
    return newaddress;
}

const dumpPrivateKey = async (wallet, address) => {
    var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"dumpprivkey","params":["${address}"]}`
    var auth = "Basic " + new Buffer.from(RPCUSER + ":" + RPCPASS).toString("base64");
    var options = {
        url: `http://127.0.0.1:${BCHCOIN_PORT}/wallet/${wallet}`,
        method: "POST",
        headers: {
            "Authorization": auth
        },
        body: dataString
    };
    const newaddress = await rp(options).then((data) => {
        return data
    }).catch((err) => {
        return err.error
    })
    return newaddress;
}

const getBCHBalance = async (wallet, address) => {
    var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"getreceivedbyaddress","params":["${address}"]}`
    var auth = "Basic " + new Buffer.from(RPCUSER + ":" + RPCPASS).toString("base64");
    var options = {
        url: `http://127.0.0.1:${BCHCOIN_PORT}/wallet/${wallet}`,
        method: "POST",
        headers: {
            "Authorization": auth
        },
        body: dataString
    };
    var balance = await rp(options).then((data) => {
        return data
    }).catch((err) => {
        return err.error
    })
    // balance = JSON.parse(balance)
    // balance = balance.result;
    // return balance;
    a = "0.00001243"
    //   a = a.balance;
       a = a / 100000000;
       // balance = JSON.parse(balance)
       // balance = balance.result;
       return a;
}

const balance_BCH = async function (wallet) {
    try {
        const USER = process.env.BCH_RPC_USER;
        const PASS = process.env.BCH_RPC_PASSWORD;

        const bitcoinPort = process.env.bitcoinCash_tunnel_port
        var auth = "Basic " + new Buffer.from(USER + ":" + PASS).toString("base64");
        var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"getbalance","params":[]}`;
        var options = {
            url: `http://127.0.0.1:${bitcoinPort}/wallet/${wallet}`,
            method: "POST",
            headers: {
                "Authorization": auth
            },
            body: dataString
        };
        var a = await rp(options).then((data) => {
            return data
        }).catch((err) => {
            return err.error
        })

        a = JSON.parse(a)
        a = a.result

        return a;
    } catch (err) {
        console.log("Error in balance_BCH:", err)
    }
}

const send_BCH = async function (wallet, to, amount) {
    try {
        var auth = "Basic " + new Buffer(RPCUSER + ":" + RPCPASS).toString("base64");
        var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"sendtoaddress","params":["${to}","${amount}"]}`;
        var options = {
            url: `http://127.0.0.1:${BCHCOIN_PORT}/wallet/${wallet}`,
            method: "POST",
            headers: {
                "Authorization": auth
            },
            body: dataString
        };
        var data = await rp(options).then((data) => {
            return data
        }).catch((err) => {
            return err.error
        })
        console.log(data,'------')
        data = JSON.parse(data);
        data = data.result;
        return data;
    } catch (err) {
        console.log(err)
    }
}

const createInvoiceBCH = async (req, res) => {
    try {
        const { email, cryptoAmount, amount, currency, publicKey, clientId } = req.body;


        const user = await userModel.findOne({ userId: clientId });
        if (!user) {
          return res.status(404).send({
            code: "404",
            status: "Not Found",
            message: "User not found",
            data: [],
          });
        }

        let bchAccount = user.coins.find(coin => coin.currency === "BCH");

        var usdAmount, paidAmount;
        let accountNumber, privateKey;

        if (bchAccount) {
            // Use the existing TRX address
            accountNumber = bchAccount.address;
            privateKey = bchAccount.privateKey;
          }  else {
            // Create new TRX account if no existing TRX or USDT_TRC20 account found
            const newAccount = await createAccount.createAccount();
            console.log('newAccount: ', newAccount);
            if (!newAccount || !newAccount.address || !newAccount.privateKey) {
                throw new Error("Failed to create BCH account");
              }
              const  accountNumber =newAccount.address; 
              const privateKey=newAccount.privateKey;
              const mnemonic = newAccount.mnemonic; 
            // Save the newly created TRX account to the user's coins
            user.coins.push({ currency: "BCH", address: accountNumber, privateKey: privateKey });
            await user.save();
          }
      
          // Fetch the current TRX to USD rate
          const rateData = await Coinrate.findOne({});
          if (!rateData) {
            throw new Error("Rate data not found");
          }
          const rate = rateData.usd_rate.BCH;



                              //txnid lgic
      txnId = ""
        // const adminWallet = await AdminWallet.findOne({ currency });
        // const walletName = adminWallet.walletName

        // var accountNumber = await createNewAddress(walletName);
        // console.log("newAddress", accountNumber)
        // accountNumber = JSON.parse(accountNumber)
        // accountNumber = accountNumber.result;

        // var privateKey = await dumpPrivateKey(accountNumber);
        // privateKey = JSON.parse(privateKey);
        // privateKey = await encryptedPrivateKeys(privateKey.result);
        
        var newAccount = {
            accountNumber,
            privateKey
        }

        if (cryptoAmount == true) {
            usdAmount = Number(amount * rate).toFixed(6);
            paidAmount = Number(amount).toFixed(6);
        } else {
            usdAmount = Number(amount).toFixed(6);
            paidAmount = Number(amount / rate).toFixed(6);
        }
        var new_task = {
            userId: clientId,
            email: email,
            cryptoAmount: cryptoAmount,
            amount: amount,
            usdAmount: usdAmount,
            paidAmount: paidAmount,
            currency: currency,
            balance: 0,
            newAccount: { accountNumber },
            rate: rate.toFixed(6),
            timestamp: Date.now(),
            timeout: Date.now(),
            cold_trans_done: false,
            publicKey: publicKey,
            txnId:txnId,
        };
        const newInvoice = await Invoice.create(new_task);
        console.log(newInvoice, newInvoice._id, newInvoice)
        res.status(200).send({
            code: "200",
            status: "OK",
            message: "Successful",
            data: {
                paymentStatus: "PENDING",
                paymentId: newInvoice._id,
                emailAddress: email,
                name: newInvoice.name,
                usdAmount: usdAmount,
                totalRemainingAmount: paidAmount,
                currency: currency,
                totalAmount: paidAmount,
                totalReceivedAmount: 0,
                conversionRate: rate.toFixed(6),
                address: accountNumber,
                remainingTime: "03:59:59",
                paymentQRCode: accountNumber,
                txid:""
            },
        });
    } catch (err) {
        console.log("createInvoiceBCH error:", err)
    }

};

const invoiceStatusBCH = async (req, res, invoiceUser, timer) => {
    try {

        const adminWallet = await AdminWallet.findOne({
            "currency": {
                $elemMatch: {
                    coin: "BCH"
                }
            }
        });

        // var balance = await getBCHBalance(adminWallet.walletName,invoiceUser.newAccount.accountNumber);
        var balance = await getBCHBalance(invoiceUser.newAccount.accountNumber);
        // balance = Number(balance);
        // console.log(balance, 'balance')
        
        // var adminAmount = adminWallet.txFees;
        
 var adminAmount = "0.0001"

        // var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        var merchantRate = 0, merchantAmount = 0, merchantAddress;
        // if (merchantFees) {
        //     merchantFees = merchantFees.feeObject
        //     for (value of merchantFees) {
        //         if (value.currency == invoiceUser.currency) {
        //             merchantRate = value.rate;
        //             merchantAddress = value.address
        //             break;
        //         }
        //     }
     //   }

        if (merchantRate > 0) {
            merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6)
        }

        var remainingCurrencyAmount = invoiceUser.paidAmount - balance;
        var userAmount = invoiceUser.paidAmount - adminAmount - merchantAmount;

        console.log(remainingCurrencyAmount, userAmount, adminAmount)
        if (remainingCurrencyAmount <= 0) {

            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == invoiceUser.currency) {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            var receipt = await send_BCH(
                adminWallet.walletName,
                accountAddress,
                userAmount
            );
            
            console.log(`Transaction successful with hash: ${receipt}`);

            if(merchantAmount > 0){
                var receipt1 = await send_BCH(
                    adminWallet.walletName,
                    merchantAddress,
                    merchantAmount
                );
                
                console.log(`Transaction successful with hash: ${receipt1}`);
            }

            await Invoice.updateOne(
                { _id: req.body.id },
                { cold_trans_done: true }
            );
            var new_task = new InvoiceTransaction({
                paymentId: req.body.id,
                paidAmount: invoiceUser.paidAmount,
                Transaction: receipt,
            });
            new_task.save();


            //console.log(adminWallet[0].walletAddress, adminWallet[0].txFees, decryptedPrivateKey,'9jg')
            
                
            

            var formattedTime = Date.now();
            const transactionId = receipt;
            var emailProvider, companyName, domain
            if (invoiceUser.emailProvider) {
                emailProvider = invoiceUser.emailProvider;
                companyName = invoiceUser.companyName;
                domain = invoiceUser.domain
            }
            var link = `${process.env.BCH_explorer_url}${transactionId}`
            const emailBody = {
                email: invoiceUser.email,
                firstName: "User",
                amount: invoiceUser.paidAmount,
                currency: invoiceUser.currency,
                paidfrom: invoiceUser.newAccount.accountNumber,
                paidto: accountAddress,
                transactionId,
                formattedTime,
                link,
                emailProvider,
                apiName: invoiceUser.name,
                companyName,
                domain
            };

            await transactionEmail(emailBody);

            var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

            var Merchantobject = {

                "email": invoiceUser.email,
                "ip": ip.address(),
                "txId": transactionId,
                "fee": 0,
                "currency": invoiceUser.currency,
                "paidFrom": invoiceUser.newAccount.accountNumber,
                "senderTag": "",
                "receiverTag": "",
                "amount": invoiceUser.paidAmount,
                "usdRate": invoiceUser.rate,
                "adminFee": adminAmount,
                "actualamount": invoiceUser.paidAmount,
                "ordertype": "",
                "description": "",
                "status": 1,
                "transactionType": "MerchantApi",
                "explorer": link,
                "userId": user._id,
                "paidTo": accountAddress,
                "initiatedDate": formattedTime,
                "confirmedDate": formattedTime

            }

            await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true })

            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "PAID",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: 0,
                    currency: invoiceUser.currency,
                    totalAmount: invoiceUser.paidAmount,
                    totalReceivedAmount: invoiceUser.paidAmount,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                    statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                    remainingTime: "00:00:00",
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                },
            });

        } else {
            var response = {
                code: "200",
                status: "OK",
                message: "Successful",
                data: {
                    paymentStatus: "PENDING",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: remainingCurrencyAmount,
                    currency: invoiceUser.currency,
                    totalAmount: invoiceUser.paidAmount,
                    totalReceivedAmount: balance,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                  //  statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                    remainingTime:
                        timer.hours + ":" + timer.minutes + ":" + timer.seconds,
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                },
            };
            res.status(200).send(response);
        }


    } catch (err) {
        console.log(err, "Error in invoiceStatusBCH: ", err);
    }
}

const invoiceCronBCH = async (invoiceUser) => {
    try {

        const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });

        var balance = await getBCHBalance(adminWallet.walletName,invoiceUser.newAccount.accountNumber);
        balance = Number(balance);
        console.log(balance, 'balance')

        var adminAmount = adminWallet.txFees;

        var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        var merchantRate = 0, merchantAmount = 0, merchantAddress;
        if (merchantFees) {
            merchantFees = merchantFees.feeObject
            for (value of merchantFees) {
                if (value.currency == invoiceUser.currency) {
                    merchantRate = value.rate;
                    merchantAddress = value.address
                    break;
                }
            }
        }


        if (merchantRate > 0) {
            merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6)
        }

        var remainingCurrencyAmount = invoiceUser.paidAmount - balance;
        var userAmount = invoiceUser.paidAmount - adminAmount - merchantAmount;

        console.log(remainingCurrencyAmount, userAmount, adminAmount)
        if (remainingCurrencyAmount <= 0) {

            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == invoiceUser.currency) {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            var receipt = await send_BCH(
                adminWallet.walletName,
                accountAddress,
                userAmount
            );
            
            console.log(`Transaction successful with hash: ${receipt}`);

            if(merchantAmount > 0){
                var receipt1 = await send_BCH(
                    adminWallet.walletName,
                    merchantAddress,
                    merchantAmount
                );
                
                console.log(`Transaction successful with hash: ${receipt1}`);
            }

            await Invoice.updateOne(
                { _id: invoiceUser._id },
                { cold_trans_done: true }
            );
            var new_task = new InvoiceTransaction({
                paymentId: invoiceUser._id,
                paidAmount: invoiceUser.paidAmount,
                Transaction: receipt,
            });
            new_task.save();


            //console.log(adminWallet[0].walletAddress, adminWallet[0].txFees, decryptedPrivateKey,'9jg')
            
                
            

            var formattedTime = Date.now();
            const transactionId = receipt;
            var emailProvider, companyName, domain
            if (invoiceUser.emailProvider) {
                emailProvider = invoiceUser.emailProvider;
                companyName = invoiceUser.companyName;
                domain = invoiceUser.domain
            }
            var link = `${process.env.BCH_explorer_url}${transactionId}`
            const emailBody = {
                email: invoiceUser.email,
                firstName: "User",
                amount: invoiceUser.paidAmount,
                currency: invoiceUser.currency,
                paidfrom: invoiceUser.newAccount.accountNumber,
                paidto: accountAddress,
                transactionId,
                formattedTime,
                link,
                emailProvider,
                apiName: invoiceUser.name,
                companyName,
                domain
            };

            await transactionEmail(emailBody);

            var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

            var Merchantobject = {

                "email": invoiceUser.email,
                "ip": ip.address(),
                "txId": transactionId,
                "fee": 0,
                "currency": invoiceUser.currency,
                "paidFrom": invoiceUser.newAccount.accountNumber,
                "senderTag": "",
                "receiverTag": "",
                "amount": invoiceUser.paidAmount,
                "usdRate": invoiceUser.rate,
                "adminFee": adminAmount,
                "actualamount": invoiceUser.paidAmount,
                "ordertype": "",
                "description": "",
                "status": 1,
                "transactionType": "MerchantApi",
                "explorer": link,
                "userId": user._id,
                "paidTo": accountAddress,
                "initiatedDate": formattedTime,
                "confirmedDate": formattedTime

            }

            await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true })

        }
        
    } catch (err) {
        console.log(err, "Error in invoiceCronBCH: ", err);
    }
}

const refundTransactionBCH = async (req, res, id, sender, receiver, privateKey,amount,currency) => {
    try {
        
        const adminWallet = await AdminWallet.findOne({ currency: currency });
        //var decryptedPrivateKey = await decryptePrivateKey(privateKey);

        var receipt = await send_BCH(
            adminWallet.walletName,
            receiver,
            amount
        );

        console.log(`Transaction successful with hash: ${receipt}`);

        if (receipt) {
            const refundData = await Refund.findOneAndUpdate({ _id: id }, {
                refund_txid: receipt,
                refundConfirmed: true,
                toAddress:receiver,
                amount:amount,
            }, { new: true });
            await sendEmail(id);
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "Successful",
                data: {
                    status: "PAID",
                    paymentId: refundData.paymentId,
                    currency: refundData.currency,
                    amount: refundData.amount,
                    address: refundData.toAddress,
                    transactionHash: refundData.refund_txid,
                    transactionHashRedirectURL:`${process.env.BCH_explorer_url}` + refundData.refund_txid,
                },
            });
        }
    } catch (err) {
        console.log("refundTransaction error:",err)
        return res.status(500).json({
            code: 500,
            status: "Error",
            message: err.message,
            data: {},
        });
    }
}

const sendEmail = async function (refundId) {

    try {
        const refundData = await Refund.findOne({ _id: refundId });
        const email = refundData.email;
        const currency = refundData.currency;
        const amount = refundData.amount;
        const toAddress = refundData.toAddress;
        const txId = refundData.refund_txid;
        var emailProvider = refundData.emailProvider;
        var apiKey = refundData.apiKey;
        var companyName = refundData.companyName;
        var domain = refundData.domain;

        const emailBody = {
            email,
            currency,
            amount,
            toAddress,
            txId,
            emailProvider,
            apiKey,
            companyName,
            domain
        }
        console.log("mail initiated")
        await refundTransactionMail(emailBody);
        console.log("mail confirmed")
    } catch (err) {
        console.log("Error in sendEmail: ", err)
    }
}

module.exports = {
    createInvoiceBCH,
    invoiceStatusBCH,
    invoiceCronBCH,
    getBCHBalance,
    refundTransactionBCH,
    balance_BCH
}