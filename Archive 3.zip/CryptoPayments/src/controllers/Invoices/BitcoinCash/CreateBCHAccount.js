const axios = require('axios');
const bitcore = require('bitcore-lib-cash');

// Function to generate a new wallet
const generateWallet = () => {
    const privateKey = new bitcore.PrivateKey();
    const address = privateKey.toAddress();

    return {
        privateKey: privateKey.toString(),
        publicKey: privateKey.toPublicKey().toString(),
        address: address.toString(),
    };
};

// Function to import a wallet from a private key
const importWallet = (privateKeyString) => {
    try {
        const privateKey = new bitcore.PrivateKey(privateKeyString);
        const address = privateKey.toAddress();

        return {
            privateKey: privateKey.toString(),
            publicKey: privateKey.toPublicKey().toString(),
            address: address.toString(),
        };
    } catch (error) {
        throw new Error('Invalid private key');
    }
};

// Function to create a new BCH account
const createAccount = async () => {
    const wallet = generateWallet(); // Generate a new wallet
    return wallet; // Return the wallet details
};

// Export the functions
module.exports = {
    generateWallet,
    importWallet,
    createAccount,
};