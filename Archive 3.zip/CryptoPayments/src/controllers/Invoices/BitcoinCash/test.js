const express = require('express');
const axios = require('axios');

const app = express();
const port = 3000;

// Bitcoin Testnet API endpoint
const TESTNET_API_URL = 'https://blockstream.info/testnet/api';

// https://alpha-aged-orb.btc-testnet.quiknode.pro/5bcb1917a130898e9de1fc861f514e46902bd748

// Helper function to make API requests
async function makeApiRequest(endpoint) {
  try {
    const response = await axios.get(`${TESTNET_API_URL}/${endpoint}`);
    return response.data;
  } catch (error) {
    console.error('Error making API request:', error.message);
    throw error;
  }
}

// Get the current block height
app.get('/block-height', async (req, res) => {
  try {
    const blockHeight = await makeApiRequest('blocks/tip/height');
    res.json({ blockHeight });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get information about a specific block
app.get('/block/:blockHash', async (req, res) => {
  const { blockHash } = req.params;
  try {
    const blockInfo = await makeApiRequest(`block/${blockHash}`);
    res.json(blockInfo);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get information about a specific transaction
app.get('/transaction/:txId', async (req, res) => {
  const { txId } = req.params;
  try {
    const transactionInfo = await makeApiRequest(`tx/${txId}`);
    res.json(transactionInfo);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});