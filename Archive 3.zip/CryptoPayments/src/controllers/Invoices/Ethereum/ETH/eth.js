var mongoose = require("mongoose");
const Invoice = require('../../../../models/Invoices/invoiceModel.js') // Invoice
const users = require('../../../../models/userModel');
const Coinrate = require('../../../../models/coinrates/usdRate.js')
const userModel = require('../../../../models/userModel');
const AdminWallet = require("../../../../models/adminWallet");
    
//const Backup = require("../../models/backupModel");
//const Acc_Balance = require("../../models/dashboard_balance");
const InvoiceTransaction =  require('../../../../models/Invoices/invoiceTransactionModel.js');
//const AdminWallet = require("../../models/adminWalletModel");
//const users = require("../../models/user.model");
//const { transactionEmail } = require("./../../../utils/transactionEmail");
 const InvoiceTransactionHistory = require('../../../../models/Invoices/invoiceTransactionModel');
//const Refund = require("../../models/confirmRefundModel");
//const { refundTransactionMail } = require("../../../utils/refundTransactionMail")
const crypto = require("crypto");
const cron = require('node-cron');
const ip = require("ip");
const ethers = require('ethers');
const ethersprovider = new ethers.JsonRpcProvider(
    "https://sepolia.infura.io/v3/5d7769a2990747789f0c9f5927d5a860"
  );

  const staticUrl = "https://app.coinuniverze.com";
const  { Web3 } = require("web3");
const web3eth = new Web3("https://sepolia.infura.io/v3/5d7769a2990747789f0c9f5927d5a860");
const logger = require('../../../../utils/logger.js')
// const MerchantFees = require("../../models/merchantFees");



const decryptePrivateKey = (data) => {
  try {
    var encrypted = Buffer.from(data, "base64");
    var salt_len = 16,
      iv_len = 16;

    var salt = encrypted.slice(0, salt_len);
    var iv = encrypted.slice(0 + salt_len, salt_len + iv_len);
    var key = crypto.pbkdf2Sync(
      process.env.pepper_for_enc,
      salt,
      100000,
      256 / 8,
      "sha256"
    );


    var decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);

    decipher.write(encrypted.slice(salt_len + iv_len));
    decipher.end();

    const decrypted = decipher.read();
    return decrypted.toString();
  } catch (err) {
    console.log("decryptedPrivateKey Error: ", err);
  }
};

const encryptedPrivateKeys = async (data) => {
  try {
    var salt = crypto.randomBytes(16);
    var iv = crypto.randomBytes(16);
    var key = crypto.pbkdf2Sync(
      process.env.pepper_for_enc,
      salt,
      100000,
      32,
      "sha256"
    );
    var cipher = crypto.createCipheriv("aes-256-cbc", key, iv);
    cipher.write(data);
    cipher.end();

    var encrypted = cipher.read();

    return Buffer.concat([salt, iv, encrypted]).toString("base64");
  } catch (err) {
    console.log("encryptedPrivateKeys Error:", err);
  }
};

const getETHBalance = async (sender) => {
  try {
    console.log(sender);
    const balance = await provider.getBalance(sender);
    return ethers.utils.formatEther(balance);
  } catch (err) {
    console.log("ETH balance Error : ", err);
  }
};

const createETHAccount = async () => {
  try {
    var newAccount = ethers.Wallet.createRandom();
    var privateKey = await encryptedPrivateKeys(newAccount.privateKey);
    var newAddress = newAccount.address;
    // console.log(newAccount, "newAccount");
    // console.log( privateKey, "privateKey");
    // console.log(newAddress, "dataaaaa");
    

    return { privateKey, newAddress };
  } catch (err) {
    console.log("createETHAccount error:", err);
  }
};

const createInvoiceETH = async (req, res) => {
  try {
    const { email, cryptoAmount, amount, currency, publicKey, clientId } = req.body;

    // Find user by clientId
    const user = await userModel.findOne({ userId: clientId });
    if (!user) {
      return res.status(404).send({
        code: "404",
        status: "Not Found",
        message: "User not found",
        data: [],
      });
    }

    // Check if the user already has an ETH account
    let usdtAccount = user.coins.find(coin => coin.currency === "USDT_ERC20");
          let ethAccount = user.coins.find(coin => coin.currency === "ETH");
   
    let accountNumber;
    if (ethAccount) {
      // Prioritize existing ETH account
      console.log('ethAccount: ', ethAccount);
      accountNumber = ethAccount.address;
      privateKey = ethAccount.privateKey;
  } else if (usdtAccount) {
      // If no ETH account, use USDT account details
      accountNumber = usdtAccount.address;
      privateKey = usdtAccount.privateKey;
  
      // Create a new ETH entry using USDT account details
      user.coins.push({ 
          currency: "ETH", 
          address: accountNumber,
          privateKey: privateKey 
      });
      await user.save();
  } else {
      // Create new ETH account if no existing ETH or USDT account found
      const newAccount = await createETHAccount();
      console.log('in else condition for ETH account')
      
      if (!newAccount || !newAccount.newAddress || !newAccount.privateKey) {
          throw new Error("Failed to create ETH account");
      }
      
      accountNumber = newAccount.newAddress;
      privateKey = newAccount.privateKey;
  
      // Save the newly created ETH account to the user's coins
      user.coins.push({ 
          currency: "ETH", 
          address: accountNumber, 
          privateKey: privateKey 
      });
      await user.save();
  }

    const rateData = await Coinrate.findOne({});
    if (!rateData) throw new Error("Rate data not found");

    const rate = rateData.usd_rate.ETH;
                //txnid lgic
      txnId = ""

    // Calculate usdAmount and paidAmount based on cryptoAmount
    const usdAmount = cryptoAmount ? (amount * rate).toFixed(6) : amount.toFixed(6);
    const paidAmount = cryptoAmount ? amount.toFixed(6) : (amount / rate).toFixed(6);
    const timeout = Date.now() + 14400000; // 4-hour timeout

    // Create the invoice entry
    const new_task = {
      userId: clientId,
      email,
      cryptoAmount,
      amount,
      usdAmount,
      paidAmount,
      currency,
      balance: 0,
      newAccount: { accountNumber },
      rate: rate.toFixed(6),
      timestamp: Date.now(),
      timeout,
      cold_trans_done: false,
      publicKey,
      txnId
    };

    const newInvoice = await Invoice.create(new_task);

    // Log the entire `newInvoice` object for debugging
    console.log("Created new invoice:", newInvoice);

    // Calculate remaining time
    const remainingTime = new Date(timeout - Date.now()).toISOString().substr(11, 8);

    res.status(200).send({
      code: "200",
      status: "OK",
      message: "Invoice created successfully",
      data: {
        paymentStatus: "PENDING",
        name: newInvoice.name || "Unnamed", // Fallback if `name` is undefined
        usdAmount,
        totalRemainingAmount: paidAmount,
        totalAmount: paidAmount,
        conversionRate: rate.toFixed(6),
        paymentId: newInvoice._id.toString(), // Ensure _id is in string format
        emailAddress: email,
        currency,
        totalReceivedAmount: 0,
        address: accountNumber,
        statusUrl: `${staticUrl}/#/invoice/${newInvoice._id}`,
        remainingTime,
        paymentQRCode: accountNumber,
        txnId:txnId,
      },
    });
  } catch (err) {
    console.error("createInvoiceETH error:", err); // Log the full error object
    res.status(500).send({
      code: "500",
      status: "Internal Server Error",
      message: err.message || "An error occurred while creating the invoice",
      data: [],
    });
  }
};


const estimateGasForETHTransaction = async (sender, receiver, amount) => {
  try {
    const gasPrice = await provider.getGasPrice();
    const estimatedGas = await provider.estimateGas({
      to: receiver,
      value: ethers.utils.parseEther(amount.toString()),
    });

    const transactionFee = gasPrice.mul(estimatedGas);
    const transactionFeeInEther = ethers.utils.formatEther(transactionFee);

    return {
      txFee: transactionFeeInEther,
      gasPrice: gasPrice.toString(),
      gasLimit: estimatedGas.toString(),
    };
  } catch (err) {
    console.log("Estimate ETHgas Error : ", err);
  }
};


const invoiceStatusETH = async (req, res, invoiceUser, timer) => {
    try {
        const balance = await getAccountBalance(invoiceUser.newAccount.accountNumber);
      //   const { adminAmount, merchantAmount, merchantAddress } = await calculateFees(invoiceUser);
        const remainingCurrencyAmount = calculateRemainingAmount(invoiceUser.paidAmount, balance);
        // 0 signifies the adminamount and merchantAmount
        var adminamount = 0;
        var merchantAmount = 0;
        const userAmount = calculateUserAmount(invoiceUser.paidAmount, 0, 0);



        var merchantAddress = '0xa753D424238EA7271eF05a01C5c056f084717D3A';
        if (remainingCurrencyAmount <= 0) {
            logger.info('remainingCurrencyAmount is higher than 0')
            await processCompletedPayment(req, res, invoiceUser, balance, adminamount, merchantAmount, merchantAddress, userAmount);
        } else {
            logger.info('remainingCurrencyAmount is lower than 0')
            sendPendingPaymentResponse(res, invoiceUser, balance, remainingCurrencyAmount, timer);
        }
    } catch (err) {
        console.error("Error in invoiceStatusETH: ", err);
        res.status(500).json({ error: "Internal server error" });
    }
};

// Helper functions
const getAccountBalance = async (accountNumber) => {
    const balanceWei = await web3eth.eth.getBalance(accountNumber);
    return Number(web3eth.utils.fromWei(balanceWei, "ether"));
};

const calculateFees = async (invoiceUser) => {
    const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });
    const adminAmount = adminWallet.txFees;

    const merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
    let merchantRate = 0, merchantAmount = 0, merchantAddress;

    if (merchantFees) {
        const fee = merchantFees.feeObject.find(value => value.currency === invoiceUser.currency);
        if (fee) {
            merchantRate = fee.rate;
            merchantAddress = fee.address;
            merchantAmount = Number((invoiceUser.paidAmount * merchantRate / 100).toFixed(6));
        }
    }

    return { adminAmount, merchantAmount, merchantAddress };
};

const calculateRemainingAmount = (paidAmount, balance) => {
    return Number(paidAmount - balance).toFixed(6);
};

const calculateUserAmount = (paidAmount, adminAmount, merchantAmount) => {
    return Number(paidAmount - adminAmount - merchantAmount).toFixed(6);
};



const sweepEthereumAddress = async  (fromAddress, toAddress, privateKey) =>  {
    try {
        // Get the current balance
        const balance = await web3eth.eth.getBalance(fromAddress);
        logger.info('balance of the address: ', balance);
      // Get the current gas price
      const gasPrice = await web3eth.eth.getGasPrice();

      // Estimate the gas required for the transaction
      const gasLimit = await web3eth.eth.estimateGas({
          to: toAddress,
          value: balance
      });

      logger.info('gaslimit: ', gasLimit);
      // Calculate the transaction fee
      const txFee = BigInt(gasPrice) * BigInt(gasLimit);

      // Calculate the amount to send (balance minus transaction fee)
      const amountToSend = BigInt(balance) - txFee;
      logger.info('amountToSend: ', amountToSend);
      // Ensure the amount to send is positive
      if (amountToSend <= BigInt(0)) {
          throw new Error("Insufficient funds to cover the transaction fee");
      }

        // Create the transaction object
        const txObject = {
            from: fromAddress,
            to: toAddress,
            value: amountToSend.toString(),
            gas: gasLimit,
            gasPrice: gasPrice
        };

        // Sign the transaction
        const signedTx = await web3eth.eth.accounts.signTransaction(txObject, privateKey);

        // Send the transaction
        const receipt = await web3eth.eth.sendSignedTransaction(signedTx.rawTransaction);
       

        console.log(`Transaction successful with hash: ${receipt.transactionHash}`);
        return receipt;
    } catch (error) {
        console.error('Error in sweeping address:', error);
        return error
        throw error;
    }
}

const processCompletedPayment = async (req, res, invoiceUser, balance, adminAmount, merchantAmount, merchantAddress, userAmount) => {

    // const accountAddress = await getAccountAddress(invoiceUser.userEmail, invoiceUser.currency);
    // const { transactionFee, gasPrice, gasLimit } = await estimateTransactionFees(invoiceUser, accountAddress, userAmount, adminAmount, merchantAmount);

    // userAmount = adjustUserAmountForFees(userAmount, transactionFee);
    logger.info('ProcessCompleted Payment Initiated');
    const decryptedPrivateKey = await decryptePrivateKey(invoiceUser.newAccount.privateKey);

    if (merchantAmount > 0) {
        await sendTransaction(invoiceUser.newAccount.accountNumber, merchantAddress, merchantAmount, gasLimit, decryptedPrivateKey);
    }
    // payment for the address AdminAdress reciver: 
    var AdminAddress = '0xa753D424238EA7271eF05a01C5c056f084717D3A';
    const userTransaction = await sendTransaction(invoiceUser.newAccount.accountNumber,AdminAddress , userAmount, decryptedPrivateKey);
    if (userTransaction && userTransaction.transactionHash) {
        // Only proceed with these actions if we have a valid transaction receipt
        await updateDatabase(req.body.id, invoiceUser, userTransaction, userAmount);
       // await sendTransactionEmail(invoiceUser, userTransaction, AdminAddress);
        await updateTransactionHistory(invoiceUser, userTransaction, adminAmount, AdminAddress);
        sendSuccessResponse(res, invoiceUser, balance);
    } else {
        throw new Error('Failed to get transaction receipt for user transaction');
    }
    


};

const getAccountAddress = async (userEmail, currency) => {
    const accountInfo = await Acc_Balance.findOne({ email: userEmail });
    return accountInfo.accounts.find(account => account.symbol === currency).account_number;
};

const estimateTransactionFees = async (invoiceUser, accountAddress, userAmount, adminAmount, merchantAmount) => {
    const transReq = await estimateGasForETHTransaction(invoiceUser.newAccount.accountNumber, accountAddress, userAmount);
    let transactionFee = transReq.txFee;

    if ((adminAmount > 0) && (merchantAmount > 0)) {
        transactionFee *= 3;
    } else if ((adminAmount > 0) || (merchantAmount > 0)) {
        transactionFee *= 2;
    }

    return { transactionFee, gasPrice: transReq.gasPrice, gasLimit: transReq.gasLimit };
};

const adjustUserAmountForFees = (userAmount, transactionFee) => {
    return Number(userAmount - transactionFee).toFixed(6);
};

const sendTransaction = async (from, to, amount, privateKey) => {
    // const transaction = await web3eth.eth.accounts.signTransaction(
    //     {
    //         from,
    //         to,
    //         value: web3eth.utils.toWei(amount.toString(), "ether"),
    //         gas: gasLimit
    //     },
    //     privateKey
    // );
    // return web3eth.eth.sendSignedTransaction(transaction.rawTransaction);

    // fromAddress, toAddress, privateKey
     console.log('inside sendTransactions')
     var response = await sweepEthereumAddress(from, to, privateKey);
     return response;
};

const updateDatabase = async (id, invoiceUser, transaction, amount) => {
    await Invoice.updateOne({ _id: id }, { cold_trans_done: true });

    const newTask = new InvoiceTransaction({
        paymentId: id,
        paidAmount: invoiceUser.paidAmount,
        Transaction: { ...transaction, amount, timestamp: Date.now() },
    });
    await newTask.save();
};



const sendTransactionEmail = async (invoiceUser, transaction, accountAddress) => {
    const link = `https://${process.env.eth_explorer_url}/tx/${transaction.transactionHash}`;
    const emailBody = {
        email: invoiceUser.email,
        firstName: "User",
        amount: invoiceUser.paidAmount,
        currency: invoiceUser.currency,
        paidfrom: invoiceUser.newAccount.accountNumber,
        paidto: accountAddress,
        transactionId: transaction.transactionHash,
        formattedTime: Date.now(),
        link,
    };

    await transactionEmail(emailBody);
};

const updateTransactionHistory = async (invoiceUser, transaction, adminAmount, accountAddress) => {
    const user = await users.findOne({ email: invoiceUser.userEmail });
    const merchantObject = {
        email: invoiceUser.email,
        ip: ip.address(),
        txId: transaction.transactionHash,
        fee: 0,
        currency: invoiceUser.currency,
        paidFrom: invoiceUser.newAccount.accountNumber,
        senderTag: "",
        receiverTag: "",
        amount: invoiceUser.paidAmount,
        usdRate: invoiceUser.rate,
        adminFee: adminAmount,
        actualamount: invoiceUser.paidAmount,
        ordertype: "",
        description: "",
        status: 1,
        transactionType: "MerchantApi",
        explorer: `https://${process.env.eth_explorer_url}/tx/${transaction.transactionHash}`,
        paidTo: accountAddress,
        initiatedDate: Date.now(),
        confirmedDate: Date.now()
    };


    const InvoceTransactionHistory = new InvoiceTransaction({
        invoiceID: invoiceUser._id,
        email: invoiceUser.email,
        paidAmount: invoiceUser.paidAmount,
        Transaction: {merchantObject} // Store public key as-is
      });
      const data = await InvoceTransactionHistory.save();   

      logger.info('Data from transaction History: ', data);

};

const sendSuccessResponse = (res, invoiceUser, balance) => {
    res.status(200).json({
        code: 200,
        status: "OK",
        message: "successful",
        data: {
            paymentStatus: "PAID",
            paymentId: invoiceUser._id,
            emailAddress: invoiceUser.email,
            name: invoiceUser.name,
            usdAmount: invoiceUser.usdAmount,
            totalRemainingAmount: 0,
            currency: invoiceUser.currency,
            totalAmount: invoiceUser.paidAmount,
            totalReceivedAmount: balance,
            conversionRate: invoiceUser.rate,
            address: invoiceUser.newAccount.accountNumber,
            remainingTime: "00:00:00",
            paymentQRCode: invoiceUser.newAccount.accountNumber,
        },
    });
};

const sendPendingPaymentResponse = (res, invoiceUser, balance, remainingCurrencyAmount, timer) => {
    res.status(200).json({
        code: "200",
        status: "OK",
        message: "Successful",
        data: {
            paymentStatus: "PENDING",
            paymentId: invoiceUser._id,
            emailAddress: invoiceUser.email,
            name: invoiceUser.name,
            usdAmount: invoiceUser.usdAmount,
            totalRemainingAmount: remainingCurrencyAmount,
            currency: invoiceUser.currency,
            totalAmount: invoiceUser.paidAmount,
            totalReceivedAmount: balance,
            conversionRate: invoiceUser.rate,
            address: invoiceUser.newAccount.accountNumber,
            remainingTime: `${timer.hours}:${timer.minutes}:${timer.seconds}`,
            paymentQRCode: invoiceUser.newAccount.accountNumber,
            txnId:""
        },
    });
};

const startInvoiceCronETH = () => {
  cron.schedule('*/15 * * * *', async () => {
      try {
          console.log('Running invoice cron job...');
          
          // Find all pending invoices that haven't been processed
          const pendingInvoices = await Invoice.find({
              cold_trans_done: false,
              timeout: { $gt: Date.now() } // Only process non-expired invoices
          });

          // Process each pending invoice
          for (const invoice of pendingInvoices) {
              try {
                  await invoiceCronETH(invoice);
              } catch (error) {
                  console.error(`Error processing invoice ${invoice._id}:`, error);
                  // Continue with next invoice even if one fails
              }
          }

      } catch (error) {
          console.error('Error in invoice cron job:', error);
      }
  });
};

const invoiceCronETH = async () => {
    try {

      var expireTime = Date.now() - 28800000; // Expiry time calculation (8 hours)
      //Invoice data fetch
        const invoices = await Invoice.find({ 
              paymentStatus: "PENDING", 
              currency: "ETH", 
              timestamp: { $gt: expireTime } 
          });
          
          if (!invoices || invoices.length === 0) {
              console.log("No pending invoices found.");
              return;
          }
  
          for (const invoiceUser of invoices) {
              if (!invoiceUser || !invoiceUser.newAccount || !invoiceUser.newAccount.accountNumber) {
                  console.error("Invalid invoice: newAccount missing", invoiceUser);
                  continue;
              }

        var balance = web3eth.utils.fromWei(await web3eth.eth.getBalance(invoiceUser.newAccount.accountNumber), "ether");
        balance = Number(balance);

        const currency = 'ETH'; 

        const adminWallet = await AdminWallet.findOne({ "currency.coin": currency });

        // var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        // var merchantRate = 0, merchantAmount = 0, merchantAddress;
        // if (merchantFees) {
        //     merchantFees = merchantFees.feeObject
        //     for (value of merchantFees) {
        //         if (value.currency == invoiceUser.currency) {
        //             merchantRate = value.rate;
        //             merchantAddress = value.address
        //             break;
        //         }
        //     }
        // }

        // if (merchantRate > 0) {
        //     merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6);
        // }

        console.log(adminAmount, 'adminAmt', invoiceUser.paidAmount, 'invoiceUser.paidAmount', balance, 'balance')
        var remainingCurrencyAmount = invoiceUser.paidAmount - balance;
        // var userAmount = +invoiceUser.paidAmount - +adminAmount - +merchantAmount;
        var userAmount = +invoiceUser.paidAmount - +adminAmount;

        console.log(remainingCurrencyAmount, 'remainingCurrencyAmount', userAmount, 'userAmount')

        if (remainingCurrencyAmount <= 0) {

            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == invoiceUser.currency) {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            const transReq = await estimateGasForETHTransaction(invoiceUser.newAccount.accountNumber, accountAddress, userAmount);
            console.log(transReq, 'transReq')
            var transactionFee = transReq.txFee;
            var gasPrice = transReq.gasPrice;
            var gasLimit = transReq.gasLimit;
            console.log(transactionFee, gasPrice, gasLimit)
            //if adminFees then calculate txFees for admin as well
            if ((adminAmount > 0) && (merchantAmount > 0)) {
                transactionFee = transactionFee * 3;
            } else if ((adminAmount > 0) || (merchantAmount > 0)) {
                transactionFee = transactionFee * 2;
            }

            //deduct transactionFee from userAmount;
            console.log(userAmount, "before")
            userAmount = userAmount - transactionFee;
            console.log(userAmount, "after")
            if (userAmount > 0) {
                var decryptedPrivateKey = await decryptePrivateKey(
                    invoiceUser.newAccount.privateKey
                );

                if (merchantAmount > 0) {
                    const transaction = await web3eth.eth.accounts.signTransaction(
                        {
                            from: invoiceUser.newAccount.accountNumber,
                            to: merchantAddress,
                            value: web3eth.utils.toWei(merchantAmount.toString(), "ether"),
                            //gasPrice: gasPrice,
                            gas: gasLimit
                        },
                        decryptedPrivateKey
                    );
                    await web3eth.eth.sendSignedTransaction(
                        transaction.rawTransaction
                    );
                }

                //user transaction
                const ETHTransaction = await web3eth.eth.accounts.signTransaction(
                    {
                        from: invoiceUser.newAccount.accountNumber,
                        to: accountAddress,
                        value: web3eth.utils.toWei(userAmount.toString(), "ether"),
                        //gasPrice: gasPrice,
                        gas: gasLimit
                    },
                    decryptedPrivateKey
                );
                var ETHReceipt = await web3eth.eth.sendSignedTransaction(
                    ETHTransaction.rawTransaction
                );
                console.log(
                    `Transaction successful with hash: ${ETHReceipt.transactionHash}`
                );
                var trans = ETHReceipt.transactionHash;
                ETHReceipt.amount = userAmount;
                ETHReceipt.timestamp = Date.now();
                await Invoice.updateOne(
                    { _id: invoiceUser._id },
                    { cold_trans_done: true }
                );
                var new_task = new InvoiceTransaction({
                    paymentId: invoiceUser._id,
                    paidAmount: invoiceUser.paidAmount,
                    Transaction: ETHReceipt,
                });
                new_task.save();

                //console.log(adminWallet[0].walletAddress, adminWallet[0].txFees, decryptedPrivateKey,'9jg')
                if (adminAmount > 0) {
                    console.log('adminfees')
                    const adminETHTransaction =
                        await web3eth.eth.accounts.signTransaction(
                            {
                                from: invoiceUser.newAccount.accountNumber,
                                to: adminWallet.walletAddress,
                                value: web3eth.utils.toWei(adminAmount.toString(), "ether"),
                                //gasPrice: gasPrice,
                                gas: gasLimit
                            },
                            decryptedPrivateKey
                        );

                    var adminETHReceipt = await web3eth.eth.sendSignedTransaction(adminETHTransaction.rawTransaction);

                    await InvoiceTransaction.updateOne(
                        { paymentId: invoiceUser._id },
                        { adminTransaction: adminETHReceipt }
                    );
                    console.log(`admin Transaction successful with hash: ${adminETHReceipt.transactionHash
                        }`);
                }

                var formattedTime = Date.now();
                const transactionId = ETHReceipt.transactionHash;
                var emailProvider, companyName, domain
                if (invoiceUser.emailProvider) {
                    emailProvider = invoiceUser.emailProvider;
                    companyName = invoiceUser.companyName;
                    domain = invoiceUser.domain
                }
                var link = `https://${process.env.eth_explorer_url}/tx/${transactionId}`
                const emailBody = {
                    email: invoiceUser.email,
                    firstName: "User",
                    amount: invoiceUser.paidAmount,
                    currency: invoiceUser.currency,
                    paidfrom: invoiceUser.newAccount.accountNumber,
                    paidto: accountAddress,
                    transactionId,
                    formattedTime,
                    link,
                    emailProvider,
                    apiName: invoiceUser.name,
                    companyName,
                    domain
                };

                await transactionEmail(emailBody);

                var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

                var Merchantobject = {

                    "email": invoiceUser.email,
                    "ip": ip.address(),
                    "txId": trans,
                    "fee": 0,
                    "currency": invoiceUser.currency,
                    "paidFrom": invoiceUser.newAccount.accountNumber,
                    "senderTag": "",
                    "receiverTag": "",
                    "amount": invoiceUser.paidAmount,
                    "usdRate": invoiceUser.rate,
                    "adminFee": adminAmount,
                    "actualamount": invoiceUser.paidAmount,
                    "ordertype": "",
                    "description": "",
                    "status": 1,
                    "transactionType": "MerchantApi",
                    "explorer": link,
                    "userId": user._id,
                    "paidTo": accountAddress,
                    "initiatedDate": formattedTime,
                    "confirmedDate": formattedTime

                }

                await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true });

            }
        }
      }
    } catch (err) {
        console.log('invoiceCronETH error:', err)
    }
}

// const refundTransactionETH = async (req, res, id, sender, receiver, privateKey) => {
//     try {
//         var amount = await getETHBalance(sender);
//         const transReq = await estimateGasForETHTransaction(sender, receiver, amount);
//         console.log(transReq, 'transReq')
//         var transactionFee = transReq.txFee;
//         var gasPrice = transReq.gasPrice;
//         var gasLimit = transReq.gasLimit;
//         console.log(transactionFee, gasPrice, gasLimit)
//         //if adminFees then calculate txFees for admin as well

//         //deduct transactionFee from userAmount;
//         console.log(amount, "before")
//         amount = amount - transactionFee;
//         console.log(amount, "after")
//         var decryptedPrivateKey = await decryptePrivateKey(privateKey);

//         //user transaction
//         const ETHTransaction = await web3eth.eth.accounts.signTransaction(
//             {
//                 from: sender,
//                 to: receiver,
//                 value: web3eth.utils.toWei(amount.toString(), "ether"),
//                 //gasPrice: gasPrice,
//                 gas: gasLimit
//             },
//             decryptedPrivateKey
//         );
//         var receipt = await web3eth.eth.sendSignedTransaction(
//             ETHTransaction.rawTransaction
//         );
//         console.log(
//             `Transaction successful with hash: ${receipt.transactionHash}`
//         );
//         if (receipt.transactionHash) {
//             const refundData = await Refund.findOneAndUpdate({ _id: id }, {
//                 refund_txid: receipt.transactionHash,
//                 refundConfirmed: true,
//                 toAddress:receiver,
//                 amount:amount.toFixed(6)
//             }, { new: true });
//             await sendEmail(id);
//             return res.status(200).json({
//                 code: 200,
//                 status: "OK",
//                 message: "Successful",
//                 data: {
//                     status: "PAID",
//                     paymentId: refundData.paymentId,
//                     currency: refundData.currency,
//                     amount: refundData.amount,
//                     address: refundData.toAddress,
//                     transactionHash: refundData.refund_txid,
//                     transactionHashRedirectURL:`https://${process.env.eth_explorer_url}/tx/` + refundData.refund_txid,
//                 },
//             });
//         }
//     } catch (err) {
//         console.log("refundTransaction error:",err)
//         return res.status(500).json({
//             code: 500,
//             status: "Error",
//             message: err.message,
//             data: {},
//         });
//     }
// }

// const sendEmail = async function (refundId) {

//     try {
//         const refundData = await Refund.findOne({ _id: refundId });
//         const email = refundData.email;
//         const currency = refundData.currency;
//         const amount = refundData.amount;
//         const toAddress = refundData.toAddress;
//         const txId = refundData.refund_txid;
//         var emailProvider = refundData.emailProvider;
//         var apiKey = refundData.apiKey;
//         var companyName = refundData.companyName;
//         var domain = refundData.domain;

//         const emailBody = {
//             email,
//             currency,
//             amount,
//             toAddress,
//             txId,
//             emailProvider,
//             apiKey,
//             companyName,
//             domain
//         }
//         console.log("mail initiated")
//         await refundTransactionMail(emailBody);
//         console.log("mail confirmed")
//     } catch (err) {
//         console.log("Error in sendEmail: ", err)
//     }
// }

module.exports = {
  createInvoiceETH,
  invoiceStatusETH,
  createETHAccount,
  invoiceCronETH,
  startInvoiceCronETH
  // getETHBalance,
  // refundTransactionETH
};
