const express = require('express');
const   ERC20_USDT  = require('../controllers/Invoices/Ethereum/USDT/ERC20_USDT')
const  {publicInvoiceStatus} = require('../controllers/Invoices/InvoiceStatus/InvoiceStatus')
const validateApiKeys = require('../middleware/authMiddleware')

const router = express.Router();

router.post("/createERC20Invoice", ERC20_USDT.createInvoiceERC20);

// router.post("/createInvoiceETH", eth.createInvoiceETH);

// router.post("/publicInvoiceStatus", publicInvoiceStatus);


module.exports = router;