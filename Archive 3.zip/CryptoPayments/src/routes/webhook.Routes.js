const express = require('express');

const webhook = require('../controllers/Webhook/webhookNotification');


const router = express.Router();


router.post("/paymentstatus", webhook.webhook);


module.exports = router;
