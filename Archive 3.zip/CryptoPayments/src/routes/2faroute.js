const express = require('express');

const fA = require('../controllers/2FA/test2fa')

const router = express.Router();

// router.route('/')
//     .get(getUsers)      // GET /api/users
//     .post(createUser);   // POST /api/users

router.post("/2facreatee", fA.create_2FA_Google);


router.post("/2favalidate", fA.validate_2FA_Google_Token);

router.post("/2facitvate", fA.activate_2FA_Google);



module.exports = router;