const express = require('express');

const withdraw = require('../controllers/Withdrawals/Withdraw/withdrawal');
const invoiceWithdraw = require('../controllers/Withdrawals/Withdraw/invoiceWithdrawal');



const router = express.Router();

router.post("/withdrawal", withdraw.createWithdraw);
router.post("/invoice_withdrawal", invoiceWithdraw.getWithdrawInvoice);

// Create 2FA Auth
// const withdrawController = require('../controllers/Withdrawals/ETH/withdraw_ETH');
// router.get("/ETH_withdraw1", withdrawController.generate2FASecret);

module.exports = router;
