const express = require('express');
const  { createInvoice } = require('../controllers/Invoices/createInvoice')
const  {publicInvoiceStatus} = require('../controllers/Invoices/InvoiceStatus/InvoiceStatus')
const  {startInvoiceCrontrc20} = require('../controllers/Invoices/Ethereum/USDT/ERC20_USDT')
const validateApiKeys = require('../middleware/authMiddleware')

const router = express.Router();

// router.post("/createInvoice",validateApiKeys, createInvoice);

router.post("/createInvoice", createInvoice);

router.post("/publicInvoiceStatus", publicInvoiceStatus);
// router.post("/cron", startInvoiceCrontrc20);




module.exports = router;