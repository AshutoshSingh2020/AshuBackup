const express = require('express');
const { createUserRequest } = require('../controllers/users/userController');
const   { cleanBody }   = require('../middleware/requestbody/cleanbody')
const  usdRate  = require('../helpers/coinToUSDRate/usdRate');


const router = express.Router();


router.post("/register",cleanBody, createUserRequest);

router.post("/coinUSDRate", usdRate);



module.exports = router;