const express = require('express');
const   eth  = require('../controllers/Invoices/Ethereum/ETH/eth')
const  {publicInvoiceStatus} = require('../controllers/Invoices/InvoiceStatus/InvoiceStatus')
const validateApiKeys = require('../middleware/authMiddleware')

const router = express.Router();

router.post("/createEthAccount", eth.createETHAccount);

router.post("/createInvoiceETH", eth.createInvoiceETH);

router.post("/publicInvoiceStatus", publicInvoiceStatus);


module.exports = router;