const KeyPair = require('../models/Keys/Keypair');
const { decrypt, hashKey } = require('../helpers/crypto/cryptoHelper');

const validateAPIKey = async (req, res, next) => {
    try {
        const { publicKeyHash } = req.body;
    
        if (!publicKeyHash) {
            return res.status(400).json({ message: 'Public key hash is required in headers' });
        }

        const keyPair = await KeyPair.findOne({ publicKeyHash });
        if (!keyPair) {
            return res.status(401).json({ message: 'Invalid API Key' });
        }

        const decryptedPublicKey = decrypt(keyPair.publicKey);
        const hashedDecryptedPublicKey = hashKey(decryptedPublicKey);

        if (hashedDecryptedPublicKey !== publicKeyHash) {
            return res.status(401).json({ message: 'Public key hash does not match' });
        }
        
        console.log('Middleware authenticated');
        next();

    } catch (error) {
        console.error('Error:', error.message);
        return res.status(400).send({
            code: "400",
            status: "Fail",
            message: "Error processing the request",
            data: [error.message],
        });
    }
};

module.exports = validateAPIKey;
