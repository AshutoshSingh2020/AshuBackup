const crypto = require('crypto');
const KeyPair = require('../models/Keys/Keypair');
const { encrypt, hashKey } = require('../helpers/crypto/cryptoHelper');

async function generateKeyPair(clientId, email) {
    try {
        const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
            modulusLength: 2048,
            publicKeyEncoding: { type: 'spki', format: 'pem' },
            privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
        });

        const publicKeyHex = encrypt(publicKey);
        const privateKeyHex = encrypt(privateKey);
        const publicKeyHash = hashKey(publicKey);

        const keyPair = new KeyPair({
            userId: clientId,
            publicKey: publicKeyHex,
            privateKey: privateKeyHex,
            publicKeyHash: publicKeyHash
        });
        await keyPair.save();

        return {
            publicKeyHash,
            publicKeyHex,
            privateKeyHex
        };
    } catch (error) {
        console.error('Error generating key pair:', error);
        throw error;
    }
}

module.exports = {
    generateKeyPair,
    hashKey,
};
