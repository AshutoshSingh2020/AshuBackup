
var mongoose = require("mongoose");
// const Invoice = require("../../models/invoiceDataModel");
// const InvoiceFee = require("../../models/invoiceFees");
// const Api = require("../../models/apiModel");
// const Backup = require("../../models/backupModel");
// const Acc_Balance = require("../../models/dashboard_balance");
// const InvoiceTransaction = require("../../models/Invoice_transactionModel");
// const AdminWallet = require("../../models/adminWalletModel");
// const users = require("../../models/user.model");
// const { transactionEmail } = require("./../../../utils/transactionEmail");
// const Transaction_History = mongoose.model("Transaction_History");
// const Coinrate = require("../../models/coinRate");
// const Refund = require("../../models/confirmRefundModel");
// const { refundTransactionMail } = require("../../../utils/refundTransactionMail");


const Invoice = require("../../../models/Invoices/invoiceModel");
const users = require('../../../models/userModel');
const Coinrate = require("../../../models/coinrates/usdRate");
const InvoiceTransaction = require("../../../models/Invoices/invoiceTransactionModel");
const AdminWallet = require("../../../models/adminWallet");
const crypto = require("crypto");
var ip = require("ip");
// const rp = require("request-promise");
// const MerchantFees = require("../../models/merchantFees");

console.log('Payments for BTC')

const decryptePrivateKey = (data) => {
    try {
        var encrypted = Buffer.from(data, 'base64');
        var salt_len = 16, iv_len = 16;

        var salt = encrypted.slice(0, salt_len);

        var iv = encrypted.slice(0 + salt_len, salt_len + iv_len);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 256 / 8, 'sha256');

        var decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);

        decipher.write(encrypted.slice(salt_len + iv_len));
        decipher.end();

        const decrypted = decipher.read();
        return decrypted.toString()
    } catch (err) {
        console.log('decryptedPrivateKey Error: ', err)
    }
};

const encryptedPrivateKeys = async (data) => {
    try {

        var salt = crypto.randomBytes(16);
        var iv = crypto.randomBytes(16);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 32, 'sha256');
        var cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        cipher.write(data);
        cipher.end()

        var encrypted = cipher.read();

        return Buffer.concat([salt, iv, encrypted]).toString('base64')
    } catch (err) {
        console.log("encryptedPrivateKeys Error:", err)
    }
};

const get_address = function (wallet) {
    try {
        // var username = USER;
        // var password = PASS;
        const username = process.env.RPC_USER;
        const password = process.env.RPC_PASSWORD;
        var auth =
            "Basic " + new Buffer(username + ":" + password).toString("base64");
        var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"getnewaddress","params":[]}`;
        var options = {
            url: `http://127.0.0.1:8080/wallet/${wallet}`,
            method: "POST",
            headers: {
                Authorization: auth,
            },
            body: dataString,
        };
        const a = rp(options)
            .then((data) => {
                return data;
            })
            .catch((err) => {
                console.log(err, ";;;;;;;");
            });

        return a;
    } catch (err) {
        console.log(err, "Error at line no. 310 in dashboard.js");
    }
};

const get_address_privKey = function (address, wallet) {
    try {
        const username = process.env.RPC_USER;
        const password = process.env.RPC_PASSWORD;
        // var username = USER;
        // var password = PASS;
        var auth =
            "Basic " + new Buffer(username + ":" + password).toString("base64");
        var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"dumpprivkey","params":["${address}"]}`;
        var options = {
            url: `http://127.0.0.1:8080/wallet/${wallet}`,
            method: "POST",
            headers: {
                Authorization: auth,
            },
            body: dataString,
        };
        const a = rp(options)
            .then((data) => {
                return data;
            })
            .catch((err) => {
                console.log(err, ";;;;;;;");
            });

        return a;
    } catch (err) {
        console.log(err, "Error at line no. 310 in dashboard.js");
    }
};

const balance_BTC = async function (wallet) {
    try {
        // const USER = process.env.RPC_USER;
        // const PASS = process.env.RPC_PASSWORD;

        const USER = process.env.RPC_USER;
        const PASS = process.env.RPC_PASSWORD;

        const bitcoinPort = process.env.bitcoin_tunnel_port
        var auth = "Basic " + new Buffer.from(USER + ":" + PASS).toString("base64");
        var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"getbalance","params":[]}`;
        var options = {
         //   url: `http://127.0.0.1:${bitcoinPort}/wallet/${wallet}`,
         url : `https://go.getblock.io/8a67bcbf1e084cb4b295dfef163b8085`,
            method: "POST",
            headers: {
                "Authorization": auth
            },
            body: dataString
        };
        const a = await rp(options).then((data) => {
            return data
        }).catch((err) => {
            return err.error
        })
        let bal = JSON.parse(a)
        bal = bal.result
        console.log('bitcoin balance ',bal)
        return bal;
    } catch (err) {
        console.log("Error in send_btc_swap:", err)
    }
}

const getBTCBalance = async function (address) {
    try {
        console.log(address, '-------')
        const requestOptions = {
            method: "GET",
            uri: `https://api.blockcypher.com/v1/btc/${process.env.bitcoin_network}/addrs/${address}/balance`,
            json: true,
            gzip: true,
        };

        var a = await rp(requestOptions)
            .then((data) => {
                return data;
            })
            .catch((err) => {
                console.log(err);
            });
    
        a = a.balance;
        a = a / 100000000;
        return a;
    } catch (err) {
        console.log('getBTCBalance error:', err);
    }
};

const send_btc = async function (address, wallet, amount) {
    var username = USER;
    var password = PASS;
    var auth =
        "Basic " + new Buffer(username + ":" + password).toString("base64");
    var dataString = `{"jsonrpc":"1.0","id":"curltext","method":"sendtoaddress","params":["${address}","${amount}"]}`;
    var options = {
        url: `http://127.0.0.1:8080/wallet/${wallet}`,
        method: "POST",
        headers: {
            Authorization: auth,
        },
        body: dataString,
    };
    var a = await rp(options)
        .then((data) => {
            return data;
        })
        .catch((err) => {
            console.log(err.error);
        });

    a = JSON.parse(a)
    a = a.result

    return a;
};

const createBTCAccount = async (wallet) => {
    try {
        var newAccount = await get_address(wallet);
        newAccount = JSON.parse(newAccount);
        var newAddress = newAccount.result;

        var privateKey = await get_address_privKey(newAddress, wallet);
        privateKey = JSON.parse(privateKey);
        privateKey = await encryptedPrivateKeys(privateKey.result)

        return { privateKey, newAddress };

    } catch (err) {
        console.log("createBTCAccount error:", err)
    }
}

const createInvoiceBTC = async (req, res) => {
    try {
        const { email, cryptoAmount, amount, currency, publicKey } = req.body;

        var usdAmount, paidAmount;

      //  var Auth = await Api.findOne({ publicKey: publicKey });
        var emailProvider, companyName, domain;
        // if (Auth.emailProviderStatus) {
        //     emailProvider = Auth.emailProvider;
        //     companyName = Auth.companyName;
        //     domain = (Auth.website).substring((Auth.website).indexOf('.') + 1)
        // }

        var rate = await Coinrate.findOne({});
        rate = rate.usd_rate.BTC;

       // const adminWallet = await AdminWallet.findOne({ currency: currency });
        const adminWallet = "BTC"
       // console.log(adminWallet.walletName)
        var account = await createBTCAccount(adminWallet);
        var accountNumber = account.newAddress;
        var privateKey = account.privateKey;
        var newAccount = {
            accountNumber,
            privateKey
        }

        if (cryptoAmount == true) {
            usdAmount = Number(amount * rate).toFixed(6);
            paidAmount = Number(amount).toFixed(6);
        } else {
            usdAmount = Number(amount).toFixed(6);
            paidAmount = Number(amount / rate).toFixed(6);
        }
        var new_task = {
            email: email,
            cryptoAmount: cryptoAmount,
            amount: amount,
            usdAmount: usdAmount,
            paidAmount: paidAmount,
          //  name: Auth.keyname,
            currency: currency,
            balance: 0,
            newAccount: newAccount,
            rate: rate.toFixed(6),
            timestamp: Date.now(),
            timeout: Date.now(),
            cold_trans_done: false,
          //  userEmail: Auth.user_id,
            emailProvider,
            companyName,
            domain,
           // refundLink: Auth.refundLink,
            publicKey: publicKey
        };
        const newInvoice = await Invoice.create(new_task);
        console.log(newInvoice, newInvoice._id, newInvoice)
        res.status(200).send({
            code: "200",
            status: "OK",
            message: "Successful",
            data: {
                paymentStatus: "PENDING",
                paymentId: newInvoice._id,
                emailAddress: email,
                name: newInvoice.name,
                usdAmount: usdAmount,
                totalRemainingAmount: paidAmount,
                currency: currency,
                totalAmount: paidAmount,
                totalReceivedAmount: 0,
                conversionRate: rate.toFixed(6),
                address: accountNumber,
                statusUrl: staticUrl + "/#/invoice/" + newInvoice._id,
                remainingTime: "03:59:59",
                paymentQRCode: accountNumber,
            },
        });
    } catch (err) {
        console.log("createInvoiceBTC error:", err)
    }

};

const invoiceStatusBTC = async (req, res, invoiceUser, timer) => {
    try {

        var balance = await getBTCBalance(invoiceUser.newAccount.accountNumber);
        balance = Number(balance);
        console.log(balance, 'balance')
        const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });

        var adminAmount = adminWallet.txFees;

        var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        var merchantRate = 0, merchantAmount = 0, merchantAddress;
        if (merchantFees) {
            merchantFees = merchantFees.feeObject
            for (value of merchantFees) {
                if (value.currency == invoiceUser.currency) {
                    merchantRate = value.rate;
                    merchantAddress = value.address
                    break;
                }
            }
        }

        if (merchantRate > 0) {
            merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6)
        }

        var remainingCurrencyAmount = Number(invoiceUser.paidAmount - balance).toFixed(6);
        var userAmount = Number(invoiceUser.paidAmount - adminAmount - merchantAmount).toFixed(6);

        console.log(remainingCurrencyAmount, userAmount, adminAmount)
        if (remainingCurrencyAmount <= 0) {

            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == invoiceUser.currency) {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            var BTCReceipt = await send_btc(
                accountAddress,
                adminWallet.walletName,
                userAmount
            );

            console.log(`Transaction successful with hash: ${BTCReceipt}`);

            if(merchantAmount > 0){
                var receipt = await send_btc(
                    merchantAddress,
                    adminWallet.walletName,
                    merchantAmount
                );
    
                console.log(`Transaction successful with hash: ${receipt}`);
            }
            
            await Invoice.updateOne(
                { _id: invoiceUser._id },
                { cold_trans_done: true }
            );
            var new_task = new InvoiceTransaction({
                paymentId: invoiceUser._id,
                paidAmount: invoiceUser.paidAmount,
                Transaction: BTCReceipt,
            });
            new_task.save();


            //console.log(adminWallet[0].walletAddress, adminWallet[0].txFees, decryptedPrivateKey,'9jg')




            var formattedTime = Date.now();
            const transactionId = BTCReceipt;
            var emailProvider, companyName, domain
            if (invoiceUser.emailProvider) {
                emailProvider = invoiceUser.emailProvider;
                companyName = invoiceUser.companyName;
                domain = invoiceUser.domain
            }
            var link = `https://${process.env.btc_explorer_url}/tx/${transactionId}`
            const emailBody = {
                email: invoiceUser.email,
                firstName: "User",
                amount: invoiceUser.paidAmount,
                currency: invoiceUser.currency,
                paidfrom: invoiceUser.newAccount.accountNumber,
                paidto: accountAddress,
                transactionId,
                formattedTime,
                link,
                emailProvider,
                apiName: invoiceUser.name,
                companyName,
                domain
            };

            await transactionEmail(emailBody);

            var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

            var Merchantobject = {

                "email": invoiceUser.email,
                "ip": ip.address(),
                "txId": transactionId,
                "fee": 0,
                "currency": invoiceUser.currency,
                "paidFrom": invoiceUser.newAccount.accountNumber,
                "senderTag": "",
                "receiverTag": "",
                "amount": invoiceUser.paidAmount,
                "usdRate": invoiceUser.rate,
                "adminFee": adminAmount,
                "actualamount": invoiceUser.paidAmount,
                "ordertype": "",
                "description": "",
                "status": 1,
                "transactionType": "MerchantApi",
                "explorer": link,
                "userId": user._id,
                "paidTo": accountAddress,
                "initiatedDate": formattedTime,
                "confirmedDate": formattedTime

            }

            await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true })

            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "PAID",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: 0,
                    currency: invoiceUser.currency,
                    totalAmount: invoiceUser.paidAmount,
                    totalReceivedAmount: invoiceUser.paidAmount,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                    statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                    remainingTime: "00:00:00",
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                },
            });

        } else {
            var response = {
                code: "200",
                status: "OK",
                message: "Successful",
                data: {
                    paymentStatus: "PENDING",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: remainingCurrencyAmount,
                    currency: invoiceUser.currency,
                    totalAmount: invoiceUser.paidAmount,
                    totalReceivedAmount: balance,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                    statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                    remainingTime:
                        timer.hours + ":" + timer.minutes + ":" + timer.seconds,
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                },
            };
            res.status(200).send(response);
        }


    } catch (err) {
        console.log(err, "Error in invoiceStatusBTC: ", err);
    }
}

const invoiceCronBTC = async (invoiceUser) => {
    try {

        var balance = await getBTCBalance(invoiceUser.newAccount.accountNumber);
        balance = Number(balance);
        console.log(balance, 'balance')
        const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });

        var adminAmount = adminWallet.txFees;

        var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        var merchantRate = 0, merchantAmount = 0, merchantAddress;
        if (merchantFees) {
            merchantFees = merchantFees.feeObject
            for (value of merchantFees) {
                if (value.currency == invoiceUser.currency) {
                    merchantRate = value.rate;
                    merchantAddress = value.address
                    break;
                }
            }
        }

        if (merchantRate > 0) {
            merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6)
        }

        var remainingCurrencyAmount = Number(invoiceUser.paidAmount - balance).toFixed(6);
        var userAmount = Number(invoiceUser.paidAmount - adminAmount - merchantAmount).toFixed(6);

        console.log(remainingCurrencyAmount, userAmount, adminAmount)
        if (remainingCurrencyAmount <= 0) {

            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == invoiceUser.currency) {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            var BTCReceipt = await send_btc(
                accountAddress,
                adminWallet.walletName,
                userAmount
            );

            console.log(`Transaction successful with hash: ${BTCReceipt}`);

            if(merchantAmount > 0){
                var receipt = await send_btc(
                    merchantAddress,
                    adminWallet.walletName,
                    merchantAmount
                );
    
                console.log(`Transaction successful with hash: ${receipt}`);
            }

            await Invoice.updateOne(
                { _id: invoiceUser._id },
                { cold_trans_done: true }
            );
            var new_task = new InvoiceTransaction({
                paymentId: invoiceUser._id,
                paidAmount: invoiceUser.paidAmount,
                Transaction: BTCReceipt,
            });
            new_task.save();

            var formattedTime = Date.now();
            const transactionId = BTCReceipt;
            var emailProvider, companyName, domain
            if (invoiceUser.emailProvider) {
                emailProvider = invoiceUser.emailProvider;
                companyName = invoiceUser.companyName;
                domain = invoiceUser.domain
            }
            var link = `https://${process.env.btc_explorer_url}/tx/${transactionId}`
            const emailBody = {
                email: invoiceUser.email,
                firstName: "User",
                amount: invoiceUser.paidAmount,
                currency: invoiceUser.currency,
                paidfrom: invoiceUser.newAccount.accountNumber,
                paidto: accountAddress,
                transactionId,
                formattedTime,
                link,
                emailProvider,
                apiName: invoiceUser.name,
                companyName,
                domain
            };

            await transactionEmail(emailBody);

            var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

            var Merchantobject = {

                "email": invoiceUser.email,
                "ip": ip.address(),
                "txId": transactionId,
                "fee": 0,
                "currency": invoiceUser.currency,
                "paidFrom": invoiceUser.newAccount.accountNumber,
                "senderTag": "",
                "receiverTag": "",
                "amount": invoiceUser.paidAmount,
                "usdRate": invoiceUser.rate,
                "adminFee": adminAmount,
                "actualamount": invoiceUser.paidAmount,
                "ordertype": "",
                "description": "",
                "status": 1,
                "transactionType": "MerchantApi",
                "explorer": link,
                "userId": user._id,
                "paidTo": accountAddress,
                "initiatedDate": formattedTime,
                "confirmedDate": formattedTime

            }

            await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true })

           

        }

    } catch (err) {
        console.log(err, "Error in invoiceCronBTC: ", err);
    }
}

const refundTransactionBTC = async (req, res, id, sender, receiver, privateKey,amount,currency) => {
    try {
        
        const adminWallet = await AdminWallet.findOne({ currency: currency });
        //var decryptedPrivateKey = await decryptePrivateKey(privateKey);

        var receipt = await send_btc(
            receiver,
            adminWallet.walletName,
            amount
        );

        console.log(`Transaction successful with hash: ${receipt}`);

        if (receipt) {
            const refundData = await Refund.findOneAndUpdate({ _id: id }, {
                refund_txid: receipt,
                refundConfirmed: true,
                toAddress:receiver,
                amount:amount
            }, { new: true });
            await sendEmail(id);
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "Successful",
                data: {
                    status: "PAID",
                    paymentId: refundData.paymentId,
                    currency: refundData.currency,
                    amount: refundData.amount,
                    address: refundData.toAddress,
                    transactionHash: refundData.refund_txid,
                    transactionHashRedirectURL:`https://${process.env.btc_explorer_url}/tx/` + refundData.refund_txid,
                },
            });
        }
    } catch (err) {
        console.log("refundTransaction error:",err)
        return res.status(500).json({
            code: 500,
            status: "Error",
            message: err.message,
            data: {},
        });
    }
}

const sendEmail = async function (refundId) {

    try {
        const refundData = await Refund.findOne({ _id: refundId });
        const email = refundData.email;
        const currency = refundData.currency;
        const amount = refundData.amount;
        const toAddress = refundData.toAddress;
        const txId = refundData.refund_txid;
        var emailProvider = refundData.emailProvider;
        var apiKey = refundData.apiKey;
        var companyName = refundData.companyName;
        var domain = refundData.domain;

        const emailBody = {
            email,
            currency,
            amount,
            toAddress,
            txId,
            emailProvider,
            apiKey,
            companyName,
            domain
        }
        console.log("mail initiated")
        await refundTransactionMail(emailBody);
        console.log("mail confirmed")
    } catch (err) {
        console.log("Error in sendEmail: ", err)
    }
}

module.exports = {
    createInvoiceBTC,
    invoiceStatusBTC,
    invoiceCronBTC,
    getBTCBalance,
    refundTransactionBTC,
    balance_BTC
}