var mongoose = require("mongoose");
const Invoice = require('../../../../models/Invoices/invoiceModel.js') // Invoice
const userModel = require('../../../../models/userModel');
// const InvoiceFee = require("../../models/invoiceFees");
//const Api = require("../../models/apiModel");
//const Backup = require("../../models/backupModel");
// const Acc_Balance = require("../../models/dashboard_balance");
const InvoiceTransaction = require("../../../../models/Invoices/invoiceTransactionModel.js");
// const AdminWallet = require("../../models/adminWalletModel");
// const users = require("../../../../models/userModel.js");
// const { transactionEmail } = require("./../../../utils/transactionEmail");
// const Transaction_History = mongoose.model("Transaction_History");
const CoinRate = require("../../../../models/coinrates/usdRate.js");
// const Refund = require("../../models/confirmRefundModel");
// const { refundTransactionMail } = require("../../../utils/refundTransactionMail")
const crypto = require("crypto");
var ip = require("ip");
const  { Web3 } = require("web3");
const web3eth = new Web3("https://sepolia.infura.io/v3/5d7769a2990747789f0c9f5927d5a860");
// const MerchantFees = require("../../models/merchantFees");

const staticUrl = "https://app.coinuniverze.com";

const decryptePrivateKey = (data) => {
    try {
        var encrypted = Buffer.from(data, 'base64');
        var salt_len = 16, iv_len = 16;

        var salt = encrypted.slice(0, salt_len);

        var iv = encrypted.slice(0 + salt_len, salt_len + iv_len);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 256 / 8, 'sha256');

        var decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);

        decipher.write(encrypted.slice(salt_len + iv_len));
        decipher.end();

        const decrypted = decipher.read();
        return decrypted.toString()
    } catch (err) {
        console.log('decryptedPrivateKey Error: ', err)
    }
};

const encryptedPrivateKeys = async (data) => {
    try {

        var salt = crypto.randomBytes(16);
        var iv = crypto.randomBytes(16);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 32, 'sha256');
        var cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        cipher.write(data);
        cipher.end()

        var encrypted = cipher.read();

        return Buffer.concat([salt, iv, encrypted]).toString('base64')
    } catch (err) {
        console.log("encryptedPrivateKeys Error:", err)
    }
};

const createETHAccount = async () => {
    try {
        var newAccount = web3eth.eth.accounts.create(web3eth.utils.randomHex(32));
        var privateKey = await encryptedPrivateKeys(newAccount.privateKey);
        var newAddress = newAccount.address;

        return { privateKey, newAddress };

    } catch (err) {
        console.log("createETHAccount error:", err)
    }
}

const createInvoiceERC20 = async (req, res) => {
    try {
        const { email, cryptoAmount, amount, currency, publicKey, clientId } = req.body;

        // Find user by clientId
        const user = await userModel.findOne({ userId: clientId });
        if (!user) {
            return res.status(404).send({
                code: "404",
                status: "Not Found",
                message: "User not found",
                data: [],
            });
        }

        // Check for existing ETH and USDT_ERC20 accounts
        let ethAccount = user.coins.find(coin => coin.currency === "ETH");
        let usdtAccount = user.coins.find(coin => coin.currency === "USDT_ERC20");
        let accountNumber;

        if (ethAccount) {
            // Use the existing ETH address
            accountNumber = ethAccount.address;

            // Add USDT_ERC20 entry if it does not exist
            if (!usdtAccount) {
                user.coins.push({
                    currency: "USDT_ERC20",
                    address: accountNumber,
                });
                await user.save();
            }
        } else if (usdtAccount) {
            // Use the existing USDT_ERC20 address
            accountNumber = usdtAccount.address;

            // Add ETH entry if it does not exist
            // user.coins.push({
            //     currency: "ETH",
            //     address: accountNumber,
            // });
             await user.save();
        } else {
            // Create a new ETH account if neither exists
            const account = await createETHAccount();
            accountNumber = account.newAddress;

            // Add both ETH and USDT_ERC20 accounts
            user.coins.push(
               // { currency: "ETH", address: accountNumber },
                { currency: "USDT_ERC20", address: accountNumber }
            );
            await user.save();
        }

        // Retrieve currency rate
        const rateData = await CoinRate.findOne({});
        const rate = currency === "SHIBA_ERC20" ? rateData.usd_rate.SHIB : rateData.usd_rate.SUPER;

        // Calculate USD and crypto amounts
        const usdAmount = cryptoAmount ? (amount * rate).toFixed(6) : amount.toFixed(6);
        const paidAmount = cryptoAmount ? amount.toFixed(6) : (amount / rate).toFixed(6);

        // Create new invoice task
        const new_task = {
            userId: clientId,
            email,
            amount,
            paidAmount,
            usdAmount,
            currency,
            rate: rate.toFixed(6),
            balance: 0,
            newAccount: { accountNumber },
            timestamp: Date.now(),
            timeout: Date.now() + 14400000, // 4 hours from now
            cold_trans_done: false,
            publicKey,
        };

        const newInvoice = await Invoice.create(new_task);

        // Calculate remaining time dynamically
        const remainingTime = new Date(new_task.timeout - Date.now()).toISOString().substr(11, 8);

        res.status(200).send({
            code: "200",
            status: "OK",
            message: "Invoice created successfully",
            data: {
                paymentStatus: "PENDING",
                name: newInvoice.name,
                usdAmount,
                totalRemainingAmount: paidAmount,
                totalAmount: paidAmount,
                conversionRate: rate.toFixed(6),
                paymentId: newInvoice._id,
                emailAddress: email,
                currency,
                totalReceivedAmount: 0,
                address: accountNumber,
                statusUrl: `${staticUrl}/#/invoice/${newInvoice._id}`,
                remainingTime,
                paymentQRCode: accountNumber,
            },
        });
    } catch (err) {
        console.error("createInvoiceERC20 error:", err);
        res.status(500).send({
            code: "500",
            status: "Internal Server Error",
            message: "An error occurred while creating the invoice",
            data: [],
        });
    }
};



const getERC20Balance = async (address, currency) => {
    try {
        // const Data1 = await TokenAddress.findOne({ symbol: currency });
        const Data1 = "0x195BED0123abeb4e68e2674c463E169E58dd510d"
        let token_Address = Data1.contract_Address

        let wallet_Address = address; // From address

        let min_ABI = JSON.parse(Data1.Abi)

        let contract0 = new web3eth.eth.Contract(min_ABI, token_Address, { from: wallet_Address })

        var balance = await contract0.methods.balanceOf(wallet_Address).call();
        balance = web3eth.utils.fromWei(balance, "ether");

        console.log("Balance of SUPER TOKEN :", balance);

        return balance
    } catch (err) {
        console.log("getSuperERC20Balance error: ", err)
    }
}

const getETHBalance = async (sender) => {

    try {
        const balance = web3eth.utils.fromWei(
            await web3eth.eth.getBalance(sender),
            'ether'
        );

        return balance;
    } catch (err) {
        console.log('ETH balance Error : ', err)
    }
}

const estimateGasTransaction = async (sender, receiver, amount, currency) => {

    try {
        console.log(sender, receiver, amount, currency, '====');

        const Data1 = await TokenAddress.findOne({ symbol: currency });

        let token_Address = Data1.contract_Address

        let wallet_Address = sender; // From address

        let min_ABI = JSON.parse(Data1.Abi)

        let contract0 = new web3eth.eth.Contract(min_ABI, token_Address, { from: wallet_Address })
        var gasLimit = await contract0.methods
            .transfer(receiver, web3eth.utils.toWei(amount.toString(), "ether"))
            .estimateGas({ from: sender });

        const gasPrice = await web3eth.eth.getGasPrice();
        var transactionFee = gasPrice * gasLimit;
        transactionFee = (await web3eth.utils.fromWei(transactionFee.toString(), 'ether'))

        return { txFee: transactionFee, gasPrice, gasLimit };

    } catch (err) {
        console.log("Estimate ETHgas Error : ", err)
    }
}

const ethTransaction = async (sender, receiver, amount, privateKey) => {
    try {
        const ETHTransaction = await web3eth.eth.accounts.signTransaction(
            {
                from: sender,
                to: receiver,
                value: web3eth.utils.toWei(amount.toString(), "ether"),
                gas: "21000",
            },
            privateKey
        );
        var receipt = await web3eth.eth.sendSignedTransaction(
            ETHTransaction.rawTransaction
        );

        receipt = receipt.transactionHash

        console.log(
            `eth Transaction successful with hash: ${receipt}`
        );
        return receipt;

    } catch (err) {
        console.log("ethTransaction error:", err)
    }
}

const sendERC20 = async (sender, amount, to_address, privateKey, currency) => {
    try {

        const Data1 = await TokenAddress.findOne({ symbol: currency });

        let token_Address = Data1.contract_Address

        let wallet_Address = sender; // From address

        let min_ABI = JSON.parse(Data1.Abi)
        let contract0 = new web3eth.eth.Contract(min_ABI, token_Address, { from: wallet_Address })

        var gasLimit = await contract0.methods
            .transfer(to_address, web3eth.utils.toWei(amount.toString(), "ether"))
            .estimateGas({ from: sender });

        var amount_value = await web3eth.utils.toWei(amount.toString(), 'ether')

        var data = contract0.methods.transfer(to_address, amount_value).encodeABI(); //Create the data for token transaction.

        var rawTransaction = { "to": token_Address, "gas": gasLimit, "data": data };

        const send = await web3eth.eth.accounts.signTransaction(rawTransaction, privateKey);

        // Deploy transaction
        var receipt = await web3eth.eth.sendSignedTransaction(send.rawTransaction);
        receipt = receipt.transactionHash
        console.log(`Transaction successful with hash: ${receipt}`);
        return receipt;
    } catch (err) {
        console.log("sendERC20 error: ", err)
        return null;
    }
}

const invoiceStatusERC20 = async (req, res, invoiceUser, timer) => {
    try {

        var balance = await getETHBalance(invoiceUser.newAccount.accountNumber, invoiceUser.currency);
        balance = Number(balance);

      //  const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });
        const adminWallet =  "0x195BED0123abeb4e68e2674c463E169E58dd510d"

        var adminAmount = adminWallet.txFees;

        // var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        // var merchantRate = 0, merchantAmount = 0, merchantAddress;
        // if (merchantFees) {
        //     merchantFees = merchantFees.feeObject
        //     for (value of merchantFees) {
        //         if (value.currency == invoiceUser.currency) {
        //             merchantRate = value.rate;
        //             merchantAddress = value.address
        //             break;
        //         }
        //     }
        // }

        // if (merchantRate > 0) {
        //     merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6)
        // }

        var remainingCurrencyAmount = invoiceUser.paidAmount - balance;
      //  var userAmount = invoiceUser.paidAmount - adminAmount - merchantAmount;
        var userAmount = invoiceUser.paidAmount - adminAmount;

        console.log(remainingCurrencyAmount, userAmount, adminAmount)

        var response = {
            code: "200",
            status: "OK",
            message: "Successful",
            data: {
                paymentStatus: "PENDING",
                paymentId: invoiceUser._id,
                emailAddress: invoiceUser.email,
                name: invoiceUser.name,
                usdAmount: invoiceUser.usdAmount,
                totalRemainingAmount: remainingCurrencyAmount,
                currency: invoiceUser.currency,
                totalAmount: invoiceUser.paidAmount,
                totalReceivedAmount: balance,
                conversionRate: invoiceUser.rate,
                address: invoiceUser.newAccount.accountNumber,
                statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                remainingTime:
                    timer.hours + ":" + timer.minutes + ":" + timer.seconds,
                paymentQRCode: invoiceUser.newAccount.accountNumber,
            },
        };

        if (remainingCurrencyAmount <= 0) {
            var newUserPrivateKey = await decryptePrivateKey(invoiceUser.newAccount.privateKey);
            var newAccountBal = web3eth.utils.fromWei(
                await web3eth.eth.getBalance(invoiceUser.newAccount.accountNumber),
                "ether"
            );
            var userPrivateKey;
            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;

            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == "ETH") {
                    console.log(accountAddress[i].account_detail.privateKey)
                    userPrivateKey = accountAddress[i].account_detail.privateKey;
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            const transReq = await estimateGasTransaction(invoiceUser.newAccount.accountNumber, accountAddress, userAmount, invoiceUser.currency);
            console.log(transReq, 'transReq')
            var transactionFee = transReq.txFee;
            var gasPrice = transReq.gasPrice;
            var gasLimit = transReq.gasLimit;
            console.log(transactionFee, gasPrice, gasLimit)
            //if adminFees then calculate txFees for admin as well

            if ((adminAmount > 0) && (merchantAmount > 0)) {
                transactionFee = transactionFee * 3;
            } else if ((adminAmount > 0) || (merchantAmount > 0)) {
                transactionFee = transactionFee * 2;
            }

            if (newAccountBal < transactionFee) {
                var userBal = web3eth.utils.fromWei(
                    await web3eth.eth.getBalance(accountAddress),
                    "ether"
                );
                transactionFee = transactionFee - newAccountBal;
                if (userBal > transactionFee * 3) {
                    userPrivateKey = await decryptePrivateKey(userPrivateKey);
                    await ethTransaction(accountAddress, invoiceUser.newAccount.accountNumber, transactionFee, userPrivateKey)
                } else {
                    return res.status(200).send(response);
                }

            }

            var receipt = await sendERC20(invoiceUser.newAccount.accountNumber, userAmount, accountAddress, newUserPrivateKey, invoiceUser.currency)
            if (receipt) {
                await Invoice.updateOne(
                    { _id: invoiceUser._id },
                    { cold_trans_done: true }
                );
                var new_task = new InvoiceTransaction({
                    paymentId: invoiceUser._id,
                    paidAmount: invoiceUser.paidAmount,
                    Transaction: receipt,
                });
                new_task.save();

                if (merchantAmount > 0) {
                    var merchantReceipt = await sendERC20(invoiceUser.newAccount.accountNumber, merchantAmount, merchantAddress, newUserPrivateKey, invoiceUser.currency)
                    console.log(`admin Transaction successful with hash: ${merchantReceipt}`);
                }

                //console.log(adminWallet[0].walletAddress, adminWallet[0].txFees, decryptedPrivateKey,'9jg')
                if (adminAmount > 0) {

                    var adminReceipt = await sendERC20(invoiceUser.newAccount.accountNumber, adminAmount, adminWallet.walletAddress, newUserPrivateKey, invoiceUser.currency)

                    await InvoiceTransaction.updateOne(
                        { paymentId: invoiceUser._id },
                        { adminTransaction: adminReceipt }
                    );
                    console.log(`admin Transaction successful with hash: ${adminReceipt}`);
                }

                var formattedTime = Date.now();
                const transactionId = receipt;
                var emailProvider, companyName, domain
                if (invoiceUser.emailProvider) {
                    emailProvider = invoiceUser.emailProvider;
                    companyName = invoiceUser.companyName;
                    domain = invoiceUser.domain
                }
                var link = `https://${process.env.eth_explorer_url}/tx/${transactionId}`
                const emailBody = {
                    email: invoiceUser.email,
                    firstName: "User",
                    amount: invoiceUser.paidAmount,
                    currency: invoiceUser.currency,
                    paidfrom: invoiceUser.newAccount.accountNumber,
                    paidto: accountAddress,
                    transactionId,
                    formattedTime,
                    link,
                    emailProvider,
                    apiName: invoiceUser.name,
                    companyName,
                    domain
                };


                await transactionEmail(emailBody);

                var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

                var Merchantobject = {

                    "email": invoiceUser.email,
                    "ip": ip.address(),
                    "txId": transactionId,
                    "fee": 0,
                    "currency": invoiceUser.currency,
                    "paidFrom": invoiceUser.newAccount.accountNumber,
                    "senderTag": "",
                    "receiverTag": "",
                    "amount": invoiceUser.paidAmount,
                    "usdRate": invoiceUser.rate,
                    "adminFee": adminAmount,
                    "actualamount": invoiceUser.paidAmount,
                    "ordertype": "",
                    "description": "",
                    "status": 1,
                    "transactionType": "MerchantApi",
                    "explorer": link,
                    "userId": user._id,
                    "paidTo": accountAddress,
                    "initiatedDate": formattedTime,
                    "confirmedDate": formattedTime

                }

                await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true })

                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        paymentStatus: "PAID",
                        paymentId: invoiceUser._id,
                        emailAddress: invoiceUser.email,
                        name: invoiceUser.name,
                        usdAmount: invoiceUser.usdAmount,
                        totalRemainingAmount: 0,
                        currency: invoiceUser.currency,
                        totalAmount: invoiceUser.paidAmount,
                        totalReceivedAmount: invoiceUser.paidAmount,
                        conversionRate: invoiceUser.rate,
                        address: invoiceUser.newAccount.accountNumber,
                        statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                        remainingTime: "00:00:00",
                        paymentQRCode: invoiceUser.newAccount.accountNumber,
                    },
                });
            } else {
                res.status(200).send(response);
            }

        } else {

            res.status(200).send(response);
        }


    } catch (err) {
        console.log(err, "Error in invoiceStatusERC20: ", err);
    }
}

const invoiceCronERC20 = async (invoiceUser) => {
    try {

        var balance = await getERC20Balance(invoiceUser.newAccount.accountNumber, invoiceUser.currency);
        balance = Number(balance);

        const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });

        var adminAmount = adminWallet.txFees;

        var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        var merchantRate = 0, merchantAmount = 0, merchantAddress;
        if (merchantFees) {
            merchantFees = merchantFees.feeObject
            for (value of merchantFees) {
                if (value.currency == invoiceUser.currency) {
                    merchantRate = value.rate;
                    merchantAddress = value.address
                    break;
                }
            }
        }

        if (merchantRate > 0) {
            merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6)
        }

        var remainingCurrencyAmount = invoiceUser.paidAmount - balance;
        var userAmount = invoiceUser.paidAmount - adminAmount - merchantAmount;

        console.log(remainingCurrencyAmount, userAmount, adminAmount)

        if (remainingCurrencyAmount <= 0) {
            var newUserPrivateKey = await decryptePrivateKey(invoiceUser.newAccount.privateKey);
            var newAccountBal = web3eth.utils.fromWei(
                await web3eth.eth.getBalance(invoiceUser.newAccount.accountNumber),
                "ether"
            );
            var userPrivateKey;
            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;

            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == "ETH") {
                    console.log(accountAddress[i].account_detail.privateKey)
                    userPrivateKey = accountAddress[i].account_detail.privateKey;
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            const transReq = await estimateGasTransaction(invoiceUser.newAccount.accountNumber, accountAddress, userAmount, invoiceUser.currency);
            console.log(transReq, 'transReq')
            var transactionFee = transReq.txFee;
            var gasPrice = transReq.gasPrice;
            var gasLimit = transReq.gasLimit;
            console.log(transactionFee, gasPrice, gasLimit)
            //if adminFees then calculate txFees for admin as well

            if ((adminAmount > 0) && (merchantAmount > 0)) {
                transactionFee = transactionFee * 3;
            } else if ((adminAmount > 0) || (merchantAmount > 0)) {
                transactionFee = transactionFee * 2;
            }

            if (newAccountBal < transactionFee) {
                var userBal = web3eth.utils.fromWei(
                    await web3eth.eth.getBalance(accountAddress),
                    "ether"
                );
                transactionFee = transactionFee - newAccountBal;
                if (userBal > transactionFee * 3) {
                    userPrivateKey = await decryptePrivateKey(userPrivateKey);
                    await ethTransaction(accountAddress, invoiceUser.newAccount.accountNumber, transactionFee, userPrivateKey)
                } else {
                    return 0;
                }

            }

            var receipt = await sendERC20(invoiceUser.newAccount.accountNumber, userAmount, accountAddress, newUserPrivateKey, invoiceUser.currency);
            if (receipt) {
                await Invoice.updateOne(
                    { _id: invoiceUser._id },
                    { cold_trans_done: true }
                );
                var new_task = new InvoiceTransaction({
                    paymentId: invoiceUser._id,
                    paidAmount: invoiceUser.paidAmount,
                    Transaction: receipt,
                });
                new_task.save();

                if (merchantAmount > 0) {
                    var merchantReceipt = await sendERC20(invoiceUser.newAccount.accountNumber, merchantAmount, merchantAddress, newUserPrivateKey, invoiceUser.currency)
                    console.log(`admin Transaction successful with hash: ${merchantReceipt}`);
                }

                //console.log(adminWallet[0].walletAddress, adminWallet[0].txFees, decryptedPrivateKey,'9jg')
                if (adminAmount > 0) {

                    var adminReceipt = await sendERC20(invoiceUser.newAccount.accountNumber, adminAmount, adminWallet.walletAddress, newUserPrivateKey, invoiceUser.currency)

                    await InvoiceTransaction.updateOne(
                        { paymentId: invoiceUser._id },
                        { adminTransaction: adminReceipt }
                    );
                    console.log(`admin Transaction successful with hash: ${adminReceipt}`);
                }

                var formattedTime = Date.now();
                const transactionId = receipt;
                var emailProvider, companyName, domain
                if (invoiceUser.emailProvider) {
                    emailProvider = invoiceUser.emailProvider;
                    companyName = invoiceUser.companyName;
                    domain = invoiceUser.domain
                }
                var link = `https://${process.env.eth_explorer_url}/tx/${transactionId}`
                const emailBody = {
                    email: invoiceUser.email,
                    firstName: "User",
                    amount: invoiceUser.paidAmount,
                    currency: invoiceUser.currency,
                    paidfrom: invoiceUser.newAccount.accountNumber,
                    paidto: accountAddress,
                    transactionId,
                    formattedTime,
                    link,
                    emailProvider,
                    apiName: invoiceUser.name,
                    companyName,
                    domain
                };

                await transactionEmail(emailBody);

                var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

                var Merchantobject = {

                    "email": invoiceUser.email,
                    "ip": ip.address(),
                    "txId": transactionId,
                    "fee": 0,
                    "currency": invoiceUser.currency,
                    "paidFrom": invoiceUser.newAccount.accountNumber,
                    "senderTag": "",
                    "receiverTag": "",
                    "amount": invoiceUser.paidAmount,
                    "usdRate": invoiceUser.rate,
                    "adminFee": adminAmount,
                    "actualamount": invoiceUser.paidAmount,
                    "ordertype": "",
                    "description": "",
                    "status": 1,
                    "transactionType": "MerchantApi",
                    "explorer": link,
                    "userId": user._id,
                    "paidTo": accountAddress,
                    "initiatedDate": formattedTime,
                    "confirmedDate": formattedTime

                }

                await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true });
            }
        }

    } catch (err) {
        console.log(err, "Error in invoiceCronERC20: ", err);
    }
}

const refundTransactionERC20 = async (req, res, id, sender, receiver, privateKey, currency, paymentId) => {
    try {
        var amount = await getERC20Balance(sender, currency)
        const Data1 = await TokenAddress.findOne({ symbol: currency });

        let token_Address = Data1.contract_Address

        let wallet_Address = sender; // From address

        let min_ABI = JSON.parse(Data1.Abi)


        let contract0 = new web3eth.eth.Contract(min_ABI, token_Address, { from: wallet_Address })
        var decryptedPrivateKey = await decryptePrivateKey(privateKey);

        var newAccountBal = await getETHBalance(sender)

        // user transaction

        var gasLimit = await contract0.methods
            .transfer(receiver, web3eth.utils.toWei((amount).toString(), "ether"))
            .estimateGas({ from: sender });

        const gasPrice = await web3eth.eth.getGasPrice();
        var transactionFee = gasPrice * gasLimit;
        transactionFee = (await web3eth.utils.fromWei(transactionFee.toString(), 'ether'))
        transactionFee = Number(transactionFee).toFixed(6)

        if (newAccountBal < transactionFee) {

            var balance, userAccount, userPrivateKey, checkStatus = false;
            const invoiceEmail = await Invoice.findOne({ _id: paymentId }, { userEmail: 1 });
            var Account = await Acc_Balance.findOne({ email: invoiceEmail.userEmail });

            Account = Account.accounts

            Account = Account.filter(el => {
                return el.symbol == "ETH"
            })

            top: for (var i = 0; i < Account.length; i++) {
                console.log(Account[i].account_number);
                userAccount = Account[i].account_number
                userPrivateKey = Account[i].account_detail.privateKey;

                balance = await getETHBalance(userAccount);
                if (Number(balance) > Number(transactionFee * 2)) {

                    console.log("got balance")
                    checkStatus = true;
                    break top;
                }
            }

            if (checkStatus == false) {
                return res.status(500).send({
                    code: "500",
                    status: "Error",
                    message: "Something wrong",
                    data: {},
                });
            }

            var userDecryptedPrivateKey = await decryptePrivateKey(userPrivateKey);
            const ETHTransaction = await web3eth.eth.accounts.signTransaction(
                {
                    from: userAccount,
                    to: sender,
                    value: web3eth.utils.toWei(transactionFee.toString(), "ether"),
                    gas: "21000",
                },
                userDecryptedPrivateKey
            );
            var receipt = await web3eth.eth.sendSignedTransaction(
                ETHTransaction.rawTransaction
            );
            console.log(
                `Transaction successful with hash: ${receipt.transactionHash}`
            );
        }

        var amount_value = await web3eth.utils.toWei(amount, 'ether')

        var data = contract0.methods.transfer(receiver, amount_value).encodeABI(); //Create the data for token transaction.

        var rawTransaction = { "to": token_Address, "gas": gasLimit, "data": data };

        const send = await web3eth.eth.accounts.signTransaction(rawTransaction, decryptedPrivateKey);

        // Deploy transaction
        var receipt = await web3eth.eth.sendSignedTransaction(send.rawTransaction);

        console.log(`Transaction successful with hash: ${receipt.transactionHash}`);
        if (receipt.transactionHash) {
            const refundData = await Refund.findOneAndUpdate({ _id: id }, {
                refund_txid: receipt.transactionHash,
                refundConfirmed: true,
                toAddress: receiver,
                amount: amount
            }, { new: true });
            await sendEmail(id);
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "Successful",
                data: {
                    status: "PAID",
                    paymentId: refundData.paymentId,
                    currency: refundData.currency,
                    amount: refundData.amount,
                    address: refundData.toAddress,
                    transactionHash: refundData.refund_txid,
                    transactionHashRedirectURL: `https://${process.env.eth_explorer_url}/tx/` + refundData.refund_txid,
                },
            });
        }
    } catch (err) {
        console.log("refundTransaction error:", err)
        return res.status(500).json({
            code: 500,
            status: "Error",
            message: err.message,
            data: {},
        });
    }
}

const sendEmail = async function (refundId) {

    try {
        const refundData = await Refund.findOne({ _id: refundId });
        const email = refundData.email;
        const currency = refundData.currency;
        const amount = refundData.amount;
        const toAddress = refundData.toAddress;
        const txId = refundData.refund_txid;
        var emailProvider = refundData.emailProvider;
        var apiKey = refundData.apiKey;
        var companyName = refundData.companyName;
        var domain = refundData.domain;

        const emailBody = {
            email,
            currency,
            amount,
            toAddress,
            txId,
            emailProvider,
            apiKey,
            companyName,
            domain
        }
        console.log("mail initiated")
        await refundTransactionMail(emailBody);
        console.log("mail confirmed")
    } catch (err) {
        console.log("Error in sendEmail: ", err)
    }
}

module.exports = {
    createInvoiceERC20,
    invoiceStatusERC20,
    invoiceCronERC20,
    getERC20Balance,
    getETHBalance,
}