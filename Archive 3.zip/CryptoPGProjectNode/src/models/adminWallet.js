'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var adminWallet = new Schema({


    id : {
        type : String,
        unique: true
      },

    currencies : {
        type : String
      },

      walletName : {
        type : String
      },

      publicKey : {
        type : String
      },

      privateKey : {
        type : String
      },


});

module.exports = mongoose.model('adminWallet', adminWallet);