const Binance = require('node-binance-api');
const cron = require("node-cron");
const CoinRate = require("../../models/coinrates/usdRate");
const binance = new Binance().options({
  APIKEY: process.env.binance_websocket_apiKey,
  APISECRET: process.env.binance_websocket_secretKey
});

const usdRate = async () => {
  try {

    let ticker = await binance.prices();

    if (ticker) {
      const usdRateObject = {
        BNB: Number(ticker.BNBUSDT),
        BTC: Number(ticker.BTCUSDT),
        TRX: Number(ticker.TRXUSDT),
        ETH: Number(ticker.ETHUSDT),
        LTC: Number(ticker.LTCUSDT),
        DOGE: Number(ticker.DOGEUSDT),
        BCH: Number(ticker.BCHUSDT),
        SOL: Number(ticker.SOLUSDT),
        XRP: Number(ticker.XRPUSDT),
        SUPER: Number(ticker.SUPERUSDT),
        SHIB: Number(ticker.SHIBUSDT),
        MATIC: Number(ticker.MATICUSDT),
        USDT_TRC20: Number(ticker.USDTDAI),
        USDT_ERC20: Number(ticker.USDTDAI),
        ADA: Number(ticker.ADAUSDT),
        STX: Number(ticker.STXUSDT),
      }

      console.log('coinrate udpated: ', usdRateObject)
      await CoinRate.findOneAndUpdate({}, { usd_rate: usdRateObject }, { upsert: true })
    }

    // binance.prices('BNBUSDT', (error, ticker) => {
    //     console.info("Price of BNBUSDT: ", ticker.BNBUSDT);
    //   });
    // return 0;
    // const btc = binance.websockets.trades( 'BTCUSDT',async(trades) => {
    //     console.log(trades.p);
    //     await CoinRate.updateOne({btc_usd_rate:trades.p}); 

    // }); 
    // binance.websockets.terminate(btc);
    // console.log(btc)
    // binance.websockets.trades( 'BNBUSDT',async (trades) => {
    //     console.log(trades.p);
    //     await CoinRate.updateOne({bsc_usd_rate:trades.p}) 

    // }); 
    // binance.websockets.terminate('bnbusdt@trade');
    // binance.websockets.trades( 'TRXUSDT',async(trades) => {
    //     console.log(trades.p)
    //     await CoinRate.updateOne({trx_usd_rate:trades.p})

    // }); 
    // binance.websockets.terminate('trxusdt@trade');
    // binance.websockets.trades( 'ETHUSDT', async(trades) => {
    //     console.log(trades.p);
    //     await CoinRate.updateOne({eth_usd_rate:trades.p})  

    // }); 
    // binance.websockets.terminate('ethusdt@trade');
  } catch (err) {
    console.log(err, "WebRate.js err");
  }
}


module.exports =  usdRate