const crypto = require('crypto');

// Hash the keys before storing them
function hashKey(key) {
    return crypto.createHash('sha256').update(key).digest('hex');
}

// Validate the keys (public & private) for a given clientId
function validateKeys(publicKey, privateKey, storedPublicKey, storedPrivateKey) {
    const hashedPrivateKey = hashKey(privateKey);

    console.log('publicKey', publicKey)
    console.log('hashedPrivateKey', hashedPrivateKey)
    console.log('storedPublicKey', storedPublicKey)
    console.log('storedPrivateKey', storedPrivateKey)

    return publicKey === storedPublicKey && hashedPrivateKey === storedPrivateKey;
}

const generateKeyPair = () => {
    const privateKey = crypto.randomBytes(32).toString('hex'); // 64-character alphanumeric
    const publicKey = crypto.randomBytes(16).toString('hex');  // 32-character alphanumeric
    return { privateKey, publicKey };
};

module.exports = {
    generateKeyPair,
    hashKey,
    validateKeys
};