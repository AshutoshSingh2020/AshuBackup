const logger = {
    error: (message) => console.error(`[ERROR]: ${message}`),
    info: (message) => console.log(`[INFO]: ${message}`)
};

module.exports = logger;