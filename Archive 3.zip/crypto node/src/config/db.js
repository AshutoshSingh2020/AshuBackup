const mongoose = require('mongoose');
const logger = require('../utils/logger');

const connectDB = async () => {
    try {
        console.log('DB check')
        const uri = process.env.MONGODB_URL;
        console.log('URI: ', uri)
        await mongoose.connect(process.env.MONGODB_URL, { 
            dbName: 'InvictaPayments',
         bufferCommands: false 
          });

        logger.info(`DB connected`);
    } catch (err) {
        logger.error(`Error: ${err.message}`);
        console.log('DB connection Failed')
        process.exit(1);
    }
};

module.exports = connectDB;