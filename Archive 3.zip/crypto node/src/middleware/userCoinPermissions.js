const Currencies = require("../models/currencies");
const User = require("../models/userModel");


exports.checkuserCoinsPermission = async (req, res, next) => {
    try {
      var { currency, amount, publicKey, privateKey } = req.body
  
      let email;
      let temp;
  
      if (publicKey !== undefined || privateKey !== undefined) {
        let userId = await Api.find({ privateKey: privateKey });
        email = userId[0].user_id;
      } else {
        return res.status(401).send({
            code: 401,
            status: "Failed",
            message: `Private and public key are not provided`,
            data: {},
      })
    }
  
      const currenciesData = await Currencies.findOne();
      var currenciesObj = currenciesData.currencies.filter(el => el.name === currency || el.symbol === currency);
      currenciesObj = currenciesObj[0];
  
      const user = await User.findOne({ email })
  
      var bool = false
      // check if user has permission to access this currency
      const userCoins = user.coins[0];
      const userCoin = userCoins[currenciesObj.name] || userCoins[currenciesObj.symbol];
      if (userCoin) {
        bool = true
      } else {
        return res.status(401).send({
          code: 401,
          status: "Failed",
          message: `Unauthorized Access, Currency ${currency} is disabled`,
          data: {},
        });
      }
  
      // // check for single maximum number of coins to withdraw
      // const permissionData = await apiPermission.findOne({ publicKey: publicKey });
      // const transactionlimit = permissionData.limits.filter(el => el.name == currenciesObj.name || el.symbol == currenciesObj.symbol);
      // if (transactionlimit.length == 0) {
      //   bool = true
      // } else {
      //   if (+transactionlimit[0].limit > +amount) {
      //     bool = true
      //   } else {
      //     return res.status(401).send({
      //       code: 400,
      //       status: "Failed",
      //       message: `Cannot withdraw more than ${+transactionlimit[0].limit} at once`,
      //       data: {},
      //     });
      //   }
      // }
  
      // let date_ob = new Date()
      // date_ob.setUTCHours(23, 59, 59, 999)
      // let date = ("0" + date_ob.getDate()).slice(-2);
      // let month = ("0" + (date_ob.getMonth() + 1)).slice(-2);
      // let year = date_ob.getFullYear();
  
      // const expiryTime = new Date(year + "-" + month + "-" + date)
  
      // if (permissionData.endDayStamp < date_ob) {
      //   console.log("helllll")
      //   await apiPermission.findOneAndUpdate({ publicKey: publicKey },
      //     {
      //       $set: {
      //         "Dailylimit.$[elem].currentAmount": 0,
      //         endDayStamp: expiryTime
      //       }
      //     },
      //     {
      //       arrayFilters: [{ "elem.currentAmount": { $gt: 0 } }], "multi": true
      //     },
      //   );
      // }
  
      // // check for maximum coins to withdraw
      // const permissionData1 = await apiPermission.findOne({ publicKey: publicKey });
      // const Dailytransactionlimit = permissionData1.Dailylimit.filter(el => el.name == currenciesObj.name || el.symbol == currenciesObj.symbol);
      // if (Dailytransactionlimit.length == 0) {
      //   bool = true
      // } else {
      //   if (+Dailytransactionlimit[0].Dailylimit > +Dailytransactionlimit[0].currentAmount) {
      //     bool = true
      //   } else {
      //     return res.status(401).send({
      //       code: 400,
      //       status: "Failed",
      //       message: `Daily transaction limit exceeds ${+Dailytransactionlimit[0].Dailylimit}`,
      //       data: {},
      //     });
      //   }
      // }
  
      // if (bool == true) {
      //   console.log("middle ware passed")
      //   next()
      // }

      next();
    } catch (error) {
      console.log(error);
    }
  };