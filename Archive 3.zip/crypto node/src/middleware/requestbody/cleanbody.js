const sanitize = require("mongo-sanitize");

const cleanBody = (req, res, next) => {
  try {
    req.body = sanitize(req.body);
    next(); // Ensure to call next() to proceed to the next middleware
  } catch (error) {
    console.log("clean-body-error", error);
    return res.status(500).json({
      error: true,
      message: "Could not sanitize body",
    });
  }
};

module.exports = { cleanBody };