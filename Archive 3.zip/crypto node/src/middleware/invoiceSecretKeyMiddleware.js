const Api = require("../models/");

exports.checkPrivatePublic = async (req, res, next) => {
    const {publicKey, privateKey} = req.body;
   
   if(!publicKey || !privateKey){
      return res
         .status(400)
         .json({
            statuscode:400,
            status: 'Fail',
            message: 'Please provide publicKey and privateKey!',
            data : {}
         });
   }
               
   var Auth = await Api.find({publicKey:publicKey, privateKey:privateKey}).then((data)=>{
      return data
   }).catch((err)=>{
      res.send(err)
   })

   if (Auth.length == 0) {
      return res.status(401).json({
            statuscode: 401,
            status: "Fail",
            message: "Incorrect Public Key and Private Key!!",
            data:{}
      });
   }
   next();
}