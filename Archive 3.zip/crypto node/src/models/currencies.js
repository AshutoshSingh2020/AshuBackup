'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var currencies = new Schema({
    currencies: {
        type: [Object]
    }
});

module.exports = mongoose.model('currencies', currencies);