'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;



var TaskSchema = new Schema({
  user_id: {
    type: String
  },
  publicKey : {
    type : String
  },
  privateKey : {
    type : String
  },
  keyname:{
    type : String,
  },
  host : {
    type :String
  },
  usage : {
    type : [Object]
  },
  count  : {
    type : Number,
  },
  createdAt : {
    type : Date,
  },
  emailProvider: {
    type:String
  },
  emailProviderStatus:{
    type:Boolean,
    default:false
  },
  companyName: {
    type:String
  },
  website:{
    type:String
  },
  refundLink:{
    type:String

  }
  
});


module.exports = mongoose.model('Api',TaskSchema);