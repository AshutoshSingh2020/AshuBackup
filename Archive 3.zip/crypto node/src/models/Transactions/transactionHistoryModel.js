"use strict";
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var TransactionHistorySchema = new Schema({
    user_id: {
        type: String
    },
    EthTransactionHistory: {
        type: [Object]
    },
    TrxTransactionHistory: {
        type: [Object]
    },
    BnbTransactionHistory: {
        type: [Object]
    },
    BtcTransactionHistory: {
        type: [Object]
    },
    DogeTransactionHistory: {
        type: [Object]
    },
    UsdtTrc20TransactionHistory: {
        type: [Object]
    },
    SuperFarmTransactionHistory: {
        type: [Object]
    },
    LtcTransactionHistory: {
        type: [Object]
    },
    ShibTransactionHistory: {
        type: [Object]
    },
    XrpTransactionHistory: {
        type: [Object]
    },
    SolTransactionHistory: {
        type: [Object]
    },
    MaticTransactionHistory: {
        type: [Object]
    },
    CardanoTransactionHistory: {
        type: [Object]
    },
    Erc20TransactionHistory: {
        type: [Object]
    },
    SuperErc20TransactionHistory: {
        type: [Object]
    },
    SuperBep20TransactionHistory: {
        type: [Object]
    },
    BchTransactionHistory: {
        type: [Object]
    },
   
    
    Merchant: {
        type: [Object]
    }

});

module.exports = mongoose.model('Transaction_History', TransactionHistorySchema);