'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var coinRateSchema = new Schema({
    usd_rate:{
        type: Object
    },

});

module.exports = mongoose.model('coinRate', coinRateSchema);