"use strict";
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var InvoiceTransactionSchema = new Schema({
  paymentId: {
    type: String,
  },
  invoiceID: { type: String },
  coin: {
    type: String,
  },
  paidAmount: {
    type: String,
  },
  Transaction: {
    type: Object,
  },
});

module.exports = mongoose.model('InvoiceTransactionHistory', InvoiceTransactionSchema);
