"use strict";
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var InvoiceSchema = new Schema({
  email : {
    type : String
  },
  amount: {
    type: Number,
  },
  currency: {
    type: String,
  }, 
  paidAmount:{
    type: Number,
    default: 0
  },
  receivingAddress:{
    type : String
  },
  balance: {
    type: Number,
  },
  conv_amount : {
    type : Number
  },
  newAccount: {
    type: Object,
  },
  rate: {
    type: Object,
  },
  timestamp : {
    type : Number,
  },
  timeout : {
    type : Object,
  },
  cold_trans_done : {
    type : Boolean
  },
  newAddress:{
    type : String
  },
  label:{
    type : String
  }
  
});

module.exports = mongoose.model("invoice", InvoiceSchema);