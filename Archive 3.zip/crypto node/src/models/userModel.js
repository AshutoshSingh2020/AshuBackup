const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const userSchema = new Schema(
  {
    userId: { type: String, unique: true, required: true },
    email: { type: String, required: true },
    accessToken: { type: String, default: null },
    role: { type: String, default: "user" },
    userActivity: { type: Boolean, default: true },
    coins: { type: [Object], default: [] },
    userIP: { type: String, default: null },
    publicKey: { type: String, required: true },   // Encrypted public key
    privateKey: { type: String, required: true },  // Encrypted private key
  },
  {
    timestamps: {
      createdAt: "createdAt",
      updatedAt: "updatedAt",
    },
  }
);

module.exports = mongoose.model('User', userSchema);