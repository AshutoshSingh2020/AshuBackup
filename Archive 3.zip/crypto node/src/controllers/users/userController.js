const User = require('../../models/userModel');
const { generateKeyPair, hashKey, validateKeys } = require('../../utils/cryptoUtils');

const createUserRequest = async (req, res) => {
  const { clientId, private_key, public_key, email } = req.body;

  if (!clientId || !email) {
    return res.status(400).json({ message: 'ClientId and Email are required' });
  }

  try {
    let user = await User.findOne({ userId: clientId });

    if (user) {
      if (public_key && private_key) {
        const isValid = validateKeys(public_key, private_key, user.publicKey, user.privateKey);
        console.log('isValid', isValid);
        if (!isValid) {
          return res.status(401).json({ message: 'Invalid public or private key' });
        }
        return res.status(200).json({ message: 'Login Successful' });
      } else {
        return res.status(400).json({ message: 'Missing required fields: public_key, private_key' });
      }
    } else {
      let { publicKey, privateKey } = generateKeyPair();
      const hashedPrivateKey = hashKey(privateKey);
      console.log('hashedPrivateKey', hashedPrivateKey)
      console.log('publicKey', publicKey)
      const newUser = new User({
        userId: clientId,
        email,
        privateKey: hashedPrivateKey,
        publicKey, // Store public key as-is
      });
      const data = await newUser.save();
      return res.status(200).json({ 
        message: 'User created successfully', 
        userId: data.userId,
        email: data.email,
        email: data.email,
        userIP: data.userIP,
        email: email,
        generatedKeys: { publicKey, privateKey } // Send back the generated keys
      });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { createUserRequest };