switch (currency) {
    case "Ethereum":
    case "ETH":
       var AdminETHWallet = await adminWallet.find({ currency: "ETH" });

    
       var ETHSender = sender;
       var ETHSenderPrivateKey = senderPrivateKey;
       // Balance call
       const balanceFrom = web3eth.utils.fromWei(
          await web3eth.eth.getBalance(sender),
          'ether'
       );
       console.log(balanceFrom);
       if (balanceFrom < amount) {
          return res.status(400).json({
             statuscode: 400,
             status: 'Failed',
             message: 'Account balance should be greater than amount',
             data: {}
          });
       }

       if (newSender == 1) {
          // first transaction
          const account = web3eth.eth.accounts.create(web3eth.utils.randomHex(32));
          const newETHSenderAddress = account.address;
          const newETHReceiver = newETHSenderAddress;
          const newETHSenderPrivateKey = account.privateKey;
          var encryptKey = await dashboardController.encrypt(newETHSenderPrivateKey)

          const ethGasfees = AdminETHWallet[0].gasfees;
          var newAmount = (+amount + + ethGasfees).toFixed(6);
          newAmount = newAmount.toString();


          await newSenderModel.create({

             paymentId: paymentId,
             newSender: newETHSenderAddress,
             privateKey: encryptKey,
             amount: newAmount,
             addressFrom: sender,
             addressTo: to_address,
             txId: 0,
             currency: "ETH"
          })

          const txIdETHNewSender = await createETHTransaction(sender, senderPrivateKey, newETHReceiver, newAmount);
          var createdAt = new Date()

          console.log(paymentId, 'diididi')
          const NewSenddata = await newSenderModel.findOne({ paymentId: paymentId })
          NewSenddata.txId = txIdETHNewSender.transactionHash
          await NewSenddata.save();


          var Link = `https://${process.env.eth_explorer_url}/#/transaction/${txId}`;
          var sendAt = new Date(createdAt.getTime() + (10 * 60 * 1000));
          var formattedCreatedAtTime = moment.tz(createdAt, "Asia/Singapore").format("DD/MM/YYYY h:mm:ss a");
          var formattedSendAtTime = moment.tz(sendAt, "Asia/Singapore").format("DD/MM/YYYY h:mm:ss a");

          const senderETHTransaction = {
             "paymentId": paymentId,
             "email": email,
             "ip": "",
             "txId": txIdETHNewSender.transactionHash,
             "fee": 0,
             "currency": currency,
             "paidFrom": sender,
             "senderTag": "",
             "receiverTag": "",
             "amount": parseFloat(amount),
             "inUsd": inUsd,
             "rateInUsd":usdRate,
             "adminFee": 0,
             "actualamount": parseFloat(amount),
             "ordertype": "Internal",
             "description": "",
             "status": 1,
             "transactionType": "",
             "explorer": Link,
             "userId": Users.toString(),
             "paidTo": newETHReceiver,
             "initiatedDate": formattedCreatedAtTime,
             "confirmedDate": formattedSendAtTime,

          }

          withdrawalTransaction.findOneAndUpdate({ user_id: Users }, {
             $push: { EthTransactionHistory: senderETHTransaction }
          }).then(() => {
             console.log(`withdrawal transactionhistory updated`)
          }).catch((err) => {
             console.log(err, "errr push eth")
          })

          const balanceFrom = web3eth.utils.fromWei(
             await web3eth.eth.getBalance(newETHSenderAddress),
             'ether'
          );
          console.log(balanceFrom, "NEW account bal");
          if (balanceFrom > 0) {
             sender = newETHSenderAddress;
             senderPrivateKey = newETHSenderPrivateKey;
             amount = balanceFrom
          }
       }

       // Second transaction
       console.log(amount)
       const txIdETH = await createETHTransaction(sender, senderPrivateKey, to_address, amount);
       var txId = txIdETH.transactionHash;
       var Link = `https://${process.env.eth_explorer_url}/tx/${txId}`;

       // Admin transaction
       if (!(AdminETHWallet[0].txFees == 0)) {
          var txIdETHAdmin = await createETHTransaction(ETHSender, ETHSenderPrivateKey, AdminETHWallet[0].walletAddress, AdminETHWallet[0].txFees);
          console.log(txIdETHAdmin)
          var txIdAdmin = txIdETHAdmin.transactionHash;
       }

       var createdAt = new Date()
       var sendAt = new Date(createdAt.getTime() + (10 * 60 * 1000));
       var formattedCreatedAtTime = moment.tz(createdAt, "Asia/Singapore").format("DD/MM/YYYY h:mm:ss a");
       var formattedSendAtTime = moment.tz(sendAt, "Asia/Singapore").format("DD/MM/YYYY h:mm:ss a");

       if (newSender == 0 || newSender == 1 && txId != undefined) {

          var ETHtransaction = {

             "paymentId": paymentId,
             "email": email,
             "ip": "",
             "txId": txId,
             "txIdAdmin": txIdAdmin,
             "fee": 0,
             "currency": currency,
             "paidFrom": sender,
             "senderTag": "",
             "receiverTag": "",
             "amount": parseFloat(amount),
             "inUsd": inUsd,
             "rateInUsd":usdRate,
             "adminFee": 0,
             "actualamount": parseFloat(amount),
             "ordertype": "send",
             "description": "",
             "status": 1,
             "transactionType": "",
             "explorer": Link,
             "userId": Users.toString(),
             "paidTo": to_address,
             "initiatedDate": formattedCreatedAtTime,
             "confirmedDate": formattedSendAtTime,
          }
          withdrawalTransaction.findOneAndUpdate({ user_id: Users }, {
             $push: { EthTransactionHistory: ETHtransaction }
          }).then(() => {
             console.log(`withdrawal transactionhistory updated`)
          }).catch((err) => {
             console.log(err, "errr push trx")
          })
       }

       break;
       default:
            return res
               .status(404)
               .json({
                  statuscode: 404,
                  status: 'Fail',
                  message: 'Please provide valid currency',
                  data: {}
               });
    }


    const createETHTransaction = async (sender, privateKey, receiver, amount) => {

        const gasLimit = await web3eth.eth.estimateGas({
           from: sender,
           to: receiver,
           value: web3eth.utils.toWei(amount.toString(), 'ether'),
        });
        console.log(gasLimit, 'doifif')
     
        const value = web3eth.utils.toWei(amount.toString(), "ether");
        const gasPrice = await web3eth.eth.getGasPrice();
     
        const transactionFee = gasPrice * gasLimit;
     
        amount = value - transactionFee;
     
        console.log(amount, gasPrice, gasLimit, transactionFee, amount, 'dki')
     
        const ETHTransaction = await web3eth.eth.accounts.signTransaction(
           {
              from: sender,
              to: receiver,
              value: amount,
              gasLimit: gasLimit,
           },
           privateKey
        );
     
        // Deploy transaction
        const ETHReceipt = await web3eth.eth.sendSignedTransaction(
           ETHTransaction.rawTransaction
        );
        console.log(
           `Transaction Successful With Hash For ETH: ${ETHReceipt.transactionHash}`
        );
        console.log(ETHReceipt);
     
        return ETHReceipt;
     }
