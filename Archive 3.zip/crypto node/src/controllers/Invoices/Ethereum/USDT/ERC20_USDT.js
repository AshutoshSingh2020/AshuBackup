
var mongoose = require("mongoose");
const Invoice = require("../../models/invoiceDataModel");
const InvoiceFee = require("../../models/invoiceFees");
const Api = require("../../models/apiModel");
const Backup = require("../../models/backupModel");
const Acc_Balance = require("../../models/dashboard_balance");
const InvoiceTransaction = require("../../models/Invoice_transactionModel");
const AdminWallet = require("../../models/adminWalletModel");
const users = require("../../models/user.model");
const { transactionEmail } = require("./../../../utils/transactionEmail");
const Transaction_History = mongoose.model("Transaction_History");
const Coinrate = require("../../models/coinRate");
const Refund = require("../../models/confirmRefundModel");
const { refundTransactionMail } = require("../../../utils/refundTransactionMail")
const crypto = require("crypto");
var ip = require("ip");
const Web3 = require("web3");
const web3eth = new Web3(process.env.ethereum_network_url);
const MerchantFees = require("../../models/merchantFees");

const staticUrl = "https://app.coinuniverze.com";

const decryptePrivateKey = (data) => {
    try {
        var encrypted = Buffer.from(data, 'base64');
        var salt_len = 16, iv_len = 16;

        var salt = encrypted.slice(0, salt_len);

        var iv = encrypted.slice(0 + salt_len, salt_len + iv_len);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 256 / 8, 'sha256');

        var decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);

        decipher.write(encrypted.slice(salt_len + iv_len));
        decipher.end();

        const decrypted = decipher.read();
        return decrypted.toString()
    } catch (err) {
        console.log('decryptedPrivateKey Error: ', err)
    }
};

const encryptedPrivateKeys = async (data) => {
    try {

        var salt = crypto.randomBytes(16);
        var iv = crypto.randomBytes(16);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 32, 'sha256');
        var cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        cipher.write(data);
        cipher.end()

        var encrypted = cipher.read();

        return Buffer.concat([salt, iv, encrypted]).toString('base64')
    } catch (err) {
        console.log("encryptedPrivateKeys Error:", err)
    }
};

const getETHBalance = async (sender) => {

    try {

        console.log(sender)
        const balance = web3eth.utils.fromWei(
            await web3eth.eth.getBalance(sender),
            'ether'
        );

        return balance;
    } catch (err) {
        console.log('ETH balance Error : ', err)
    }
}

const createETHAccount = async () => {
    try {
        var newAccount = web3eth.eth.accounts.create(web3eth.utils.randomHex(32));
        var privateKey = await encryptedPrivateKeys(newAccount.privateKey);
        var newAddress = newAccount.address;

        return { privateKey, newAddress };

    } catch (err) {
        console.log("createETHAccount error:", err)
    }
}

const createInvoiceETH = async (req, res) => {
    try {
        const { email, cryptoAmount, amount, currency, publicKey } = req.body;

        var usdAmount, paidAmount;

        var Auth = await Api.findOne({ publicKey: publicKey });
        var emailProvider, companyName, domain;
        if (Auth.emailProviderStatus) {
            emailProvider = Auth.emailProvider;
            companyName = Auth.companyName;
            domain = (Auth.website).substring((Auth.website).indexOf('.') + 1)
        }

        var rate = await Coinrate.findOne({});
        rate = rate.usd_rate.ETH;

        var account = await createETHAccount();
        var accountNumber = account.newAddress;
        var privateKey = account.privateKey;
        var newAccount = {
            accountNumber,
            privateKey
        }

        if (cryptoAmount == true) {
            usdAmount = (amount * rate).toFixed(6);
            paidAmount = (amount).toFixed(6);
        } else {
            usdAmount = (amount).toFixed(6);
            paidAmount = (amount / rate).toFixed(6);
        }
        var new_task = {
            email: email,
            cryptoAmount: cryptoAmount,
            amount: amount,
            usdAmount: usdAmount,
            paidAmount: paidAmount,
            name: Auth.keyname,
            currency: currency,
            balance: 0,
            newAccount: newAccount,
            rate: rate.toFixed(6),
            timestamp: Date.now(),
            timeout: Date.now(),
            cold_trans_done: false,
            userEmail: Auth.user_id,
            emailProvider,
            companyName,
            domain,
            refundLink: Auth.refundLink,
            publicKey: publicKey
        };
        const newInvoice = await Invoice.create(new_task);
        console.log(newInvoice, newInvoice._id, newInvoice)
        res.status(200).send({
            code: "200",
            status: "OK",
            message: "Successful",
            data: {
                paymentStatus: "PENDING",
                paymentId: newInvoice._id,
                emailAddress: email,
                name: newInvoice.name,
                usdAmount: usdAmount,
                totalRemainingAmount: paidAmount,
                currency: currency,
                totalAmount: paidAmount,
                totalReceivedAmount: 0,
                conversionRate: rate.toFixed(6),
                address: accountNumber,
                statusUrl: staticUrl + "/#/invoice/" + newInvoice._id,
                remainingTime: "03:59:59",
                paymentQRCode: accountNumber,
            },
        });
    } catch (err) {
        console.log("createInvoiceETH error:", err)
    }

};

const estimateGasForETHTransaction = async (sender, receiver, amount) => {

    try {

        var gasPrice = await web3eth.eth.getGasPrice(); // estimate the gas price
        //console.log('gas Price : ',gasPrice)
        var transactionObject = {
            from: sender,
            to: receiver,
            amount: web3eth.utils.toWei(amount.toString(), 'ether')
        }

        var gasLimit = await web3eth.eth.estimateGas(transactionObject); // estimate the gas limit for this transaction

        var transactionFee = gasPrice * gasLimit // calculate the transaction fee

        var transactionFeeInEther = await web3eth.utils.fromWei(transactionFee.toString(), 'ether');

        return { txFee: transactionFeeInEther, gasPrice, gasLimit };

    } catch (err) {
        console.log("Estimate ETHgas Error : ", err)
    }
}
const invoiceStatusETH = async (req, res, invoiceUser, timer) => {
    try {


        var balance = web3eth.utils.fromWei(await web3eth.eth.getBalance(invoiceUser.newAccount.accountNumber), "ether");
        balance = Number(balance);

        const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });

        var adminAmount = adminWallet.txFees;

        var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        var merchantRate = 0, merchantAmount = 0, merchantAddress;
        if (merchantFees) {
            merchantFees = merchantFees.feeObject
            for (value of merchantFees) {
                if (value.currency == invoiceUser.currency) {
                    merchantRate = value.rate;
                    merchantAddress = value.address
                    break;
                }
            }
        }

        if (merchantRate > 0) {
            merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6)
        }

        var remainingCurrencyAmount = Number(invoiceUser.paidAmount - balance).toFixed(6);
        var userAmount = Number(invoiceUser.paidAmount - adminAmount - merchantAmount).toFixed(6);

        console.log(remainingCurrencyAmount, userAmount, adminAmount)
        if (remainingCurrencyAmount <= 0) {

            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == invoiceUser.currency) {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            const transReq = await estimateGasForETHTransaction(invoiceUser.newAccount.accountNumber, accountAddress, userAmount);
            console.log(transReq, 'transReq')
            var transactionFee = transReq.txFee;
            var gasPrice = transReq.gasPrice;
            var gasLimit = transReq.gasLimit;
            console.log(transactionFee, gasPrice, gasLimit)
            //if adminFees then calculate txFees for admin as well
            if ((adminAmount > 0) && (merchantAmount > 0)) {
                transactionFee = transactionFee * 3;
            } else if ((adminAmount > 0) || (merchantAmount > 0)) {
                transactionFee = transactionFee * 2;
            }

            //deduct transactionFee from userAmount;
            console.log(userAmount, "before")
            userAmount = Number(userAmount - transactionFee).toFixed(6);
            console.log(userAmount, "after")
            var decryptedPrivateKey = await decryptePrivateKey(
                invoiceUser.newAccount.privateKey
            );

            if (merchantAmount > 0) {
                const transaction = await web3eth.eth.accounts.signTransaction(
                    {
                        from: invoiceUser.newAccount.accountNumber,
                        to: merchantAddress,
                        value: web3eth.utils.toWei(merchantAmount.toString(), "ether"),
                        //gasPrice: gasPrice,
                        gas: gasLimit
                    },
                    decryptedPrivateKey
                );
                await web3eth.eth.sendSignedTransaction(
                    transaction.rawTransaction
                );
            }

            //user transaction
            const ETHTransaction = await web3eth.eth.accounts.signTransaction(
                {
                    from: invoiceUser.newAccount.accountNumber,
                    to: accountAddress,
                    value: web3eth.utils.toWei(userAmount.toString(), "ether"),
                    //gasPrice: gasPrice,
                    gas: gasLimit
                },
                decryptedPrivateKey
            );
            var ETHReceipt = await web3eth.eth.sendSignedTransaction(
                ETHTransaction.rawTransaction
            );
            console.log(
                `Transaction successful with hash: ${ETHReceipt.transactionHash}`
            );
            var trans = ETHReceipt.transactionHash;
            ETHReceipt.amount = userAmount;
            ETHReceipt.timestamp = Date.now();
            await Invoice.updateOne(
                { _id: req.body.id },
                { cold_trans_done: true }
            );
            var new_task = new InvoiceTransaction({
                paymentId: req.body.id,
                paidAmount: invoiceUser.paidAmount,
                Transaction: ETHReceipt,
            });
            new_task.save();


            //console.log(adminWallet[0].walletAddress, adminWallet[0].txFees, decryptedPrivateKey,'9jg')
            if (adminAmount > 0) {
                console.log('adminfees')
                const adminETHTransaction =
                    await web3eth.eth.accounts.signTransaction(
                        {
                            from: invoiceUser.newAccount.accountNumber,
                            to: adminWallet.walletAddress,
                            value: web3eth.utils.toWei(adminAmount.toString(), "ether"),
                            //gasPrice: gasPrice,
                            gas: gasLimit
                        },
                        decryptedPrivateKey
                    );

                var adminETHReceipt = await web3eth.eth.sendSignedTransaction(adminETHTransaction.rawTransaction);

                await InvoiceTransaction.updateOne(
                    { paymentId: invoiceUser._id },
                    { adminTransaction: adminETHReceipt }
                );
                console.log(`admin Transaction successful with hash: ${adminETHReceipt.transactionHash}`);
            }

            var formattedTime = Date.now();
            const transactionId = ETHReceipt.transactionHash;
            var emailProvider, companyName, domain
            if (invoiceUser.emailProvider) {
                emailProvider = invoiceUser.emailProvider;
                companyName = invoiceUser.companyName;
                domain = invoiceUser.domain
            }
            var link = `https://${process.env.eth_explorer_url}/tx/${transactionId}`
            const emailBody = {
                email: invoiceUser.email,
                firstName: "User",
                amount: invoiceUser.paidAmount,
                currency: invoiceUser.currency,
                paidfrom: invoiceUser.newAccount.accountNumber,
                paidto: accountAddress,
                transactionId,
                formattedTime,
                link,
                emailProvider,
                apiName: invoiceUser.name,
                companyName,
                domain
            };

            await transactionEmail(emailBody);

            var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

            var Merchantobject = {

                "email": invoiceUser.email,
                "ip": ip.address(),
                "txId": trans,
                "fee": 0,
                "currency": invoiceUser.currency,
                "paidFrom": invoiceUser.newAccount.accountNumber,
                "senderTag": "",
                "receiverTag": "",
                "amount": invoiceUser.paidAmount,
                "usdRate": invoiceUser.rate,
                "adminFee": adminAmount,
                "actualamount": invoiceUser.paidAmount,
                "ordertype": "",
                "description": "",
                "status": 1,
                "transactionType": "MerchantApi",
                "explorer": link,
                "userId": user._id,
                "paidTo": accountAddress,
                "initiatedDate": formattedTime,
                "confirmedDate": formattedTime

            }

            await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true })

            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "PAID",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: 0,
                    currency: invoiceUser.currency,
                    totalAmount: invoiceUser.paidAmount,
                    totalReceivedAmount: invoiceUser.paidAmount,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                    statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                    remainingTime: "00:00:00",
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                },
            });

        } else {
            var response = {
                code: "200",
                status: "OK",
                message: "Successful",
                data: {
                    paymentStatus: "PENDING",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: remainingCurrencyAmount,
                    currency: invoiceUser.currency,
                    totalAmount: invoiceUser.paidAmount,
                    totalReceivedAmount: balance,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                    statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                    remainingTime:
                        timer.hours + ":" + timer.minutes + ":" + timer.seconds,
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                },
            };
            res.status(200).send(response);
        }


    } catch (err) {
        console.log(err, "Error in invoiceStatusETH: ", err);
    }
}

const invoiceCronETH = async (invoiceUser) => {
    try {


        var balance = web3eth.utils.fromWei(await web3eth.eth.getBalance(invoiceUser.newAccount.accountNumber), "ether");
        balance = Number(balance);

        const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });

        var adminAmount = adminWallet.txFees;

        var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        var merchantRate = 0, merchantAmount = 0, merchantAddress;
        if (merchantFees) {
            merchantFees = merchantFees.feeObject
            for (value of merchantFees) {
                if (value.currency == invoiceUser.currency) {
                    merchantRate = value.rate;
                    merchantAddress = value.address
                    break;
                }
            }
        }

        if (merchantRate > 0) {
            merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6);
        }

        console.log(adminAmount, 'adminAmt', invoiceUser.paidAmount, 'invoiceUser.paidAmount', balance, 'balance')
        var remainingCurrencyAmount = invoiceUser.paidAmount - balance;
        var userAmount = +invoiceUser.paidAmount - +adminAmount - +merchantAmount;

        console.log(remainingCurrencyAmount, 'remainingCurrencyAmount', userAmount, 'userAmount')

        if (remainingCurrencyAmount <= 0) {

            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == invoiceUser.currency) {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            const transReq = await estimateGasForETHTransaction(invoiceUser.newAccount.accountNumber, accountAddress, userAmount);
            console.log(transReq, 'transReq')
            var transactionFee = transReq.txFee;
            var gasPrice = transReq.gasPrice;
            var gasLimit = transReq.gasLimit;
            console.log(transactionFee, gasPrice, gasLimit)
            //if adminFees then calculate txFees for admin as well
            if ((adminAmount > 0) && (merchantAmount > 0)) {
                transactionFee = transactionFee * 3;
            } else if ((adminAmount > 0) || (merchantAmount > 0)) {
                transactionFee = transactionFee * 2;
            }

            //deduct transactionFee from userAmount;
            console.log(userAmount, "before")
            userAmount = userAmount - transactionFee;
            console.log(userAmount, "after")
            if (userAmount > 0) {
                var decryptedPrivateKey = await decryptePrivateKey(
                    invoiceUser.newAccount.privateKey
                );

                if (merchantAmount > 0) {
                    const transaction = await web3eth.eth.accounts.signTransaction(
                        {
                            from: invoiceUser.newAccount.accountNumber,
                            to: merchantAddress,
                            value: web3eth.utils.toWei(merchantAmount.toString(), "ether"),
                            //gasPrice: gasPrice,
                            gas: gasLimit
                        },
                        decryptedPrivateKey
                    );
                    await web3eth.eth.sendSignedTransaction(
                        transaction.rawTransaction
                    );
                }

                //user transaction
                const ETHTransaction = await web3eth.eth.accounts.signTransaction(
                    {
                        from: invoiceUser.newAccount.accountNumber,
                        to: accountAddress,
                        value: web3eth.utils.toWei(userAmount.toString(), "ether"),
                        //gasPrice: gasPrice,
                        gas: gasLimit
                    },
                    decryptedPrivateKey
                );
                var ETHReceipt = await web3eth.eth.sendSignedTransaction(
                    ETHTransaction.rawTransaction
                );
                console.log(
                    `Transaction successful with hash: ${ETHReceipt.transactionHash}`
                );
                var trans = ETHReceipt.transactionHash;
                ETHReceipt.amount = userAmount;
                ETHReceipt.timestamp = Date.now();
                await Invoice.updateOne(
                    { _id: invoiceUser._id },
                    { cold_trans_done: true }
                );
                var new_task = new InvoiceTransaction({
                    paymentId: invoiceUser._id,
                    paidAmount: invoiceUser.paidAmount,
                    Transaction: ETHReceipt,
                });
                new_task.save();


                //console.log(adminWallet[0].walletAddress, adminWallet[0].txFees, decryptedPrivateKey,'9jg')
                if (adminAmount > 0) {
                    console.log('adminfees')
                    const adminETHTransaction =
                        await web3eth.eth.accounts.signTransaction(
                            {
                                from: invoiceUser.newAccount.accountNumber,
                                to: adminWallet.walletAddress,
                                value: web3eth.utils.toWei(adminAmount.toString(), "ether"),
                                //gasPrice: gasPrice,
                                gas: gasLimit
                            },
                            decryptedPrivateKey
                        );

                    var adminETHReceipt = await web3eth.eth.sendSignedTransaction(adminETHTransaction.rawTransaction);

                    await InvoiceTransaction.updateOne(
                        { paymentId: invoiceUser._id },
                        { adminTransaction: adminETHReceipt }
                    );
                    console.log(`admin Transaction successful with hash: ${adminETHReceipt.transactionHash
                        }`);
                }

                var formattedTime = Date.now();
                const transactionId = ETHReceipt.transactionHash;
                var emailProvider, companyName, domain
                if (invoiceUser.emailProvider) {
                    emailProvider = invoiceUser.emailProvider;
                    companyName = invoiceUser.companyName;
                    domain = invoiceUser.domain
                }
                var link = `https://${process.env.eth_explorer_url}/tx/${transactionId}`
                const emailBody = {
                    email: invoiceUser.email,
                    firstName: "User",
                    amount: invoiceUser.paidAmount,
                    currency: invoiceUser.currency,
                    paidfrom: invoiceUser.newAccount.accountNumber,
                    paidto: accountAddress,
                    transactionId,
                    formattedTime,
                    link,
                    emailProvider,
                    apiName: invoiceUser.name,
                    companyName,
                    domain
                };

                await transactionEmail(emailBody);

                var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

                var Merchantobject = {

                    "email": invoiceUser.email,
                    "ip": ip.address(),
                    "txId": trans,
                    "fee": 0,
                    "currency": invoiceUser.currency,
                    "paidFrom": invoiceUser.newAccount.accountNumber,
                    "senderTag": "",
                    "receiverTag": "",
                    "amount": invoiceUser.paidAmount,
                    "usdRate": invoiceUser.rate,
                    "adminFee": adminAmount,
                    "actualamount": invoiceUser.paidAmount,
                    "ordertype": "",
                    "description": "",
                    "status": 1,
                    "transactionType": "MerchantApi",
                    "explorer": link,
                    "userId": user._id,
                    "paidTo": accountAddress,
                    "initiatedDate": formattedTime,
                    "confirmedDate": formattedTime

                }

                await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true });

            }
        }
    } catch (err) {
        console.log('invoiceCronETH error:', err)
    }
}

const refundTransactionETH = async (req, res, id, sender, receiver, privateKey) => {
    try {
        var amount = await getETHBalance(sender);
        const transReq = await estimateGasForETHTransaction(sender, receiver, amount);
        console.log(transReq, 'transReq')
        var transactionFee = transReq.txFee;
        var gasPrice = transReq.gasPrice;
        var gasLimit = transReq.gasLimit;
        console.log(transactionFee, gasPrice, gasLimit)
        //if adminFees then calculate txFees for admin as well

        //deduct transactionFee from userAmount;
        console.log(amount, "before")
        amount = amount - transactionFee;
        console.log(amount, "after")
        var decryptedPrivateKey = await decryptePrivateKey(privateKey);

        //user transaction
        const ETHTransaction = await web3eth.eth.accounts.signTransaction(
            {
                from: sender,
                to: receiver,
                value: web3eth.utils.toWei(amount.toString(), "ether"),
                //gasPrice: gasPrice,
                gas: gasLimit
            },
            decryptedPrivateKey
        );
        var receipt = await web3eth.eth.sendSignedTransaction(
            ETHTransaction.rawTransaction
        );
        console.log(
            `Transaction successful with hash: ${receipt.transactionHash}`
        );
        if (receipt.transactionHash) {
            const refundData = await Refund.findOneAndUpdate({ _id: id }, {
                refund_txid: receipt.transactionHash,
                refundConfirmed: true,
                toAddress:receiver,
                amount:amount.toFixed(6)
            }, { new: true });
            await sendEmail(id);
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "Successful",
                data: {
                    status: "PAID",
                    paymentId: refundData.paymentId,
                    currency: refundData.currency,
                    amount: refundData.amount,
                    address: refundData.toAddress,
                    transactionHash: refundData.refund_txid,
                    transactionHashRedirectURL:`https://${process.env.eth_explorer_url}/tx/` + refundData.refund_txid,
                },
            });
        }
    } catch (err) {
        console.log("refundTransaction error:",err)
        return res.status(500).json({
            code: 500,
            status: "Error",
            message: err.message,
            data: {},
        });
    }
}

const sendEmail = async function (refundId) {

    try {
        const refundData = await Refund.findOne({ _id: refundId });
        const email = refundData.email;
        const currency = refundData.currency;
        const amount = refundData.amount;
        const toAddress = refundData.toAddress;
        const txId = refundData.refund_txid;
        var emailProvider = refundData.emailProvider;
        var apiKey = refundData.apiKey;
        var companyName = refundData.companyName;
        var domain = refundData.domain;

        const emailBody = {
            email,
            currency,
            amount,
            toAddress,
            txId,
            emailProvider,
            apiKey,
            companyName,
            domain
        }
        console.log("mail initiated")
        await refundTransactionMail(emailBody);
        console.log("mail confirmed")
    } catch (err) {
        console.log("Error in sendEmail: ", err)
    }
}

module.exports = {
    createInvoiceETH,
    invoiceStatusETH,
    invoiceCronETH,
    getETHBalance,
    refundTransactionETH
}