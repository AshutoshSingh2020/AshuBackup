const Invoice = require("../../../models/Invoices/invoiceModel");
// const Api = require("../../models/apiModel");
const swapInvoice = require("../../../models/Invoices/invoiceDataModel");

const { invoiceStatusETH } = require('../Ethereum/ETH/eth');
// const { invoiceStatusTRX } = require('./trx');

// const { invoiceStatusBSC } = require('./bsc');
// const { invoiceStatusBTC } = require('./btc');
// const { invoiceStatusERC20 } = require('./erc20');
// const { invoiceStatusBEP20 } = require('./bep20');
// const { invoiceStatusBCH } = require('./bch');
// const { invoiceStatusLTC } = require('./ltc');
// const { invoiceStatusDOGE } = require('./doge');
// const { invoiceStatusTRC20 } = require('./trc20');
// const { invoiceStatusXRP } = require('./xrp');
// const { invoiceStatusMATIC } = require('./matic');
// const { invoiceStatusADA } = require('./ada');
// const { invoiceStatusSOL } = require('./sol');
// const { invoiceStatusSTX } = require('./stx');

// const staticUrl = "https://app.coinuniverze.com";

const getTimeRemaining = async (endtime) => {
    try {
        const total =
            Date.parse(endtime) -
            Date.parse(
                new Date().toLocaleString("en-US", { timeZone: "Asia/Singapore" })
            );
        const seconds = Math.floor((total / 1000) % 60).toLocaleString("en-US", {
            minimumIntegerDigits: 2,
            useGrouping: false,
        });
        const minutes = Math.floor((total / 1000 / 60) % 60).toLocaleString(
            "en-US",
            { minimumIntegerDigits: 2, useGrouping: false }
        );
        const hours = Math.floor((total / (1000 * 60 * 60)) % 24).toLocaleString(
            "en-US",
            { minimumIntegerDigits: 2, useGrouping: false }
        );
        const days = Math.floor(total / (1000 * 60 * 60 * 24));
        return { total, days, hours, minutes, seconds };
    } catch (err) {
        console.log("gettimeRemaining Error: ", err);
    }
};

const publicInvoiceStatus = async (req, res, next) => {
    try {
        const { id } = req.body;

        if (!id) {
            return res.status(400).json({
                code: 400,
                status: "Fail",
                message: "Fill required details",
                data: {},
            });
        }

        if (id.substring(0, 4) == "SWA4") {
            console.log(true)
            const invoiceData = await swapInvoice.find({ paymentId: id });

            if (invoiceData.length == 0) {
                return res.status(400).json({
                    code: 400,
                    status: "Fail",
                    message: "Id not found",
                    data: {},
                });
            }
            const endTime = new Date(invoiceData[0].timeout + 86400000).toLocaleString(
                "en-US",
                {
                    timeZone: "Asia/Singapore",
                }
            );
            const timer = await getTimeRemaining(endTime);

            swapInvokeInvoiceStatus(req, res, invoiceData, timer);

        } else {

            const invoiceUsers = await Invoice.findOne({ _id: id });
            if (!invoiceUsers) {
                return res.status(400).json({
                    code: 400,
                    status: "Fail",
                    message: "Id not found",
                    data: {},
                });
            }

            var expireTime = invoiceUsers.timestamp + 14400000 < Date.now();
            console.log('invoiceUsers.cold_trans_done', invoiceUsers.cold_trans_done);
            if (invoiceUsers.cold_trans_done == true) {

                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        paymentStatus: "PAID",
                        paymentId: invoiceUsers._id,
                        emailAddress: invoiceUsers.email,
                        name: invoiceUsers.name,
                        usdAmount: invoiceUsers.usdAmount,
                        totalRemainingAmount: 0,
                        currency: invoiceUsers.currency,
                        totalAmount: invoiceUsers.paidAmount,
                        totalReceivedAmount: invoiceUsers.paidAmount,
                        conversionRate: invoiceUsers.rate,
                        address: invoiceUsers.newAccount.accountNumber,
                        remainingTime: "00:00:00", 
                        paymentQRCode: invoiceUsers.newAccount.accountNumber,
                    },
                });
            } else if (expireTime) {
                return res.status(200).json({
                    code: 200,
                    status: "OK",
                    message: "successful",
                    data: {
                        paymentStatus: "EXPIRED",
                        paymentId: invoiceUsers._id,
                        emailAddress: invoiceUsers.email,
                        name: invoiceUsers.name,
                        usdAmount: invoiceUsers.usdAmount,
                        totalRemainingAmount: 0,
                        currency: invoiceUsers.currency,
                        totalAmount: invoiceUsers.paidAmount,
                        totalReceivedAmount: 0,
                        conversionRate: invoiceUsers.rate,
                        address: invoiceUsers.newAccount.accountNumber,
                        remainingTime: "00:00:00",
                        paymentQRCode: invoiceUsers.newAccount.accountNumber,
                    },
                });
            } else {
                const endTime = new Date(invoiceUsers.timeout + 14400000).toLocaleString(
                    "en-US",
                    {
                        timeZone: "Asia/Singapore",
                    }
                );
                const timer = await getTimeRemaining(endTime);
                switch (invoiceUsers.currency) {
                    // case "TRX":
                    //     await invoiceStatusTRX(req, res, invoiceUsers, timer)
                    //     break;
                    case "ETH":
                        await invoiceStatusETH(req, res, invoiceUsers, timer)
                        break;
                    // case "BSC":
                    //     await invoiceStatusBSC(req, res, invoiceUsers, timer)
                    //     break;
                    // case "BTC":
                    //     await invoiceStatusBTC(req, res, invoiceUsers, timer)
                    //     break;
                    // case "SHIBA_ERC20":
                    //     await invoiceStatusERC20(req, res, invoiceUsers, timer)
                    //     break;
                    // case "SUPER_ERC20":
                    //     await invoiceStatusERC20(req, res, invoiceUsers, timer)
                    //     break;
                    // case "SUPER_BEP20":
                    //     await invoiceStatusBEP20(req, res, invoiceUsers, timer)
                    //     break;
                    // case "BCH":
                    //     await invoiceStatusBCH(req, res, invoiceUsers, timer)
                    //     break;
                    // case "LTC":
                    //     await invoiceStatusLTC(req, res, invoiceUsers, timer)
                    //     break;
                    // case "DOGE":
                    //     await invoiceStatusDOGE(req, res, invoiceUsers, timer)
                    //     break;
                    // case "USDT_TRC20":
                    //     await invoiceStatusTRC20(req, res, invoiceUsers, timer)
                    //     break;
                    // case "XRP":
                    //     await invoiceStatusXRP(req, res, invoiceUsers, timer)
                    //     break;
                    // case "MATIC":
                    //     await invoiceStatusMATIC(req, res, invoiceUsers, timer)
                    //     break;
                    // case "ADA":
                    //     await invoiceStatusADA(req, res, invoiceUsers, timer)
                    //     break;
                    // case "SOL":
                    //     await invoiceStatusSOL(req, res, invoiceUsers, timer)
                    //     break;
                    // case "STX":
                    //     await invoiceStatusSTX(req, res, invoiceUsers, timer)
                    //     break;
                    // case "USDT_ERC20":
                    //     await invoiceStatusERC20(req, res, invoiceUsers, timer)
                    //     break;
                    default:
                        return res.status(400).send({
                            code: "400",
                            status: "Not Found",
                            message: "Invalid Currency",
                            data: {},
                        });
                        break;
                }
            }
        }


    } catch (err) {
        console.log("invoiceStatus error:", err)
        return res.status(500).json({
            code: 500,
            status: "Error",
            message: err.message,
            data: {},
        });
    }
};

module.exports = {
    publicInvoiceStatus
}