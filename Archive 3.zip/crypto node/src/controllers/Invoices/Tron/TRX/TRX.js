var mongoose = require("mongoose");
const Invoice = require("../../models/invoiceDataModel");
const InvoiceFee = require("../../models/invoiceFees");
const Api = require("../../models/apiModel");
const Backup = require("../../models/backupModel");
const Acc_Balance = require("../../models/dashboard_balance");
const InvoiceTransaction = require("../../models/Invoice_transactionModel");
const AdminWallet = require("../../models/adminWalletModel");
const users = require("../../models/user.model");
const { transactionEmail } = require("./../../../utils/transactionEmail");
const Transaction_History = mongoose.model("Transaction_History");
const Coinrate = require("../../models/coinRate");
const Refund = require("../../models/confirmRefundModel");
const { refundTransactionMail } = require("../../../utils/refundTransactionMail")
const crypto = require("crypto");
const TronWeb = require("tronweb");
var ip = require("ip");

const HttpProvider = TronWeb.providers.HttpProvider;
const fullNode = new HttpProvider(process.env.tron_first_url);
const solidityNode = new HttpProvider(process.env.tron_second_url);
const eventServer = new HttpProvider(process.env.tron_third_url);
const trxPrivateKey = process.env.trx_transaction_to_address_privKey;
const tronWeb = new TronWeb(fullNode, solidityNode, eventServer, trxPrivateKey);
// const MerchantFees = require("../../models/merchantFees");


const staticUrl = "https://app.coinuniverze.com";

const decryptePrivateKey = (data) => {
    try {
        var encrypted = Buffer.from(data, 'base64');
        var salt_len = 16, iv_len = 16;

        var salt = encrypted.slice(0, salt_len);

        var iv = encrypted.slice(0 + salt_len, salt_len + iv_len);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 256 / 8, 'sha256');

        var decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);

        decipher.write(encrypted.slice(salt_len + iv_len));
        decipher.end();

        const decrypted = decipher.read();
        return decrypted.toString()
    } catch (err) {
        console.log('decryptedPrivateKey Error: ', err)
    }
};

const encryptedPrivateKeys = async (data) => {
    try {

        var salt = crypto.randomBytes(16);
        var iv = crypto.randomBytes(16);
        var key = crypto.pbkdf2Sync(process.env.pepper_for_enc, salt, 100000, 32, 'sha256');
        var cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
        cipher.write(data);
        cipher.end()

        var encrypted = cipher.read();

        return Buffer.concat([salt, iv, encrypted]).toString('base64')
    } catch (err) {
        console.log("encryptedPrivateKeys Error:", err)
    }
};

const getTRXBalance = async (sender) => {
    try {
        const bal = await tronWeb.trx.getBalance(sender);
        const balance = tronWeb.fromSun(bal);
        return balance;
    } catch (err) {
        console.log('TRX balance Error : ', err)
    }
}

const createTRXAccount = async () => {
    try {
        var newAccount = await tronWeb.createAccount();

        var privateKey = await encryptedPrivateKeys(newAccount.privateKey);
        var newAddress = newAccount.address.base58;

        return { privateKey, newAddress };

    } catch (err) {
        console.log("createTRXAccount error:", err)
    }
}

const createInvoiceTRX = async (req, res) => {
    try {
        const { email, cryptoAmount, amount, currency, publicKey } = req.body;

        var invoiceFeeStatus = false;
        var usdAmount, paidAmount;
        const minimumAmount = process.env.TRX_MINIMUM_AMOUNT;
        if (cryptoAmount == true) {
            if (amount < minimumAmount) {
                return res.status(400).send({
                    code: "400",
                    status: "Fail",
                    message: "TRX amount should be greater than ${minimumAmount}",
                    data: {},
                });
            }
        }
        const invoiceFeeData = await InvoiceFee.findOne({ currency: currency });
        if (invoiceFeeData) {
            if (publicKey === invoiceFeeData.publicKey) {
                invoiceFeeStatus = true;
            }
        }

        var Auth = await Api.findOne({ publicKey: publicKey });
        var emailProvider, companyName, domain;
        if (Auth.emailProviderStatus) {
            emailProvider = Auth.emailProvider;
            companyName = Auth.companyName;
            domain = (Auth.website).substring((Auth.website).indexOf('.') + 1)
        }

        var rate = await Coinrate.findOne({});
        rate = rate.usd_rate.TRX;
        

        var account = await createTRXAccount();
        var accountNumber = account.newAddress;
        var privateKey = account.privateKey;
        var newAccount = {
            accountNumber,
            privateKey
        }

        if (cryptoAmount == true) {
            usdAmount = (amount * rate).toFixed(6);
            paidAmount = (amount).toFixed(6);
        } else {
            usdAmount = (amount).toFixed(6);
            paidAmount = (amount / rate).toFixed(6);
        }
        var new_task = {
            email: email,
            cryptoAmount: cryptoAmount,
            amount: amount,
            usdAmount: usdAmount,
            paidAmount: paidAmount,
            name: Auth.keyname,
            currency: currency,
            balance: 0,
            newAccount: newAccount,
            rate: rate.toFixed(6),
            timestamp: Date.now(),
            timeout: Date.now(),
            cold_trans_done: false,
            userEmail: Auth.user_id,
            invoiceFeeStatus: invoiceFeeStatus,
            emailProvider,
            companyName,
            domain,
            refundLink: Auth.refundLink,
            publicKey: publicKey
        };
        const newInvoice = await Invoice.create(new_task);
        console.log(newInvoice, newInvoice._id, newInvoice)
        res.status(200).send({
            code: "200",
            status: "OK",
            message: "Successful",
            data: {
                paymentStatus: "PENDING",
                paymentId: newInvoice._id,
                emailAddress: email,
                name: newInvoice.name,
                usdAmount: usdAmount,
                totalRemainingAmount: paidAmount,
                currency: currency,
                totalAmount: paidAmount,
                totalReceivedAmount: 0,
                conversionRate: rate.toFixed(6),
                address: accountNumber,
                statusUrl: staticUrl + "/#/invoice/" + newInvoice._id,
                remainingTime: "03:59:59",
                paymentQRCode: accountNumber,
                // paymentQRCode: data[0].newAccount.address.base58
            },
        });
    } catch (err) {
        console.log("createInvoiceTRX", err);
    }
};

const invoiceStatusTRX = async (req, res, invoiceUser, timer) => {
    try {

        var trongenieFees = 0;
        var trongenieFeesAddress;
        var balance = tronWeb.fromSun((await tronWeb.trx.getBalance(invoiceUser.newAccount.accountNumber)));
        balance = Number(balance);

        const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });
        if (invoiceUser.invoiceFeeStatus) {
            const invoiceFeeData = await InvoiceFee.findOne({ currency: invoiceUser.currency })
            trongenieFeesAddress = invoiceFeeData.feeAddress;
            trongenieFees = invoiceFeeData.fee;

        }
        var adminAmount = adminWallet.txFees;

        var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        var merchantRate = 0, merchantAmount = 0, merchantAddress;
        if (merchantFees) {
            merchantFees = merchantFees.feeObject
            for (value of merchantFees) {
                if (value.currency == invoiceUser.currency) {
                    merchantRate = value.rate;
                    merchantAddress = value.address
                    break;
                }
            }
        }

        if (merchantRate > 0) {
            merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6)
        }

        var remainingCurrencyAmount = invoiceUser.paidAmount - balance;
        var userAmount = +invoiceUser.paidAmount - +adminAmount - +trongenieFees - +merchantAmount;

        console.log(remainingCurrencyAmount, userAmount, adminAmount)
        if (remainingCurrencyAmount <= 0) {

            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == invoiceUser.currency) {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            var decryptedPrivateKey = await decryptePrivateKey(
                invoiceUser.newAccount.privateKey
            );

            //trongenieFeesAddress transaction
            if (invoiceUser.invoiceFeeStatus) {
                console.log("invoiceFeeTrans")
                await tronWeb.trx.sendTransaction(
                    trongenieFeesAddress,
                    tronWeb.toSun(trongenieFees),
                    decryptedPrivateKey
                )
            }

            //trongenieFeesAddress transaction
            if (merchantAmount > 0) {
                console.log("merchantTrans")
                await tronWeb.trx.sendTransaction(
                    merchantAddress,
                    tronWeb.toSun(merchantAmount),
                    decryptedPrivateKey
                )
            }

            //user transaction
            const trans = await tronWeb.trx.sendTransaction(
                accountAddress,
                tronWeb.toSun(userAmount),
                decryptedPrivateKey
            )
            await Invoice.updateOne(
                { _id: req.body.id },
                { cold_trans_done: true }
            );
            var new_task = new InvoiceTransaction({
                paymentId: req.body.id,
                paidAmount: invoiceUser.paidAmount,
                Transaction: trans,
            });
            new_task.save();
            console.log(`user Transaction successful with hash: ${trans.txid}`);

            //console.log(adminWallet[0].walletAddress, adminWallet[0].txFees, decryptedPrivateKey,'9jg')
            if (adminAmount > 0.4) {
                console.log('adminfees')
                const admin = await tronWeb.trx.sendTransaction(
                    adminWallet.walletAddress,
                    tronWeb.toSun(adminAmount),
                    decryptedPrivateKey
                );

                await InvoiceTransaction.updateOne(
                    { paymentId: req.body.id },
                    { adminTransaction: admin }
                );
                console.log(`admin Transaction successful with hash: ${admin.txid}`);
            }

            var formattedTime = Date.now();
            const transactionId = trans.txid;
            var emailProvider, companyName, domain
            if (invoiceUser.emailProvider) {
                emailProvider = invoiceUser.emailProvider;
                companyName = invoiceUser.companyName;
                domain = invoiceUser.domain
            }
            var link = `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`
            const emailBody = {
                email: invoiceUser.email,
                firstName: "User",
                amount: invoiceUser.paidAmount,
                currency: invoiceUser.currency,
                paidfrom: invoiceUser.newAccount.accountNumber,
                paidto: accountAddress,
                transactionId,
                formattedTime,
                link,
                emailProvider,
                apiName: invoiceUser.name,
                companyName,
                domain
            };

            await transactionEmail(emailBody);

            var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

            var Merchantobject = {

                "email": invoiceUser.email,
                "ip": ip.address(),
                "txId": trans,
                "fee": 0,
                "currency": invoiceUser.currency,
                "paidFrom": invoiceUser.newAccount.accountNumber,
                "senderTag": "",
                "receiverTag": "",
                "amount": invoiceUser.paidAmount,
                "usdRate": invoiceUser.rate,
                "adminFee": adminAmount,
                "otherFees": trongenieFees,
                "actualamount": invoiceUser.paidAmount,
                "ordertype": "",
                "description": "",
                "status": 1,
                "transactionType": "MerchantApi",
                "explorer": `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`,
                "userId": user._id,
                "paidTo": accountAddress,
                "initiatedDate": formattedTime,
                "confirmedDate": formattedTime

            }

            await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true })

            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "successful",
                data: {
                    paymentStatus: "PAID",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: 0,
                    currency: invoiceUser.currency,
                    totalAmount: invoiceUser.paidAmount,
                    totalReceivedAmount: invoiceUser.paidAmount,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                    statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                    remainingTime: "00:00:00",
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                },
            });

        } else {
            var response = {
                code: "200",
                status: "OK",
                message: "Successful",
                data: {
                    paymentStatus: "PENDING",
                    paymentId: invoiceUser._id,
                    emailAddress: invoiceUser.email,
                    name: invoiceUser.name,
                    usdAmount: invoiceUser.usdAmount,
                    totalRemainingAmount: remainingCurrencyAmount,
                    currency: invoiceUser.currency,
                    totalAmount: invoiceUser.paidAmount,
                    totalReceivedAmount: balance,
                    conversionRate: invoiceUser.rate,
                    address: invoiceUser.newAccount.accountNumber,
                    statusUrl: staticUrl + "/#/invoice/" + invoiceUser._id,
                    remainingTime:
                        timer.hours + ":" + timer.minutes + ":" + timer.seconds,
                    paymentQRCode: invoiceUser.newAccount.accountNumber,
                },
            };
            res.status(200).send(response);
        }


    } catch (err) {
        console.log(err, "Error in invoiceStatusTRX: ", err);
    }
}

const invoiceCronTRX = async (invoiceUser) => {
    try {

        var trongenieFees = 0;
        var trongenieFeesAddress;
        var balance = tronWeb.fromSun((await tronWeb.trx.getBalance(invoiceUser.newAccount.accountNumber)));
        balance = Number(balance);

        const adminWallet = await AdminWallet.findOne({ currency: invoiceUser.currency });
        if (invoiceUser.invoiceFeeStatus) {
            const invoiceFeeData = await InvoiceFee.findOne({ currency: invoiceUser.currency })
            trongenieFeesAddress = invoiceFeeData.feeAddress;
            trongenieFees = invoiceFeeData.fee;

        }
        var adminAmount = adminWallet.txFees;

        var merchantFees = await MerchantFees.findOne({ publicKey: invoiceUser.publicKey });
        var merchantRate = 0, merchantAmount = 0, merchantAddress;
        if (merchantFees) {
            merchantFees = merchantFees.feeObject
            for (value of merchantFees) {
                if (value.currency == invoiceUser.currency) {
                    merchantRate = value.rate;
                    merchantAddress = value.address
                    break;
                }
            }
        }

        if (merchantRate > 0) {
            merchantAmount = Number(invoiceUser.paidAmount * merchantRate / 100).toFixed(6)
        }

        var remainingCurrencyAmount = invoiceUser.paidAmount - balance;
        var userAmount = +invoiceUser.paidAmount - +adminAmount - +trongenieFees - +merchantAmount;

        console.log(remainingCurrencyAmount, userAmount, adminAmount)
        if (remainingCurrencyAmount <= 0) {

            var accountAddress = await Acc_Balance.findOne({ email: invoiceUser.userEmail })
            accountAddress = accountAddress.accounts;
            for (var i = 0; i < accountAddress.length; i++) {
                if (accountAddress[i].symbol == invoiceUser.currency) {
                    accountAddress = accountAddress[i].account_number;
                    break;
                }
            }

            var decryptedPrivateKey = await decryptePrivateKey(
                invoiceUser.newAccount.privateKey
            );

            //trongenieFeesAddress transaction
            if (invoiceUser.invoiceFeeStatus) {
                console.log("invoiceFeeTrans")
                await tronWeb.trx.sendTransaction(
                    trongenieFeesAddress,
                    tronWeb.toSun(trongenieFees),
                    decryptedPrivateKey
                )
            }

            if(merchantAmount > 0){
                console.log('merchantTrans');
                await tronWeb.trx.sendTransaction(
                    merchantAddress,
                    tronWeb.toSun(merchantAmount),
                    decryptedPrivateKey
                )
            }

            //user transaction
            const trans = await tronWeb.trx.sendTransaction(
                accountAddress,
                tronWeb.toSun(userAmount),
                decryptedPrivateKey
            )
            await Invoice.updateOne(
                { _id: invoiceUser._id },
                { cold_trans_done: true }
            );
            var new_task = new InvoiceTransaction({
                paymentId: invoiceUser._id,
                paidAmount: invoiceUser.paidAmount,
                Transaction: trans,
            });
            new_task.save();
            console.log(`user Transaction successful with hash: ${trans.txid}`);

            //console.log(adminWallet[0].walletAddress, adminWallet[0].txFees, decryptedPrivateKey,'9jg')
            if (adminAmount > 0.4) {
                console.log('adminfees')
                const admin = await tronWeb.trx.sendTransaction(
                    adminWallet.walletAddress,
                    tronWeb.toSun(adminAmount),
                    decryptedPrivateKey
                );

                await InvoiceTransaction.updateOne(
                    { paymentId: invoiceUser._id },
                    { adminTransaction: admin }
                );
                console.log(`admin Transaction successful with hash: ${admin.txid}`);
            }

            var formattedTime = Date.now();
            const transactionId = trans.txid;
            var emailProvider, companyName, domain
            if (invoiceUser.emailProvider) {
                emailProvider = invoiceUser.emailProvider;
                companyName = invoiceUser.companyName;
                domain = invoiceUser.domain
            }
            var link = `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`
            const emailBody = {
                email: invoiceUser.email,
                firstName: "User",
                amount: invoiceUser.paidAmount,
                currency: invoiceUser.currency,
                paidfrom: invoiceUser.newAccount.accountNumber,
                paidto: accountAddress,
                transactionId,
                formattedTime,
                link,
                emailProvider,
                apiName: invoiceUser.name,
                companyName,
                domain
            };

            await transactionEmail(emailBody);

            var user = await users.findOne({ email: invoiceUser.userEmail }, { _id: 1 });

            var Merchantobject = {

                "email": invoiceUser.email,
                "ip": ip.address(),
                "txId": trans,
                "fee": 0,
                "currency": invoiceUser.currency,
                "paidFrom": invoiceUser.newAccount.accountNumber,
                "senderTag": "",
                "receiverTag": "",
                "amount": invoiceUser.paidAmount,
                "usdRate": invoiceUser.rate,
                "adminFee": adminAmount,
                "otherFees": trongenieFees,
                "actualamount": invoiceUser.paidAmount,
                "ordertype": "",
                "description": "",
                "status": 1,
                "transactionType": "MerchantApi",
                "explorer": `https://${process.env.tron_explorer_url}/#/transaction/${transactionId}`,
                "userId": user._id,
                "paidTo": accountAddress,
                "initiatedDate": formattedTime,
                "confirmedDate": formattedTime

            }

            await Transaction_History.findOneAndUpdate({ user_id: user._id }, { $push: { Merchant: Merchantobject } }, { upsert: true });

        }
    } catch (err) {
        console.log(err, "Error in invoiceCronTRX: ", err);
    }
}

const refundTransactionTRX = async (req, res, id, sender, receiver, privateKey) => {
    try {
        var amount = await getTRXBalance(sender);

        var decryptedPrivateKey = await decryptePrivateKey(privateKey);

        //user transaction
        var receipt = await tronWeb.trx.sendTransaction(
            receiver,
            tronWeb.toSun(amount),
            decryptedPrivateKey
        )
        console.log(
            `Transaction successful with hash: ${receipt.txid}`
        );
        if (receipt.txid) {
            const refundData = await Refund.findOneAndUpdate({ _id: id }, {
                refund_txid: receipt.txid,
                refundConfirmed: true,
                toAddress: receiver,
                amount: amount.toFixed(6)
            }, { new: true });
            await sendEmail(id);
            return res.status(200).json({
                code: 200,
                status: "OK",
                message: "Successful",
                data: {
                    status: "PAID",
                    paymentId: refundData.paymentId,
                    currency: refundData.currency,
                    amount: refundData.amount,
                    address: refundData.toAddress,
                    transactionHash: refundData.refund_txid,
                    transactionHashRedirectURL: `https://${process.env.tron_explorer_url}/#/transaction/` + refundData.refund_txid,
                },
            });
        }
    } catch (err) {
        console.log("refundTransaction error:", err)
        return res.status(500).json({
            code: 500,
            status: "Error",
            message: err.message,
            data: {},
        });
    }
}

const sendEmail = async function (refundId) {

    try {
        const refundData = await Refund.findOne({ _id: refundId });
        const email = refundData.email;
        const currency = refundData.currency;
        const amount = refundData.amount;
        const toAddress = refundData.toAddress;
        const txId = refundData.refund_txid;
        var emailProvider = refundData.emailProvider;
        var apiKey = refundData.apiKey;
        var companyName = refundData.companyName;
        var domain = refundData.domain;

        const emailBody = {
            email,
            currency,
            amount,
            toAddress,
            txId,
            emailProvider,
            apiKey,
            companyName,
            domain
        }
        console.log("mail initiated")
        await refundTransactionMail(emailBody);
        console.log("mail confirmed")
    } catch (err) {
        console.log("Error in sendEmail: ", err)
    }
}

module.exports = {
    createInvoiceTRX,
    invoiceStatusTRX,
    invoiceCronTRX,
    getTRXBalance,
    refundTransactionTRX
}