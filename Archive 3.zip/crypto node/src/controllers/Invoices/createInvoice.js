// const { createInvoiceTRX } = require("./trx");
const { createInvoiceETH } = require("./Ethereum/ETH/eth");
// const { createInvoiceBSC } = require("./bsc");
// const { createInvoiceTRC20 } = require("./trc20");
// const { createInvoiceBTC } = require('./btc');
// const { createInvoiceDOGE } = require('./doge');
// const { createInvoiceLTC } = require('./ltc');
// const { createInvoiceBCH } = require('./bch');
// const { createInvoiceERC20 } = require('./erc20');
// const { createInvoiceBEP20 } = require('./bep20');
// const { createInvoiceXRP } = require('./xrp');
// const { createInvoiceMATIC } = require('./matic');
// const { createInvoiceADA } = require('./ada');
// const { createInvoiceSOL } = require('./sol');
// const { createInvoiceSTX } = require('./stx');

const createInvoice = async (req, res) => {
  try {
    const { cliendID, email, currency, amount, publicKey, privateKey } = req.body;

    if (!cliendID || !currency || !amount || !email) {
      return res.status(400).send({
        code: "400",
        status: "Fail",
        message: "Fill required details",
        data: [],
      });
    }

    switch (currency) {
      case "ETH":
        await createInvoiceETH(req, res);
        break;
    //   case "TRX":
    //     await createInvoiceTRX(req, res);
    //     break;
    //   case "BSC":
    //     await createInvoiceBSC(req, res);
    //     break;
    //   case "BTC":
    //     await createInvoiceBTC(req, res);
    //     break;
    //   case "DOGE":
    //     await createInvoiceDOGE(req, res);
    //     break;
    //   case "LTC":
    //     await createInvoiceLTC(req, res);
    //     break;
    //   case "BCH":
    //     await createInvoiceBCH(req, res);
    //     break;
    //   case "USDT_TRC20":
    //     await createInvoiceTRC20(req, res);
    //     break;
    //   case "SHIBA_ERC20":
    //     await createInvoiceERC20(req, res);
    //     break;
    //   case "SUPER_ERC20":
    //     await createInvoiceERC20(req, res);
    //     break;
    //   case "SUPER_BEP20":
    //     await createInvoiceBEP20(req, res);
    //     break;
    //   case "XRP":
    //     await createInvoiceXRP(req, res);
    //     break;
    //   case "MATIC":
    //     await createInvoiceMATIC(req, res);
    //     break;
    //   case "ADA":
    //     await createInvoiceADA(req, res);
    //     break;
    //   case "SOL":
    //     await createInvoiceSOL(req, res);
    //     break;
    //   case "STX":
    //     await createInvoiceSTX(req, res);
    //     break;
    //   case "USDT_ERC20":
    //     await createInvoiceERC20(req, res);
    //     break;
      default:
        res.status(400).send({
          code: "400",
          status: "Not Found",
          message: "Invalid Currency",
          data: {},
        });
        break;
    }
  } catch (error) {
    return res.status(500).json({
      code: 500,
      status: "Error",
      message: error.message,
      data: {},
    });
  }
};

module.exports = {
  createInvoice,
};
