const express = require('express');
// const { getUsers, createUser } = require('');
const { createUserRequest } = require('../controllers/users/userController');
const  usdRate  = require('../helpers/coinToUSDRate/usdRate');


const   { cleanBody }   = require('../middleware/requestbody/cleanbody')

const router = express.Router();

// router.route('/')
//     .get(getUsers)      // GET /api/users
//     .post(createUser);   // POST /api/users

router.post("/register",cleanBody, createUserRequest);


router.post("/coinUSDRate", usdRate);



module.exports = router;