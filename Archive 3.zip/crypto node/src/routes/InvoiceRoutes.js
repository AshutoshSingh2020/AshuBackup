const express = require('express');
const  { createInvoice } = require('../controllers/Invoices/createInvoice')
const  {publicInvoiceStatus} = require('../controllers/Invoices/InvoiceStatus/InvoiceStatus')

const router = express.Router();

router.post("/createInvoice", createInvoice);

router.post("/publicInvoiceStatus", publicInvoiceStatus);




module.exports = router;