const express = require('express');
const { usdRate } = require('../helpers/coinToUSDRate/usdRate');
const router = express.Router();

router.post("/coinUSDRate", usdRate);




// module.exports = router;