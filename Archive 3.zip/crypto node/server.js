const express = require('express');
const dotenv = require('dotenv');
const userRoutes = require('./src/routes/userRoutes');
const invoiceRoutes = require('./src/routes/InvoiceRoutes')
const connectDB = require('./src/config/db');
const { errorHandler } = require('./src/middleware/errorMiddleware');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to the database
connectDB();

// Middleware
app.use(express.json()); // Body parser for JSON requests

app.use("/api/v1/user", userRoutes); // This should work now
app.use("/api/v1/invoice", invoiceRoutes); 

// Routes
app.get('/', (req, res) => {
  res.status(200).json({ "message": "server connected Successfully" });
});

// Error Handling Middleware
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});